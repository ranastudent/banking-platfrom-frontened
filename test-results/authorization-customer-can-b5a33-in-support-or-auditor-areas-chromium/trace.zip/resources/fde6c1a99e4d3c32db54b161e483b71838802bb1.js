import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/customer/accounts/pages/AccountDetailsPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Link, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { ArrowLeft, CalendarDays, Copy, CreditCard, Landmark, ShieldCheck, Wallet } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { Button } from "/src/components/ui/Button.tsx";
import { Badge } from "/src/components/ui/Badge.tsx";
import { normalizeApiError } from "/src/lib/api/apiError.ts";
import { useAccount } from "/src/features/customer/accounts/hooks/useAccounts.ts";
const money = (value, code, symbol) => {
  const amount = Number(value);
  return Number.isFinite(amount) ? `${symbol ?? code} ${amount.toLocaleString(void 0, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : `${code} —`;
};
const typeName = (type) => ({ SAVINGS: "Savings Account", CURRENT: "Current Account", FOREIGN_CURRENCY: "Foreign Currency Account" })[type] ?? type;
const dateName = (value) => new Date(value).toLocaleString(void 0, { year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" });
export function AccountDetailsPage() {
  _s();
  const { accountId = "" } = useParams();
  const { data: account, isLoading, isError, error, refetch, isFetching } = useAccount(accountId);
  async function copyNumber() {
    if (!account) return;
    try {
      await navigator.clipboard.writeText(account.accountNumber);
      toast.success("Account number copied");
    } catch {
      toast.error("Could not copy account number");
    }
  }
  if (isLoading) return /* @__PURE__ */ jsxDEV("section", { className: "portal-content", children: /* @__PURE__ */ jsxDEV("div", { className: "account-state", role: "status", children: "Loading account details…" }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
    lineNumber: 26,
    columnNumber: 61
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
    lineNumber: 26,
    columnNumber: 25
  }, this);
  if (isError || !account) return /* @__PURE__ */ jsxDEV("section", { className: "portal-content", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "portal-page-heading", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { className: "eyebrow", children: "CUSTOMER ACCOUNTS" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 27,
          columnNumber: 113
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: "Account Details" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 27,
          columnNumber: 157
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 27,
        columnNumber: 108
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/customer/accounts", className: "account-back-link", children: [
        /* @__PURE__ */ jsxDEV(ArrowLeft, { size: 16 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 27,
          columnNumber: 247
        }, this),
        " Back to accounts"
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 27,
        columnNumber: 187
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
      lineNumber: 27,
      columnNumber: 71
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "account-alert", role: "alert", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: normalizeApiError(error).status === 404 ? "Account not found" : "Unable to load account" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 27,
          columnNumber: 349
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: normalizeApiError(error).message }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 27,
          columnNumber: 456
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 27,
        columnNumber: 344
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", onClick: () => void refetch(), loading: isFetching, children: "Try again" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 27,
        columnNumber: 503
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
      lineNumber: 27,
      columnNumber: 300
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
    lineNumber: 27,
    columnNumber: 35
  }, this);
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content customer-page", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "account-breadcrumb", children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/customer/accounts", children: [
        /* @__PURE__ */ jsxDEV(ArrowLeft, { size: 15 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 30,
          columnNumber: 71
        }, this),
        " My Accounts"
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 30,
        columnNumber: 41
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: "/" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 30,
        columnNumber: 113
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: "Account Details" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 30,
        columnNumber: 127
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
      lineNumber: 30,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "portal-page-heading", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { className: "eyebrow", children: "ACCOUNT OVERVIEW" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 31,
          columnNumber: 47
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: "Account Details" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 31,
          columnNumber: 90
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "muted", children: "View account information and available balances." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 31,
          columnNumber: 114
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 31,
        columnNumber: 42
      }, this),
      /* @__PURE__ */ jsxDEV(Badge, { variant: account.status === "ACTIVE" ? "success" : account.status === "FROZEN" ? "warning" : "danger", children: account.status }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 31,
        columnNumber: 193
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
      lineNumber: 31,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "account-detail-grid", children: [
      /* @__PURE__ */ jsxDEV("article", { className: "account-balance-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "account-balance-card-top", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "account-balance-symbol", children: /* @__PURE__ */ jsxDEV(Landmark, { size: 25 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 33,
            columnNumber: 132
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 33,
            columnNumber: 91
          }, this),
          /* @__PURE__ */ jsxDEV(Badge, { variant: account.status === "ACTIVE" ? "success" : account.status === "FROZEN" ? "warning" : "danger", children: account.status }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 33,
            columnNumber: 161
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 33,
          columnNumber: 49
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "account-balance-type", children: typeName(account.accountType) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 33,
          columnNumber: 301
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "account-number-large", children: [
          account.accountNumber,
          /* @__PURE__ */ jsxDEV("button", { onClick: () => void copyNumber(), "aria-label": "Copy account number", children: /* @__PURE__ */ jsxDEV(Copy, { size: 15 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 33,
            columnNumber: 514
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 33,
            columnNumber: 439
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 33,
          columnNumber: 378
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "account-balance-list", children: account.balances.map((balance) => /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("small", { children: [
            "Available balance · ",
            balance.currency?.name ?? balance.currencyCode
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 33,
            columnNumber: 642
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: money(balance.availableBalance, balance.currencyCode, balance.currency?.symbol) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 33,
            columnNumber: 725
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Locked: ",
            money(balance.lockedBalance, balance.currencyCode, balance.currency?.symbol)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 33,
            columnNumber: 823
          }, this)
        ] }, balance.id, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 33,
          columnNumber: 620
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 33,
          columnNumber: 547
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 33,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card account-information-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "account-section-heading", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { children: "Account Information" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 111
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Verified details from your account record" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 139
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 34,
            columnNumber: 106
          }, this),
          /* @__PURE__ */ jsxDEV(CreditCard, { size: 19 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 34,
            columnNumber: 193
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 34,
          columnNumber: 65
        }, this),
        /* @__PURE__ */ jsxDEV("dl", { className: "account-info-list", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("dt", { children: [
              /* @__PURE__ */ jsxDEV(Wallet, { size: 15 }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
                lineNumber: 34,
                columnNumber: 266
              }, this),
              " Account number"
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 262
            }, this),
            /* @__PURE__ */ jsxDEV("dd", { children: account.accountNumber }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 306
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 34,
            columnNumber: 257
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("dt", { children: [
              /* @__PURE__ */ jsxDEV(Landmark, { size: 15 }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
                lineNumber: 34,
                columnNumber: 353
              }, this),
              " Account type"
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 349
            }, this),
            /* @__PURE__ */ jsxDEV("dd", { children: typeName(account.accountType) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 393
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 34,
            columnNumber: 344
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("dt", { children: [
              /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 15 }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
                lineNumber: 34,
                columnNumber: 448
              }, this),
              " Account status"
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 444
            }, this),
            /* @__PURE__ */ jsxDEV("dd", { children: /* @__PURE__ */ jsxDEV(Badge, { variant: account.status === "ACTIVE" ? "success" : account.status === "FROZEN" ? "warning" : "danger", children: account.status }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 497
            }, this) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 493
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 34,
            columnNumber: 439
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("dt", { children: [
              /* @__PURE__ */ jsxDEV(CalendarDays, { size: 15 }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
                lineNumber: 34,
                columnNumber: 651
              }, this),
              " Opened on"
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 647
            }, this),
            /* @__PURE__ */ jsxDEV("dd", { children: dateName(account.createdAt) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 692
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 34,
            columnNumber: 642
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("dt", { children: [
              /* @__PURE__ */ jsxDEV(CalendarDays, { size: 15 }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
                lineNumber: 34,
                columnNumber: 745
              }, this),
              " Last updated"
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 741
            }, this),
            /* @__PURE__ */ jsxDEV("dd", { children: dateName(account.updatedAt) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
              lineNumber: 34,
              columnNumber: 789
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 34,
            columnNumber: 736
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 34,
          columnNumber: 223
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 34,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
      lineNumber: 32,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card account-balance-breakdown", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "account-section-heading", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Balance Breakdown" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 36,
          columnNumber: 110
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Balances are separated by currency and are never combined." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 36,
          columnNumber: 136
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 36,
        columnNumber: 105
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 36,
        columnNumber: 64
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "account-balance-breakdown-grid", children: account.balances.map((balance) => /* @__PURE__ */ jsxDEV("div", { className: "account-currency-tile", children: [
        /* @__PURE__ */ jsxDEV("span", { children: balance.currency?.name ?? balance.currencyCode }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 36,
          columnNumber: 352
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: money(balance.availableBalance, balance.currencyCode, balance.currency?.symbol) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 36,
          columnNumber: 413
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: "Available balance" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 36,
          columnNumber: 511
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { children: "Locked balance" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 36,
            columnNumber: 548
          }, this),
          /* @__PURE__ */ jsxDEV("b", { children: money(balance.lockedBalance, balance.currencyCode, balance.currency?.symbol) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
            lineNumber: 36,
            columnNumber: 575
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
          lineNumber: 36,
          columnNumber: 543
        }, this)
      ] }, balance.id, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 36,
        columnNumber: 296
      }, this)) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
        lineNumber: 36,
        columnNumber: 213
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
      lineNumber: 36,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "account-disclaimer", children: "This view displays account data returned by the backend. Transaction history and money movement actions will be connected in their dedicated Phase 6 sub-phases." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
      lineNumber: 37,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx",
    lineNumber: 29,
    columnNumber: 10
  }, this);
}
_s(AccountDetailsPage, "+rlZF3Mq/idV5AkVybLJfARV4AM=", false, function() {
  return [useParams, useAccount];
});
_c = AccountDetailsPage;
var _c;
$RefreshReg$(_c, "AccountDetailsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountDetailsPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUI0RDs7QUF6QjVELFNBQVNBLE1BQU1DLGlCQUFpQjtBQUNoQyxTQUFTQyxXQUFXQyxjQUFjQyxNQUFNQyxZQUFZQyxVQUFVQyxhQUFhQyxjQUFjO0FBQ3pGLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsUUFBUUEsQ0FBQ0MsT0FBd0JDLE1BQWNDLFdBQW9CO0FBQ3ZFLFFBQU1DLFNBQVNDLE9BQU9KLEtBQUs7QUFDM0IsU0FBT0ksT0FBT0MsU0FBU0YsTUFBTSxJQUFJLEdBQUdELFVBQVVELElBQUksSUFBSUUsT0FBT0csZUFBZUMsUUFBVSxFQUFDQyx1QkFBc0IsR0FBRUMsdUJBQXNCLEVBQUMsQ0FBQyxDQUFDLEtBQUssR0FBR1IsSUFBSTtBQUN0SjtBQUNBLE1BQU1TLFdBQVdBLENBQUNDLFVBQWtCLEVBQUVDLFNBQVMsbUJBQW1CQyxTQUFTLG1CQUFtQkMsa0JBQWtCLDJCQUEyQixHQUFFSCxJQUFJLEtBQUtBO0FBQ3RKLE1BQU1JLFdBQVdBLENBQUNmLFVBQWtCLElBQUlnQixLQUFLaEIsS0FBSyxFQUFFTSxlQUFlQyxRQUFVLEVBQUNVLE1BQUssV0FBVUMsT0FBTSxTQUFRQyxLQUFJLFdBQVVDLE1BQUssV0FBVUMsUUFBTyxVQUFTLENBQUM7QUFFbEosZ0JBQVNDLHFCQUFxQjtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sRUFBRUMsWUFBWSxHQUFHLElBQUl0QyxVQUFVO0FBQ3JDLFFBQU0sRUFBRXVDLE1BQU1DLFNBQVNDLFdBQVdDLFNBQVNDLE9BQU9DLFNBQVNDLFdBQVcsSUFBSWpDLFdBQVcwQixTQUFTO0FBRTlGLGlCQUFlUSxhQUFhO0FBQzFCLFFBQUksQ0FBQ04sUUFBUztBQUNkLFFBQUk7QUFBRSxZQUFNTyxVQUFVQyxVQUFVQyxVQUFVVCxRQUFRVSxhQUFhO0FBQUcxQyxZQUFNMkMsUUFBUSx1QkFBdUI7QUFBQSxJQUFHLFFBQ3BHO0FBQUUzQyxZQUFNbUMsTUFBTSwrQkFBK0I7QUFBQSxJQUFHO0FBQUEsRUFDeEQ7QUFFQSxNQUFJRixVQUFXLFFBQU8sdUJBQUMsYUFBUSxXQUFVLGtCQUFpQixpQ0FBQyxTQUFJLFdBQVUsaUJBQWdCLE1BQUssVUFBUyx3Q0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFxRSxLQUF6RztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQStHO0FBQ3JJLE1BQUlDLFdBQVcsQ0FBQ0YsUUFBUyxRQUFPLHVCQUFDLGFBQVEsV0FBVSxrQkFBaUI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsdUJBQXNCO0FBQUEsNkJBQUMsU0FBSTtBQUFBLCtCQUFDLE9BQUUsV0FBVSxXQUFVLGlDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFBSSx1QkFBQyxRQUFHLCtCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxXQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlFO0FBQUEsTUFBTSx1QkFBQyxRQUFLLElBQUcsc0JBQXFCLFdBQVUscUJBQW9CO0FBQUEsK0JBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUFFO0FBQUEsV0FBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRztBQUFBLFNBQXZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOE47QUFBQSxJQUFNLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsTUFBSyxTQUFRO0FBQUEsNkJBQUMsU0FBSTtBQUFBLCtCQUFDLFlBQVE3Qiw0QkFBa0JnQyxLQUFLLEVBQUVTLFdBQVcsTUFBTSxzQkFBc0IsNEJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0c7QUFBQSxRQUFTLHVCQUFDLE9BQUd6Qyw0QkFBa0JnQyxLQUFLLEVBQUVVLFdBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxXQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlKO0FBQUEsTUFBTSx1QkFBQyxVQUFPLFNBQVEsV0FBVSxTQUFTLE1BQU0sS0FBS1QsUUFBUSxHQUFHLFNBQVNDLFlBQVkseUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUY7QUFBQSxTQUFsUztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJTO0FBQUEsT0FBbmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeWpCO0FBRXpsQixTQUFPLHVCQUFDLGFBQVEsV0FBVSxnQ0FDeEI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsc0JBQXFCO0FBQUEsNkJBQUMsUUFBSyxJQUFHLHNCQUFxQjtBQUFBLCtCQUFDLGFBQVUsTUFBTSxNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsUUFBRTtBQUFBLFdBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxNQUFPLHVCQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsTUFBTyx1QkFBQyxVQUFLLCtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUI7QUFBQSxTQUE5STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFKO0FBQUEsSUFDckosdUJBQUMsU0FBSSxXQUFVLHVCQUFzQjtBQUFBLDZCQUFDLFNBQUk7QUFBQSwrQkFBQyxPQUFFLFdBQVUsV0FBVSxnQ0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQUksdUJBQUMsUUFBRywrQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CO0FBQUEsUUFBSyx1QkFBQyxPQUFFLFdBQVUsU0FBUSxnRUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRTtBQUFBLFdBQTdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUo7QUFBQSxNQUFNLHVCQUFDLFNBQU0sU0FBU0wsUUFBUVksV0FBVyxXQUFXLFlBQVlaLFFBQVFZLFdBQVcsV0FBVyxZQUFZLFVBQVdaLGtCQUFRWSxVQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThIO0FBQUEsU0FBMVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrVTtBQUFBLElBQ2xVLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLDZCQUFDLGFBQVEsV0FBVSx3QkFBdUI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNEJBQTJCO0FBQUEsaUNBQUMsVUFBSyxXQUFVLDBCQUF5QixpQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUIsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQ7QUFBQSxVQUFPLHVCQUFDLFNBQU0sU0FBU1osUUFBUVksV0FBVyxXQUFXLFlBQVlaLFFBQVFZLFdBQVcsV0FBVyxZQUFZLFVBQVdaLGtCQUFRWSxVQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4SDtBQUFBLGFBQTdPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcVA7QUFBQSxRQUFNLHVCQUFDLFVBQUssV0FBVSx3QkFBd0I1QixtQkFBU2dCLFFBQVFjLFdBQVcsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRTtBQUFBLFFBQU8sdUJBQUMsU0FBSSxXQUFVLHdCQUF3QmQ7QUFBQUEsa0JBQVFVO0FBQUFBLFVBQWMsdUJBQUMsWUFBTyxTQUFTLE1BQU0sS0FBS0osV0FBVyxHQUFHLGNBQVcsdUJBQXNCLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWUsS0FBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEY7QUFBQSxhQUF6SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtLO0FBQUEsUUFBTSx1QkFBQyxTQUFJLFdBQVUsd0JBQXdCTixrQkFBUWUsU0FBU0MsSUFBSSxDQUFDQyxZQUFZLHVCQUFDLFNBQXFCO0FBQUEsaUNBQUMsV0FBTTtBQUFBO0FBQUEsWUFBcUJBLFFBQVFDLFVBQVVDLFFBQVFGLFFBQVFHO0FBQUFBLGVBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFBUSx1QkFBQyxZQUFRL0MsZ0JBQU00QyxRQUFRSSxrQkFBaUJKLFFBQVFHLGNBQWFILFFBQVFDLFVBQVUxQyxNQUFNLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFBUyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxZQUFTSCxNQUFNNEMsUUFBUUssZUFBY0wsUUFBUUcsY0FBYUgsUUFBUUMsVUFBVTFDLE1BQU07QUFBQSxlQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLGFBQXpSeUMsUUFBUU0sSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwUyxDQUFNLEtBQXpYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMlg7QUFBQSxXQUFyNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyNUI7QUFBQSxNQUMzNUIsdUJBQUMsYUFBUSxXQUFVLHdDQUF1QztBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFBMEI7QUFBQSxpQ0FBQyxTQUFJO0FBQUEsbUNBQUMsUUFBRyxtQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QjtBQUFBLFlBQUssdUJBQUMsT0FBRSx5REFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBLGVBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlGO0FBQUEsVUFBTSx1QkFBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUI7QUFBQSxhQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVKO0FBQUEsUUFBTSx1QkFBQyxRQUFHLFdBQVUscUJBQW9CO0FBQUEsaUNBQUMsU0FBSTtBQUFBLG1DQUFDLFFBQUc7QUFBQSxxQ0FBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQjtBQUFBLGNBQUU7QUFBQSxpQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUFLLHVCQUFDLFFBQUl2QixrQkFBUVUsaUJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQSxlQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRjtBQUFBLFVBQU0sdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFFBQUc7QUFBQSxxQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFFO0FBQUEsaUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUEsWUFBSyx1QkFBQyxRQUFJMUIsbUJBQVNnQixRQUFRYyxXQUFXLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1DO0FBQUEsZUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Y7QUFBQSxVQUFNLHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxRQUFHO0FBQUEscUNBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNCO0FBQUEsY0FBRTtBQUFBLGlCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQUssdUJBQUMsUUFBRyxpQ0FBQyxTQUFNLFNBQVNkLFFBQVFZLFdBQVcsV0FBVyxZQUFZWixRQUFRWSxXQUFXLFdBQVcsWUFBWSxVQUFXWixrQkFBUVksVUFBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEgsS0FBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEk7QUFBQSxlQUEvTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvTTtBQUFBLFVBQU0sdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFFBQUc7QUFBQSxxQ0FBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVCO0FBQUEsY0FBRTtBQUFBLGlCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQUssdUJBQUMsUUFBSXZCLG1CQUFTVyxRQUFRd0IsU0FBUyxLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLGVBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFBTSx1QkFBQyxTQUFJO0FBQUEsbUNBQUMsUUFBRztBQUFBLHFDQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUI7QUFBQSxjQUFFO0FBQUEsaUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFBSyx1QkFBQyxRQUFJbkMsbUJBQVNXLFFBQVF5QixTQUFTLEtBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDO0FBQUEsZUFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEY7QUFBQSxhQUF2bEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2bEI7QUFBQSxXQUFwekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5ekI7QUFBQSxTQUYzekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxhQUFRLFdBQVUseUNBQXdDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUEwQixpQ0FBQyxTQUFJO0FBQUEsK0JBQUMsUUFBRyxpQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsUUFBSyx1QkFBQyxPQUFFLDBFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxXQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdHLEtBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0k7QUFBQSxNQUFNLHVCQUFDLFNBQUksV0FBVSxrQ0FBa0N6QixrQkFBUWUsU0FBU0MsSUFBSSxDQUFDQyxZQUFZLHVCQUFDLFNBQUksV0FBVSx5QkFBeUM7QUFBQSwrQkFBQyxVQUFNQSxrQkFBUUMsVUFBVUMsUUFBUUYsUUFBUUcsZ0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUFPLHVCQUFDLFlBQVEvQyxnQkFBTTRDLFFBQVFJLGtCQUFpQkosUUFBUUcsY0FBYUgsUUFBUUMsVUFBVTFDLE1BQU0sS0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFFBQVMsdUJBQUMsV0FBTSxpQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsUUFBUSx1QkFBQyxTQUFJO0FBQUEsaUNBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLFVBQU8sdUJBQUMsT0FBR0gsZ0JBQU00QyxRQUFRSyxlQUFjTCxRQUFRRyxjQUFhSCxRQUFRQyxVQUFVMUMsTUFBTSxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLGFBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxXQUE1VHlDLFFBQVFNLElBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOFcsQ0FBTSxLQUF2YztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXljO0FBQUEsU0FBenBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK3BCO0FBQUEsSUFDL3BCLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsZ0xBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa007QUFBQSxPQVI3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU1A7QUFDRjtBQUFDMUIsR0F2QmVELG9CQUFrQjtBQUFBLFVBQ0xwQyxXQUMrQ1ksVUFBVTtBQUFBO0FBQUEsS0FGdEV3QjtBQUFrQixJQUFBOEI7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTGluayIsInVzZVBhcmFtcyIsIkFycm93TGVmdCIsIkNhbGVuZGFyRGF5cyIsIkNvcHkiLCJDcmVkaXRDYXJkIiwiTGFuZG1hcmsiLCJTaGllbGRDaGVjayIsIldhbGxldCIsInRvYXN0IiwiQnV0dG9uIiwiQmFkZ2UiLCJub3JtYWxpemVBcGlFcnJvciIsInVzZUFjY291bnQiLCJtb25leSIsInZhbHVlIiwiY29kZSIsInN5bWJvbCIsImFtb3VudCIsIk51bWJlciIsImlzRmluaXRlIiwidG9Mb2NhbGVTdHJpbmciLCJ1bmRlZmluZWQiLCJtaW5pbXVtRnJhY3Rpb25EaWdpdHMiLCJtYXhpbXVtRnJhY3Rpb25EaWdpdHMiLCJ0eXBlTmFtZSIsInR5cGUiLCJTQVZJTkdTIiwiQ1VSUkVOVCIsIkZPUkVJR05fQ1VSUkVOQ1kiLCJkYXRlTmFtZSIsIkRhdGUiLCJ5ZWFyIiwibW9udGgiLCJkYXkiLCJob3VyIiwibWludXRlIiwiQWNjb3VudERldGFpbHNQYWdlIiwiX3MiLCJhY2NvdW50SWQiLCJkYXRhIiwiYWNjb3VudCIsImlzTG9hZGluZyIsImlzRXJyb3IiLCJlcnJvciIsInJlZmV0Y2giLCJpc0ZldGNoaW5nIiwiY29weU51bWJlciIsIm5hdmlnYXRvciIsImNsaXBib2FyZCIsIndyaXRlVGV4dCIsImFjY291bnROdW1iZXIiLCJzdWNjZXNzIiwic3RhdHVzIiwibWVzc2FnZSIsImFjY291bnRUeXBlIiwiYmFsYW5jZXMiLCJtYXAiLCJiYWxhbmNlIiwiY3VycmVuY3kiLCJuYW1lIiwiY3VycmVuY3lDb2RlIiwiYXZhaWxhYmxlQmFsYW5jZSIsImxvY2tlZEJhbGFuY2UiLCJpZCIsImNyZWF0ZWRBdCIsInVwZGF0ZWRBdCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFjY291bnREZXRhaWxzUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlUGFyYW1zIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IEFycm93TGVmdCwgQ2FsZW5kYXJEYXlzLCBDb3B5LCBDcmVkaXRDYXJkLCBMYW5kbWFyaywgU2hpZWxkQ2hlY2ssIFdhbGxldCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcInNvbm5lclwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0JhZGdlXCI7XG5pbXBvcnQgeyBub3JtYWxpemVBcGlFcnJvciB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvYXBpL2FwaUVycm9yXCI7XG5pbXBvcnQgeyB1c2VBY2NvdW50IH0gZnJvbSBcIi4uL2hvb2tzL3VzZUFjY291bnRzXCI7XG5cbmNvbnN0IG1vbmV5ID0gKHZhbHVlOiBzdHJpbmcgfCBudW1iZXIsIGNvZGU6IHN0cmluZywgc3ltYm9sPzogc3RyaW5nKSA9PiB7XG4gIGNvbnN0IGFtb3VudCA9IE51bWJlcih2YWx1ZSk7XG4gIHJldHVybiBOdW1iZXIuaXNGaW5pdGUoYW1vdW50KSA/IGAke3N5bWJvbCA/PyBjb2RlfSAke2Ftb3VudC50b0xvY2FsZVN0cmluZyh1bmRlZmluZWQse21pbmltdW1GcmFjdGlvbkRpZ2l0czoyLG1heGltdW1GcmFjdGlvbkRpZ2l0czoyfSl9YCA6IGAke2NvZGV9IOKAlGA7XG59O1xuY29uc3QgdHlwZU5hbWUgPSAodHlwZTogc3RyaW5nKSA9PiAoeyBTQVZJTkdTOiBcIlNhdmluZ3MgQWNjb3VudFwiLCBDVVJSRU5UOiBcIkN1cnJlbnQgQWNjb3VudFwiLCBGT1JFSUdOX0NVUlJFTkNZOiBcIkZvcmVpZ24gQ3VycmVuY3kgQWNjb3VudFwiIH1bdHlwZV0gPz8gdHlwZSk7XG5jb25zdCBkYXRlTmFtZSA9ICh2YWx1ZTogc3RyaW5nKSA9PiBuZXcgRGF0ZSh2YWx1ZSkudG9Mb2NhbGVTdHJpbmcodW5kZWZpbmVkLHt5ZWFyOlwibnVtZXJpY1wiLG1vbnRoOlwic2hvcnRcIixkYXk6XCIyLWRpZ2l0XCIsaG91cjpcIjItZGlnaXRcIixtaW51dGU6XCIyLWRpZ2l0XCJ9KTtcblxuZXhwb3J0IGZ1bmN0aW9uIEFjY291bnREZXRhaWxzUGFnZSgpIHtcbiAgY29uc3QgeyBhY2NvdW50SWQgPSBcIlwiIH0gPSB1c2VQYXJhbXMoKTtcbiAgY29uc3QgeyBkYXRhOiBhY2NvdW50LCBpc0xvYWRpbmcsIGlzRXJyb3IsIGVycm9yLCByZWZldGNoLCBpc0ZldGNoaW5nIH0gPSB1c2VBY2NvdW50KGFjY291bnRJZCk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gY29weU51bWJlcigpIHtcbiAgICBpZiAoIWFjY291bnQpIHJldHVybjtcbiAgICB0cnkgeyBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChhY2NvdW50LmFjY291bnROdW1iZXIpOyB0b2FzdC5zdWNjZXNzKFwiQWNjb3VudCBudW1iZXIgY29waWVkXCIpOyB9XG4gICAgY2F0Y2ggeyB0b2FzdC5lcnJvcihcIkNvdWxkIG5vdCBjb3B5IGFjY291bnQgbnVtYmVyXCIpOyB9XG4gIH1cblxuICBpZiAoaXNMb2FkaW5nKSByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9ydGFsLWNvbnRlbnRcIj48ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtc3RhdGVcIiByb2xlPVwic3RhdHVzXCI+TG9hZGluZyBhY2NvdW50IGRldGFpbHPigKY8L2Rpdj48L3NlY3Rpb24+O1xuICBpZiAoaXNFcnJvciB8fCAhYWNjb3VudCkgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvcnRhbC1jb250ZW50XCI+PGRpdiBjbGFzc05hbWU9XCJwb3J0YWwtcGFnZS1oZWFkaW5nXCI+PGRpdj48cCBjbGFzc05hbWU9XCJleWVicm93XCI+Q1VTVE9NRVIgQUNDT1VOVFM8L3A+PGgxPkFjY291bnQgRGV0YWlsczwvaDE+PC9kaXY+PExpbmsgdG89XCIvY3VzdG9tZXIvYWNjb3VudHNcIiBjbGFzc05hbWU9XCJhY2NvdW50LWJhY2stbGlua1wiPjxBcnJvd0xlZnQgc2l6ZT17MTZ9Lz4gQmFjayB0byBhY2NvdW50czwvTGluaz48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtYWxlcnRcIiByb2xlPVwiYWxlcnRcIj48ZGl2PjxzdHJvbmc+e25vcm1hbGl6ZUFwaUVycm9yKGVycm9yKS5zdGF0dXMgPT09IDQwNCA/IFwiQWNjb3VudCBub3QgZm91bmRcIiA6IFwiVW5hYmxlIHRvIGxvYWQgYWNjb3VudFwifTwvc3Ryb25nPjxwPntub3JtYWxpemVBcGlFcnJvcihlcnJvcikubWVzc2FnZX08L3A+PC9kaXY+PEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IHZvaWQgcmVmZXRjaCgpfSBsb2FkaW5nPXtpc0ZldGNoaW5nfT5UcnkgYWdhaW48L0J1dHRvbj48L2Rpdj48L3NlY3Rpb24+O1xuXG4gIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJwb3J0YWwtY29udGVudCBjdXN0b21lci1wYWdlXCI+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LWJyZWFkY3J1bWJcIj48TGluayB0bz1cIi9jdXN0b21lci9hY2NvdW50c1wiPjxBcnJvd0xlZnQgc2l6ZT17MTV9Lz4gTXkgQWNjb3VudHM8L0xpbms+PHNwYW4+Lzwvc3Bhbj48c3Bhbj5BY2NvdW50IERldGFpbHM8L3NwYW4+PC9kaXY+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJwb3J0YWwtcGFnZS1oZWFkaW5nXCI+PGRpdj48cCBjbGFzc05hbWU9XCJleWVicm93XCI+QUNDT1VOVCBPVkVSVklFVzwvcD48aDE+QWNjb3VudCBEZXRhaWxzPC9oMT48cCBjbGFzc05hbWU9XCJtdXRlZFwiPlZpZXcgYWNjb3VudCBpbmZvcm1hdGlvbiBhbmQgYXZhaWxhYmxlIGJhbGFuY2VzLjwvcD48L2Rpdj48QmFkZ2UgdmFyaWFudD17YWNjb3VudC5zdGF0dXMgPT09IFwiQUNUSVZFXCIgPyBcInN1Y2Nlc3NcIiA6IGFjY291bnQuc3RhdHVzID09PSBcIkZST1pFTlwiID8gXCJ3YXJuaW5nXCIgOiBcImRhbmdlclwifT57YWNjb3VudC5zdGF0dXN9PC9CYWRnZT48L2Rpdj5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtZGV0YWlsLWdyaWRcIj5cbiAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cImFjY291bnQtYmFsYW5jZS1jYXJkXCI+PGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LWJhbGFuY2UtY2FyZC10b3BcIj48c3BhbiBjbGFzc05hbWU9XCJhY2NvdW50LWJhbGFuY2Utc3ltYm9sXCI+PExhbmRtYXJrIHNpemU9ezI1fS8+PC9zcGFuPjxCYWRnZSB2YXJpYW50PXthY2NvdW50LnN0YXR1cyA9PT0gXCJBQ1RJVkVcIiA/IFwic3VjY2Vzc1wiIDogYWNjb3VudC5zdGF0dXMgPT09IFwiRlJPWkVOXCIgPyBcIndhcm5pbmdcIiA6IFwiZGFuZ2VyXCJ9PnthY2NvdW50LnN0YXR1c308L0JhZGdlPjwvZGl2PjxzcGFuIGNsYXNzTmFtZT1cImFjY291bnQtYmFsYW5jZS10eXBlXCI+e3R5cGVOYW1lKGFjY291bnQuYWNjb3VudFR5cGUpfTwvc3Bhbj48ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtbnVtYmVyLWxhcmdlXCI+e2FjY291bnQuYWNjb3VudE51bWJlcn08YnV0dG9uIG9uQ2xpY2s9eygpID0+IHZvaWQgY29weU51bWJlcigpfSBhcmlhLWxhYmVsPVwiQ29weSBhY2NvdW50IG51bWJlclwiPjxDb3B5IHNpemU9ezE1fS8+PC9idXR0b24+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LWJhbGFuY2UtbGlzdFwiPnthY2NvdW50LmJhbGFuY2VzLm1hcCgoYmFsYW5jZSkgPT4gPGRpdiBrZXk9e2JhbGFuY2UuaWR9PjxzbWFsbD5BdmFpbGFibGUgYmFsYW5jZSDCtyB7YmFsYW5jZS5jdXJyZW5jeT8ubmFtZSA/PyBiYWxhbmNlLmN1cnJlbmN5Q29kZX08L3NtYWxsPjxzdHJvbmc+e21vbmV5KGJhbGFuY2UuYXZhaWxhYmxlQmFsYW5jZSxiYWxhbmNlLmN1cnJlbmN5Q29kZSxiYWxhbmNlLmN1cnJlbmN5Py5zeW1ib2wpfTwvc3Ryb25nPjxzcGFuPkxvY2tlZDoge21vbmV5KGJhbGFuY2UubG9ja2VkQmFsYW5jZSxiYWxhbmNlLmN1cnJlbmN5Q29kZSxiYWxhbmNlLmN1cnJlbmN5Py5zeW1ib2wpfTwvc3Bhbj48L2Rpdj4pfTwvZGl2PjwvYXJ0aWNsZT5cbiAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIGFjY291bnQtaW5mb3JtYXRpb24tY2FyZFwiPjxkaXYgY2xhc3NOYW1lPVwiYWNjb3VudC1zZWN0aW9uLWhlYWRpbmdcIj48ZGl2PjxoMj5BY2NvdW50IEluZm9ybWF0aW9uPC9oMj48cD5WZXJpZmllZCBkZXRhaWxzIGZyb20geW91ciBhY2NvdW50IHJlY29yZDwvcD48L2Rpdj48Q3JlZGl0Q2FyZCBzaXplPXsxOX0vPjwvZGl2PjxkbCBjbGFzc05hbWU9XCJhY2NvdW50LWluZm8tbGlzdFwiPjxkaXY+PGR0PjxXYWxsZXQgc2l6ZT17MTV9Lz4gQWNjb3VudCBudW1iZXI8L2R0PjxkZD57YWNjb3VudC5hY2NvdW50TnVtYmVyfTwvZGQ+PC9kaXY+PGRpdj48ZHQ+PExhbmRtYXJrIHNpemU9ezE1fS8+IEFjY291bnQgdHlwZTwvZHQ+PGRkPnt0eXBlTmFtZShhY2NvdW50LmFjY291bnRUeXBlKX08L2RkPjwvZGl2PjxkaXY+PGR0PjxTaGllbGRDaGVjayBzaXplPXsxNX0vPiBBY2NvdW50IHN0YXR1czwvZHQ+PGRkPjxCYWRnZSB2YXJpYW50PXthY2NvdW50LnN0YXR1cyA9PT0gXCJBQ1RJVkVcIiA/IFwic3VjY2Vzc1wiIDogYWNjb3VudC5zdGF0dXMgPT09IFwiRlJPWkVOXCIgPyBcIndhcm5pbmdcIiA6IFwiZGFuZ2VyXCJ9PnthY2NvdW50LnN0YXR1c308L0JhZGdlPjwvZGQ+PC9kaXY+PGRpdj48ZHQ+PENhbGVuZGFyRGF5cyBzaXplPXsxNX0vPiBPcGVuZWQgb248L2R0PjxkZD57ZGF0ZU5hbWUoYWNjb3VudC5jcmVhdGVkQXQpfTwvZGQ+PC9kaXY+PGRpdj48ZHQ+PENhbGVuZGFyRGF5cyBzaXplPXsxNX0vPiBMYXN0IHVwZGF0ZWQ8L2R0PjxkZD57ZGF0ZU5hbWUoYWNjb3VudC51cGRhdGVkQXQpfTwvZGQ+PC9kaXY+PC9kbD48L2FydGljbGU+XG4gICAgPC9kaXY+XG4gICAgPGFydGljbGUgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQgYWNjb3VudC1iYWxhbmNlLWJyZWFrZG93blwiPjxkaXYgY2xhc3NOYW1lPVwiYWNjb3VudC1zZWN0aW9uLWhlYWRpbmdcIj48ZGl2PjxoMj5CYWxhbmNlIEJyZWFrZG93bjwvaDI+PHA+QmFsYW5jZXMgYXJlIHNlcGFyYXRlZCBieSBjdXJyZW5jeSBhbmQgYXJlIG5ldmVyIGNvbWJpbmVkLjwvcD48L2Rpdj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtYmFsYW5jZS1icmVha2Rvd24tZ3JpZFwiPnthY2NvdW50LmJhbGFuY2VzLm1hcCgoYmFsYW5jZSkgPT4gPGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LWN1cnJlbmN5LXRpbGVcIiBrZXk9e2JhbGFuY2UuaWR9PjxzcGFuPntiYWxhbmNlLmN1cnJlbmN5Py5uYW1lID8/IGJhbGFuY2UuY3VycmVuY3lDb2RlfTwvc3Bhbj48c3Ryb25nPnttb25leShiYWxhbmNlLmF2YWlsYWJsZUJhbGFuY2UsYmFsYW5jZS5jdXJyZW5jeUNvZGUsYmFsYW5jZS5jdXJyZW5jeT8uc3ltYm9sKX08L3N0cm9uZz48c21hbGw+QXZhaWxhYmxlIGJhbGFuY2U8L3NtYWxsPjxkaXY+PHNwYW4+TG9ja2VkIGJhbGFuY2U8L3NwYW4+PGI+e21vbmV5KGJhbGFuY2UubG9ja2VkQmFsYW5jZSxiYWxhbmNlLmN1cnJlbmN5Q29kZSxiYWxhbmNlLmN1cnJlbmN5Py5zeW1ib2wpfTwvYj48L2Rpdj48L2Rpdj4pfTwvZGl2PjwvYXJ0aWNsZT5cbiAgICA8cCBjbGFzc05hbWU9XCJhY2NvdW50LWRpc2NsYWltZXJcIj5UaGlzIHZpZXcgZGlzcGxheXMgYWNjb3VudCBkYXRhIHJldHVybmVkIGJ5IHRoZSBiYWNrZW5kLiBUcmFuc2FjdGlvbiBoaXN0b3J5IGFuZCBtb25leSBtb3ZlbWVudCBhY3Rpb25zIHdpbGwgYmUgY29ubmVjdGVkIGluIHRoZWlyIGRlZGljYXRlZCBQaGFzZSA2IHN1Yi1waGFzZXMuPC9wPlxuICA8L3NlY3Rpb24+O1xufVxuIl0sImZpbGUiOiJEOi9OZXdfZm9sZGVyXygyKS9Tb2Z0d2FyZSBkZXZlbG9wbWVudCBQcm9qZWN0L2JhbmtpbmctcGxhdGZyb20vZnJvbnRlbmQvYmFua2luZy1wbGF0Zm9ybS1mcm9udGVuZC9zcmMvZmVhdHVyZXMvY3VzdG9tZXIvYWNjb3VudHMvcGFnZXMvQWNjb3VudERldGFpbHNQYWdlLnRzeCJ9