import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/providers/AuthProvider.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const createContext = __vite__cjsImport1_react["createContext"]; const useCallback = __vite__cjsImport1_react["useCallback"]; const useContext = __vite__cjsImport1_react["useContext"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];
import { authApi } from "/src/features/auth/authApi.ts";
import { tokenStorage } from "/src/lib/api/tokenStorage.ts";
const AuthContext = createContext(void 0);
export function AuthProvider({ children }) {
  _s();
  const [user, setUser] = useState(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const refreshUser = useCallback(async () => {
    const current = await authApi.me();
    setUser(current);
  }, []);
  useEffect(() => {
    let active = true;
    const initialize = async () => {
      if (!tokenStorage.getAccessToken() && !tokenStorage.getRefreshToken()) {
        if (active) setIsInitializing(false);
        return;
      }
      try {
        const current = await authApi.me();
        if (active) setUser(current);
      } catch {
        if (active) setUser(null);
      } finally {
        if (active) setIsInitializing(false);
      }
    };
    const onExpired = () => setUser(null);
    window.addEventListener("banking:session-expired", onExpired);
    void initialize();
    return () => {
      active = false;
      window.removeEventListener("banking:session-expired", onExpired);
    };
  }, []);
  const login = useCallback(async (payload) => {
    const result = await authApi.login(payload);
    setUser(result.user);
    return result.user;
  }, []);
  const register = useCallback((payload) => authApi.register(payload), []);
  const verifyEmail = useCallback((payload) => authApi.verifyEmail(payload), []);
  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } finally {
      setUser(null);
    }
  }, []);
  const value = useMemo(() => ({
    user,
    isAuthenticated: Boolean(user),
    isInitializing,
    login,
    register,
    verifyEmail,
    logout,
    refreshUser
  }), [user, isInitializing, login, register, verifyEmail, logout, refreshUser]);
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { value, children }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/providers/AuthProvider.tsx",
    lineNumber: 72,
    columnNumber: 10
  }, this);
}
_s(AuthProvider, "n88dA3wsL/Fpc7wemfUeaBhNEIg=");
_c = AuthProvider;
export function useAuth() {
  _s2();
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
}
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/providers/AuthProvider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/providers/AuthProvider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/providers/AuthProvider.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUVTOztBQXZFVCxTQUFTQSxlQUFlQyxhQUFhQyxZQUFZQyxXQUFXQyxTQUFTQyxnQkFBZ0I7QUFFckYsU0FBU0MsZUFBZTtBQUV4QixTQUFTQyxvQkFBb0I7QUFZN0IsTUFBTUMsY0FBY1IsY0FBNENTLE1BQVM7QUFFbEUsZ0JBQVNDLGFBQWEsRUFBRUMsU0FBa0MsR0FBRztBQUFBQyxLQUFBO0FBQ2xFLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJVCxTQUEwQixJQUFJO0FBQ3RELFFBQU0sQ0FBQ1UsZ0JBQWdCQyxpQkFBaUIsSUFBSVgsU0FBUyxJQUFJO0FBRXpELFFBQU1ZLGNBQWNoQixZQUFZLFlBQVk7QUFDMUMsVUFBTWlCLFVBQVUsTUFBTVosUUFBUWEsR0FBRztBQUNqQ0wsWUFBUUksT0FBTztBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMZixZQUFVLE1BQU07QUFDZCxRQUFJaUIsU0FBUztBQUNiLFVBQU1DLGFBQWEsWUFBWTtBQUM3QixVQUFJLENBQUNkLGFBQWFlLGVBQWUsS0FBSyxDQUFDZixhQUFhZ0IsZ0JBQWdCLEdBQUc7QUFDckUsWUFBSUgsT0FBUUosbUJBQWtCLEtBQUs7QUFDbkM7QUFBQSxNQUNGO0FBQ0EsVUFBSTtBQUNGLGNBQU1FLFVBQVUsTUFBTVosUUFBUWEsR0FBRztBQUNqQyxZQUFJQyxPQUFRTixTQUFRSSxPQUFPO0FBQUEsTUFDN0IsUUFBUTtBQUNOLFlBQUlFLE9BQVFOLFNBQVEsSUFBSTtBQUFBLE1BQzFCLFVBQUM7QUFDQyxZQUFJTSxPQUFRSixtQkFBa0IsS0FBSztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU1RLFlBQVlBLE1BQU1WLFFBQVEsSUFBSTtBQUNwQ1csV0FBT0MsaUJBQWlCLDJCQUEyQkYsU0FBUztBQUM1RCxTQUFLSCxXQUFXO0FBQ2hCLFdBQU8sTUFBTTtBQUNYRCxlQUFTO0FBQ1RLLGFBQU9FLG9CQUFvQiwyQkFBMkJILFNBQVM7QUFBQSxJQUNqRTtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUksUUFBUTNCLFlBQVksT0FBTzRCLFlBQTBCO0FBQ3pELFVBQU1DLFNBQVMsTUFBTXhCLFFBQVFzQixNQUFNQyxPQUFPO0FBQzFDZixZQUFRZ0IsT0FBT2pCLElBQUk7QUFDbkIsV0FBT2lCLE9BQU9qQjtBQUFBQSxFQUNoQixHQUFHLEVBQUU7QUFDTCxRQUFNa0IsV0FBVzlCLFlBQVksQ0FBQzRCLFlBQTZCdkIsUUFBUXlCLFNBQVNGLE9BQU8sR0FBRyxFQUFFO0FBQ3hGLFFBQU1HLGNBQWMvQixZQUFZLENBQUM0QixZQUFnQ3ZCLFFBQVEwQixZQUFZSCxPQUFPLEdBQUcsRUFBRTtBQUNqRyxRQUFNSSxTQUFTaEMsWUFBWSxZQUFZO0FBQ3JDLFFBQUk7QUFDRixZQUFNSyxRQUFRMkIsT0FBTztBQUFBLElBQ3ZCLFVBQUM7QUFDQ25CLGNBQVEsSUFBSTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1vQixRQUFROUIsUUFBUSxPQUFPO0FBQUEsSUFDM0JTO0FBQUFBLElBQU1zQixpQkFBaUJDLFFBQVF2QixJQUFJO0FBQUEsSUFBR0U7QUFBQUEsSUFBZ0JhO0FBQUFBLElBQU9HO0FBQUFBLElBQVVDO0FBQUFBLElBQWFDO0FBQUFBLElBQVFoQjtBQUFBQSxFQUM5RixJQUFJLENBQUNKLE1BQU1FLGdCQUFnQmEsT0FBT0csVUFBVUMsYUFBYUMsUUFBUWhCLFdBQVcsQ0FBQztBQUU3RSxTQUFPLHVCQUFDLFlBQVksVUFBWixFQUFxQixPQUFlTixZQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThDO0FBQ3ZEO0FBQUNDLEdBdERlRixjQUFZO0FBQUEsS0FBWkE7QUF3RFQsZ0JBQVMyQixVQUFVO0FBQUFDLE1BQUE7QUFDeEIsUUFBTUMsVUFBVXJDLFdBQVdNLFdBQVc7QUFDdEMsTUFBSSxDQUFDK0IsUUFBUyxPQUFNLElBQUlDLE1BQU0sMENBQTBDO0FBQ3hFLFNBQU9EO0FBQ1Q7QUFBQ0QsSUFKZUQsU0FBTztBQUFBLElBQUFJO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDYWxsYmFjayIsInVzZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJhdXRoQXBpIiwidG9rZW5TdG9yYWdlIiwiQXV0aENvbnRleHQiLCJ1bmRlZmluZWQiLCJBdXRoUHJvdmlkZXIiLCJjaGlsZHJlbiIsIl9zIiwidXNlciIsInNldFVzZXIiLCJpc0luaXRpYWxpemluZyIsInNldElzSW5pdGlhbGl6aW5nIiwicmVmcmVzaFVzZXIiLCJjdXJyZW50IiwibWUiLCJhY3RpdmUiLCJpbml0aWFsaXplIiwiZ2V0QWNjZXNzVG9rZW4iLCJnZXRSZWZyZXNoVG9rZW4iLCJvbkV4cGlyZWQiLCJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImxvZ2luIiwicGF5bG9hZCIsInJlc3VsdCIsInJlZ2lzdGVyIiwidmVyaWZ5RW1haWwiLCJsb2dvdXQiLCJ2YWx1ZSIsImlzQXV0aGVudGljYXRlZCIsIkJvb2xlYW4iLCJ1c2VBdXRoIiwiX3MyIiwiY29udGV4dCIsIkVycm9yIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXV0aFByb3ZpZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDYWxsYmFjaywgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGF1dGhBcGkgfSBmcm9tIFwiLi4vLi4vZmVhdHVyZXMvYXV0aC9hdXRoQXBpXCI7XG5pbXBvcnQgdHlwZSB7IEF1dGhVc2VyLCBMb2dpblBheWxvYWQsIFJlZ2lzdGVyUGF5bG9hZCwgVmVyaWZ5RW1haWxQYXlsb2FkIH0gZnJvbSBcIi4uLy4uL2ZlYXR1cmVzL2F1dGgvYXV0aC50eXBlc1wiO1xuaW1wb3J0IHsgdG9rZW5TdG9yYWdlIH0gZnJvbSBcIi4uLy4uL2xpYi9hcGkvdG9rZW5TdG9yYWdlXCI7XG5cbnR5cGUgQXV0aENvbnRleHRWYWx1ZSA9IHtcbiAgdXNlcjogQXV0aFVzZXIgfCBudWxsO1xuICBpc0F1dGhlbnRpY2F0ZWQ6IGJvb2xlYW47XG4gIGlzSW5pdGlhbGl6aW5nOiBib29sZWFuO1xuICBsb2dpbjogKHBheWxvYWQ6IExvZ2luUGF5bG9hZCkgPT4gUHJvbWlzZTxBdXRoVXNlcj47XG4gIHJlZ2lzdGVyOiAocGF5bG9hZDogUmVnaXN0ZXJQYXlsb2FkKSA9PiBQcm9taXNlPHVua25vd24+O1xuICB2ZXJpZnlFbWFpbDogKHBheWxvYWQ6IFZlcmlmeUVtYWlsUGF5bG9hZCkgPT4gUHJvbWlzZTx1bmtub3duPjtcbiAgbG9nb3V0OiAoKSA9PiBQcm9taXNlPHZvaWQ+O1xuICByZWZyZXNoVXNlcjogKCkgPT4gUHJvbWlzZTx2b2lkPjtcbn07XG5jb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8QXV0aENvbnRleHRWYWx1ZSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcblxuZXhwb3J0IGZ1bmN0aW9uIEF1dGhQcm92aWRlcih7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0Tm9kZSB9KSB7XG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlPEF1dGhVc2VyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc0luaXRpYWxpemluZywgc2V0SXNJbml0aWFsaXppbmddID0gdXNlU3RhdGUodHJ1ZSk7XG5cbiAgY29uc3QgcmVmcmVzaFVzZXIgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgY3VycmVudCA9IGF3YWl0IGF1dGhBcGkubWUoKTtcbiAgICBzZXRVc2VyKGN1cnJlbnQpO1xuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZTtcbiAgICBjb25zdCBpbml0aWFsaXplID0gYXN5bmMgKCkgPT4ge1xuICAgICAgaWYgKCF0b2tlblN0b3JhZ2UuZ2V0QWNjZXNzVG9rZW4oKSAmJiAhdG9rZW5TdG9yYWdlLmdldFJlZnJlc2hUb2tlbigpKSB7XG4gICAgICAgIGlmIChhY3RpdmUpIHNldElzSW5pdGlhbGl6aW5nKGZhbHNlKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY3VycmVudCA9IGF3YWl0IGF1dGhBcGkubWUoKTtcbiAgICAgICAgaWYgKGFjdGl2ZSkgc2V0VXNlcihjdXJyZW50KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBpZiAoYWN0aXZlKSBzZXRVc2VyKG51bGwpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgaWYgKGFjdGl2ZSkgc2V0SXNJbml0aWFsaXppbmcoZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgb25FeHBpcmVkID0gKCkgPT4gc2V0VXNlcihudWxsKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImJhbmtpbmc6c2Vzc2lvbi1leHBpcmVkXCIsIG9uRXhwaXJlZCk7XG4gICAgdm9pZCBpbml0aWFsaXplKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGFjdGl2ZSA9IGZhbHNlO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJiYW5raW5nOnNlc3Npb24tZXhwaXJlZFwiLCBvbkV4cGlyZWQpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICBjb25zdCBsb2dpbiA9IHVzZUNhbGxiYWNrKGFzeW5jIChwYXlsb2FkOiBMb2dpblBheWxvYWQpID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhdXRoQXBpLmxvZ2luKHBheWxvYWQpO1xuICAgIHNldFVzZXIocmVzdWx0LnVzZXIpO1xuICAgIHJldHVybiByZXN1bHQudXNlcjtcbiAgfSwgW10pO1xuICBjb25zdCByZWdpc3RlciA9IHVzZUNhbGxiYWNrKChwYXlsb2FkOiBSZWdpc3RlclBheWxvYWQpID0+IGF1dGhBcGkucmVnaXN0ZXIocGF5bG9hZCksIFtdKTtcbiAgY29uc3QgdmVyaWZ5RW1haWwgPSB1c2VDYWxsYmFjaygocGF5bG9hZDogVmVyaWZ5RW1haWxQYXlsb2FkKSA9PiBhdXRoQXBpLnZlcmlmeUVtYWlsKHBheWxvYWQpLCBbXSk7XG4gIGNvbnN0IGxvZ291dCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXV0aEFwaS5sb2dvdXQoKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0VXNlcihudWxsKTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICBjb25zdCB2YWx1ZSA9IHVzZU1lbW8oKCkgPT4gKHtcbiAgICB1c2VyLCBpc0F1dGhlbnRpY2F0ZWQ6IEJvb2xlYW4odXNlciksIGlzSW5pdGlhbGl6aW5nLCBsb2dpbiwgcmVnaXN0ZXIsIHZlcmlmeUVtYWlsLCBsb2dvdXQsIHJlZnJlc2hVc2VyLFxuICB9KSwgW3VzZXIsIGlzSW5pdGlhbGl6aW5nLCBsb2dpbiwgcmVnaXN0ZXIsIHZlcmlmeUVtYWlsLCBsb2dvdXQsIHJlZnJlc2hVc2VyXSk7XG5cbiAgcmV0dXJuIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWV9PntjaGlsZHJlbn08L0F1dGhDb250ZXh0LlByb3ZpZGVyPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKSB7XG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KEF1dGhDb250ZXh0KTtcbiAgaWYgKCFjb250ZXh0KSB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VBdXRoIG11c3QgYmUgdXNlZCB3aXRoaW4gQXV0aFByb3ZpZGVyXCIpO1xuICByZXR1cm4gY29udGV4dDtcbn1cbiJdLCJmaWxlIjoiRDovTmV3X2ZvbGRlcl8oMikvU29mdHdhcmUgZGV2ZWxvcG1lbnQgUHJvamVjdC9iYW5raW5nLXBsYXRmcm9tL2Zyb250ZW5kL2JhbmtpbmctcGxhdGZvcm0tZnJvbnRlbmQvc3JjL2FwcC9wcm92aWRlcnMvQXV0aFByb3ZpZGVyLnRzeCJ9