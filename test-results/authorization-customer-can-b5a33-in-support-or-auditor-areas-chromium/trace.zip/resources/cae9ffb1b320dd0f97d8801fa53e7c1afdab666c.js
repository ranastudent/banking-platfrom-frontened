import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/router/RoleRoutes.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import { Navigate, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { useAuth } from "/src/app/providers/AuthProvider.tsx";
export function roleHome(role) {
  switch (String(role).toUpperCase()) {
    case "CUSTOMER":
      return "/customer/dashboard";
    case "ADMIN":
      return "/admin/dashboard";
    case "SUPPORT":
      return "/support/dashboard";
    case "AUDITOR":
      return "/auditor/dashboard";
    default:
      return "/403";
  }
}
export function RequireAuth() {
  _s();
  const { isAuthenticated, isInitializing } = useAuth();
  const location = useLocation();
  if (isInitializing) return /* @__PURE__ */ jsxDEV("div", { className: "route-state", role: "status", children: "Restoring your secure session…" }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx",
    lineNumber: 18,
    columnNumber: 30
  }, this);
  if (!isAuthenticated) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true, state: { from: location } }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx",
    lineNumber: 19,
    columnNumber: 32
  }, this);
  return /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}
_s(RequireAuth, "Qr9IoQEnUxEMbAQzPWPcvRQloD0=", false, function() {
  return [useAuth, useLocation];
});
_c = RequireAuth;
export function RequireRole({ allowed }) {
  _s2();
  const { user, isInitializing } = useAuth();
  if (isInitializing) return /* @__PURE__ */ jsxDEV("div", { className: "route-state", role: "status", children: "Checking your access…" }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx",
    lineNumber: 25,
    columnNumber: 30
  }, this);
  if (!user) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx",
    lineNumber: 26,
    columnNumber: 21
  }, this);
  if (!allowed.includes(String(user.role).toUpperCase())) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/403", replace: true }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx",
    lineNumber: 27,
    columnNumber: 66
  }, this);
  return /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
}
_s2(RequireRole, "w9n5SIYcdNc9YbXTvB9culdHHP4=", false, function() {
  return [useAuth];
});
_c2 = RequireRole;
var _c, _c2;
$RefreshReg$(_c, "RequireAuth");
$RefreshReg$(_c2, "RequireRole");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/router/RoleRoutes.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUI2Qjs7QUFqQjdCLFNBQVNBLFVBQVVDLFFBQVFDLG1CQUFtQjtBQUM5QyxTQUFTQyxlQUFlO0FBR2pCLGdCQUFTQyxTQUFTQyxNQUFnQjtBQUN2QyxVQUFRQyxPQUFPRCxJQUFJLEVBQUVFLFlBQVksR0FBQztBQUFBLElBQ2hDLEtBQUs7QUFBWSxhQUFPO0FBQUEsSUFDeEIsS0FBSztBQUFTLGFBQU87QUFBQSxJQUNyQixLQUFLO0FBQVcsYUFBTztBQUFBLElBQ3ZCLEtBQUs7QUFBVyxhQUFPO0FBQUEsSUFDdkI7QUFBUyxhQUFPO0FBQUEsRUFDbEI7QUFDRjtBQUVPLGdCQUFTQyxjQUFjO0FBQUFDLEtBQUE7QUFDNUIsUUFBTSxFQUFFQyxpQkFBaUJDLGVBQWUsSUFBSVIsUUFBUTtBQUNwRCxRQUFNUyxXQUFXVixZQUFZO0FBQzdCLE1BQUlTLGVBQWdCLFFBQU8sdUJBQUMsU0FBSSxXQUFVLGVBQWMsTUFBSyxVQUFTLDhDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlFO0FBQ3BHLE1BQUksQ0FBQ0QsZ0JBQWlCLFFBQU8sdUJBQUMsWUFBUyxJQUFHLFVBQVMsU0FBTyxNQUFDLE9BQU8sRUFBRUcsTUFBTUQsU0FBUyxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXdEO0FBQ3JGLFNBQU8sdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQU87QUFDaEI7QUFBQ0gsR0FOZUQsYUFBVztBQUFBLFVBQ21CTCxTQUMzQkQsV0FBVztBQUFBO0FBQUEsS0FGZE07QUFRVCxnQkFBU00sWUFBWSxFQUFFQyxRQUFpQyxHQUFHO0FBQUFDLE1BQUE7QUFDaEUsUUFBTSxFQUFFQyxNQUFNTixlQUFlLElBQUlSLFFBQVE7QUFDekMsTUFBSVEsZUFBZ0IsUUFBTyx1QkFBQyxTQUFJLFdBQVUsZUFBYyxNQUFLLFVBQVMscUNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0U7QUFDM0YsTUFBSSxDQUFDTSxLQUFNLFFBQU8sdUJBQUMsWUFBUyxJQUFHLFVBQVMsU0FBTyxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTZCO0FBQy9DLE1BQUksQ0FBQ0YsUUFBUUcsU0FBU1osT0FBT1csS0FBS1osSUFBSSxFQUFFRSxZQUFZLENBQUMsRUFBRyxRQUFPLHVCQUFDLFlBQVMsSUFBRyxRQUFPLFNBQU8sUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQjtBQUMxRixTQUFPLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFPO0FBQ2hCO0FBQUNTLElBTmVGLGFBQVc7QUFBQSxVQUNRWCxPQUFPO0FBQUE7QUFBQSxNQUQxQlc7QUFBVyxJQUFBSyxJQUFBQztBQUFBLGFBQUFELElBQUE7QUFBQSxhQUFBQyxLQUFBIiwibmFtZXMiOlsiTmF2aWdhdGUiLCJPdXRsZXQiLCJ1c2VMb2NhdGlvbiIsInVzZUF1dGgiLCJyb2xlSG9tZSIsInJvbGUiLCJTdHJpbmciLCJ0b1VwcGVyQ2FzZSIsIlJlcXVpcmVBdXRoIiwiX3MiLCJpc0F1dGhlbnRpY2F0ZWQiLCJpc0luaXRpYWxpemluZyIsImxvY2F0aW9uIiwiZnJvbSIsIlJlcXVpcmVSb2xlIiwiYWxsb3dlZCIsIl9zMiIsInVzZXIiLCJpbmNsdWRlcyIsIl9jIiwiX2MyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJvbGVSb3V0ZXMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5hdmlnYXRlLCBPdXRsZXQsIHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vcHJvdmlkZXJzL0F1dGhQcm92aWRlclwiO1xuaW1wb3J0IHR5cGUgeyBVc2VyUm9sZSB9IGZyb20gXCIuLi8uLi9mZWF0dXJlcy9hdXRoL2F1dGgudHlwZXNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHJvbGVIb21lKHJvbGU6IFVzZXJSb2xlKSB7XG4gIHN3aXRjaCAoU3RyaW5nKHJvbGUpLnRvVXBwZXJDYXNlKCkpIHtcbiAgICBjYXNlIFwiQ1VTVE9NRVJcIjogcmV0dXJuIFwiL2N1c3RvbWVyL2Rhc2hib2FyZFwiO1xuICAgIGNhc2UgXCJBRE1JTlwiOiByZXR1cm4gXCIvYWRtaW4vZGFzaGJvYXJkXCI7XG4gICAgY2FzZSBcIlNVUFBPUlRcIjogcmV0dXJuIFwiL3N1cHBvcnQvZGFzaGJvYXJkXCI7XG4gICAgY2FzZSBcIkFVRElUT1JcIjogcmV0dXJuIFwiL2F1ZGl0b3IvZGFzaGJvYXJkXCI7XG4gICAgZGVmYXVsdDogcmV0dXJuIFwiLzQwM1wiO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBSZXF1aXJlQXV0aCgpIHtcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQsIGlzSW5pdGlhbGl6aW5nIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgaWYgKGlzSW5pdGlhbGl6aW5nKSByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJyb3V0ZS1zdGF0ZVwiIHJvbGU9XCJzdGF0dXNcIj5SZXN0b3JpbmcgeW91ciBzZWN1cmUgc2Vzc2lvbuKApjwvZGl2PjtcbiAgaWYgKCFpc0F1dGhlbnRpY2F0ZWQpIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIHN0YXRlPXt7IGZyb206IGxvY2F0aW9uIH19IC8+O1xuICByZXR1cm4gPE91dGxldCAvPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFJlcXVpcmVSb2xlKHsgYWxsb3dlZCB9OiB7IGFsbG93ZWQ6IFVzZXJSb2xlW10gfSkge1xuICBjb25zdCB7IHVzZXIsIGlzSW5pdGlhbGl6aW5nIH0gPSB1c2VBdXRoKCk7XG4gIGlmIChpc0luaXRpYWxpemluZykgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwicm91dGUtc3RhdGVcIiByb2xlPVwic3RhdHVzXCI+Q2hlY2tpbmcgeW91ciBhY2Nlc3PigKY8L2Rpdj47XG4gIGlmICghdXNlcikgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIHJlcGxhY2UgLz47XG4gIGlmICghYWxsb3dlZC5pbmNsdWRlcyhTdHJpbmcodXNlci5yb2xlKS50b1VwcGVyQ2FzZSgpKSkgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi80MDNcIiByZXBsYWNlIC8+O1xuICByZXR1cm4gPE91dGxldCAvPjtcbn1cbiJdLCJmaWxlIjoiRDovTmV3X2ZvbGRlcl8oMikvU29mdHdhcmUgZGV2ZWxvcG1lbnQgUHJvamVjdC9iYW5raW5nLXBsYXRmcm9tL2Zyb250ZW5kL2JhbmtpbmctcGxhdGZvcm0tZnJvbnRlbmQvc3JjL2FwcC9yb3V0ZXIvUm9sZVJvdXRlcy50c3gifQ==