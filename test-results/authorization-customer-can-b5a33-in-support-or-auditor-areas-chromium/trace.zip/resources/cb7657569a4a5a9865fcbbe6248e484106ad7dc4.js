import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/public/pages/AboutPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { ArrowRight, ArrowUpRight, BarChart3, Eye, Globe2, Layers3, ShieldCheck, Users, Target } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
const features = [
  [Layers3, "Account Management", "Create and manage multiple accounts with real-time balance."],
  [ArrowRight, "Transaction Management", "Deposit, withdrawal, transfer and complete transaction history."],
  [Globe2, "Multi-Currency Support", "Operate with multiple currencies and real-time exchange rates."],
  [ShieldCheck, "Fraud Monitoring", "AI-powered fraud detection and risk assessment."],
  [BarChart3, "Financial Reporting", "Insights, audit logs and compliance-ready reports."],
  [Users, "Role-Based Access", "Secure and controlled access for Customer, Admin, Support and Auditor."]
];
export function AboutPage() {
  return /* @__PURE__ */ jsxDEV("div", { className: "about-page", children: [
    /* @__PURE__ */ jsxDEV("section", { className: "about-hero", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "hero-text", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "section-pill", children: "About Our Platform" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 16,
          columnNumber: 34
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: [
          "A Modern, Secure & Scalable ",
          /* @__PURE__ */ jsxDEV("em", { children: "Banking Platform" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 16,
            columnNumber: 126
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 16,
          columnNumber: 90
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "A complete digital banking and financial management solution for individuals, businesses and institutions." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 16,
          columnNumber: 156
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-actions", children: [
          /* @__PURE__ */ jsxDEV(Link, { className: "primary-action", to: "/register", children: [
            "Get Started ",
            /* @__PURE__ */ jsxDEV(ArrowRight, { size: 16 }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
              lineNumber: 16,
              columnNumber: 359
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 16,
            columnNumber: 299
          }, this),
          /* @__PURE__ */ jsxDEV("a", { className: "secondary-action", href: "#features", children: "Explore Features" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 16,
            columnNumber: 390
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 16,
          columnNumber: 269
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 16,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hero-visual", "aria-hidden": "true", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "hero-glow" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 17,
          columnNumber: 55
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-bank", children: [
          /* @__PURE__ */ jsxDEV(LandmarkIllustration, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 17,
            columnNumber: 115
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: "BANK" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 17,
            columnNumber: 139
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 17,
          columnNumber: 88
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-shield", children: /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 46 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 17,
          columnNumber: 195
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 17,
          columnNumber: 166
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-gold", children: [
          /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 17,
            columnNumber: 253
          }, this),
          /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 17,
            columnNumber: 261
          }, this),
          /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 17,
            columnNumber: 269
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 17,
          columnNumber: 226
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 17,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
      lineNumber: 15,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "about-intro", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "building-photo", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "building-sky" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 20,
          columnNumber: 39
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "building", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "building-sign", children: [
            /* @__PURE__ */ jsxDEV(LandmarkIllustration, {}, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
              lineNumber: 20,
              columnNumber: 132
            }, this),
            " Banking Platform"
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 20,
            columnNumber: 101
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "building-windows" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 20,
            columnNumber: 179
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 20,
          columnNumber: 75
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "building-green" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 20,
          columnNumber: 225
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 20,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "intro-copy", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "About the Platform" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 21,
          columnNumber: 35
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Our Banking Platform is a production-grade digital banking solution that enables secure account management, multi-currency operations, fund transfers, transaction monitoring and financial administration through a role-based system." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 21,
          columnNumber: 62
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 21,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "purpose-card", children: [
        /* @__PURE__ */ jsxDEV(Target, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 22,
          columnNumber: 41
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: "Our Mission" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 22,
          columnNumber: 51
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "To deliver a secure, reliable and inclusive digital banking experience." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 22,
          columnNumber: 71
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 22,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "purpose-card", children: [
        /* @__PURE__ */ jsxDEV(Eye, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 23,
          columnNumber: 41
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { children: "Our Vision" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 23,
          columnNumber: 48
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "To be a trusted, intelligent and globally accessible financial platform." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 23,
          columnNumber: 67
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 23,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
      lineNumber: 19,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { id: "features", className: "features-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-heading", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Core Features" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 25,
          columnNumber: 90
        }, this),
        /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 25,
          columnNumber: 112
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 25,
        columnNumber: 57
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "feature-grid", children: features.map(([Icon, title, description]) => /* @__PURE__ */ jsxDEV("article", { className: "feature-card", children: [
        /* @__PURE__ */ jsxDEV(Icon, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 25,
          columnNumber: 248
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { children: title }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 25,
            columnNumber: 261
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: description }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 25,
            columnNumber: 277
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 25,
          columnNumber: 256
        }, this)
      ] }, title, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 25,
        columnNumber: 202
      }, this)) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 25,
        columnNumber: 126
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
      lineNumber: 25,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { id: "security", className: "security-strip", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "security-emblem", children: /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 54 }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 26,
        columnNumber: 88
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 26,
        columnNumber: 55
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "security-copy", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Security & Reliability" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 26,
          columnNumber: 150
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Built with industry best practices to help keep your money and data safe." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 26,
          columnNumber: 185
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "security-points", children: ["JWT Authentication", "Input Validation", "Rate Limiting", "Audit Logging", "Idempotency"].map((x) => /* @__PURE__ */ jsxDEV("span", { children: [
          /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 13 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
            lineNumber: 26,
            columnNumber: 416
          }, this),
          x
        ] }, x, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 26,
          columnNumber: 402
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 26,
          columnNumber: 265
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 26,
        columnNumber: 119
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
      lineNumber: 26,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "technology-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-heading", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Technology Stack" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 27,
          columnNumber: 78
        }, this),
        /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 27,
          columnNumber: 103
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 27,
        columnNumber: 45
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "tech-grid", children: [["React", "Frontend", "⚛"], ["Node.js", "Backend", "⬡"], ["Prisma", "ORM", "◈"], ["PostgreSQL", "Database", "🐘"], ["Redis", "Caching", "▰"], ["Docker", "Deployment", "🐳"], ["AWS", "Cloud, Planned", "aws"]].map(([name, sub, mark]) => /* @__PURE__ */ jsxDEV("div", { className: "tech-card", children: [
        /* @__PURE__ */ jsxDEV("strong", { className: `tech-mark tech-${name.toLowerCase()}`, children: mark }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 27,
          columnNumber: 419
        }, this),
        /* @__PURE__ */ jsxDEV("b", { children: name }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 27,
          columnNumber: 493
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: [
          "(",
          sub,
          ")"
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 27,
          columnNumber: 506
        }, this)
      ] }, name, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 27,
        columnNumber: 381
      }, this)) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 27,
        columnNumber: 117
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
      lineNumber: 27,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { id: "contact", className: "about-cta", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Ready to get started?" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 28,
          columnNumber: 54
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Explore the platform with a demo account." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 28,
          columnNumber: 84
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 28,
        columnNumber: 49
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { className: "primary-action", to: "/register", children: [
        "Create an Account ",
        /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 16 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
          lineNumber: 28,
          columnNumber: 204
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
        lineNumber: 28,
        columnNumber: 138
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
      lineNumber: 28,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
_c = AboutPage;
function LandmarkIllustration() {
  return /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 150 110", children: [
    /* @__PURE__ */ jsxDEV("path", { d: "M8 32 75 5l67 27H8Z", fill: "currentColor" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
      lineNumber: 31,
      columnNumber: 68
    }, this),
    /* @__PURE__ */ jsxDEV("path", { d: "M17 38h116v8H17zM26 49h13v45H26zM56 49h13v45H56zM86 49h13v45H86zM116 49h13v45h-13zM12 96h126v9H12z", fill: "currentColor" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
      lineNumber: 31,
      columnNumber: 120
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx",
    lineNumber: 31,
    columnNumber: 41
  }, this);
}
_c2 = LandmarkIllustration;
var _c, _c2;
$RefreshReg$(_c, "AboutPage");
$RefreshReg$(_c2, "LandmarkIllustration");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/AboutPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZWlDO0FBZmpDLFNBQVNBLFlBQVlDLGNBQWNDLFdBQVdDLEtBQUtDLFFBQVFDLFNBQVNDLGFBQWFDLE9BQU9DLGNBQWM7QUFDdEcsU0FBU0MsWUFBWTtBQUVyQixNQUFNQyxXQUFXO0FBQUEsRUFDZixDQUFDTCxTQUFTLHNCQUFzQiw2REFBNkQ7QUFBQSxFQUM3RixDQUFDTCxZQUFZLDBCQUEwQixpRUFBaUU7QUFBQSxFQUN4RyxDQUFDSSxRQUFRLDBCQUEwQixnRUFBZ0U7QUFBQSxFQUNuRyxDQUFDRSxhQUFhLG9CQUFvQixpREFBaUQ7QUFBQSxFQUNuRixDQUFDSixXQUFXLHVCQUF1QixvREFBb0Q7QUFBQSxFQUN2RixDQUFDSyxPQUFPLHFCQUFxQix3RUFBd0U7QUFBQztBQUdqRyxnQkFBU0ksWUFBWTtBQUMxQixTQUFPLHVCQUFDLFNBQUksV0FBVSxjQUNwQjtBQUFBLDJCQUFDLGFBQVEsV0FBVSxjQUNqQjtBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUFZO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGdCQUFlLGtDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsUUFBTyx1QkFBQyxRQUFHO0FBQUE7QUFBQSxVQUFnQyx1QkFBQyxRQUFHLGdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsYUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFFBQUssdUJBQUMsT0FBRSwwSEFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZHO0FBQUEsUUFBSSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQSxpQ0FBQyxRQUFLLFdBQVUsa0JBQWlCLElBQUcsYUFBWTtBQUFBO0FBQUEsWUFBWSx1QkFBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUI7QUFBQSxlQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLFVBQU8sdUJBQUMsT0FBRSxXQUFVLG9CQUFtQixNQUFLLGFBQVksZ0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsYUFBekw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2TDtBQUFBLFdBQW5jO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeWM7QUFBQSxNQUN6Yyx1QkFBQyxTQUFJLFdBQVUsZUFBYyxlQUFZLFFBQU87QUFBQSwrQkFBQyxTQUFJLFdBQVUsZUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFBTSx1QkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBLGlDQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsVUFBRSx1QkFBQyxZQUFPLG9CQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQSxhQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFBTSx1QkFBQyxTQUFJLFdBQVUsZUFBYyxpQ0FBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQixLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFBTSx1QkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBLGlDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBSztBQUFBLFVBQUUsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFLO0FBQUEsVUFBRSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUs7QUFBQSxhQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdEO0FBQUEsV0FBelE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErUTtBQUFBLFNBRmpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsYUFBUSxXQUFVLGVBQ2pCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGtCQUFpQjtBQUFBLCtCQUFDLFNBQUksV0FBVSxrQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThCO0FBQUEsUUFBTSx1QkFBQyxTQUFJLFdBQVUsWUFBVztBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFBZ0I7QUFBQSxtQ0FBQywwQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQjtBQUFBLFlBQUU7QUFBQSxlQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RTtBQUFBLFVBQU0sdUJBQUMsU0FBSSxXQUFVLHNCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtDO0FBQUEsYUFBekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErSTtBQUFBLFFBQU0sdUJBQUMsU0FBSSxXQUFVLG9CQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxXQUF6UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStQO0FBQUEsTUFDL1AsdUJBQUMsU0FBSSxXQUFVLGNBQWE7QUFBQSwrQkFBQyxRQUFHLGtDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0I7QUFBQSxRQUFLLHVCQUFDLE9BQUUsdVBBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwTztBQUFBLFdBQWpTO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcVM7QUFBQSxNQUNyUyx1QkFBQyxhQUFRLFdBQVUsZ0JBQWU7QUFBQSwrQkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTztBQUFBLFFBQUUsdUJBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUFLLHVCQUFDLE9BQUUsdUZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRTtBQUFBLFdBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkk7QUFBQSxNQUM3SSx1QkFBQyxhQUFRLFdBQVUsZ0JBQWU7QUFBQSwrQkFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBSTtBQUFBLFFBQUUsdUJBQUMsUUFBRywwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWM7QUFBQSxRQUFLLHVCQUFDLE9BQUUsd0ZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFdBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEk7QUFBQSxTQUo1STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLGFBQVEsSUFBRyxZQUFXLFdBQVUsb0JBQW1CO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG1CQUFrQjtBQUFBLCtCQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQUssdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUs7QUFBQSxXQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFBTSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWdCRCxtQkFBU0UsSUFBSSxDQUFDLENBQUNDLE1BQUtDLE9BQU1DLFdBQVcsTUFBSSx1QkFBQyxhQUFRLFdBQVUsZ0JBQTJCO0FBQUEsK0JBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUs7QUFBQSxRQUFFLHVCQUFDLFNBQUk7QUFBQSxpQ0FBQyxRQUFJRCxtQkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFBSyx1QkFBQyxPQUFHQyx5QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLGFBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxXQUF2REQsT0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRyxDQUFVLEtBQXRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0w7QUFBQSxTQUFoVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNUO0FBQUEsSUFDdFQsdUJBQUMsYUFBUSxJQUFHLFlBQVcsV0FBVSxrQkFBaUI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUJBQWtCLGlDQUFDLGVBQVksTUFBTSxNQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxNQUFNLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0I7QUFBQSwrQkFBQyxRQUFHLHNDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEI7QUFBQSxRQUFLLHVCQUFDLE9BQUUseUZBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFFBQUksdUJBQUMsU0FBSSxXQUFVLG1CQUFtQixXQUFDLHNCQUFxQixvQkFBbUIsaUJBQWdCLGlCQUFnQixhQUFhLEVBQUVGLElBQUksQ0FBQUksTUFBRyx1QkFBQyxVQUFhO0FBQUEsaUNBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCO0FBQUEsVUFBR0E7QUFBQUEsYUFBNUJBLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QyxDQUFPLEtBQWpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUw7QUFBQSxXQUFyVTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJVO0FBQUEsU0FBNWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrYztBQUFBLElBQ2xjLHVCQUFDLGFBQVEsV0FBVSxzQkFBcUI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUJBQWtCO0FBQUEsK0JBQUMsUUFBRyxnQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBQUEsUUFBSyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBSztBQUFBLFdBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxNQUFNLHVCQUFDLFNBQUksV0FBVSxhQUFhLFdBQUMsQ0FBRSxTQUFRLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVSxXQUFVLEdBQUcsR0FBRSxDQUFDLFVBQVMsT0FBTSxHQUFHLEdBQUUsQ0FBQyxjQUFhLFlBQVcsSUFBSSxHQUFFLENBQUMsU0FBUSxXQUFVLEdBQUcsR0FBRSxDQUFDLFVBQVMsY0FBYSxJQUFJLEdBQUUsQ0FBQyxPQUFNLGtCQUFpQixLQUFLLENBQUMsRUFBRUosSUFBSSxDQUFDLENBQUNLLE1BQUtDLEtBQUlDLElBQUksTUFBSSx1QkFBQyxTQUFJLFdBQVUsYUFBdUI7QUFBQSwrQkFBQyxZQUFPLFdBQVcsa0JBQWtCRixLQUFLRyxZQUFZLENBQUMsSUFBS0Qsa0JBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUFTLHVCQUFDLE9BQUdGLGtCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUztBQUFBLFFBQUksdUJBQUMsV0FBTTtBQUFBO0FBQUEsVUFBRUM7QUFBQUEsVUFBSTtBQUFBLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFjO0FBQUEsV0FBM0dELE1BQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUosQ0FBTSxLQUE1WTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThZO0FBQUEsU0FBN2Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtZ0I7QUFBQSxJQUNuZ0IsdUJBQUMsYUFBUSxJQUFHLFdBQVUsV0FBVSxhQUFZO0FBQUEsNkJBQUMsU0FBSTtBQUFBLCtCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQUssdUJBQUMsT0FBRSx5REFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsV0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLE1BQU0sdUJBQUMsUUFBSyxXQUFVLGtCQUFpQixJQUFHLGFBQVk7QUFBQTtBQUFBLFFBQWtCLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFdBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkY7QUFBQSxTQUFoTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVPO0FBQUEsT0FkbE87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVQO0FBQ0Y7QUFBQ0ksS0FqQmVWO0FBa0JoQixTQUFTVyx1QkFBc0I7QUFBQyxTQUFPLHVCQUFDLFNBQUksU0FBUSxlQUFjO0FBQUEsMkJBQUMsVUFBSyxHQUFFLHVCQUFzQixNQUFLLGtCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFBRSx1QkFBQyxVQUFLLEdBQUUsc0dBQXFHLE1BQUssa0JBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0k7QUFBQSxPQUE5TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWdOO0FBQU07QUFBQ0MsTUFBclBEO0FBQW9CLElBQUFELElBQUFFO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFFLEtBQUEiLCJuYW1lcyI6WyJBcnJvd1JpZ2h0IiwiQXJyb3dVcFJpZ2h0IiwiQmFyQ2hhcnQzIiwiRXllIiwiR2xvYmUyIiwiTGF5ZXJzMyIsIlNoaWVsZENoZWNrIiwiVXNlcnMiLCJUYXJnZXQiLCJMaW5rIiwiZmVhdHVyZXMiLCJBYm91dFBhZ2UiLCJtYXAiLCJJY29uIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsIngiLCJuYW1lIiwic3ViIiwibWFyayIsInRvTG93ZXJDYXNlIiwiX2MiLCJMYW5kbWFya0lsbHVzdHJhdGlvbiIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBYm91dFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFycm93UmlnaHQsIEFycm93VXBSaWdodCwgQmFyQ2hhcnQzLCBFeWUsIEdsb2JlMiwgTGF5ZXJzMywgU2hpZWxkQ2hlY2ssIFVzZXJzLCBUYXJnZXQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcblxuY29uc3QgZmVhdHVyZXMgPSBbXG4gIFtMYXllcnMzLCBcIkFjY291bnQgTWFuYWdlbWVudFwiLCBcIkNyZWF0ZSBhbmQgbWFuYWdlIG11bHRpcGxlIGFjY291bnRzIHdpdGggcmVhbC10aW1lIGJhbGFuY2UuXCJdLFxuICBbQXJyb3dSaWdodCwgXCJUcmFuc2FjdGlvbiBNYW5hZ2VtZW50XCIsIFwiRGVwb3NpdCwgd2l0aGRyYXdhbCwgdHJhbnNmZXIgYW5kIGNvbXBsZXRlIHRyYW5zYWN0aW9uIGhpc3RvcnkuXCJdLFxuICBbR2xvYmUyLCBcIk11bHRpLUN1cnJlbmN5IFN1cHBvcnRcIiwgXCJPcGVyYXRlIHdpdGggbXVsdGlwbGUgY3VycmVuY2llcyBhbmQgcmVhbC10aW1lIGV4Y2hhbmdlIHJhdGVzLlwiXSxcbiAgW1NoaWVsZENoZWNrLCBcIkZyYXVkIE1vbml0b3JpbmdcIiwgXCJBSS1wb3dlcmVkIGZyYXVkIGRldGVjdGlvbiBhbmQgcmlzayBhc3Nlc3NtZW50LlwiXSxcbiAgW0JhckNoYXJ0MywgXCJGaW5hbmNpYWwgUmVwb3J0aW5nXCIsIFwiSW5zaWdodHMsIGF1ZGl0IGxvZ3MgYW5kIGNvbXBsaWFuY2UtcmVhZHkgcmVwb3J0cy5cIl0sXG4gIFtVc2VycywgXCJSb2xlLUJhc2VkIEFjY2Vzc1wiLCBcIlNlY3VyZSBhbmQgY29udHJvbGxlZCBhY2Nlc3MgZm9yIEN1c3RvbWVyLCBBZG1pbiwgU3VwcG9ydCBhbmQgQXVkaXRvci5cIl0sXG5dIGFzIGNvbnN0O1xuXG5leHBvcnQgZnVuY3Rpb24gQWJvdXRQYWdlKCkge1xuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJhYm91dC1wYWdlXCI+XG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYWJvdXQtaGVyb1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLXRleHRcIj48c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLXBpbGxcIj5BYm91dCBPdXIgUGxhdGZvcm08L3NwYW4+PGgxPkEgTW9kZXJuLCBTZWN1cmUgJmFtcDsgU2NhbGFibGUgPGVtPkJhbmtpbmcgUGxhdGZvcm08L2VtPjwvaDE+PHA+QSBjb21wbGV0ZSBkaWdpdGFsIGJhbmtpbmcgYW5kIGZpbmFuY2lhbCBtYW5hZ2VtZW50IHNvbHV0aW9uIGZvciBpbmRpdmlkdWFscywgYnVzaW5lc3NlcyBhbmQgaW5zdGl0dXRpb25zLjwvcD48ZGl2IGNsYXNzTmFtZT1cImhlcm8tYWN0aW9uc1wiPjxMaW5rIGNsYXNzTmFtZT1cInByaW1hcnktYWN0aW9uXCIgdG89XCIvcmVnaXN0ZXJcIj5HZXQgU3RhcnRlZCA8QXJyb3dSaWdodCBzaXplPXsxNn0vPjwvTGluaz48YSBjbGFzc05hbWU9XCJzZWNvbmRhcnktYWN0aW9uXCIgaHJlZj1cIiNmZWF0dXJlc1wiPkV4cGxvcmUgRmVhdHVyZXM8L2E+PC9kaXY+PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tdmlzdWFsXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+PGRpdiBjbGFzc05hbWU9XCJoZXJvLWdsb3dcIj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImhlcm8tYmFua1wiPjxMYW5kbWFya0lsbHVzdHJhdGlvbi8+PHN0cm9uZz5CQU5LPC9zdHJvbmc+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJoZXJvLXNoaWVsZFwiPjxTaGllbGRDaGVjayBzaXplPXs0Nn0vPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiaGVyby1nb2xkXCI+PHNwYW4vPjxzcGFuLz48c3Bhbi8+PC9kaXY+PC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImFib3V0LWludHJvXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1aWxkaW5nLXBob3RvXCI+PGRpdiBjbGFzc05hbWU9XCJidWlsZGluZy1za3lcIj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImJ1aWxkaW5nXCI+PGRpdiBjbGFzc05hbWU9XCJidWlsZGluZy1zaWduXCI+PExhbmRtYXJrSWxsdXN0cmF0aW9uLz4gQmFua2luZyBQbGF0Zm9ybTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiYnVpbGRpbmctd2luZG93c1wiPjwvZGl2PjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiYnVpbGRpbmctZ3JlZW5cIj48L2Rpdj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW50cm8tY29weVwiPjxoMj5BYm91dCB0aGUgUGxhdGZvcm08L2gyPjxwPk91ciBCYW5raW5nIFBsYXRmb3JtIGlzIGEgcHJvZHVjdGlvbi1ncmFkZSBkaWdpdGFsIGJhbmtpbmcgc29sdXRpb24gdGhhdCBlbmFibGVzIHNlY3VyZSBhY2NvdW50IG1hbmFnZW1lbnQsIG11bHRpLWN1cnJlbmN5IG9wZXJhdGlvbnMsIGZ1bmQgdHJhbnNmZXJzLCB0cmFuc2FjdGlvbiBtb25pdG9yaW5nIGFuZCBmaW5hbmNpYWwgYWRtaW5pc3RyYXRpb24gdGhyb3VnaCBhIHJvbGUtYmFzZWQgc3lzdGVtLjwvcD48L2Rpdj5cbiAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInB1cnBvc2UtY2FyZFwiPjxUYXJnZXQvPjxoMz5PdXIgTWlzc2lvbjwvaDM+PHA+VG8gZGVsaXZlciBhIHNlY3VyZSwgcmVsaWFibGUgYW5kIGluY2x1c2l2ZSBkaWdpdGFsIGJhbmtpbmcgZXhwZXJpZW5jZS48L3A+PC9hcnRpY2xlPlxuICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwicHVycG9zZS1jYXJkXCI+PEV5ZS8+PGgzPk91ciBWaXNpb248L2gzPjxwPlRvIGJlIGEgdHJ1c3RlZCwgaW50ZWxsaWdlbnQgYW5kIGdsb2JhbGx5IGFjY2Vzc2libGUgZmluYW5jaWFsIHBsYXRmb3JtLjwvcD48L2FydGljbGU+XG4gICAgPC9zZWN0aW9uPlxuICAgIDxzZWN0aW9uIGlkPVwiZmVhdHVyZXNcIiBjbGFzc05hbWU9XCJmZWF0dXJlcy1zZWN0aW9uXCI+PGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWhlYWRpbmdcIj48aDI+Q29yZSBGZWF0dXJlczwvaDI+PHNwYW4vPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1ncmlkXCI+e2ZlYXR1cmVzLm1hcCgoW0ljb24sdGl0bGUsZGVzY3JpcHRpb25dKT0+PGFydGljbGUgY2xhc3NOYW1lPVwiZmVhdHVyZS1jYXJkXCIga2V5PXt0aXRsZX0+PEljb24vPjxkaXY+PGgzPnt0aXRsZX08L2gzPjxwPntkZXNjcmlwdGlvbn08L3A+PC9kaXY+PC9hcnRpY2xlPil9PC9kaXY+PC9zZWN0aW9uPlxuICAgIDxzZWN0aW9uIGlkPVwic2VjdXJpdHlcIiBjbGFzc05hbWU9XCJzZWN1cml0eS1zdHJpcFwiPjxkaXYgY2xhc3NOYW1lPVwic2VjdXJpdHktZW1ibGVtXCI+PFNoaWVsZENoZWNrIHNpemU9ezU0fS8+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJzZWN1cml0eS1jb3B5XCI+PGgyPlNlY3VyaXR5ICZhbXA7IFJlbGlhYmlsaXR5PC9oMj48cD5CdWlsdCB3aXRoIGluZHVzdHJ5IGJlc3QgcHJhY3RpY2VzIHRvIGhlbHAga2VlcCB5b3VyIG1vbmV5IGFuZCBkYXRhIHNhZmUuPC9wPjxkaXYgY2xhc3NOYW1lPVwic2VjdXJpdHktcG9pbnRzXCI+e1tcIkpXVCBBdXRoZW50aWNhdGlvblwiLFwiSW5wdXQgVmFsaWRhdGlvblwiLFwiUmF0ZSBMaW1pdGluZ1wiLFwiQXVkaXQgTG9nZ2luZ1wiLFwiSWRlbXBvdGVuY3lcIl0ubWFwKHg9PjxzcGFuIGtleT17eH0+PFNoaWVsZENoZWNrIHNpemU9ezEzfS8+e3h9PC9zcGFuPil9PC9kaXY+PC9kaXY+PC9zZWN0aW9uPlxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInRlY2hub2xvZ3ktc2VjdGlvblwiPjxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1oZWFkaW5nXCI+PGgyPlRlY2hub2xvZ3kgU3RhY2s8L2gyPjxzcGFuLz48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInRlY2gtZ3JpZFwiPntbWyBcIlJlYWN0XCIsXCJGcm9udGVuZFwiLCBcIuKam1wiIF0sW1wiTm9kZS5qc1wiLFwiQmFja2VuZFwiLFwi4qyhXCJdLFtcIlByaXNtYVwiLFwiT1JNXCIsXCLil4hcIl0sW1wiUG9zdGdyZVNRTFwiLFwiRGF0YWJhc2VcIixcIvCfkJhcIl0sW1wiUmVkaXNcIixcIkNhY2hpbmdcIixcIuKWsFwiXSxbXCJEb2NrZXJcIixcIkRlcGxveW1lbnRcIixcIvCfkLNcIl0sW1wiQVdTXCIsXCJDbG91ZCwgUGxhbm5lZFwiLFwiYXdzXCJdXS5tYXAoKFtuYW1lLHN1YixtYXJrXSk9PjxkaXYgY2xhc3NOYW1lPVwidGVjaC1jYXJkXCIga2V5PXtuYW1lfT48c3Ryb25nIGNsYXNzTmFtZT17YHRlY2gtbWFyayB0ZWNoLSR7bmFtZS50b0xvd2VyQ2FzZSgpfWB9PnttYXJrfTwvc3Ryb25nPjxiPntuYW1lfTwvYj48c21hbGw+KHtzdWJ9KTwvc21hbGw+PC9kaXY+KX08L2Rpdj48L3NlY3Rpb24+XG4gICAgPHNlY3Rpb24gaWQ9XCJjb250YWN0XCIgY2xhc3NOYW1lPVwiYWJvdXQtY3RhXCI+PGRpdj48aDI+UmVhZHkgdG8gZ2V0IHN0YXJ0ZWQ/PC9oMj48cD5FeHBsb3JlIHRoZSBwbGF0Zm9ybSB3aXRoIGEgZGVtbyBhY2NvdW50LjwvcD48L2Rpdj48TGluayBjbGFzc05hbWU9XCJwcmltYXJ5LWFjdGlvblwiIHRvPVwiL3JlZ2lzdGVyXCI+Q3JlYXRlIGFuIEFjY291bnQgPEFycm93VXBSaWdodCBzaXplPXsxNn0vPjwvTGluaz48L3NlY3Rpb24+XG4gIDwvZGl2Pjtcbn1cbmZ1bmN0aW9uIExhbmRtYXJrSWxsdXN0cmF0aW9uKCl7cmV0dXJuIDxzdmcgdmlld0JveD1cIjAgMCAxNTAgMTEwXCI+PHBhdGggZD1cIk04IDMyIDc1IDVsNjcgMjdIOFpcIiBmaWxsPVwiY3VycmVudENvbG9yXCIvPjxwYXRoIGQ9XCJNMTcgMzhoMTE2djhIMTd6TTI2IDQ5aDEzdjQ1SDI2ek01NiA0OWgxM3Y0NUg1NnpNODYgNDloMTN2NDVIODZ6TTExNiA0OWgxM3Y0NWgtMTN6TTEyIDk2aDEyNnY5SDEyelwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIi8+PC9zdmc+fVxuIl0sImZpbGUiOiJEOi9OZXdfZm9sZGVyXygyKS9Tb2Z0d2FyZSBkZXZlbG9wbWVudCBQcm9qZWN0L2JhbmtpbmctcGxhdGZyb20vZnJvbnRlbmQvYmFua2luZy1wbGF0Zm9ybS1mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHVibGljL3BhZ2VzL0Fib3V0UGFnZS50c3gifQ==