import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/PortalLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];
import { NavLink, Outlet, useNavigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import {
  Activity,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  Bell,
  Building2,
  ChevronDown,
  CircleHelp,
  ClipboardList,
  FileClock,
  FileText,
  Gauge,
  Globe2,
  Home,
  Landmark,
  LogOut,
  Menu,
  Moon,
  Search,
  Settings,
  Shield,
  ShieldAlert,
  Sun,
  Users,
  Wallet,
  X,
  UserRound
} from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { useAuth } from "/src/app/providers/AuthProvider.tsx";
import { useTheme } from "/src/app/providers/ThemeProvider.tsx";
const roleLabels = { CUSTOMER: "Customer", ADMIN: "Admin", SUPPORT: "Support", AUDITOR: "Auditor" };
const navByRole = {
  CUSTOMER: [
    ["Dashboard", "/customer/dashboard", Gauge],
    ["My Accounts", "/customer/accounts", Wallet],
    ["Transactions", "/customer/transactions", ArrowLeftRight],
    ["Deposit", "/customer/deposit", ArrowDownLeft],
    ["Withdrawal", "/customer/withdrawal", ArrowUpRight],
    ["Transfer Money", "/customer/transfer", ArrowLeftRight],
    ["Beneficiaries", "/customer/beneficiaries", Users],
    ["Notifications", "/customer/notifications", Bell],
    ["Decision Explanations", "/customer/decision-explanations", FileText],
    ["Profile & Settings", "/customer/profile", Settings]
  ],
  ADMIN: [
    ["Admin Dashboard", "/admin/dashboard", Gauge],
    ["Users & Status", "/admin/users", Users],
    ["Accounts", "/admin/accounts", Wallet],
    ["Transactions", "/admin/transactions", ArrowLeftRight],
    ["Currencies", "/admin/currencies", Globe2],
    ["Exchange Rates", "/admin/exchange-rates", Activity],
    ["Currency Reserves", "/admin/reserves", Building2],
    ["FX Approvals", "/admin/fx-approvals", ClipboardList],
    ["Risk Reviews", "/admin/risk-reviews", ShieldAlert],
    ["Fraud Management", "/admin/fraud", Shield],
    ["Monitoring", "/admin/monitoring", Activity],
    ["Audit Logs", "/admin/audit-logs", FileClock]
  ],
  SUPPORT: [
    ["Support Dashboard", "/support/dashboard", Gauge],
    ["Customer Lookup", "/support/customers", Users],
    ["Account Assistance", "/support/accounts", Wallet],
    ["Transaction Assistance", "/support/transactions", ArrowLeftRight],
    ["Beneficiary Assistance", "/support/beneficiaries", Users],
    ["Support Tickets", "/support/tickets", FileText],
    ["Support Operations", "/support/operations", Settings],
    ["FX Requests (Read)", "/support/fx-requests", Globe2],
    ["Support Audit Logs", "/support/audit-logs", FileClock]
  ],
  AUDITOR: [
    ["Auditor Dashboard", "/auditor/dashboard", Gauge],
    ["Audit Logs", "/auditor/audit-logs", FileClock],
    ["Transactions (Read)", "/auditor/transactions", ArrowLeftRight],
    ["Account Activity", "/auditor/account-activity", Activity],
    ["Approval Records", "/auditor/approvals", ClipboardList],
    ["FX Requests (Read)", "/auditor/fx-requests", Globe2],
    ["Currencies (Read)", "/auditor/currencies", Globe2],
    ["Reserves (Read)", "/auditor/reserves", Building2]
  ]
};
export function PortalLayout({ role }) {
  _s();
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const items = useMemo(() => navByRole[role], [role]);
  const displayName = String(user?.name ?? user?.fullName ?? user?.email ?? "Account User");
  async function handleLogout() {
    setLoggingOut(true);
    try {
      await logout();
      toast.success("You have been signed out.");
    } catch {
      toast.error("Signed out locally. The server could not confirm token revocation.");
    } finally {
      setLoggingOut(false);
      navigate("/login", { replace: true });
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: `portal-shell portal-${role.toLowerCase()}`, children: [
    mobileOpen && /* @__PURE__ */ jsxDEV("button", { className: "sidebar-scrim", "aria-label": "Close navigation menu", onClick: () => setMobileOpen(false) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 62,
      columnNumber: 20
    }, this),
    /* @__PURE__ */ jsxDEV("aside", { className: `portal-sidebar ${mobileOpen ? "is-open" : ""}`, "aria-label": `${roleLabels[role]} navigation`, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "portal-brand", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "portal-brand-mark", children: /* @__PURE__ */ jsxDEV(Landmark, { size: 21 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 64,
          columnNumber: 73
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 64,
          columnNumber: 37
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Banking Platform" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 64,
            columnNumber: 108
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Secure • Smart • Reliable" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 64,
            columnNumber: 141
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 64,
          columnNumber: 102
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "icon-button mobile-close", onClick: () => setMobileOpen(false), "aria-label": "Close menu", children: /* @__PURE__ */ jsxDEV(X, { size: 19 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 64,
          columnNumber: 294
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 64,
          columnNumber: 188
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 64,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "sidebar-role-label", children: [
        roleLabels[role],
        " Portal"
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 65,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { className: "portal-nav", children: items.map(([label, path, Icon]) => /* @__PURE__ */ jsxDEV(NavLink, { to: path, end: path.endsWith("dashboard"), onClick: () => setMobileOpen(false), className: ({ isActive }) => `portal-nav-link${isActive ? " active" : ""}`, children: [
        /* @__PURE__ */ jsxDEV(Icon, { size: 17 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 67,
          columnNumber: 221
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: label }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 67,
          columnNumber: 239
        }, this)
      ] }, path, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 67,
        columnNumber: 45
      }, this)) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 66,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "portal-sidebar-bottom", children: [
        role !== "CUSTOMER" && /* @__PURE__ */ jsxDEV(NavLink, { to: "/customer/dashboard", className: "portal-nav-link", children: [
          /* @__PURE__ */ jsxDEV(Home, { size: 17 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 70,
            columnNumber: 95
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Back to App" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 70,
            columnNumber: 113
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 70,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "portal-logout", onClick: () => void handleLogout(), disabled: loggingOut, children: [
          /* @__PURE__ */ jsxDEV(LogOut, { size: 17 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 71,
            columnNumber: 101
          }, this),
          loggingOut ? "Signing out…" : "Log Out"
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 71,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 69,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 63,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "portal-main", children: [
      /* @__PURE__ */ jsxDEV("header", { className: "portal-header", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "portal-header-title", children: [
          /* @__PURE__ */ jsxDEV("button", { className: "icon-button mobile-menu", onClick: () => setMobileOpen(true), "aria-label": "Open navigation menu", children: /* @__PURE__ */ jsxDEV(Menu, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 76,
            columnNumber: 160
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 76,
            columnNumber: 46
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "header-kicker", children: [
              roleLabels[role],
              " workspace"
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 76,
              columnNumber: 182
            }, this),
            /* @__PURE__ */ jsxDEV("strong", { children: location.pathname.split("/").filter(Boolean).at(-1)?.replaceAll("-", " ")?.replace(/^./, (c) => c.toUpperCase()) ?? roleLabels[role] }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 76,
              columnNumber: 249
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 76,
            columnNumber: 177
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 76,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "portal-header-actions", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "portal-search", children: [
            /* @__PURE__ */ jsxDEV(Search, { size: 16 }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 78,
              columnNumber: 44
            }, this),
            /* @__PURE__ */ jsxDEV("input", { "aria-label": "Search this workspace", placeholder: "Search accounts, transactions, or help…" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 78,
              columnNumber: 64
            }, this),
            /* @__PURE__ */ jsxDEV("kbd", { children: "Ctrl + K" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 78,
              columnNumber: 162
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 78,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "icon-button", "aria-label": "Notifications", onClick: () => navigate(role === "CUSTOMER" ? "/customer/notifications" : `/${role.toLowerCase()}/dashboard`), children: [
            /* @__PURE__ */ jsxDEV(Bell, { size: 18 }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 79,
              columnNumber: 181
            }, this),
            /* @__PURE__ */ jsxDEV("i", { className: "notification-dot" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 79,
              columnNumber: 199
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 79,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "icon-button", onClick: toggleTheme, "aria-label": `Switch to ${theme === "light" ? "dark" : "light"} theme`, children: theme === "light" ? /* @__PURE__ */ jsxDEV(Moon, { size: 18 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 80,
            columnNumber: 157
          }, this) : /* @__PURE__ */ jsxDEV(Sun, { size: 18 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 80,
            columnNumber: 178
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 80,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "profile-wrap", children: [
            /* @__PURE__ */ jsxDEV("button", { className: "profile-trigger", "aria-expanded": profileOpen, onClick: () => setProfileOpen((v) => !v), children: [
              /* @__PURE__ */ jsxDEV("span", { className: "avatar", children: displayName.split(/\s+/).map((x) => x[0]).slice(0, 2).join("").toUpperCase() }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                lineNumber: 82,
                columnNumber: 119
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "profile-copy", children: [
                /* @__PURE__ */ jsxDEV("strong", { children: displayName }, void 0, false, {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                  lineNumber: 82,
                  columnNumber: 260
                }, this),
                /* @__PURE__ */ jsxDEV("small", { children: roleLabels[role] }, void 0, false, {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                  lineNumber: 82,
                  columnNumber: 290
                }, this)
              ] }, void 0, true, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                lineNumber: 82,
                columnNumber: 229
              }, this),
              /* @__PURE__ */ jsxDEV(ChevronDown, { size: 16 }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                lineNumber: 82,
                columnNumber: 330
              }, this)
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 82,
              columnNumber: 13
            }, this),
            profileOpen && /* @__PURE__ */ jsxDEV("div", { className: "profile-menu", children: [
              /* @__PURE__ */ jsxDEV("button", { onClick: () => {
                setProfileOpen(false);
                navigate(`/${role.toLowerCase()}/profile`);
              }, children: [
                /* @__PURE__ */ jsxDEV(UserRound, { size: 15 }, void 0, false, {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                  lineNumber: 83,
                  columnNumber: 151
                }, this),
                " Profile"
              ] }, void 0, true, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                lineNumber: 83,
                columnNumber: 59
              }, this),
              /* @__PURE__ */ jsxDEV("button", { onClick: () => void handleLogout(), children: [
                /* @__PURE__ */ jsxDEV(LogOut, { size: 15 }, void 0, false, {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                  lineNumber: 83,
                  columnNumber: 235
                }, this),
                " Log out"
              ] }, void 0, true, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
                lineNumber: 83,
                columnNumber: 191
              }, this)
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 83,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 81,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 77,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 75,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 87,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 74,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
    lineNumber: 61,
    columnNumber: 10
  }, this);
}
_s(PortalLayout, "jxNeR/NNW+duimXZQlGZDDGDdTU=", false, function() {
  return [useAuth, useTheme, useNavigate, useLocation];
});
_c = PortalLayout;
export function PortalDashboard({ role }) {
  const copy = {
    CUSTOMER: { title: "Dashboard", subtitle: "Your money, accounts and everyday banking at a glance.", metrics: [["Total Balance", "৳ 125,430.75"], ["Active Accounts", "3"], ["This Month In", "৳ 86,500.00"], ["This Month Out", "৳ 42,320.00"]], links: [["Transfer Money", "/customer/transfer"], ["My Accounts", "/customer/accounts"], ["Transactions", "/customer/transactions"]] },
    ADMIN: { title: "Admin Dashboard", subtitle: "Overview of users, accounts, transactions, FX requests, risks and system health.", metrics: [["Total Users", "—"], ["Total Accounts", "—"], ["Total Transactions", "—"], ["Fraud Alerts", "—"]], links: [["Users & Status", "/admin/users"], ["Transactions", "/admin/transactions"], ["Audit Logs", "/admin/audit-logs"]] },
    SUPPORT: { title: "Support Dashboard", subtitle: "Customer assistance, case operations and support activities overview.", metrics: [["Total Tickets", "—"], ["Resolved", "—"], ["In Progress", "—"], ["Escalated", "—"]], links: [["Customer Lookup", "/support/customers"], ["Support Tickets", "/support/tickets"], ["Support Operations", "/support/operations"]] },
    AUDITOR: { title: "Auditor Dashboard", subtitle: "Read-only overview of critical system, user and approval activities.", metrics: [["Total Logs", "—"], ["Success", "—"], ["Warning", "—"], ["Failed / Blocked", "—"]], links: [["Audit Logs", "/auditor/audit-logs"], ["Transaction Review", "/auditor/transactions"], ["Approval Records", "/auditor/approvals"]] }
  }[role];
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "portal-page-heading", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { className: "eyebrow", children: [
          roleLabels[role],
          " OVERVIEW"
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 99,
          columnNumber: 88
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: copy.title }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 99,
          columnNumber: 142
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "muted", children: copy.subtitle }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 99,
          columnNumber: 163
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 99,
        columnNumber: 83
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "demo-tag", children: "Demo dashboard · API data integration pending" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 99,
        columnNumber: 209
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 99,
      columnNumber: 46
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "portal-metrics", children: copy.metrics.map(([label, value], i) => /* @__PURE__ */ jsxDEV("article", { className: "portal-card metric-card", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "metric-icon", children: [/* @__PURE__ */ jsxDEV(Wallet, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 100,
        columnNumber: 163
      }, this), /* @__PURE__ */ jsxDEV(Users, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 100,
        columnNumber: 175
      }, this), /* @__PURE__ */ jsxDEV(ArrowLeftRight, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 100,
        columnNumber: 186
      }, this), /* @__PURE__ */ jsxDEV(ShieldAlert, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 100,
        columnNumber: 206
      }, this)][i] }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 100,
        columnNumber: 132
      }, this),
      /* @__PURE__ */ jsxDEV("span", { children: label }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 100,
        columnNumber: 232
      }, this),
      /* @__PURE__ */ jsxDEV("strong", { children: value }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 100,
        columnNumber: 252
      }, this)
    ] }, label, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 100,
      columnNumber: 75
    }, this)) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 100,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "portal-dashboard-grid", children: [
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card overview-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "portal-card-heading", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { children: role === "CUSTOMER" ? "Balance Overview" : role === "SUPPORT" ? "Ticket Activity" : role === "AUDITOR" ? "Audit Activity" : "Platform Activity" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 101,
              columnNumber: 130
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Workspace overview" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 101,
              columnNumber: 284
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 101,
            columnNumber: 125
          }, this),
          /* @__PURE__ */ jsxDEV(Activity, { size: 19 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 101,
            columnNumber: 315
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 101,
          columnNumber: 88
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "empty-chart", children: /* @__PURE__ */ jsxDEV("div", { className: "chart-placeholder", children: [
          /* @__PURE__ */ jsxDEV(Activity, { size: 28 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 101,
            columnNumber: 407
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: "Live analytics will appear here when dashboard APIs are connected." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 101,
            columnNumber: 429
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 101,
          columnNumber: 372
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 101,
          columnNumber: 343
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 101,
        columnNumber: 41
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card quick-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "portal-card-heading", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { children: "Quick Access" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 102,
              columnNumber: 88
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Frequently used workspace pages" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
              lineNumber: 102,
              columnNumber: 109
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 102,
            columnNumber: 83
          }, this),
          /* @__PURE__ */ jsxDEV(CircleHelp, { size: 19 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 102,
            columnNumber: 153
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 102,
          columnNumber: 46
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "quick-link-list", children: copy.links.map(([label, path]) => /* @__PURE__ */ jsxDEV("a", { href: path, className: "quick-link", children: [
          /* @__PURE__ */ jsxDEV("span", { children: label }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 102,
            columnNumber: 300
          }, this),
          /* @__PURE__ */ jsxDEV("span", { "aria-hidden": "true", children: "→" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
            lineNumber: 102,
            columnNumber: 320
          }, this)
        ] }, path, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 102,
          columnNumber: 251
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
          lineNumber: 102,
          columnNumber: 183
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 102,
        columnNumber: 2
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 101,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "demo-disclaimer", children: "Portfolio demonstration interface. Figures shown as placeholders are not live banking balances." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 103,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
    lineNumber: 99,
    columnNumber: 10
  }, this);
}
_c2 = PortalDashboard;
export function PlaceholderPage({ title, description }) {
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "portal-page-heading", children: /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "eyebrow", children: "WORKSPACE" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 107,
        columnNumber: 88
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: title }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 107,
        columnNumber: 124
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "muted", children: description ?? "This page is scaffolded for the next implementation phase." }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 107,
        columnNumber: 140
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 107,
      columnNumber: 83
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 107,
      columnNumber: 46
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card placeholder-panel", children: [
      /* @__PURE__ */ jsxDEV(Activity, { size: 28 }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 107,
        columnNumber: 305
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: title }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 107,
        columnNumber: 327
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Navigation and role protection are active. Detailed page functionality will be implemented in its designated phase." }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
        lineNumber: 107,
        columnNumber: 343
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
      lineNumber: 107,
      columnNumber: 254
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx",
    lineNumber: 107,
    columnNumber: 10
  }, this);
}
_c3 = PlaceholderPage;
var _c, _c2, _c3;
$RefreshReg$(_c, "PortalLayout");
$RefreshReg$(_c2, "PortalDashboard");
$RefreshReg$(_c3, "PlaceholderPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/layout/PortalLayout.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRtQjs7QUE3RG5CLFNBQVNBLFNBQVNDLGdCQUFnQjtBQUNsQyxTQUFTQyxTQUFTQyxRQUFRQyxhQUFhQyxtQkFBbUI7QUFDMUQ7QUFBQSxFQUNFQztBQUFBQSxFQUFVQztBQUFBQSxFQUFlQztBQUFBQSxFQUFjQztBQUFBQSxFQUFnQkM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBV0M7QUFBQUEsRUFBYUM7QUFBQUEsRUFBWUM7QUFBQUEsRUFDaEdDO0FBQUFBLEVBQVdDO0FBQUFBLEVBQVVDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQVNDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQVVDO0FBQUFBLEVBQ3REQztBQUFBQSxFQUFNQztBQUFBQSxFQUFNQztBQUFBQSxFQUFRQztBQUFBQSxFQUFVQztBQUFBQSxFQUFRQztBQUFBQSxFQUFhQztBQUFBQSxFQUFLQztBQUFBQSxFQUFPQztBQUFBQSxFQUFRQztBQUFBQSxFQUFHQztBQUFBQSxPQUNyRTtBQUNQLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxnQkFBZ0I7QUFJekIsTUFBTUMsYUFBd0MsRUFBRUMsVUFBUyxZQUFZQyxPQUFNLFNBQVNDLFNBQVEsV0FBV0MsU0FBUSxVQUFVO0FBQ3pILE1BQU1DLFlBQVk7QUFBQSxFQUNoQkosVUFBVTtBQUFBLElBQ1IsQ0FBQyxhQUFZLHVCQUFzQnBCLEtBQUs7QUFBQSxJQUFFLENBQUMsZUFBYyxzQkFBcUJhLE1BQU07QUFBQSxJQUNwRixDQUFDLGdCQUFlLDBCQUF5QnJCLGNBQWM7QUFBQSxJQUFFLENBQUMsV0FBVSxxQkFBb0JGLGFBQWE7QUFBQSxJQUFFLENBQUMsY0FBYSx3QkFBdUJDLFlBQVk7QUFBQSxJQUFFLENBQUMsa0JBQWlCLHNCQUFxQkMsY0FBYztBQUFBLElBQy9NLENBQUMsaUJBQWdCLDJCQUEwQm9CLEtBQUs7QUFBQSxJQUFFLENBQUMsaUJBQWdCLDJCQUEwQm5CLElBQUk7QUFBQSxJQUNqRyxDQUFDLHlCQUF3QixtQ0FBa0NNLFFBQVE7QUFBQSxJQUFFLENBQUMsc0JBQXFCLHFCQUFvQlMsUUFBUTtBQUFBLEVBQUM7QUFBQSxFQUUxSGEsT0FBTztBQUFBLElBQ0wsQ0FBQyxtQkFBa0Isb0JBQW1CckIsS0FBSztBQUFBLElBQUUsQ0FBQyxrQkFBaUIsZ0JBQWVZLEtBQUs7QUFBQSxJQUNuRixDQUFDLFlBQVcsbUJBQWtCQyxNQUFNO0FBQUEsSUFBRSxDQUFDLGdCQUFlLHVCQUFzQnJCLGNBQWM7QUFBQSxJQUMxRixDQUFDLGNBQWEscUJBQW9CUyxNQUFNO0FBQUEsSUFBRSxDQUFDLGtCQUFpQix5QkFBd0JaLFFBQVE7QUFBQSxJQUM1RixDQUFDLHFCQUFvQixtQkFBa0JLLFNBQVM7QUFBQSxJQUFFLENBQUMsZ0JBQWUsdUJBQXNCRyxhQUFhO0FBQUEsSUFDckcsQ0FBQyxnQkFBZSx1QkFBc0JhLFdBQVc7QUFBQSxJQUFFLENBQUMsb0JBQW1CLGdCQUFlRCxNQUFNO0FBQUEsSUFDNUYsQ0FBQyxjQUFhLHFCQUFvQnBCLFFBQVE7QUFBQSxJQUFFLENBQUMsY0FBYSxxQkFBb0JTLFNBQVM7QUFBQSxFQUFDO0FBQUEsRUFFMUZ3QixTQUFTO0FBQUEsSUFDUCxDQUFDLHFCQUFvQixzQkFBcUJ0QixLQUFLO0FBQUEsSUFBRSxDQUFDLG1CQUFrQixzQkFBcUJZLEtBQUs7QUFBQSxJQUM5RixDQUFDLHNCQUFxQixxQkFBb0JDLE1BQU07QUFBQSxJQUFFLENBQUMsMEJBQXlCLHlCQUF3QnJCLGNBQWM7QUFBQSxJQUNsSCxDQUFDLDBCQUF5QiwwQkFBeUJvQixLQUFLO0FBQUEsSUFBRSxDQUFDLG1CQUFrQixvQkFBbUJiLFFBQVE7QUFBQSxJQUN4RyxDQUFDLHNCQUFxQix1QkFBc0JTLFFBQVE7QUFBQSxJQUFFLENBQUMsc0JBQXFCLHdCQUF1QlAsTUFBTTtBQUFBLElBQ3pHLENBQUMsc0JBQXFCLHVCQUFzQkgsU0FBUztBQUFBLEVBQUM7QUFBQSxFQUV4RHlCLFNBQVM7QUFBQSxJQUNQLENBQUMscUJBQW9CLHNCQUFxQnZCLEtBQUs7QUFBQSxJQUFFLENBQUMsY0FBYSx1QkFBc0JGLFNBQVM7QUFBQSxJQUM5RixDQUFDLHVCQUFzQix5QkFBd0JOLGNBQWM7QUFBQSxJQUFFLENBQUMsb0JBQW1CLDZCQUE0QkgsUUFBUTtBQUFBLElBQ3ZILENBQUMsb0JBQW1CLHNCQUFxQlEsYUFBYTtBQUFBLElBQUUsQ0FBQyxzQkFBcUIsd0JBQXVCSSxNQUFNO0FBQUEsSUFDM0csQ0FBQyxxQkFBb0IsdUJBQXNCQSxNQUFNO0FBQUEsSUFBRSxDQUFDLG1CQUFrQixxQkFBb0JQLFNBQVM7QUFBQSxFQUFDO0FBRXhHO0FBRU8sZ0JBQVMrQixhQUFhLEVBQUVDLEtBQTJCLEdBQUc7QUFBQUMsS0FBQTtBQUMzRCxRQUFNLEVBQUVDLE1BQU1DLE9BQU8sSUFBSVosUUFBUTtBQUNqQyxRQUFNLEVBQUVhLE9BQU9DLFlBQVksSUFBSWIsU0FBUztBQUN4QyxRQUFNYyxXQUFXN0MsWUFBWTtBQUM3QixRQUFNOEMsV0FBVzdDLFlBQVk7QUFDN0IsUUFBTSxDQUFDOEMsWUFBV0MsYUFBYSxJQUFJbkQsU0FBUyxLQUFLO0FBQ2pELFFBQU0sQ0FBQ29ELGFBQVlDLGNBQWMsSUFBSXJELFNBQVMsS0FBSztBQUNuRCxRQUFNLENBQUNzRCxZQUFXQyxhQUFhLElBQUl2RCxTQUFTLEtBQUs7QUFDakQsUUFBTXdELFFBQVF6RCxRQUFRLE1BQU15QyxVQUFVRSxJQUFJLEdBQUcsQ0FBQ0EsSUFBSSxDQUFDO0FBQ25ELFFBQU1lLGNBQWNDLE9BQU9kLE1BQU1lLFFBQVFmLE1BQU1nQixZQUFZaEIsTUFBTWlCLFNBQVMsY0FBYztBQUN4RixpQkFBZUMsZUFBZTtBQUM1QlAsa0JBQWMsSUFBSTtBQUNsQixRQUFJO0FBQUUsWUFBTVYsT0FBTztBQUFHYixZQUFNK0IsUUFBUSwyQkFBMkI7QUFBQSxJQUFHLFFBQzVEO0FBQUUvQixZQUFNZ0MsTUFBTSxvRUFBb0U7QUFBQSxJQUFHLFVBQUM7QUFDbEZULG9CQUFjLEtBQUs7QUFBR1AsZUFBUyxVQUFTLEVBQUNpQixTQUFRLEtBQUksQ0FBQztBQUFBLElBQUc7QUFBQSxFQUNyRTtBQUNBLFNBQU8sdUJBQUMsU0FBSSxXQUFXLHVCQUF1QnZCLEtBQUt3QixZQUFZLENBQUMsSUFDN0RoQjtBQUFBQSxrQkFBYyx1QkFBQyxZQUFPLFdBQVUsaUJBQWdCLGNBQVcseUJBQXdCLFNBQVMsTUFBSUMsY0FBYyxLQUFLLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUc7QUFBQSxJQUN0SCx1QkFBQyxXQUFNLFdBQVcsa0JBQWtCRCxhQUFXLFlBQVUsRUFBRSxJQUFJLGNBQVksR0FBR2YsV0FBV08sSUFBSSxDQUFDLGVBQzVGO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHFCQUFvQixpQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQixLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsUUFBTyx1QkFBQyxVQUFLO0FBQUEsaUNBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLFVBQVMsdUJBQUMsV0FBTSx5Q0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLGFBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxRQUFPLHVCQUFDLFlBQU8sV0FBVSw0QkFBMkIsU0FBUyxNQUFJUyxjQUFjLEtBQUssR0FBRyxjQUFXLGNBQWEsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFZLEtBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0g7QUFBQSxXQUExUztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1UO0FBQUEsTUFDblQsdUJBQUMsU0FBSSxXQUFVLHNCQUFzQmhCO0FBQUFBLG1CQUFXTyxJQUFJO0FBQUEsUUFBRTtBQUFBLFdBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxNQUM3RCx1QkFBQyxTQUFJLFdBQVUsY0FDWmMsZ0JBQU1XLElBQUksQ0FBQyxDQUFDQyxPQUFNQyxNQUFLQyxJQUFJLE1BQUssdUJBQUMsV0FBbUIsSUFBSUQsTUFBTSxLQUFLQSxLQUFLRSxTQUFTLFdBQVcsR0FBRyxTQUFTLE1BQUlwQixjQUFjLEtBQUssR0FBRyxXQUFXLENBQUMsRUFBQ3FCLFNBQVEsTUFBSSxrQkFBa0JBLFdBQVMsWUFBVSxFQUFFLElBQUk7QUFBQSwrQkFBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUFFLHVCQUFDLFVBQU1KLG1CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYTtBQUFBLFdBQXRMQyxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMk0sQ0FBVSxLQUR4UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDWjNCO0FBQUFBLGlCQUFPLGNBQWMsdUJBQUMsV0FBUSxJQUFHLHVCQUFzQixXQUFVLG1CQUFrQjtBQUFBLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUFFLHVCQUFDLFVBQUssMkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUI7QUFBQSxhQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVHO0FBQUEsUUFDN0gsdUJBQUMsWUFBTyxXQUFVLGlCQUFnQixTQUFTLE1BQUksS0FBS29CLGFBQWEsR0FBRyxVQUFVUixZQUFZO0FBQUEsaUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUI7QUFBQSxVQUFHQSxhQUFXLGlCQUFlO0FBQUEsYUFBeEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSjtBQUFBLFdBRnBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFDQSx1QkFBQyxVQUFLLFdBQVUsZUFDZDtBQUFBLDZCQUFDLFlBQU8sV0FBVSxpQkFDaEI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdUJBQXNCO0FBQUEsaUNBQUMsWUFBTyxXQUFVLDJCQUEwQixTQUFTLE1BQUlILGNBQWMsSUFBSSxHQUFHLGNBQVcsd0JBQXVCLGlDQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBSyxLQUFySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1SDtBQUFBLFVBQVMsdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFVBQUssV0FBVSxpQkFBaUJoQjtBQUFBQSx5QkFBV08sSUFBSTtBQUFBLGNBQUU7QUFBQSxpQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQSxZQUFPLHVCQUFDLFlBQVFPLG1CQUFTd0IsU0FBU0MsTUFBTSxHQUFHLEVBQUVDLE9BQU9DLE9BQU8sRUFBRUMsR0FBRyxFQUFFLEdBQUdDLFdBQVcsS0FBSSxHQUFHLEdBQUdiLFFBQVEsTUFBTSxDQUFBYyxNQUFHQSxFQUFFQyxZQUFZLENBQUMsS0FBSzdDLFdBQVdPLElBQUksS0FBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUk7QUFBQSxlQUFqTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwTjtBQUFBLGFBQS9YO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcVk7QUFBQSxRQUNyWSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaUJBQWdCO0FBQUEsbUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQSxZQUFFLHVCQUFDLFdBQU0sY0FBVyx5QkFBd0IsYUFBWSw2Q0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Y7QUFBQSxZQUFFLHVCQUFDLFNBQUksd0JBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYTtBQUFBLGVBQWxLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdLO0FBQUEsVUFDeEssdUJBQUMsWUFBTyxXQUFVLGVBQWMsY0FBVyxpQkFBZ0IsU0FBUyxNQUFJTSxTQUFTTixTQUFPLGFBQVcsNEJBQTBCLElBQUlBLEtBQUt3QixZQUFZLENBQUMsWUFBWSxHQUFHO0FBQUEsbUNBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZTtBQUFBLFlBQUUsdUJBQUMsT0FBRSxXQUFVLHNCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUEsZUFBbE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb047QUFBQSxVQUNwTix1QkFBQyxZQUFPLFdBQVUsZUFBYyxTQUFTbkIsYUFBYSxjQUFZLGFBQWFELFVBQVEsVUFBUSxTQUFPLE9BQU8sVUFBV0Esb0JBQVEsVUFBUSx1QkFBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlLElBQUcsdUJBQUMsT0FBSSxNQUFNLE1BQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYyxLQUF4SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEySztBQUFBLFVBQzNLLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLG1DQUFDLFlBQU8sV0FBVSxtQkFBa0IsaUJBQWVNLGFBQWEsU0FBUyxNQUFJQyxlQUFlLENBQUE0QixNQUFHLENBQUNBLENBQUMsR0FBRztBQUFBLHFDQUFDLFVBQUssV0FBVSxVQUFVeEIsc0JBQVlpQixNQUFNLEtBQUssRUFBRVAsSUFBSSxDQUFBZSxNQUFHQSxFQUFFLENBQUMsQ0FBQyxFQUFFQyxNQUFNLEdBQUUsQ0FBQyxFQUFFQyxLQUFLLEVBQUUsRUFBRUosWUFBWSxLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRztBQUFBLGNBQU8sdUJBQUMsVUFBSyxXQUFVLGdCQUFlO0FBQUEsdUNBQUMsWUFBUXZCLHlCQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFCO0FBQUEsZ0JBQVMsdUJBQUMsV0FBT3RCLHFCQUFXTyxJQUFJLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUEsbUJBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThGO0FBQUEsY0FBTyx1QkFBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0I7QUFBQSxpQkFBeFU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMFU7QUFBQSxZQUN6VVUsZUFBZSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQSxxQ0FBQyxZQUFPLFNBQVMsTUFBSTtBQUFDQywrQkFBZSxLQUFLO0FBQUVMLHlCQUFTLElBQUlOLEtBQUt3QixZQUFZLENBQUMsVUFBVTtBQUFBLGNBQUUsR0FBRztBQUFBLHVDQUFDLGFBQVUsTUFBTSxNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQjtBQUFBLGdCQUFFO0FBQUEsbUJBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdIO0FBQUEsY0FBUyx1QkFBQyxZQUFPLFNBQVMsTUFBSSxLQUFLSixhQUFhLEdBQUc7QUFBQSx1Q0FBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQjtBQUFBLGdCQUFFO0FBQUEsbUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsaUJBQXBPO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZPO0FBQUEsZUFGL1A7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUNBLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsU0FiVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxPQTNCSztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNEJQO0FBQ0Y7QUFBQ25CLEdBN0NlRixjQUFZO0FBQUEsVUFDRFIsU0FDTUMsVUFDZC9CLGFBQ0FDLFdBQVc7QUFBQTtBQUFBLEtBSmRxQztBQStDVCxnQkFBUzRDLGdCQUFnQixFQUFFM0MsS0FBMkIsR0FBRztBQUMvRCxRQUFNNEMsT0FBTztBQUFBLElBQ2JsRCxVQUFTLEVBQUNtRCxPQUFNLGFBQVlDLFVBQVMsMERBQXlEQyxTQUFRLENBQUMsQ0FBQyxpQkFBZ0IsY0FBYyxHQUFFLENBQUMsbUJBQWtCLEdBQUcsR0FBRSxDQUFDLGlCQUFnQixhQUFhLEdBQUUsQ0FBQyxrQkFBaUIsYUFBYSxDQUFDLEdBQUVDLE9BQU0sQ0FBQyxDQUFDLGtCQUFpQixvQkFBb0IsR0FBRSxDQUFDLGVBQWMsb0JBQW9CLEdBQUUsQ0FBQyxnQkFBZSx3QkFBd0IsQ0FBQyxFQUFDO0FBQUEsSUFDaFdyRCxPQUFNLEVBQUNrRCxPQUFNLG1CQUFrQkMsVUFBUyxvRkFBbUZDLFNBQVEsQ0FBQyxDQUFDLGVBQWMsR0FBRyxHQUFFLENBQUMsa0JBQWlCLEdBQUcsR0FBRSxDQUFDLHNCQUFxQixHQUFHLEdBQUUsQ0FBQyxnQkFBZSxHQUFHLENBQUMsR0FBRUMsT0FBTSxDQUFDLENBQUMsa0JBQWlCLGNBQWMsR0FBRSxDQUFDLGdCQUFlLHFCQUFxQixHQUFFLENBQUMsY0FBYSxtQkFBbUIsQ0FBQyxFQUFDO0FBQUEsSUFDblZwRCxTQUFRLEVBQUNpRCxPQUFNLHFCQUFvQkMsVUFBUyx5RUFBd0VDLFNBQVEsQ0FBQyxDQUFDLGlCQUFnQixHQUFHLEdBQUUsQ0FBQyxZQUFXLEdBQUcsR0FBRSxDQUFDLGVBQWMsR0FBRyxHQUFFLENBQUMsYUFBWSxHQUFHLENBQUMsR0FBRUMsT0FBTSxDQUFDLENBQUMsbUJBQWtCLG9CQUFvQixHQUFFLENBQUMsbUJBQWtCLGtCQUFrQixHQUFFLENBQUMsc0JBQXFCLHFCQUFxQixDQUFDLEVBQUM7QUFBQSxJQUMvVW5ELFNBQVEsRUFBQ2dELE9BQU0scUJBQW9CQyxVQUFTLHdFQUF1RUMsU0FBUSxDQUFDLENBQUMsY0FBYSxHQUFHLEdBQUUsQ0FBQyxXQUFVLEdBQUcsR0FBRSxDQUFDLFdBQVUsR0FBRyxHQUFFLENBQUMsb0JBQW1CLEdBQUcsQ0FBQyxHQUFFQyxPQUFNLENBQUMsQ0FBQyxjQUFhLHFCQUFxQixHQUFFLENBQUMsc0JBQXFCLHVCQUF1QixHQUFFLENBQUMsb0JBQW1CLG9CQUFvQixDQUFDLEVBQUM7QUFBQSxFQUM5VSxFQUFFaEQsSUFBSTtBQUNOLFNBQU8sdUJBQUMsYUFBUSxXQUFVLGtCQUFpQjtBQUFBLDJCQUFDLFNBQUksV0FBVSx1QkFBc0I7QUFBQSw2QkFBQyxTQUFJO0FBQUEsK0JBQUMsT0FBRSxXQUFVLFdBQVdQO0FBQUFBLHFCQUFXTyxJQUFJO0FBQUEsVUFBRTtBQUFBLGFBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxRQUFJLHVCQUFDLFFBQUk0QyxlQUFLQyxTQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUFLLHVCQUFDLE9BQUUsV0FBVSxTQUFTRCxlQUFLRSxZQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsV0FBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3SDtBQUFBLE1BQU0sdUJBQUMsVUFBSyxXQUFVLFlBQVcsNkRBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0U7QUFBQSxTQUEzTztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtQO0FBQUEsSUFDN1IsdUJBQUMsU0FBSSxXQUFVLGtCQUFrQkYsZUFBS0csUUFBUXRCLElBQUksQ0FBQyxDQUFDQyxPQUFNdUIsS0FBSyxHQUFFQyxNQUFJLHVCQUFDLGFBQVEsV0FBVSwyQkFBc0M7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZUFBZSxXQUFDLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPLEdBQUcsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU0sR0FBRyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsR0FBRyx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVksQ0FBRSxFQUFFQSxDQUFDLEtBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUY7QUFBQSxNQUFNLHVCQUFDLFVBQU14QixtQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWE7QUFBQSxNQUFPLHVCQUFDLFlBQVF1QixtQkFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxTQUF2SXZCLE9BQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa00sQ0FBVSxLQUFqUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1SO0FBQUEsSUFDblIsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QjtBQUFBLDZCQUFDLGFBQVEsV0FBVSw2QkFBNEI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdUJBQXNCO0FBQUEsaUNBQUMsU0FBSTtBQUFBLG1DQUFDLFFBQUkxQixtQkFBTyxhQUFXLHFCQUFtQkEsU0FBTyxZQUFVLG9CQUFrQkEsU0FBTyxZQUFVLG1CQUFpQix1QkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUk7QUFBQSxZQUFLLHVCQUFDLE9BQUUsa0NBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUI7QUFBQSxlQUFsSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzSztBQUFBLFVBQU0sdUJBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsYUFBcE87QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzTztBQUFBLFFBQU0sdUJBQUMsU0FBSSxXQUFVLGVBQWMsaUNBQUMsU0FBSSxXQUFVLHFCQUFvQjtBQUFBLGlDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQjtBQUFBLFVBQUUsdUJBQUMsVUFBSyxrRkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLGFBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUksS0FBcEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSztBQUFBLFdBQXJjO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMmM7QUFBQSxNQUNsZix1QkFBQyxhQUFRLFdBQVUsMEJBQXlCO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHVCQUFzQjtBQUFBLGlDQUFDLFNBQUk7QUFBQSxtQ0FBQyxRQUFHLDRCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdCO0FBQUEsWUFBSyx1QkFBQyxPQUFFLCtDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsZUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0U7QUFBQSxVQUFNLHVCQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQjtBQUFBLGFBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0k7QUFBQSxRQUFNLHVCQUFDLFNBQUksV0FBVSxtQkFBbUI0QyxlQUFLSSxNQUFNdkIsSUFBSSxDQUFDLENBQUNDLE9BQU1DLElBQUksTUFBSSx1QkFBQyxPQUFhLE1BQU1BLE1BQU0sV0FBVSxjQUFhO0FBQUEsaUNBQUMsVUFBTUQsbUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQU8sdUJBQUMsVUFBSyxlQUFZLFFBQU8saUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsYUFBdkZDLE1BQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRyxDQUFJLEtBQTNLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNks7QUFBQSxXQUFqVztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVXO0FBQUEsU0FEdlc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUNpWDtBQUFBLElBQ2pYLHVCQUFDLE9BQUUsV0FBVSxtQkFBa0IsK0dBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEg7QUFBQSxPQUp2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSTJIO0FBQ25JO0FBQUN3QixNQVplUjtBQWNULGdCQUFTUyxnQkFBZ0IsRUFBRVAsT0FBT1EsWUFBbUQsR0FBRztBQUM5RixTQUFPLHVCQUFDLGFBQVEsV0FBVSxrQkFBaUI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsdUJBQXNCLGlDQUFDLFNBQUk7QUFBQSw2QkFBQyxPQUFFLFdBQVUsV0FBVSx5QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLE1BQUksdUJBQUMsUUFBSVIsbUJBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFBSyx1QkFBQyxPQUFFLFdBQVUsU0FBU1EseUJBQWUsZ0VBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0c7QUFBQSxTQUEzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStKLEtBQXBNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBME07QUFBQSxJQUFNLHVCQUFDLGFBQVEsV0FBVSxpQ0FBZ0M7QUFBQSw2QkFBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQjtBQUFBLE1BQUUsdUJBQUMsUUFBSVIsbUJBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFBSyx1QkFBQyxPQUFFLG1JQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0g7QUFBQSxTQUE5TTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtOO0FBQUEsT0FBdGM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnZDtBQUN4ZDtBQUFDUyxNQUZlRjtBQUFlLElBQUFHLElBQUFKLEtBQUFHO0FBQUEsYUFBQUMsSUFBQTtBQUFBLGFBQUFKLEtBQUE7QUFBQSxhQUFBRyxLQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwiTmF2TGluayIsIk91dGxldCIsInVzZU5hdmlnYXRlIiwidXNlTG9jYXRpb24iLCJBY3Rpdml0eSIsIkFycm93RG93bkxlZnQiLCJBcnJvd1VwUmlnaHQiLCJBcnJvd0xlZnRSaWdodCIsIkJlbGwiLCJCdWlsZGluZzIiLCJDaGV2cm9uRG93biIsIkNpcmNsZUhlbHAiLCJDbGlwYm9hcmRMaXN0IiwiRmlsZUNsb2NrIiwiRmlsZVRleHQiLCJHYXVnZSIsIkdsb2JlMiIsIkhvbWUiLCJMYW5kbWFyayIsIkxvZ091dCIsIk1lbnUiLCJNb29uIiwiU2VhcmNoIiwiU2V0dGluZ3MiLCJTaGllbGQiLCJTaGllbGRBbGVydCIsIlN1biIsIlVzZXJzIiwiV2FsbGV0IiwiWCIsIlVzZXJSb3VuZCIsInRvYXN0IiwidXNlQXV0aCIsInVzZVRoZW1lIiwicm9sZUxhYmVscyIsIkNVU1RPTUVSIiwiQURNSU4iLCJTVVBQT1JUIiwiQVVESVRPUiIsIm5hdkJ5Um9sZSIsIlBvcnRhbExheW91dCIsInJvbGUiLCJfcyIsInVzZXIiLCJsb2dvdXQiLCJ0aGVtZSIsInRvZ2dsZVRoZW1lIiwibmF2aWdhdGUiLCJsb2NhdGlvbiIsIm1vYmlsZU9wZW4iLCJzZXRNb2JpbGVPcGVuIiwicHJvZmlsZU9wZW4iLCJzZXRQcm9maWxlT3BlbiIsImxvZ2dpbmdPdXQiLCJzZXRMb2dnaW5nT3V0IiwiaXRlbXMiLCJkaXNwbGF5TmFtZSIsIlN0cmluZyIsIm5hbWUiLCJmdWxsTmFtZSIsImVtYWlsIiwiaGFuZGxlTG9nb3V0Iiwic3VjY2VzcyIsImVycm9yIiwicmVwbGFjZSIsInRvTG93ZXJDYXNlIiwibWFwIiwibGFiZWwiLCJwYXRoIiwiSWNvbiIsImVuZHNXaXRoIiwiaXNBY3RpdmUiLCJwYXRobmFtZSIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsImF0IiwicmVwbGFjZUFsbCIsImMiLCJ0b1VwcGVyQ2FzZSIsInYiLCJ4Iiwic2xpY2UiLCJqb2luIiwiUG9ydGFsRGFzaGJvYXJkIiwiY29weSIsInRpdGxlIiwic3VidGl0bGUiLCJtZXRyaWNzIiwibGlua3MiLCJ2YWx1ZSIsImkiLCJfYzIiLCJQbGFjZWhvbGRlclBhZ2UiLCJkZXNjcmlwdGlvbiIsIl9jMyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBvcnRhbExheW91dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE5hdkxpbmssIE91dGxldCwgdXNlTmF2aWdhdGUsIHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7XG4gIEFjdGl2aXR5LCBBcnJvd0Rvd25MZWZ0LCBBcnJvd1VwUmlnaHQsIEFycm93TGVmdFJpZ2h0LCBCZWxsLCBCdWlsZGluZzIsIENoZXZyb25Eb3duLCBDaXJjbGVIZWxwLCBDbGlwYm9hcmRMaXN0LFxuICAgRmlsZUNsb2NrLCBGaWxlVGV4dCwgR2F1Z2UsIEdsb2JlMiwgIEhvbWUsIExhbmRtYXJrLCBMb2dPdXQsXG4gIE1lbnUsIE1vb24sIFNlYXJjaCwgU2V0dGluZ3MsIFNoaWVsZCwgU2hpZWxkQWxlcnQsIFN1biwgVXNlcnMsIFdhbGxldCwgWCwgVXNlclJvdW5kLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCJzb25uZXJcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vYXBwL3Byb3ZpZGVycy9BdXRoUHJvdmlkZXJcIjtcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSBcIi4uLy4uL2FwcC9wcm92aWRlcnMvVGhlbWVQcm92aWRlclwiO1xuXG5cbnR5cGUgUG9ydGFsUm9sZSA9IFwiQ1VTVE9NRVJcIiB8IFwiQURNSU5cIiB8IFwiU1VQUE9SVFwiIHwgXCJBVURJVE9SXCI7XG5jb25zdCByb2xlTGFiZWxzOiBSZWNvcmQ8UG9ydGFsUm9sZSxzdHJpbmc+ID0geyBDVVNUT01FUjpcIkN1c3RvbWVyXCIsIEFETUlOOlwiQWRtaW5cIiwgU1VQUE9SVDpcIlN1cHBvcnRcIiwgQVVESVRPUjpcIkF1ZGl0b3JcIiB9O1xuY29uc3QgbmF2QnlSb2xlID0ge1xuICBDVVNUT01FUjogW1xuICAgIFtcIkRhc2hib2FyZFwiLFwiL2N1c3RvbWVyL2Rhc2hib2FyZFwiLEdhdWdlXSxbXCJNeSBBY2NvdW50c1wiLFwiL2N1c3RvbWVyL2FjY291bnRzXCIsV2FsbGV0XSxcbiAgICBbXCJUcmFuc2FjdGlvbnNcIixcIi9jdXN0b21lci90cmFuc2FjdGlvbnNcIixBcnJvd0xlZnRSaWdodF0sW1wiRGVwb3NpdFwiLFwiL2N1c3RvbWVyL2RlcG9zaXRcIixBcnJvd0Rvd25MZWZ0XSxbXCJXaXRoZHJhd2FsXCIsXCIvY3VzdG9tZXIvd2l0aGRyYXdhbFwiLEFycm93VXBSaWdodF0sW1wiVHJhbnNmZXIgTW9uZXlcIixcIi9jdXN0b21lci90cmFuc2ZlclwiLEFycm93TGVmdFJpZ2h0XSxcbiAgICBbXCJCZW5lZmljaWFyaWVzXCIsXCIvY3VzdG9tZXIvYmVuZWZpY2lhcmllc1wiLFVzZXJzXSxbXCJOb3RpZmljYXRpb25zXCIsXCIvY3VzdG9tZXIvbm90aWZpY2F0aW9uc1wiLEJlbGxdLFxuICAgIFtcIkRlY2lzaW9uIEV4cGxhbmF0aW9uc1wiLFwiL2N1c3RvbWVyL2RlY2lzaW9uLWV4cGxhbmF0aW9uc1wiLEZpbGVUZXh0XSxbXCJQcm9maWxlICYgU2V0dGluZ3NcIixcIi9jdXN0b21lci9wcm9maWxlXCIsU2V0dGluZ3NdLFxuICBdLFxuICBBRE1JTjogW1xuICAgIFtcIkFkbWluIERhc2hib2FyZFwiLFwiL2FkbWluL2Rhc2hib2FyZFwiLEdhdWdlXSxbXCJVc2VycyAmIFN0YXR1c1wiLFwiL2FkbWluL3VzZXJzXCIsVXNlcnNdLFxuICAgIFtcIkFjY291bnRzXCIsXCIvYWRtaW4vYWNjb3VudHNcIixXYWxsZXRdLFtcIlRyYW5zYWN0aW9uc1wiLFwiL2FkbWluL3RyYW5zYWN0aW9uc1wiLEFycm93TGVmdFJpZ2h0XSxcbiAgICBbXCJDdXJyZW5jaWVzXCIsXCIvYWRtaW4vY3VycmVuY2llc1wiLEdsb2JlMl0sW1wiRXhjaGFuZ2UgUmF0ZXNcIixcIi9hZG1pbi9leGNoYW5nZS1yYXRlc1wiLEFjdGl2aXR5XSxcbiAgICBbXCJDdXJyZW5jeSBSZXNlcnZlc1wiLFwiL2FkbWluL3Jlc2VydmVzXCIsQnVpbGRpbmcyXSxbXCJGWCBBcHByb3ZhbHNcIixcIi9hZG1pbi9meC1hcHByb3ZhbHNcIixDbGlwYm9hcmRMaXN0XSxcbiAgICBbXCJSaXNrIFJldmlld3NcIixcIi9hZG1pbi9yaXNrLXJldmlld3NcIixTaGllbGRBbGVydF0sW1wiRnJhdWQgTWFuYWdlbWVudFwiLFwiL2FkbWluL2ZyYXVkXCIsU2hpZWxkXSxcbiAgICBbXCJNb25pdG9yaW5nXCIsXCIvYWRtaW4vbW9uaXRvcmluZ1wiLEFjdGl2aXR5XSxbXCJBdWRpdCBMb2dzXCIsXCIvYWRtaW4vYXVkaXQtbG9nc1wiLEZpbGVDbG9ja10sXG4gIF0sXG4gIFNVUFBPUlQ6IFtcbiAgICBbXCJTdXBwb3J0IERhc2hib2FyZFwiLFwiL3N1cHBvcnQvZGFzaGJvYXJkXCIsR2F1Z2VdLFtcIkN1c3RvbWVyIExvb2t1cFwiLFwiL3N1cHBvcnQvY3VzdG9tZXJzXCIsVXNlcnNdLFxuICAgIFtcIkFjY291bnQgQXNzaXN0YW5jZVwiLFwiL3N1cHBvcnQvYWNjb3VudHNcIixXYWxsZXRdLFtcIlRyYW5zYWN0aW9uIEFzc2lzdGFuY2VcIixcIi9zdXBwb3J0L3RyYW5zYWN0aW9uc1wiLEFycm93TGVmdFJpZ2h0XSxcbiAgICBbXCJCZW5lZmljaWFyeSBBc3Npc3RhbmNlXCIsXCIvc3VwcG9ydC9iZW5lZmljaWFyaWVzXCIsVXNlcnNdLFtcIlN1cHBvcnQgVGlja2V0c1wiLFwiL3N1cHBvcnQvdGlja2V0c1wiLEZpbGVUZXh0XSxcbiAgICBbXCJTdXBwb3J0IE9wZXJhdGlvbnNcIixcIi9zdXBwb3J0L29wZXJhdGlvbnNcIixTZXR0aW5nc10sW1wiRlggUmVxdWVzdHMgKFJlYWQpXCIsXCIvc3VwcG9ydC9meC1yZXF1ZXN0c1wiLEdsb2JlMl0sXG4gICAgW1wiU3VwcG9ydCBBdWRpdCBMb2dzXCIsXCIvc3VwcG9ydC9hdWRpdC1sb2dzXCIsRmlsZUNsb2NrXSxcbiAgXSxcbiAgQVVESVRPUjogW1xuICAgIFtcIkF1ZGl0b3IgRGFzaGJvYXJkXCIsXCIvYXVkaXRvci9kYXNoYm9hcmRcIixHYXVnZV0sW1wiQXVkaXQgTG9nc1wiLFwiL2F1ZGl0b3IvYXVkaXQtbG9nc1wiLEZpbGVDbG9ja10sXG4gICAgW1wiVHJhbnNhY3Rpb25zIChSZWFkKVwiLFwiL2F1ZGl0b3IvdHJhbnNhY3Rpb25zXCIsQXJyb3dMZWZ0UmlnaHRdLFtcIkFjY291bnQgQWN0aXZpdHlcIixcIi9hdWRpdG9yL2FjY291bnQtYWN0aXZpdHlcIixBY3Rpdml0eV0sXG4gICAgW1wiQXBwcm92YWwgUmVjb3Jkc1wiLFwiL2F1ZGl0b3IvYXBwcm92YWxzXCIsQ2xpcGJvYXJkTGlzdF0sW1wiRlggUmVxdWVzdHMgKFJlYWQpXCIsXCIvYXVkaXRvci9meC1yZXF1ZXN0c1wiLEdsb2JlMl0sXG4gICAgW1wiQ3VycmVuY2llcyAoUmVhZClcIixcIi9hdWRpdG9yL2N1cnJlbmNpZXNcIixHbG9iZTJdLFtcIlJlc2VydmVzIChSZWFkKVwiLFwiL2F1ZGl0b3IvcmVzZXJ2ZXNcIixCdWlsZGluZzJdLFxuICBdLFxufSBzYXRpc2ZpZXMgUmVjb3JkPFBvcnRhbFJvbGUsIFtzdHJpbmcsc3RyaW5nLHR5cGVvZiBHYXVnZV1bXT47XG5cbmV4cG9ydCBmdW5jdGlvbiBQb3J0YWxMYXlvdXQoeyByb2xlIH06IHsgcm9sZTogUG9ydGFsUm9sZSB9KSB7XG4gIGNvbnN0IHsgdXNlciwgbG9nb3V0IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IHsgdGhlbWUsIHRvZ2dsZVRoZW1lIH0gPSB1c2VUaGVtZSgpO1xuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgY29uc3QgW21vYmlsZU9wZW4sc2V0TW9iaWxlT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtwcm9maWxlT3BlbixzZXRQcm9maWxlT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtsb2dnaW5nT3V0LHNldExvZ2dpbmdPdXRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBpdGVtcyA9IHVzZU1lbW8oKCkgPT4gbmF2QnlSb2xlW3JvbGVdLCBbcm9sZV0pO1xuICBjb25zdCBkaXNwbGF5TmFtZSA9IFN0cmluZyh1c2VyPy5uYW1lID8/IHVzZXI/LmZ1bGxOYW1lID8/IHVzZXI/LmVtYWlsID8/IFwiQWNjb3VudCBVc2VyXCIpO1xuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVMb2dvdXQoKSB7XG4gICAgc2V0TG9nZ2luZ091dCh0cnVlKTtcbiAgICB0cnkgeyBhd2FpdCBsb2dvdXQoKTsgdG9hc3Quc3VjY2VzcyhcIllvdSBoYXZlIGJlZW4gc2lnbmVkIG91dC5cIik7IH1cbiAgICBjYXRjaCB7IHRvYXN0LmVycm9yKFwiU2lnbmVkIG91dCBsb2NhbGx5LiBUaGUgc2VydmVyIGNvdWxkIG5vdCBjb25maXJtIHRva2VuIHJldm9jYXRpb24uXCIpOyB9XG4gICAgZmluYWxseSB7IHNldExvZ2dpbmdPdXQoZmFsc2UpOyBuYXZpZ2F0ZShcIi9sb2dpblwiLHtyZXBsYWNlOnRydWV9KTsgfVxuICB9XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT17YHBvcnRhbC1zaGVsbCBwb3J0YWwtJHtyb2xlLnRvTG93ZXJDYXNlKCl9YH0+XG4gICAge21vYmlsZU9wZW4gJiYgPGJ1dHRvbiBjbGFzc05hbWU9XCJzaWRlYmFyLXNjcmltXCIgYXJpYS1sYWJlbD1cIkNsb3NlIG5hdmlnYXRpb24gbWVudVwiIG9uQ2xpY2s9eygpPT5zZXRNb2JpbGVPcGVuKGZhbHNlKX0gLz59XG4gICAgPGFzaWRlIGNsYXNzTmFtZT17YHBvcnRhbC1zaWRlYmFyICR7bW9iaWxlT3Blbj9cImlzLW9wZW5cIjpcIlwifWB9IGFyaWEtbGFiZWw9e2Ake3JvbGVMYWJlbHNbcm9sZV19IG5hdmlnYXRpb25gfT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9ydGFsLWJyYW5kXCI+PHNwYW4gY2xhc3NOYW1lPVwicG9ydGFsLWJyYW5kLW1hcmtcIj48TGFuZG1hcmsgc2l6ZT17MjF9Lz48L3NwYW4+PHNwYW4+PHN0cm9uZz5CYW5raW5nIFBsYXRmb3JtPC9zdHJvbmc+PHNtYWxsPlNlY3VyZSDigKIgU21hcnQg4oCiIFJlbGlhYmxlPC9zbWFsbD48L3NwYW4+PGJ1dHRvbiBjbGFzc05hbWU9XCJpY29uLWJ1dHRvbiBtb2JpbGUtY2xvc2VcIiBvbkNsaWNrPXsoKT0+c2V0TW9iaWxlT3BlbihmYWxzZSl9IGFyaWEtbGFiZWw9XCJDbG9zZSBtZW51XCI+PFggc2l6ZT17MTl9Lz48L2J1dHRvbj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lkZWJhci1yb2xlLWxhYmVsXCI+e3JvbGVMYWJlbHNbcm9sZV19IFBvcnRhbDwvZGl2PlxuICAgICAgPG5hdiBjbGFzc05hbWU9XCJwb3J0YWwtbmF2XCI+XG4gICAgICAgIHtpdGVtcy5tYXAoKFtsYWJlbCxwYXRoLEljb25dKT0+IDxOYXZMaW5rIGtleT17cGF0aH0gdG89e3BhdGh9IGVuZD17cGF0aC5lbmRzV2l0aChcImRhc2hib2FyZFwiKX0gb25DbGljaz17KCk9PnNldE1vYmlsZU9wZW4oZmFsc2UpfSBjbGFzc05hbWU9eyh7aXNBY3RpdmV9KT0+YHBvcnRhbC1uYXYtbGluayR7aXNBY3RpdmU/XCIgYWN0aXZlXCI6XCJcIn1gfT48SWNvbiBzaXplPXsxN30vPjxzcGFuPntsYWJlbH08L3NwYW4+PC9OYXZMaW5rPil9XG4gICAgICA8L25hdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9ydGFsLXNpZGViYXItYm90dG9tXCI+XG4gICAgICAgIHtyb2xlIT09XCJDVVNUT01FUlwiICYmIDxOYXZMaW5rIHRvPVwiL2N1c3RvbWVyL2Rhc2hib2FyZFwiIGNsYXNzTmFtZT1cInBvcnRhbC1uYXYtbGlua1wiPjxIb21lIHNpemU9ezE3fS8+PHNwYW4+QmFjayB0byBBcHA8L3NwYW4+PC9OYXZMaW5rPn1cbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwb3J0YWwtbG9nb3V0XCIgb25DbGljaz17KCk9PnZvaWQgaGFuZGxlTG9nb3V0KCl9IGRpc2FibGVkPXtsb2dnaW5nT3V0fT48TG9nT3V0IHNpemU9ezE3fS8+e2xvZ2dpbmdPdXQ/XCJTaWduaW5nIG91dOKAplwiOlwiTG9nIE91dFwifTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9hc2lkZT5cbiAgICA8bWFpbiBjbGFzc05hbWU9XCJwb3J0YWwtbWFpblwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJwb3J0YWwtaGVhZGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9ydGFsLWhlYWRlci10aXRsZVwiPjxidXR0b24gY2xhc3NOYW1lPVwiaWNvbi1idXR0b24gbW9iaWxlLW1lbnVcIiBvbkNsaWNrPXsoKT0+c2V0TW9iaWxlT3Blbih0cnVlKX0gYXJpYS1sYWJlbD1cIk9wZW4gbmF2aWdhdGlvbiBtZW51XCI+PE1lbnUvPjwvYnV0dG9uPjxkaXY+PHNwYW4gY2xhc3NOYW1lPVwiaGVhZGVyLWtpY2tlclwiPntyb2xlTGFiZWxzW3JvbGVdfSB3b3Jrc3BhY2U8L3NwYW4+PHN0cm9uZz57bG9jYXRpb24ucGF0aG5hbWUuc3BsaXQoXCIvXCIpLmZpbHRlcihCb29sZWFuKS5hdCgtMSk/LnJlcGxhY2VBbGwoXCItXCIsXCIgXCIpPy5yZXBsYWNlKC9eLi8sIGM9PmMudG9VcHBlckNhc2UoKSkgPz8gcm9sZUxhYmVsc1tyb2xlXX08L3N0cm9uZz48L2Rpdj48L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb3J0YWwtaGVhZGVyLWFjdGlvbnNcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwicG9ydGFsLXNlYXJjaFwiPjxTZWFyY2ggc2l6ZT17MTZ9Lz48aW5wdXQgYXJpYS1sYWJlbD1cIlNlYXJjaCB0aGlzIHdvcmtzcGFjZVwiIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGFjY291bnRzLCB0cmFuc2FjdGlvbnMsIG9yIGhlbHDigKZcIi8+PGtiZD5DdHJsICsgSzwva2JkPjwvbGFiZWw+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpY29uLWJ1dHRvblwiIGFyaWEtbGFiZWw9XCJOb3RpZmljYXRpb25zXCIgb25DbGljaz17KCk9Pm5hdmlnYXRlKHJvbGU9PT1cIkNVU1RPTUVSXCI/XCIvY3VzdG9tZXIvbm90aWZpY2F0aW9uc1wiOmAvJHtyb2xlLnRvTG93ZXJDYXNlKCl9L2Rhc2hib2FyZGApfT48QmVsbCBzaXplPXsxOH0vPjxpIGNsYXNzTmFtZT1cIm5vdGlmaWNhdGlvbi1kb3RcIi8+PC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJpY29uLWJ1dHRvblwiIG9uQ2xpY2s9e3RvZ2dsZVRoZW1lfSBhcmlhLWxhYmVsPXtgU3dpdGNoIHRvICR7dGhlbWU9PT1cImxpZ2h0XCI/XCJkYXJrXCI6XCJsaWdodFwifSB0aGVtZWB9Pnt0aGVtZT09PVwibGlnaHRcIj88TW9vbiBzaXplPXsxOH0vPjo8U3VuIHNpemU9ezE4fS8+fTwvYnV0dG9uPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS13cmFwXCI+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInByb2ZpbGUtdHJpZ2dlclwiIGFyaWEtZXhwYW5kZWQ9e3Byb2ZpbGVPcGVufSBvbkNsaWNrPXsoKT0+c2V0UHJvZmlsZU9wZW4odj0+IXYpfT48c3BhbiBjbGFzc05hbWU9XCJhdmF0YXJcIj57ZGlzcGxheU5hbWUuc3BsaXQoL1xccysvKS5tYXAoeD0+eFswXSkuc2xpY2UoMCwyKS5qb2luKFwiXCIpLnRvVXBwZXJDYXNlKCl9PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInByb2ZpbGUtY29weVwiPjxzdHJvbmc+e2Rpc3BsYXlOYW1lfTwvc3Ryb25nPjxzbWFsbD57cm9sZUxhYmVsc1tyb2xlXX08L3NtYWxsPjwvc3Bhbj48Q2hldnJvbkRvd24gc2l6ZT17MTZ9Lz48L2J1dHRvbj5cbiAgICAgICAgICAgIHtwcm9maWxlT3BlbiAmJiA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtbWVudVwiPjxidXR0b24gb25DbGljaz17KCk9PntzZXRQcm9maWxlT3BlbihmYWxzZSk7bmF2aWdhdGUoYC8ke3JvbGUudG9Mb3dlckNhc2UoKX0vcHJvZmlsZWApO319PjxVc2VyUm91bmQgc2l6ZT17MTV9Lz4gUHJvZmlsZTwvYnV0dG9uPjxidXR0b24gb25DbGljaz17KCk9PnZvaWQgaGFuZGxlTG9nb3V0KCl9PjxMb2dPdXQgc2l6ZT17MTV9Lz4gTG9nIG91dDwvYnV0dG9uPjwvZGl2Pn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cbiAgICAgIDxPdXRsZXQvPlxuICAgIDwvbWFpbj5cbiAgPC9kaXY+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gUG9ydGFsRGFzaGJvYXJkKHsgcm9sZSB9OiB7IHJvbGU6IFBvcnRhbFJvbGUgfSkge1xuIGNvbnN0IGNvcHkgPSB7XG4gQ1VTVE9NRVI6e3RpdGxlOlwiRGFzaGJvYXJkXCIsc3VidGl0bGU6XCJZb3VyIG1vbmV5LCBhY2NvdW50cyBhbmQgZXZlcnlkYXkgYmFua2luZyBhdCBhIGdsYW5jZS5cIixtZXRyaWNzOltbXCJUb3RhbCBCYWxhbmNlXCIsXCLgp7MgMTI1LDQzMC43NVwiXSxbXCJBY3RpdmUgQWNjb3VudHNcIixcIjNcIl0sW1wiVGhpcyBNb250aCBJblwiLFwi4KezIDg2LDUwMC4wMFwiXSxbXCJUaGlzIE1vbnRoIE91dFwiLFwi4KezIDQyLDMyMC4wMFwiXV0sbGlua3M6W1tcIlRyYW5zZmVyIE1vbmV5XCIsXCIvY3VzdG9tZXIvdHJhbnNmZXJcIl0sW1wiTXkgQWNjb3VudHNcIixcIi9jdXN0b21lci9hY2NvdW50c1wiXSxbXCJUcmFuc2FjdGlvbnNcIixcIi9jdXN0b21lci90cmFuc2FjdGlvbnNcIl1dfSxcbiBBRE1JTjp7dGl0bGU6XCJBZG1pbiBEYXNoYm9hcmRcIixzdWJ0aXRsZTpcIk92ZXJ2aWV3IG9mIHVzZXJzLCBhY2NvdW50cywgdHJhbnNhY3Rpb25zLCBGWCByZXF1ZXN0cywgcmlza3MgYW5kIHN5c3RlbSBoZWFsdGguXCIsbWV0cmljczpbW1wiVG90YWwgVXNlcnNcIixcIuKAlFwiXSxbXCJUb3RhbCBBY2NvdW50c1wiLFwi4oCUXCJdLFtcIlRvdGFsIFRyYW5zYWN0aW9uc1wiLFwi4oCUXCJdLFtcIkZyYXVkIEFsZXJ0c1wiLFwi4oCUXCJdXSxsaW5rczpbW1wiVXNlcnMgJiBTdGF0dXNcIixcIi9hZG1pbi91c2Vyc1wiXSxbXCJUcmFuc2FjdGlvbnNcIixcIi9hZG1pbi90cmFuc2FjdGlvbnNcIl0sW1wiQXVkaXQgTG9nc1wiLFwiL2FkbWluL2F1ZGl0LWxvZ3NcIl1dfSxcbiBTVVBQT1JUOnt0aXRsZTpcIlN1cHBvcnQgRGFzaGJvYXJkXCIsc3VidGl0bGU6XCJDdXN0b21lciBhc3Npc3RhbmNlLCBjYXNlIG9wZXJhdGlvbnMgYW5kIHN1cHBvcnQgYWN0aXZpdGllcyBvdmVydmlldy5cIixtZXRyaWNzOltbXCJUb3RhbCBUaWNrZXRzXCIsXCLigJRcIl0sW1wiUmVzb2x2ZWRcIixcIuKAlFwiXSxbXCJJbiBQcm9ncmVzc1wiLFwi4oCUXCJdLFtcIkVzY2FsYXRlZFwiLFwi4oCUXCJdXSxsaW5rczpbW1wiQ3VzdG9tZXIgTG9va3VwXCIsXCIvc3VwcG9ydC9jdXN0b21lcnNcIl0sW1wiU3VwcG9ydCBUaWNrZXRzXCIsXCIvc3VwcG9ydC90aWNrZXRzXCJdLFtcIlN1cHBvcnQgT3BlcmF0aW9uc1wiLFwiL3N1cHBvcnQvb3BlcmF0aW9uc1wiXV19LFxuIEFVRElUT1I6e3RpdGxlOlwiQXVkaXRvciBEYXNoYm9hcmRcIixzdWJ0aXRsZTpcIlJlYWQtb25seSBvdmVydmlldyBvZiBjcml0aWNhbCBzeXN0ZW0sIHVzZXIgYW5kIGFwcHJvdmFsIGFjdGl2aXRpZXMuXCIsbWV0cmljczpbW1wiVG90YWwgTG9nc1wiLFwi4oCUXCJdLFtcIlN1Y2Nlc3NcIixcIuKAlFwiXSxbXCJXYXJuaW5nXCIsXCLigJRcIl0sW1wiRmFpbGVkIC8gQmxvY2tlZFwiLFwi4oCUXCJdXSxsaW5rczpbW1wiQXVkaXQgTG9nc1wiLFwiL2F1ZGl0b3IvYXVkaXQtbG9nc1wiXSxbXCJUcmFuc2FjdGlvbiBSZXZpZXdcIixcIi9hdWRpdG9yL3RyYW5zYWN0aW9uc1wiXSxbXCJBcHByb3ZhbCBSZWNvcmRzXCIsXCIvYXVkaXRvci9hcHByb3ZhbHNcIl1dfSxcbiB9W3JvbGVdO1xuIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJwb3J0YWwtY29udGVudFwiPjxkaXYgY2xhc3NOYW1lPVwicG9ydGFsLXBhZ2UtaGVhZGluZ1wiPjxkaXY+PHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPntyb2xlTGFiZWxzW3JvbGVdfSBPVkVSVklFVzwvcD48aDE+e2NvcHkudGl0bGV9PC9oMT48cCBjbGFzc05hbWU9XCJtdXRlZFwiPntjb3B5LnN1YnRpdGxlfTwvcD48L2Rpdj48c3BhbiBjbGFzc05hbWU9XCJkZW1vLXRhZ1wiPkRlbW8gZGFzaGJvYXJkIMK3IEFQSSBkYXRhIGludGVncmF0aW9uIHBlbmRpbmc8L3NwYW4+PC9kaXY+XG4gPGRpdiBjbGFzc05hbWU9XCJwb3J0YWwtbWV0cmljc1wiPntjb3B5Lm1ldHJpY3MubWFwKChbbGFiZWwsdmFsdWVdLGkpPT48YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBtZXRyaWMtY2FyZFwiIGtleT17bGFiZWx9PjxkaXYgY2xhc3NOYW1lPVwibWV0cmljLWljb25cIj57WzxXYWxsZXQvPiw8VXNlcnMvPiw8QXJyb3dMZWZ0UmlnaHQvPiw8U2hpZWxkQWxlcnQvPl1baV19PC9kaXY+PHNwYW4+e2xhYmVsfTwvc3Bhbj48c3Ryb25nPnt2YWx1ZX08L3N0cm9uZz48L2FydGljbGU+KX08L2Rpdj5cbiA8ZGl2IGNsYXNzTmFtZT1cInBvcnRhbC1kYXNoYm9hcmQtZ3JpZFwiPjxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIG92ZXJ2aWV3LWNhcmRcIj48ZGl2IGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkLWhlYWRpbmdcIj48ZGl2PjxoMj57cm9sZT09PVwiQ1VTVE9NRVJcIj9cIkJhbGFuY2UgT3ZlcnZpZXdcIjpyb2xlPT09XCJTVVBQT1JUXCI/XCJUaWNrZXQgQWN0aXZpdHlcIjpyb2xlPT09XCJBVURJVE9SXCI/XCJBdWRpdCBBY3Rpdml0eVwiOlwiUGxhdGZvcm0gQWN0aXZpdHlcIn08L2gyPjxwPldvcmtzcGFjZSBvdmVydmlldzwvcD48L2Rpdj48QWN0aXZpdHkgc2l6ZT17MTl9Lz48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImVtcHR5LWNoYXJ0XCI+PGRpdiBjbGFzc05hbWU9XCJjaGFydC1wbGFjZWhvbGRlclwiPjxBY3Rpdml0eSBzaXplPXsyOH0vPjxzcGFuPkxpdmUgYW5hbHl0aWNzIHdpbGwgYXBwZWFyIGhlcmUgd2hlbiBkYXNoYm9hcmQgQVBJcyBhcmUgY29ubmVjdGVkLjwvc3Bhbj48L2Rpdj48L2Rpdj48L2FydGljbGU+XG4gPGFydGljbGUgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQgcXVpY2stY2FyZFwiPjxkaXYgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQtaGVhZGluZ1wiPjxkaXY+PGgyPlF1aWNrIEFjY2VzczwvaDI+PHA+RnJlcXVlbnRseSB1c2VkIHdvcmtzcGFjZSBwYWdlczwvcD48L2Rpdj48Q2lyY2xlSGVscCBzaXplPXsxOX0vPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwicXVpY2stbGluay1saXN0XCI+e2NvcHkubGlua3MubWFwKChbbGFiZWwscGF0aF0pPT48YSBrZXk9e3BhdGh9IGhyZWY9e3BhdGh9IGNsYXNzTmFtZT1cInF1aWNrLWxpbmtcIj48c3Bhbj57bGFiZWx9PC9zcGFuPjxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPuKGkjwvc3Bhbj48L2E+KX08L2Rpdj48L2FydGljbGU+PC9kaXY+XG4gPHAgY2xhc3NOYW1lPVwiZGVtby1kaXNjbGFpbWVyXCI+UG9ydGZvbGlvIGRlbW9uc3RyYXRpb24gaW50ZXJmYWNlLiBGaWd1cmVzIHNob3duIGFzIHBsYWNlaG9sZGVycyBhcmUgbm90IGxpdmUgYmFua2luZyBiYWxhbmNlcy48L3A+PC9zZWN0aW9uPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFBsYWNlaG9sZGVyUGFnZSh7IHRpdGxlLCBkZXNjcmlwdGlvbiB9OiB7IHRpdGxlOnN0cmluZzsgZGVzY3JpcHRpb24/OnN0cmluZyB9KSB7XG4gcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvcnRhbC1jb250ZW50XCI+PGRpdiBjbGFzc05hbWU9XCJwb3J0YWwtcGFnZS1oZWFkaW5nXCI+PGRpdj48cCBjbGFzc05hbWU9XCJleWVicm93XCI+V09SS1NQQUNFPC9wPjxoMT57dGl0bGV9PC9oMT48cCBjbGFzc05hbWU9XCJtdXRlZFwiPntkZXNjcmlwdGlvbiA/PyBcIlRoaXMgcGFnZSBpcyBzY2FmZm9sZGVkIGZvciB0aGUgbmV4dCBpbXBsZW1lbnRhdGlvbiBwaGFzZS5cIn08L3A+PC9kaXY+PC9kaXY+PGFydGljbGUgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQgcGxhY2Vob2xkZXItcGFuZWxcIj48QWN0aXZpdHkgc2l6ZT17Mjh9Lz48aDI+e3RpdGxlfTwvaDI+PHA+TmF2aWdhdGlvbiBhbmQgcm9sZSBwcm90ZWN0aW9uIGFyZSBhY3RpdmUuIERldGFpbGVkIHBhZ2UgZnVuY3Rpb25hbGl0eSB3aWxsIGJlIGltcGxlbWVudGVkIGluIGl0cyBkZXNpZ25hdGVkIHBoYXNlLjwvcD48L2FydGljbGU+PC9zZWN0aW9uPjtcbn1cbiJdLCJmaWxlIjoiRDovTmV3X2ZvbGRlcl8oMikvU29mdHdhcmUgZGV2ZWxvcG1lbnQgUHJvamVjdC9iYW5raW5nLXBsYXRmcm9tL2Zyb250ZW5kL2JhbmtpbmctcGxhdGZvcm0tZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvbGF5b3V0L1BvcnRhbExheW91dC50c3gifQ==