import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/public/components/PublicLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useState = __vite__cjsImport1_react["useState"];
import { Link, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { Landmark, Moon, Sun, Menu, X } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { useTheme } from "/src/app/providers/ThemeProvider.tsx";
export function PublicLayout() {
  _s();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);
  const isAbout = location.pathname === "/" || location.pathname === "/about";
  return /* @__PURE__ */ jsxDEV("div", { className: "public-shell", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "public-header", children: [
      /* @__PURE__ */ jsxDEV(Link, { className: "public-brand", to: "/", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "public-brand-icon", children: /* @__PURE__ */ jsxDEV(Landmark, { size: 24, strokeWidth: 2.6 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 16,
          columnNumber: 47
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 16,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Banking Platform" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
            lineNumber: 17,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Secure • Smart • Reliable" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
            lineNumber: 17,
            columnNumber: 50
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 17,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 15,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { id: "public-navigation", className: `public-nav${menuOpen ? " is-open" : ""}`, "aria-label": "Main navigation", children: [
        /* @__PURE__ */ jsxDEV(Link, { onClick: closeMenu, className: isAbout ? "selected" : "", to: "/about", children: "About" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 20,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { onClick: closeMenu, to: "/login", children: "Login" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 21,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { onClick: closeMenu, to: "/register", children: "Register" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 22,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 19,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "mobile-nav-toggle", type: "button", onClick: () => setMenuOpen((open) => !open), "aria-label": menuOpen ? "Close navigation menu" : "Open navigation menu", "aria-expanded": menuOpen, "aria-controls": "public-navigation", children: menuOpen ? /* @__PURE__ */ jsxDEV(X, { size: 19 }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 25,
        columnNumber: 23
      }, this) : /* @__PURE__ */ jsxDEV(Menu, { size: 19 }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 25,
        columnNumber: 41
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 24,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "theme-switch", onClick: toggleTheme, "aria-label": `Switch to ${theme === "light" ? "dark" : "light"} theme`, children: [
        theme === "light" ? /* @__PURE__ */ jsxDEV(Moon, { size: 17 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 28,
          columnNumber: 32
        }, this) : /* @__PURE__ */ jsxDEV(Sun, { size: 17 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 28,
          columnNumber: 53
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          theme === "light" ? "Dark" : "Light",
          " theme"
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 29,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 27,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "public-main", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
      lineNumber: 32,
      columnNumber: 37
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("footer", { className: "public-footer", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "footer-brand", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "public-brand-icon", children: /* @__PURE__ */ jsxDEV(Landmark, { size: 18 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 34,
          columnNumber: 75
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 34,
          columnNumber: 39
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: [
          /* @__PURE__ */ jsxDEV("strong", { children: "Banking Platform" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
            lineNumber: 34,
            columnNumber: 110
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "A secure and modern digital banking solution." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
            lineNumber: 34,
            columnNumber: 143
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 34,
          columnNumber: 104
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "footer-links", children: [
        /* @__PURE__ */ jsxDEV(Link, { to: "/about", children: "About" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 35,
          columnNumber: 39
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: "/about#security", children: "Security" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 35,
          columnNumber: 69
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/login", children: "Login" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 35,
          columnNumber: 107
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("small", { className: "copyright", children: [
        "© 2026 Banking Platform. All rights reserved. ",
        /* @__PURE__ */ jsxDEV("span", { children: "Demo application — no real funds." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
          lineNumber: 36,
          columnNumber: 84
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx",
    lineNumber: 13,
    columnNumber: 5
  }, this);
}
_s(PublicLayout, "wBOMN2GQRDVmbY4shWhXKLzf6ho=", false, function() {
  return [useTheme, useLocation];
});
_c = PublicLayout;
var _c;
$RefreshReg$(_c, "PublicLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/PublicLayout.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZThDOztBQWY5QyxTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsTUFBTUMsUUFBUUMsbUJBQW1CO0FBQzFDLFNBQVNDLFVBQVVDLE1BQU1DLEtBQUtDLE1BQU1DLFNBQVM7QUFDN0MsU0FBU0MsZ0JBQWdCO0FBRWxCLGdCQUFTQyxlQUFlO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxFQUFFQyxPQUFPQyxZQUFZLElBQUlKLFNBQVM7QUFDeEMsUUFBTUssV0FBV1gsWUFBWTtBQUM3QixRQUFNLENBQUNZLFVBQVVDLFdBQVcsSUFBSWhCLFNBQVMsS0FBSztBQUM5QyxRQUFNaUIsWUFBWUEsTUFBTUQsWUFBWSxLQUFLO0FBQ3pDLFFBQU1FLFVBQVVKLFNBQVNLLGFBQWEsT0FBT0wsU0FBU0ssYUFBYTtBQUNuRSxTQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLDJCQUFDLFlBQU8sV0FBVSxpQkFDaEI7QUFBQSw2QkFBQyxRQUFLLFdBQVUsZ0JBQWUsSUFBRyxLQUNoQztBQUFBLCtCQUFDLFVBQUssV0FBVSxxQkFBb0IsaUNBQUMsWUFBUyxNQUFNLElBQUksYUFBYSxPQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxRQUM1RSx1QkFBQyxVQUFLO0FBQUEsaUNBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLFVBQVMsdUJBQUMsV0FBTSx5Q0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLGFBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxXQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksSUFBRyxxQkFBb0IsV0FBVyxhQUFhSixXQUFXLGFBQWEsRUFBRSxJQUFJLGNBQVcsbUJBQzNGO0FBQUEsK0JBQUMsUUFBSyxTQUFTRSxXQUFXLFdBQVdDLFVBQVUsYUFBYSxJQUFJLElBQUcsVUFBUyxxQkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRjtBQUFBLFFBQ2pGLHVCQUFDLFFBQUssU0FBU0QsV0FBVyxJQUFHLFVBQVMscUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkM7QUFBQSxRQUMzQyx1QkFBQyxRQUFLLFNBQVNBLFdBQVcsSUFBRyxhQUFZLHdCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsV0FIbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLFdBQVUscUJBQW9CLE1BQUssVUFBUyxTQUFTLE1BQU1ELFlBQVksQ0FBQ0ksU0FBUyxDQUFDQSxJQUFJLEdBQUcsY0FBWUwsV0FBVywwQkFBMEIsd0JBQXdCLGlCQUFlQSxVQUFVLGlCQUFjLHFCQUM5TUEscUJBQVcsdUJBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLElBQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxXQUFVLGdCQUFlLFNBQVNGLGFBQWEsY0FBWSxhQUFhRCxVQUFVLFVBQVUsU0FBUyxPQUFPLFVBQ2pIQTtBQUFBQSxrQkFBVSxVQUFVLHVCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZSxJQUFNLHVCQUFDLE9BQUksTUFBTSxNQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ3hELHVCQUFDLFVBQU1BO0FBQUFBLG9CQUFVLFVBQVUsU0FBUztBQUFBLFVBQVE7QUFBQSxhQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsV0FGcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBQ0EsdUJBQUMsVUFBSyxXQUFVLGVBQWMsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QztBQUFBLElBQ3hDLHVCQUFDLFlBQU8sV0FBVSxpQkFDaEI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQSwrQkFBQyxVQUFLLFdBQVUscUJBQW9CLGlDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxRQUFPLHVCQUFDLFVBQUs7QUFBQSxpQ0FBQyxZQUFPLGdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsVUFBUyx1QkFBQyxXQUFNLDZEQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsYUFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRztBQUFBLFdBQWxNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeU07QUFBQSxNQUN6TSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQSwrQkFBQyxRQUFLLElBQUcsVUFBUyxxQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFFBQU8sdUJBQUMsT0FBRSxNQUFLLG1CQUFrQix3QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQztBQUFBLFFBQUksdUJBQUMsUUFBSyxJQUFHLFVBQVMscUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxXQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdJO0FBQUEsTUFDaEksdUJBQUMsV0FBTSxXQUFVLGFBQVk7QUFBQTtBQUFBLFFBQThDLHVCQUFDLFVBQUssaURBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFdBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUg7QUFBQSxTQUgzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUJBO0FBRUo7QUFBQ0QsR0FsQ2VELGNBQVk7QUFBQSxVQUNLRCxVQUNkTixXQUFXO0FBQUE7QUFBQSxLQUZkTztBQUFZLElBQUFXO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsIk91dGxldCIsInVzZUxvY2F0aW9uIiwiTGFuZG1hcmsiLCJNb29uIiwiU3VuIiwiTWVudSIsIlgiLCJ1c2VUaGVtZSIsIlB1YmxpY0xheW91dCIsIl9zIiwidGhlbWUiLCJ0b2dnbGVUaGVtZSIsImxvY2F0aW9uIiwibWVudU9wZW4iLCJzZXRNZW51T3BlbiIsImNsb3NlTWVudSIsImlzQWJvdXQiLCJwYXRobmFtZSIsIm9wZW4iLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQdWJsaWNMYXlvdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCBPdXRsZXQsIHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IExhbmRtYXJrLCBNb29uLCBTdW4sIE1lbnUsIFggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gXCIuLi8uLi8uLi9hcHAvcHJvdmlkZXJzL1RoZW1lUHJvdmlkZXJcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFB1YmxpY0xheW91dCgpIHtcbiAgY29uc3QgeyB0aGVtZSwgdG9nZ2xlVGhlbWUgfSA9IHVzZVRoZW1lKCk7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgY29uc3QgW21lbnVPcGVuLCBzZXRNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGNsb3NlTWVudSA9ICgpID0+IHNldE1lbnVPcGVuKGZhbHNlKTtcbiAgY29uc3QgaXNBYm91dCA9IGxvY2F0aW9uLnBhdGhuYW1lID09PSBcIi9cIiB8fCBsb2NhdGlvbi5wYXRobmFtZSA9PT0gXCIvYWJvdXRcIjtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInB1YmxpYy1zaGVsbFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJwdWJsaWMtaGVhZGVyXCI+XG4gICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cInB1YmxpYy1icmFuZFwiIHRvPVwiL1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB1YmxpYy1icmFuZC1pY29uXCI+PExhbmRtYXJrIHNpemU9ezI0fSBzdHJva2VXaWR0aD17Mi42fSAvPjwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj48c3Ryb25nPkJhbmtpbmcgUGxhdGZvcm08L3N0cm9uZz48c21hbGw+U2VjdXJlIOKAoiBTbWFydCDigKIgUmVsaWFibGU8L3NtYWxsPjwvc3Bhbj5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgICA8bmF2IGlkPVwicHVibGljLW5hdmlnYXRpb25cIiBjbGFzc05hbWU9e2BwdWJsaWMtbmF2JHttZW51T3BlbiA/IFwiIGlzLW9wZW5cIiA6IFwiXCJ9YH0gYXJpYS1sYWJlbD1cIk1haW4gbmF2aWdhdGlvblwiPlxuICAgICAgICAgIDxMaW5rIG9uQ2xpY2s9e2Nsb3NlTWVudX0gY2xhc3NOYW1lPXtpc0Fib3V0ID8gXCJzZWxlY3RlZFwiIDogXCJcIn0gdG89XCIvYWJvdXRcIj5BYm91dDwvTGluaz5cbiAgICAgICAgICA8TGluayBvbkNsaWNrPXtjbG9zZU1lbnV9IHRvPVwiL2xvZ2luXCI+TG9naW48L0xpbms+XG4gICAgICAgICAgPExpbmsgb25DbGljaz17Y2xvc2VNZW51fSB0bz1cIi9yZWdpc3RlclwiPlJlZ2lzdGVyPC9MaW5rPlxuICAgICAgICA8L25hdj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJtb2JpbGUtbmF2LXRvZ2dsZVwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRNZW51T3Blbigob3BlbikgPT4gIW9wZW4pfSBhcmlhLWxhYmVsPXttZW51T3BlbiA/IFwiQ2xvc2UgbmF2aWdhdGlvbiBtZW51XCIgOiBcIk9wZW4gbmF2aWdhdGlvbiBtZW51XCJ9IGFyaWEtZXhwYW5kZWQ9e21lbnVPcGVufSBhcmlhLWNvbnRyb2xzPVwicHVibGljLW5hdmlnYXRpb25cIj5cbiAgICAgICAgICB7bWVudU9wZW4gPyA8WCBzaXplPXsxOX0gLz4gOiA8TWVudSBzaXplPXsxOX0gLz59XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInRoZW1lLXN3aXRjaFwiIG9uQ2xpY2s9e3RvZ2dsZVRoZW1lfSBhcmlhLWxhYmVsPXtgU3dpdGNoIHRvICR7dGhlbWUgPT09IFwibGlnaHRcIiA/IFwiZGFya1wiIDogXCJsaWdodFwifSB0aGVtZWB9PlxuICAgICAgICAgIHt0aGVtZSA9PT0gXCJsaWdodFwiID8gPE1vb24gc2l6ZT17MTd9IC8+IDogPFN1biBzaXplPXsxN30gLz59XG4gICAgICAgICAgPHNwYW4+e3RoZW1lID09PSBcImxpZ2h0XCIgPyBcIkRhcmtcIiA6IFwiTGlnaHRcIn0gdGhlbWU8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9oZWFkZXI+XG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJwdWJsaWMtbWFpblwiPjxPdXRsZXQgLz48L21haW4+XG4gICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cInB1YmxpYy1mb290ZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItYnJhbmRcIj48c3BhbiBjbGFzc05hbWU9XCJwdWJsaWMtYnJhbmQtaWNvblwiPjxMYW5kbWFyayBzaXplPXsxOH0gLz48L3NwYW4+PHNwYW4+PHN0cm9uZz5CYW5raW5nIFBsYXRmb3JtPC9zdHJvbmc+PHNtYWxsPkEgc2VjdXJlIGFuZCBtb2Rlcm4gZGlnaXRhbCBiYW5raW5nIHNvbHV0aW9uLjwvc21hbGw+PC9zcGFuPjwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1saW5rc1wiPjxMaW5rIHRvPVwiL2Fib3V0XCI+QWJvdXQ8L0xpbms+PGEgaHJlZj1cIi9hYm91dCNzZWN1cml0eVwiPlNlY3VyaXR5PC9hPjxMaW5rIHRvPVwiL2xvZ2luXCI+TG9naW48L0xpbms+PC9kaXY+XG4gICAgICAgIDxzbWFsbCBjbGFzc05hbWU9XCJjb3B5cmlnaHRcIj7CqSAyMDI2IEJhbmtpbmcgUGxhdGZvcm0uIEFsbCByaWdodHMgcmVzZXJ2ZWQuIDxzcGFuPkRlbW8gYXBwbGljYXRpb24g4oCUIG5vIHJlYWwgZnVuZHMuPC9zcGFuPjwvc21hbGw+XG4gICAgICA8L2Zvb3Rlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovTmV3X2ZvbGRlcl8oMikvU29mdHdhcmUgZGV2ZWxvcG1lbnQgUHJvamVjdC9iYW5raW5nLXBsYXRmcm9tL2Zyb250ZW5kL2JhbmtpbmctcGxhdGZvcm0tZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3B1YmxpYy9jb21wb25lbnRzL1B1YmxpY0xheW91dC50c3gifQ==