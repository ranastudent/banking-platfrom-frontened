import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "e2e", "PROD": false, "SSR": false, "VITE_API_BASE_URL": "http://127.0.0.1:5001"};import axios from "/node_modules/.vite/deps/axios.js?v=d15d18f8";
import { tokenStorage } from "/src/lib/api/tokenStorage.ts";
const configuredOrigin = import.meta.env.VITE_API_BASE_URL?.trim();
const API_ORIGIN = (configuredOrigin || "https://banking-platform-api-dzm3.onrender.com").replace(/\/+$/, "");
const API_PREFIX = "/api/v1";
export const API_BASE_URL = `${API_ORIGIN}${API_PREFIX}`;
export const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 2e4,
  withCredentials: true,
  headers: { "Content-Type": "application/json", Accept: "application/json" }
});
const refreshClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 2e4,
  withCredentials: true,
  headers: { "Content-Type": "application/json", Accept: "application/json" }
});
let refreshPromise = null;
const AUTH_PATHS = [
  "/auth/login",
  "/auth/register",
  "/auth/verify-email",
  "/auth/refresh",
  "/auth/logout",
  "/auth/reset-password/request",
  "/auth/reset-password/verify-otp",
  "/auth/reset-password"
];
api.interceptors.request.use((config) => {
  const token = tokenStorage.getAccessToken();
  if (token && config.url && !config.url.includes("/auth/refresh")) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    const requestUrl = original?.url ?? "";
    const isAuthRequest = AUTH_PATHS.some((path) => requestUrl.includes(path));
    if (error.response?.status !== 401 || !original || original._retry || isAuthRequest) {
      return Promise.reject(error);
    }
    const refreshToken = tokenStorage.getRefreshToken();
    if (!refreshToken) {
      tokenStorage.clear();
      window.dispatchEvent(new Event("banking:session-expired"));
      return Promise.reject(error);
    }
    original._retry = true;
    try {
      if (!refreshPromise) {
        refreshPromise = refreshClient.post("/auth/refresh", { refreshToken }).then((response) => {
          const payload = response.data?.data ?? response.data;
          if (!payload?.accessToken || !payload?.refreshToken) {
            throw new Error("Refresh response did not contain both tokens.");
          }
          tokenStorage.setTokens(payload.accessToken, payload.refreshToken);
          return payload.accessToken;
        }).finally(() => {
          refreshPromise = null;
        });
      }
      const newAccessToken = await refreshPromise;
      original.headers = original.headers ?? {};
      original.headers.Authorization = `Bearer ${newAccessToken}`;
      return api(original);
    } catch (refreshError) {
      tokenStorage.clear();
      window.dispatchEvent(new Event("banking:session-expired"));
      return Promise.reject(refreshError);
    }
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaUNsaWVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5pbXBvcnQgdHlwZSB7IEF4aW9zRXJyb3IsIEludGVybmFsQXhpb3NSZXF1ZXN0Q29uZmlnIH0gZnJvbSBcImF4aW9zXCI7XG5pbXBvcnQgeyB0b2tlblN0b3JhZ2UgfSBmcm9tIFwiLi90b2tlblN0b3JhZ2VcIjtcblxuY29uc3QgY29uZmlndXJlZE9yaWdpbiA9IGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9CQVNFX1VSTD8udHJpbSgpO1xuY29uc3QgQVBJX09SSUdJTiA9IChjb25maWd1cmVkT3JpZ2luIHx8IFwiaHR0cHM6Ly9iYW5raW5nLXBsYXRmb3JtLWFwaS1kem0zLm9ucmVuZGVyLmNvbVwiKS5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpO1xuY29uc3QgQVBJX1BSRUZJWCA9IFwiL2FwaS92MVwiO1xuZXhwb3J0IGNvbnN0IEFQSV9CQVNFX1VSTCA9IGAke0FQSV9PUklHSU59JHtBUElfUFJFRklYfWA7XG5cbnR5cGUgUmV0cnlDb25maWcgPSBJbnRlcm5hbEF4aW9zUmVxdWVzdENvbmZpZyAmIHsgX3JldHJ5PzogYm9vbGVhbiB9O1xuXG5leHBvcnQgY29uc3QgYXBpID0gYXhpb3MuY3JlYXRlKHtcbiAgYmFzZVVSTDogQVBJX0JBU0VfVVJMLFxuICB0aW1lb3V0OiAyMF8wMDAsXG4gIHdpdGhDcmVkZW50aWFsczogdHJ1ZSxcbiAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiwgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxufSk7XG5cbmNvbnN0IHJlZnJlc2hDbGllbnQgPSBheGlvcy5jcmVhdGUoe1xuICBiYXNlVVJMOiBBUElfQkFTRV9VUkwsXG4gIHRpbWVvdXQ6IDIwXzAwMCxcbiAgd2l0aENyZWRlbnRpYWxzOiB0cnVlLFxuICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLCBBY2NlcHQ6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXG59KTtcblxubGV0IHJlZnJlc2hQcm9taXNlOiBQcm9taXNlPHN0cmluZz4gfCBudWxsID0gbnVsbDtcbmNvbnN0IEFVVEhfUEFUSFMgPSBbXG4gIFwiL2F1dGgvbG9naW5cIixcbiAgXCIvYXV0aC9yZWdpc3RlclwiLFxuICBcIi9hdXRoL3ZlcmlmeS1lbWFpbFwiLFxuICBcIi9hdXRoL3JlZnJlc2hcIixcbiAgXCIvYXV0aC9sb2dvdXRcIixcbiAgXCIvYXV0aC9yZXNldC1wYXNzd29yZC9yZXF1ZXN0XCIsXG4gIFwiL2F1dGgvcmVzZXQtcGFzc3dvcmQvdmVyaWZ5LW90cFwiLFxuICBcIi9hdXRoL3Jlc2V0LXBhc3N3b3JkXCIsXG5dO1xuXG5hcGkuaW50ZXJjZXB0b3JzLnJlcXVlc3QudXNlKChjb25maWcpID0+IHtcbiAgY29uc3QgdG9rZW4gPSB0b2tlblN0b3JhZ2UuZ2V0QWNjZXNzVG9rZW4oKTtcbiAgaWYgKHRva2VuICYmIGNvbmZpZy51cmwgJiYgIWNvbmZpZy51cmwuaW5jbHVkZXMoXCIvYXV0aC9yZWZyZXNoXCIpKSB7XG4gICAgY29uZmlnLmhlYWRlcnMuQXV0aG9yaXphdGlvbiA9IGBCZWFyZXIgJHt0b2tlbn1gO1xuICB9XG4gIHJldHVybiBjb25maWc7XG59KTtcblxuYXBpLmludGVyY2VwdG9ycy5yZXNwb25zZS51c2UoXG4gIChyZXNwb25zZSkgPT4gcmVzcG9uc2UsXG4gIGFzeW5jIChlcnJvcjogQXhpb3NFcnJvcikgPT4ge1xuICAgIGNvbnN0IG9yaWdpbmFsID0gZXJyb3IuY29uZmlnIGFzIFJldHJ5Q29uZmlnIHwgdW5kZWZpbmVkO1xuICAgIGNvbnN0IHJlcXVlc3RVcmwgPSBvcmlnaW5hbD8udXJsID8/IFwiXCI7XG4gICAgY29uc3QgaXNBdXRoUmVxdWVzdCA9IEFVVEhfUEFUSFMuc29tZSgocGF0aCkgPT4gcmVxdWVzdFVybC5pbmNsdWRlcyhwYXRoKSk7XG4gICAgaWYgKGVycm9yLnJlc3BvbnNlPy5zdGF0dXMgIT09IDQwMSB8fCAhb3JpZ2luYWwgfHwgb3JpZ2luYWwuX3JldHJ5IHx8IGlzQXV0aFJlcXVlc3QpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuXG4gICAgY29uc3QgcmVmcmVzaFRva2VuID0gdG9rZW5TdG9yYWdlLmdldFJlZnJlc2hUb2tlbigpO1xuICAgIGlmICghcmVmcmVzaFRva2VuKSB7XG4gICAgICB0b2tlblN0b3JhZ2UuY2xlYXIoKTtcbiAgICAgIHdpbmRvdy5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImJhbmtpbmc6c2Vzc2lvbi1leHBpcmVkXCIpKTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuXG4gICAgb3JpZ2luYWwuX3JldHJ5ID0gdHJ1ZTtcbiAgICB0cnkge1xuICAgICAgaWYgKCFyZWZyZXNoUHJvbWlzZSkge1xuICAgICAgICByZWZyZXNoUHJvbWlzZSA9IHJlZnJlc2hDbGllbnQucG9zdChcIi9hdXRoL3JlZnJlc2hcIiwgeyByZWZyZXNoVG9rZW4gfSlcbiAgICAgICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSByZXNwb25zZS5kYXRhPy5kYXRhID8/IHJlc3BvbnNlLmRhdGE7XG4gICAgICAgICAgICBpZiAoIXBheWxvYWQ/LmFjY2Vzc1Rva2VuIHx8ICFwYXlsb2FkPy5yZWZyZXNoVG9rZW4pIHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUmVmcmVzaCByZXNwb25zZSBkaWQgbm90IGNvbnRhaW4gYm90aCB0b2tlbnMuXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdG9rZW5TdG9yYWdlLnNldFRva2VucyhwYXlsb2FkLmFjY2Vzc1Rva2VuLCBwYXlsb2FkLnJlZnJlc2hUb2tlbik7XG4gICAgICAgICAgICByZXR1cm4gcGF5bG9hZC5hY2Nlc3NUb2tlbiBhcyBzdHJpbmc7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuZmluYWxseSgoKSA9PiB7IHJlZnJlc2hQcm9taXNlID0gbnVsbDsgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBuZXdBY2Nlc3NUb2tlbiA9IGF3YWl0IHJlZnJlc2hQcm9taXNlO1xuICAgICAgb3JpZ2luYWwuaGVhZGVycyA9IG9yaWdpbmFsLmhlYWRlcnMgPz8ge307XG4gICAgICBvcmlnaW5hbC5oZWFkZXJzLkF1dGhvcml6YXRpb24gPSBgQmVhcmVyICR7bmV3QWNjZXNzVG9rZW59YDtcbiAgICAgIHJldHVybiBhcGkob3JpZ2luYWwpO1xuICAgIH0gY2F0Y2ggKHJlZnJlc2hFcnJvcikge1xuICAgICAgdG9rZW5TdG9yYWdlLmNsZWFyKCk7XG4gICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJiYW5raW5nOnNlc3Npb24tZXhwaXJlZFwiKSk7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QocmVmcmVzaEVycm9yKTtcbiAgICB9XG4gIH0sXG4pO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLFdBQVc7QUFFbEIsU0FBUyxvQkFBb0I7QUFFN0IsTUFBTSxtQkFBbUIsWUFBWSxJQUFJLG1CQUFtQixLQUFLO0FBQ2pFLE1BQU0sY0FBYyxvQkFBb0Isa0RBQWtELFFBQVEsUUFBUSxFQUFFO0FBQzVHLE1BQU0sYUFBYTtBQUNaLGFBQU0sZUFBZSxHQUFHLFVBQVUsR0FBRyxVQUFVO0FBSS9DLGFBQU0sTUFBTSxNQUFNLE9BQU87QUFBQSxFQUM5QixTQUFTO0FBQUEsRUFDVCxTQUFTO0FBQUEsRUFDVCxpQkFBaUI7QUFBQSxFQUNqQixTQUFTLEVBQUUsZ0JBQWdCLG9CQUFvQixRQUFRLG1CQUFtQjtBQUM1RSxDQUFDO0FBRUQsTUFBTSxnQkFBZ0IsTUFBTSxPQUFPO0FBQUEsRUFDakMsU0FBUztBQUFBLEVBQ1QsU0FBUztBQUFBLEVBQ1QsaUJBQWlCO0FBQUEsRUFDakIsU0FBUyxFQUFFLGdCQUFnQixvQkFBb0IsUUFBUSxtQkFBbUI7QUFDNUUsQ0FBQztBQUVELElBQUksaUJBQXlDO0FBQzdDLE1BQU0sYUFBYTtBQUFBLEVBQ2pCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGO0FBRUEsSUFBSSxhQUFhLFFBQVEsSUFBSSxDQUFDLFdBQVc7QUFDdkMsUUFBTSxRQUFRLGFBQWEsZUFBZTtBQUMxQyxNQUFJLFNBQVMsT0FBTyxPQUFPLENBQUMsT0FBTyxJQUFJLFNBQVMsZUFBZSxHQUFHO0FBQ2hFLFdBQU8sUUFBUSxnQkFBZ0IsVUFBVSxLQUFLO0FBQUEsRUFDaEQ7QUFDQSxTQUFPO0FBQ1QsQ0FBQztBQUVELElBQUksYUFBYSxTQUFTO0FBQUEsRUFDeEIsQ0FBQyxhQUFhO0FBQUEsRUFDZCxPQUFPLFVBQXNCO0FBQzNCLFVBQU0sV0FBVyxNQUFNO0FBQ3ZCLFVBQU0sYUFBYSxVQUFVLE9BQU87QUFDcEMsVUFBTSxnQkFBZ0IsV0FBVyxLQUFLLENBQUMsU0FBUyxXQUFXLFNBQVMsSUFBSSxDQUFDO0FBQ3pFLFFBQUksTUFBTSxVQUFVLFdBQVcsT0FBTyxDQUFDLFlBQVksU0FBUyxVQUFVLGVBQWU7QUFDbkYsYUFBTyxRQUFRLE9BQU8sS0FBSztBQUFBLElBQzdCO0FBRUEsVUFBTSxlQUFlLGFBQWEsZ0JBQWdCO0FBQ2xELFFBQUksQ0FBQyxjQUFjO0FBQ2pCLG1CQUFhLE1BQU07QUFDbkIsYUFBTyxjQUFjLElBQUksTUFBTSx5QkFBeUIsQ0FBQztBQUN6RCxhQUFPLFFBQVEsT0FBTyxLQUFLO0FBQUEsSUFDN0I7QUFFQSxhQUFTLFNBQVM7QUFDbEIsUUFBSTtBQUNGLFVBQUksQ0FBQyxnQkFBZ0I7QUFDbkIseUJBQWlCLGNBQWMsS0FBSyxpQkFBaUIsRUFBRSxhQUFhLENBQUMsRUFDbEUsS0FBSyxDQUFDLGFBQWE7QUFDbEIsZ0JBQU0sVUFBVSxTQUFTLE1BQU0sUUFBUSxTQUFTO0FBQ2hELGNBQUksQ0FBQyxTQUFTLGVBQWUsQ0FBQyxTQUFTLGNBQWM7QUFDbkQsa0JBQU0sSUFBSSxNQUFNLCtDQUErQztBQUFBLFVBQ2pFO0FBQ0EsdUJBQWEsVUFBVSxRQUFRLGFBQWEsUUFBUSxZQUFZO0FBQ2hFLGlCQUFPLFFBQVE7QUFBQSxRQUNqQixDQUFDLEVBQ0EsUUFBUSxNQUFNO0FBQUUsMkJBQWlCO0FBQUEsUUFBTSxDQUFDO0FBQUEsTUFDN0M7QUFDQSxZQUFNLGlCQUFpQixNQUFNO0FBQzdCLGVBQVMsVUFBVSxTQUFTLFdBQVcsQ0FBQztBQUN4QyxlQUFTLFFBQVEsZ0JBQWdCLFVBQVUsY0FBYztBQUN6RCxhQUFPLElBQUksUUFBUTtBQUFBLElBQ3JCLFNBQVMsY0FBYztBQUNyQixtQkFBYSxNQUFNO0FBQ25CLGFBQU8sY0FBYyxJQUFJLE1BQU0seUJBQXlCLENBQUM7QUFDekQsYUFBTyxRQUFRLE9BQU8sWUFBWTtBQUFBLElBQ3BDO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=