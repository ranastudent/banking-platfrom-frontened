import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/providers/ThemeProvider.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const createContext = __vite__cjsImport1_react["createContext"]; const useCallback = __vite__cjsImport1_react["useCallback"]; const useContext = __vite__cjsImport1_react["useContext"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"]






;
const STORAGE_KEY = "banking-platform-theme";
const ThemeContext = createContext(void 0);
function getInitialTheme() {
  if (typeof window === "undefined") return "light";
  const saved = window.localStorage.getItem(STORAGE_KEY);
  if (saved === "light" || saved === "dark") return saved;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}
export function ThemeProvider({ children }) {
  _s();
  const [theme, setThemeState] = useState(getInitialTheme);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
    window.localStorage.setItem(STORAGE_KEY, theme);
  }, [theme]);
  const setTheme = useCallback((nextTheme) => setThemeState(nextTheme), []);
  const toggleTheme = useCallback(
    () => setThemeState((current) => current === "light" ? "dark" : "light"),
    []
  );
  const value = useMemo(
    () => ({ theme, setTheme, toggleTheme }),
    [theme, setTheme, toggleTheme]
  );
  return /* @__PURE__ */ jsxDEV(ThemeContext.Provider, { value, children }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/providers/ThemeProvider.tsx",
    lineNumber: 48,
    columnNumber: 10
  }, this);
}
_s(ThemeProvider, "ON6gbV3qi04FhC5okzVA9fO+MnU=");
_c = ThemeProvider;
export function useTheme() {
  _s2();
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used inside ThemeProvider");
  return context;
}
_s2(useTheme, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "ThemeProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/providers/ThemeProvider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/providers/ThemeProvider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/app/providers/ThemeProvider.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NTOztBQS9DVDtBQUFBLEVBQ0VBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BRUs7QUFTUCxNQUFNQyxjQUFjO0FBQ3BCLE1BQU1DLGVBQWVQLGNBQTZDUSxNQUFTO0FBRTNFLFNBQVNDLGtCQUF5QjtBQUNoQyxNQUFJLE9BQU9DLFdBQVcsWUFBYSxRQUFPO0FBQzFDLFFBQU1DLFFBQVFELE9BQU9FLGFBQWFDLFFBQVFQLFdBQVc7QUFDckQsTUFBSUssVUFBVSxXQUFXQSxVQUFVLE9BQVEsUUFBT0E7QUFDbEQsU0FBT0QsT0FBT0ksV0FBVyw4QkFBOEIsRUFBRUMsVUFBVSxTQUFTO0FBQzlFO0FBRU8sZ0JBQVNDLGNBQWMsRUFBRUMsU0FBa0MsR0FBRztBQUFBQyxLQUFBO0FBQ25FLFFBQU0sQ0FBQ0MsT0FBT0MsYUFBYSxJQUFJZixTQUFnQkksZUFBZTtBQUU5RE4sWUFBVSxNQUFNO0FBQ2RrQixhQUFTQyxnQkFBZ0JDLFFBQVFKLFFBQVFBO0FBQ3pDRSxhQUFTQyxnQkFBZ0JFLE1BQU1DLGNBQWNOO0FBQzdDVCxXQUFPRSxhQUFhYyxRQUFRcEIsYUFBYWEsS0FBSztBQUFBLEVBQ2hELEdBQUcsQ0FBQ0EsS0FBSyxDQUFDO0FBRVYsUUFBTVEsV0FBVzFCLFlBQVksQ0FBQzJCLGNBQXFCUixjQUFjUSxTQUFTLEdBQUcsRUFBRTtBQUMvRSxRQUFNQyxjQUFjNUI7QUFBQUEsSUFDbEIsTUFBTW1CLGNBQWMsQ0FBQ1UsWUFBYUEsWUFBWSxVQUFVLFNBQVMsT0FBUTtBQUFBLElBQ3pFO0FBQUEsRUFDRjtBQUVBLFFBQU1DLFFBQVEzQjtBQUFBQSxJQUNaLE9BQU8sRUFBRWUsT0FBT1EsVUFBVUUsWUFBWTtBQUFBLElBQ3RDLENBQUNWLE9BQU9RLFVBQVVFLFdBQVc7QUFBQSxFQUMvQjtBQUVBLFNBQU8sdUJBQUMsYUFBYSxVQUFiLEVBQXNCLE9BQWVaLFlBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0M7QUFDeEQ7QUFBQ0MsR0FyQmVGLGVBQWE7QUFBQSxLQUFiQTtBQXVCVCxnQkFBU2dCLFdBQVc7QUFBQUMsTUFBQTtBQUN6QixRQUFNQyxVQUFVaEMsV0FBV0ssWUFBWTtBQUN2QyxNQUFJLENBQUMyQixRQUFTLE9BQU0sSUFBSUMsTUFBTSw0Q0FBNEM7QUFDMUUsU0FBT0Q7QUFDVDtBQUFDRCxJQUplRCxVQUFRO0FBQUEsSUFBQUk7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNhbGxiYWNrIiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIlNUT1JBR0VfS0VZIiwiVGhlbWVDb250ZXh0IiwidW5kZWZpbmVkIiwiZ2V0SW5pdGlhbFRoZW1lIiwid2luZG93Iiwic2F2ZWQiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwibWF0Y2hNZWRpYSIsIm1hdGNoZXMiLCJUaGVtZVByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsInRoZW1lIiwic2V0VGhlbWVTdGF0ZSIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50IiwiZGF0YXNldCIsInN0eWxlIiwiY29sb3JTY2hlbWUiLCJzZXRJdGVtIiwic2V0VGhlbWUiLCJuZXh0VGhlbWUiLCJ0b2dnbGVUaGVtZSIsImN1cnJlbnQiLCJ2YWx1ZSIsInVzZVRoZW1lIiwiX3MyIiwiY29udGV4dCIsIkVycm9yIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGhlbWVQcm92aWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgY3JlYXRlQ29udGV4dCxcbiAgdXNlQ2FsbGJhY2ssXG4gIHVzZUNvbnRleHQsXG4gIHVzZUVmZmVjdCxcbiAgdXNlTWVtbyxcbiAgdXNlU3RhdGUsXG4gIHR5cGUgUmVhY3ROb2RlLFxufSBmcm9tIFwicmVhY3RcIjtcblxuZXhwb3J0IHR5cGUgVGhlbWUgPSBcImxpZ2h0XCIgfCBcImRhcmtcIjtcbnR5cGUgVGhlbWVDb250ZXh0VmFsdWUgPSB7XG4gIHRoZW1lOiBUaGVtZTtcbiAgc2V0VGhlbWU6ICh0aGVtZTogVGhlbWUpID0+IHZvaWQ7XG4gIHRvZ2dsZVRoZW1lOiAoKSA9PiB2b2lkO1xufTtcblxuY29uc3QgU1RPUkFHRV9LRVkgPSBcImJhbmtpbmctcGxhdGZvcm0tdGhlbWVcIjtcbmNvbnN0IFRoZW1lQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8VGhlbWVDb250ZXh0VmFsdWUgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG5cbmZ1bmN0aW9uIGdldEluaXRpYWxUaGVtZSgpOiBUaGVtZSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gXCJsaWdodFwiO1xuICBjb25zdCBzYXZlZCA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShTVE9SQUdFX0tFWSk7XG4gIGlmIChzYXZlZCA9PT0gXCJsaWdodFwiIHx8IHNhdmVkID09PSBcImRhcmtcIikgcmV0dXJuIHNhdmVkO1xuICByZXR1cm4gd2luZG93Lm1hdGNoTWVkaWEoXCIocHJlZmVycy1jb2xvci1zY2hlbWU6IGRhcmspXCIpLm1hdGNoZXMgPyBcImRhcmtcIiA6IFwibGlnaHRcIjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFRoZW1lUHJvdmlkZXIoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdE5vZGUgfSkge1xuICBjb25zdCBbdGhlbWUsIHNldFRoZW1lU3RhdGVdID0gdXNlU3RhdGU8VGhlbWU+KGdldEluaXRpYWxUaGVtZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuZGF0YXNldC50aGVtZSA9IHRoZW1lO1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS5jb2xvclNjaGVtZSA9IHRoZW1lO1xuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWSwgdGhlbWUpO1xuICB9LCBbdGhlbWVdKTtcblxuICBjb25zdCBzZXRUaGVtZSA9IHVzZUNhbGxiYWNrKChuZXh0VGhlbWU6IFRoZW1lKSA9PiBzZXRUaGVtZVN0YXRlKG5leHRUaGVtZSksIFtdKTtcbiAgY29uc3QgdG9nZ2xlVGhlbWUgPSB1c2VDYWxsYmFjayhcbiAgICAoKSA9PiBzZXRUaGVtZVN0YXRlKChjdXJyZW50KSA9PiAoY3VycmVudCA9PT0gXCJsaWdodFwiID8gXCJkYXJrXCIgOiBcImxpZ2h0XCIpKSxcbiAgICBbXSxcbiAgKTtcblxuICBjb25zdCB2YWx1ZSA9IHVzZU1lbW8oXG4gICAgKCkgPT4gKHsgdGhlbWUsIHNldFRoZW1lLCB0b2dnbGVUaGVtZSB9KSxcbiAgICBbdGhlbWUsIHNldFRoZW1lLCB0b2dnbGVUaGVtZV0sXG4gICk7XG5cbiAgcmV0dXJuIDxUaGVtZUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT57Y2hpbGRyZW59PC9UaGVtZUNvbnRleHQuUHJvdmlkZXI+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlVGhlbWUoKSB7XG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KFRoZW1lQ29udGV4dCk7XG4gIGlmICghY29udGV4dCkgdGhyb3cgbmV3IEVycm9yKFwidXNlVGhlbWUgbXVzdCBiZSB1c2VkIGluc2lkZSBUaGVtZVByb3ZpZGVyXCIpO1xuICByZXR1cm4gY29udGV4dDtcbn1cbiJdLCJmaWxlIjoiRDovTmV3X2ZvbGRlcl8oMikvU29mdHdhcmUgZGV2ZWxvcG1lbnQgUHJvamVjdC9iYW5raW5nLXBsYXRmcm9tL2Zyb250ZW5kL2JhbmtpbmctcGxhdGZvcm0tZnJvbnRlbmQvc3JjL2FwcC9wcm92aWRlcnMvVGhlbWVQcm92aWRlci50c3gifQ==