import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/customer/phase6/CustomerPages.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$(), _s5 = $RefreshSig$(), _s6 = $RefreshSig$(), _s7 = $RefreshSig$(), _s8 = $RefreshSig$(), _s9 = $RefreshSig$(), _s0 = $RefreshSig$(), _s1 = $RefreshSig$(), _s10 = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];
import { Link, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=d15d18f8";
import { api } from "/src/lib/api/apiClient.ts";
import { useAuth } from "/src/app/providers/AuthProvider.tsx";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { ArrowDownLeft, ArrowUpRight, ArrowLeftRight, Bell, Check, ChevronLeft, CircleAlert, CreditCard, RefreshCw, Search, ShieldCheck, UserRound, Wallet } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
const unwrap = (r) => r?.data?.data ?? r?.data ?? {};
const money = (value, currency = "BDT") => {
  const n = Number(value);
  if (!Number.isFinite(n)) return "—";
  try {
    return new Intl.NumberFormat(void 0, { style: "currency", currency, maximumFractionDigits: 2 }).format(n);
  } catch {
    return `${currency} ${n.toFixed(2)}`;
  }
};
const date = (v) => v ? new Date(v).toLocaleString() : "—";
const errorMessage = (e) => e?.response?.data?.error?.message ?? e?.response?.data?.message ?? e?.message ?? "Something went wrong. Please try again.";
function PageHeading({ title, subtitle, action }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "p6-heading", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "eyebrow", children: "CUSTOMER WORKSPACE" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 20,
        columnNumber: 146
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { children: title }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 20,
        columnNumber: 191
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "muted", children: subtitle }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 20,
        columnNumber: 207
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 20,
      columnNumber: 141
    }, this),
    action
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 20,
    columnNumber: 113
  }, this);
}
_c = PageHeading;
function State({ kind = "loading", message, retry }) {
  return /* @__PURE__ */ jsxDEV("div", { className: `p6-state p6-${kind}`, role: kind === "loading" ? "status" : "alert", children: [
    /* @__PURE__ */ jsxDEV("span", { children: kind === "loading" ? /* @__PURE__ */ jsxDEV(RefreshCw, { size: 20 }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 21,
      columnNumber: 264
    }, this) : kind === "denied" ? /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 20 }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 21,
      columnNumber: 310
    }, this) : /* @__PURE__ */ jsxDEV(CircleAlert, { size: 20 }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 21,
      columnNumber: 338
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 21,
      columnNumber: 236
    }, this),
    /* @__PURE__ */ jsxDEV("strong", { children: message ?? { loading: "Loading your information…", empty: "Nothing to show yet.", error: "We could not load this information.", denied: "You do not have permission to access this information." }[kind] }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 21,
      columnNumber: 371
    }, this),
    retry && /* @__PURE__ */ jsxDEV("button", { className: "btn btn-secondary", onClick: retry, children: "Try again" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 21,
      columnNumber: 600
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 21,
    columnNumber: 150
  }, this);
}
_c2 = State;
function useAccounts() {
  _s();
  return useQuery({ queryKey: ["customer", "accounts"], queryFn: async () => {
    const d = unwrap(await api.get("/accounts"));
    return d.accounts ?? [];
  } });
}
_s(useAccounts, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
  return [useQuery];
});
function useTransactions(params = {}) {
  _s2();
  return useQuery({ queryKey: ["customer", "transactions", params], queryFn: async () => {
    const d = unwrap(await api.get("/transactions", { params: { page: 1, limit: 20, ...params } }));
    return { rows: d.transactions ?? [], pagination: d.pagination };
  } });
}
_s2(useTransactions, "4ZpngI1uv+Uo3WQHEZmTQ5FNM+k=", false, function() {
  return [useQuery];
});
function Status({ value }) {
  const v = value ?? "UNKNOWN";
  return /* @__PURE__ */ jsxDEV("span", { className: `p6-status status-${v.toLowerCase()}`, children: v.replaceAll("_", " ") }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 24,
    columnNumber: 84
  }, this);
}
_c3 = Status;
function TableShell({ children }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "p6-table-wrap", children: /* @__PURE__ */ jsxDEV("table", { className: "p6-table", children }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 25,
    columnNumber: 98
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 25,
    columnNumber: 67
  }, this);
}
_c4 = TableShell;
export function CustomerDashboardPage() {
  _s3();
  const accounts = useAccounts();
  const tx = useTransactions({ limit: 8 });
  const { user } = useAuth();
  const all = tx.data?.rows ?? [];
  const balances = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    (accounts.data ?? []).forEach((a) => (a.balances ?? []).forEach((b) => map.set(b.currencyCode, (map.get(b.currencyCode) ?? 0) + Number(b.availableBalance))));
    return [...map.entries()];
  }, [accounts.data]);
  const inflow = all.filter((t) => ["DEPOSIT", "EXTERNAL_DEPOSIT"].includes(t.type) && t.status === "COMPLETED");
  const outflow = all.filter((t) => ["WITHDRAWAL", "INTERNAL_TRANSFER", "EXTERNAL_TRANSFER"].includes(t.type) && t.status === "COMPLETED");
  const sumByCurrency = (items) => {
    const totals = /* @__PURE__ */ new Map();
    items.forEach((t) => totals.set(t.currencyCode, (totals.get(t.currencyCode) ?? 0) + Number(t.amount)));
    return [...totals.entries()].map(([c, v]) => money(v, c)).join(" · ") || "—";
  };
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: `Welcome${typeof user?.name === "string" ? `, ${user.name.split(" ")[0]}` : ""}`, subtitle: "A live overview of your accounts and recent activity.", action: /* @__PURE__ */ jsxDEV(Link, { className: "btn btn-primary", to: "/customer/transfer", children: [
      /* @__PURE__ */ jsxDEV(ArrowLeftRight, { size: 16 }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 35,
        columnNumber: 290
      }, this),
      " Transfer money"
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 35,
      columnNumber: 232
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 35,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p6-metrics", children: [
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-metric", children: [
        /* @__PURE__ */ jsxDEV(Wallet, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 73
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "My accounts" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 83
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: accounts.data?.length ?? "—" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 107
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: "Accounts linked to your profile" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 154
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 36,
        columnNumber: 30
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-metric", children: [
        /* @__PURE__ */ jsxDEV(ArrowDownLeft, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 253
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Recent incoming" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 270
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: tx.isLoading ? "—" : sumByCurrency(inflow) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 298
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: "Completed deposits in returned page" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 359
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 36,
        columnNumber: 210
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-metric", children: [
        /* @__PURE__ */ jsxDEV(ArrowUpRight, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 462
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Recent outgoing" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 478
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: tx.isLoading ? "—" : sumByCurrency(outflow) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 506
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: "Completed withdrawals and transfers in returned page" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 568
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 36,
        columnNumber: 419
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-metric", children: [
        /* @__PURE__ */ jsxDEV(ArrowLeftRight, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 688
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "Recent transactions" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 706
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: tx.data?.rows.length ?? "—" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 738
        }, this),
        /* @__PURE__ */ jsxDEV("small", { children: "Latest records returned by the API" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 36,
          columnNumber: 784
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 36,
        columnNumber: 645
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 36,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p6-grid", children: [
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p6-panel-head", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { children: "Account balances" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 37,
              columnNumber: 105
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "Available balances grouped by currency" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 37,
              columnNumber: 130
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 37,
            columnNumber: 100
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/customer/accounts", children: "View accounts →" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 37,
            columnNumber: 181
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 37,
          columnNumber: 69
        }, this),
        accounts.isLoading ? /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 37,
          columnNumber: 261
        }, this) : accounts.isError ? /* @__PURE__ */ jsxDEV(State, { kind: "error", message: errorMessage(accounts.error), retry: () => void accounts.refetch() }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 37,
          columnNumber: 292
        }, this) : balances.length === 0 ? /* @__PURE__ */ jsxDEV(State, { kind: "empty", message: "No accounts yet. Create an account to get started." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 37,
          columnNumber: 418
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p6-balance-list", children: balances.map(([c, v]) => /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("span", { children: c }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 37,
            columnNumber: 576
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: money(v, c) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 37,
            columnNumber: 592
          }, this)
        ] }, c, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 37,
          columnNumber: 563
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 37,
          columnNumber: 504
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 37,
        columnNumber: 27
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p6-panel-head", children: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Quick actions" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 38,
            columnNumber: 80
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Available customer actions" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 38,
            columnNumber: 102
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 38,
          columnNumber: 75
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 38,
          columnNumber: 44
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p6-actions", children: [
          /* @__PURE__ */ jsxDEV(Link, { to: "/customer/accounts", children: [
            /* @__PURE__ */ jsxDEV(CreditCard, {}, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 38,
              columnNumber: 205
            }, this),
            " Manage accounts"
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 38,
            columnNumber: 175
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/customer/deposit", children: [
            /* @__PURE__ */ jsxDEV(ArrowDownLeft, {}, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 38,
              columnNumber: 271
            }, this),
            " Deposit"
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 38,
            columnNumber: 242
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/customer/withdrawal", children: [
            /* @__PURE__ */ jsxDEV(ArrowUpRight, {}, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 38,
              columnNumber: 335
            }, this),
            " Withdraw"
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 38,
            columnNumber: 303
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/customer/beneficiaries", children: [
            /* @__PURE__ */ jsxDEV(UserRound, {}, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 38,
              columnNumber: 402
            }, this),
            " Beneficiaries"
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 38,
            columnNumber: 367
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 38,
          columnNumber: 147
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 38,
        columnNumber: 2
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 37,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p6-panel-head", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Recent transactions" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 80
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Latest transactions returned by your account history" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 108
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 39,
          columnNumber: 75
        }, this),
        /* @__PURE__ */ jsxDEV(Link, { to: "/customer/transactions", children: "View all →" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 39,
          columnNumber: 173
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 39,
        columnNumber: 44
      }, this),
      tx.isLoading ? /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 39,
        columnNumber: 246
      }, this) : tx.isError ? /* @__PURE__ */ jsxDEV(State, { kind: "error", message: errorMessage(tx.error), retry: () => void tx.refetch() }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 39,
        columnNumber: 271
      }, this) : all.length === 0 ? /* @__PURE__ */ jsxDEV(State, { kind: "empty", message: "No transactions found." }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 39,
        columnNumber: 380
      }, this) : /* @__PURE__ */ jsxDEV(TableShell, { children: [
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { children: "Reference" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 461
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Type" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 479
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Date" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 492
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Status" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 505
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "align-right", children: "Amount" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 520
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 39,
          columnNumber: 457
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 39,
          columnNumber: 450
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: all.map((t) => /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(Link, { to: `/customer/transactions/${t.id}`, children: t.reference ?? t.id.slice(0, 10) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 614
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 610
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: t.type.replaceAll("_", " ") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 704
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: date(t.createdAt) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 742
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(Status, { value: t.status }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 774
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 770
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "align-right", children: money(t.amount, t.currencyCode) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 39,
            columnNumber: 806
          }, this)
        ] }, t.id, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 39,
          columnNumber: 595
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 39,
          columnNumber: 572
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 39,
        columnNumber: 438
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 39,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "demo-disclaimer", children: "Dashboard figures are calculated only from API records currently returned. Transaction flow totals reflect the latest page, not a complete statement." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 40,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
}
_s3(CustomerDashboardPage, "M18Bq2JICAgYGqL/akq/YpPuggI=", false, function() {
  return [useAccounts, useTransactions, useAuth];
});
_c5 = CustomerDashboardPage;
export function TransactionsPage() {
  _s4();
  const [filters, setFilters] = useState({ type: "", status: "", startDate: "", endDate: "", minAmount: "", maxAmount: "" });
  const [page, setPage] = useState(1);
  const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ""));
  const tx = useTransactions({ page, limit: 20, ...params });
  const rows = tx.data?.rows ?? [];
  const totalPages = tx.data?.pagination?.totalPages ?? 1;
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: "Transactions", subtitle: "Search and review transactions associated with your accounts." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 48,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "portal-card p6-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p6-filter-grid", children: [
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Type",
          /* @__PURE__ */ jsxDEV("select", { value: filters.type, onChange: (e) => setFilters({ ...filters, type: e.target.value }), children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: "All types" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 49,
              columnNumber: 179
            }, this),
            ["DEPOSIT", "WITHDRAWAL", "INTERNAL_TRANSFER", "EXTERNAL_DEPOSIT", "EXTERNAL_TRANSFER", "FX_CONVERSION", "REFUND"].map((x) => /* @__PURE__ */ jsxDEV("option", { children: x }, x, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 49,
              columnNumber: 341
            }, this))
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 49,
            columnNumber: 83
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 49,
          columnNumber: 72
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Status",
          /* @__PURE__ */ jsxDEV("select", { value: filters.status, onChange: (e) => setFilters({ ...filters, status: e.target.value }), children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: "All statuses" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 49,
              columnNumber: 501
            }, this),
            ["PENDING", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED", "REFUNDED"].map((x) => /* @__PURE__ */ jsxDEV("option", { children: x }, x, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 49,
              columnNumber: 625
            }, this))
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 49,
            columnNumber: 401
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 49,
          columnNumber: 388
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "From",
          /* @__PURE__ */ jsxDEV("input", { type: "date", value: filters.startDate, onChange: (e) => setFilters({ ...filters, startDate: e.target.value }) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 49,
            columnNumber: 683
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 49,
          columnNumber: 672
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "To",
          /* @__PURE__ */ jsxDEV("input", { type: "date", value: filters.endDate, onChange: (e) => setFilters({ ...filters, endDate: e.target.value }) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 49,
            columnNumber: 819
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 49,
          columnNumber: 810
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Min amount",
          /* @__PURE__ */ jsxDEV("input", { inputMode: "decimal", value: filters.minAmount, onChange: (e) => setFilters({ ...filters, minAmount: e.target.value }) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 49,
            columnNumber: 959
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 49,
          columnNumber: 942
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Max amount",
          /* @__PURE__ */ jsxDEV("input", { inputMode: "decimal", value: filters.maxAmount, onChange: (e) => setFilters({ ...filters, maxAmount: e.target.value }) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 49,
            columnNumber: 1111
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 49,
          columnNumber: 1094
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 49,
        columnNumber: 40
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p6-filter-actions", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-secondary", onClick: () => {
          setFilters({ type: "", status: "", startDate: "", endDate: "", minAmount: "", maxAmount: "" });
          setPage(1);
        }, children: "Clear filters" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 49,
          columnNumber: 1287
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", onClick: () => void tx.refetch(), children: [
          /* @__PURE__ */ jsxDEV(Search, { size: 15 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 49,
            columnNumber: 1542
          }, this),
          " Apply filters"
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 49,
          columnNumber: 1472
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 49,
        columnNumber: 1252
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 49,
      columnNumber: 2
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p6-panel-head", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Transaction history" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 50,
          columnNumber: 80
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          tx.data?.pagination?.total ?? rows.length,
          " records in current result"
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 50,
          columnNumber: 108
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 50,
        columnNumber: 75
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 50,
        columnNumber: 44
      }, this),
      tx.isLoading ? /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 50,
        columnNumber: 212
      }, this) : tx.isError ? /* @__PURE__ */ jsxDEV(State, { kind: "error", message: errorMessage(tx.error), retry: () => void tx.refetch() }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 50,
        columnNumber: 237
      }, this) : rows.length === 0 ? /* @__PURE__ */ jsxDEV(State, { kind: "empty", message: "No transactions match these filters." }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 50,
        columnNumber: 347
      }, this) : /* @__PURE__ */ jsxDEV(TableShell, { children: [
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { children: "Reference" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 442
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Type" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 460
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Created" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 473
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Status" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 489
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Currency" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 504
          }, this),
          /* @__PURE__ */ jsxDEV("th", { className: "align-right", children: "Amount" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 521
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 50,
          columnNumber: 438
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 50,
          columnNumber: 431
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: rows.map((t) => /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(Link, { to: `/customer/transactions/${t.id}`, children: t.reference ?? t.id.slice(0, 12) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 616
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 612
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: t.type.replaceAll("_", " ") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 706
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: date(t.createdAt) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 744
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(Status, { value: t.status }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 776
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 772
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: t.currencyCode }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 808
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "align-right", children: money(t.amount, t.currencyCode) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 833
          }, this)
        ] }, t.id, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 50,
          columnNumber: 597
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 50,
          columnNumber: 573
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 50,
        columnNumber: 419
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p6-pagination", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "muted", children: [
          "Page ",
          page,
          " of ",
          totalPages
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 50,
          columnNumber: 959
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-secondary btn-sm", disabled: page <= 1 || tx.isFetching, onClick: () => setPage((v) => Math.max(1, v - 1)), children: [
            /* @__PURE__ */ jsxDEV(ChevronLeft, { size: 14 }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 50,
              columnNumber: 1156
            }, this),
            " Previous"
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 1022
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-secondary btn-sm", disabled: page >= totalPages || tx.isFetching, onClick: () => setPage((v) => v + 1), children: [
            "Next ",
            /* @__PURE__ */ jsxDEV(ChevronLeft, { size: 14, style: { transform: "rotate(180deg)" } }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 50,
              columnNumber: 1334
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 50,
            columnNumber: 1199
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 50,
          columnNumber: 1017
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 50,
        columnNumber: 928
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "muted p6-footnote", children: "Offset pagination is used here (page, limit). The API also supports cursor pagination; page and cursor are never combined." }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 50,
        columnNumber: 1420
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 50,
      columnNumber: 2
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 48,
    columnNumber: 10
  }, this);
}
_s4(TransactionsPage, "aADVowDX0FrsTtBqKNsmjHzIfIM=", false, function() {
  return [useTransactions];
});
_c6 = TransactionsPage;
export function TransactionDetailsPage() {
  _s5();
  const { transactionId = "" } = useParams();
  const q = useQuery({ queryKey: ["transaction", transactionId], queryFn: async () => unwrap(await api.get(`/transactions/${transactionId}`)).transaction });
  if (q.isLoading) return /* @__PURE__ */ jsxDEV("section", { className: "portal-content", children: /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 55,
    columnNumber: 63
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 55,
    columnNumber: 27
  }, this);
  if (q.isError) return /* @__PURE__ */ jsxDEV("section", { className: "portal-content", children: /* @__PURE__ */ jsxDEV(State, { kind: q.error && q.error.response?.status === 403 ? "denied" : "error", message: errorMessage(q.error), retry: () => void q.refetch() }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 56,
    columnNumber: 61
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 56,
    columnNumber: 25
  }, this);
  const t = q.data;
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: "Transaction details", subtitle: "Read-only details returned by the transaction API.", action: /* @__PURE__ */ jsxDEV(Link, { className: "btn btn-secondary", to: "/customer/transactions", children: [
      /* @__PURE__ */ jsxDEV(ChevronLeft, { size: 16 }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 58,
        columnNumber: 232
      }, this),
      " Back to transactions"
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 58,
      columnNumber: 168
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 58,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p6-detail-amount", children: [
        /* @__PURE__ */ jsxDEV("span", { children: t.type?.replaceAll("_", " ") }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 58,
          columnNumber: 365
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: money(t.amount, t.currencyCode) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 58,
          columnNumber: 408
        }, this),
        /* @__PURE__ */ jsxDEV(Status, { value: t.status }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 58,
          columnNumber: 458
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 58,
        columnNumber: 331
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p6-detail-grid", children: Object.entries({ Reference: t.reference, ID: t.id, Currency: t.currencyCode, Type: t.type, Status: t.status, Created: date(t.createdAt), Updated: date(t.updatedAt), Description: t.description }).filter(([, v]) => v !== void 0 && v !== null).map(([k, v]) => /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("small", { children: k }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 58,
          columnNumber: 797
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: String(v) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 58,
          columnNumber: 815
        }, this)
      ] }, k, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 58,
        columnNumber: 784
      }, this)) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 58,
        columnNumber: 491
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 58,
      columnNumber: 289
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 58,
    columnNumber: 10
  }, this);
}
_s5(TransactionDetailsPage, "6WYee6bCT8MO79QNn5BmVdLif8U=", false, function() {
  return [useParams, useQuery];
});
_c7 = TransactionDetailsPage;
function MoneyMovementPage({ mode }) {
  _s6();
  const accounts = useAccounts();
  const qc = useQueryClient();
  const [accountId, setAccountId] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("BDT");
  const [idem, setIdem] = useState("");
  const selected = accounts.data?.find((a) => a.id === accountId);
  const mutation = useMutation({ mutationFn: async () => {
    const key = idem || crypto.randomUUID();
    setIdem(key);
    return unwrap(await api.post(`/accounts/${accountId}/${mode === "deposit" ? "deposits" : "withdrawals"}`, { amount, currency: currency.toUpperCase() }, { headers: { "Idempotency-Key": key } }));
  }, onSuccess: async () => {
    toast.success(`${mode === "deposit" ? "Deposit" : "Withdrawal"} request completed.`);
    setAmount("");
    setIdem("");
    await Promise.all([qc.invalidateQueries({ queryKey: ["customer", "accounts"] }), qc.invalidateQueries({ queryKey: ["customer", "transactions"] })]);
  }, onError: (e) => toast.error(errorMessage(e)) });
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: mode === "deposit" ? "Deposit funds" : "Withdraw funds", subtitle: "Submit a money movement request using the account-scoped backend endpoint." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 65,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p6-form-layout", children: [
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: /* @__PURE__ */ jsxDEV("form", { className: "p6-form", onSubmit: (e) => {
        e.preventDefault();
        if (!accountId) return;
        mutation.mutate();
      }, children: [
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Account",
          /* @__PURE__ */ jsxDEV("select", { required: true, value: accountId, onChange: (e) => {
            const next = accounts.data?.find((a) => a.id === e.target.value);
            setAccountId(e.target.value);
            setCurrency(next?.balances?.[0]?.currencyCode ?? "BDT");
            setIdem("");
          }, children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select an account" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 65,
              columnNumber: 635
            }, this),
            (accounts.data ?? []).map((a) => /* @__PURE__ */ jsxDEV("option", { value: a.id, children: [
              a.accountNumber,
              " · ",
              a.accountType,
              " · ",
              a.status
            ] }, a.id, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 65,
              columnNumber: 712
            }, this))
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 417
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 403
        }, this),
        accounts.isLoading && /* @__PURE__ */ jsxDEV("small", { children: "Loading accounts…" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 843
        }, this),
        accounts.isError && /* @__PURE__ */ jsxDEV(State, { kind: "error", message: errorMessage(accounts.error), retry: () => void accounts.refetch() }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 897
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Amount",
          /* @__PURE__ */ jsxDEV("input", { required: true, inputMode: "decimal", pattern: "^\\d+(\\.\\d{1,8})?$", min: "0.00000001", placeholder: "0.00", value: amount, onChange: (e) => {
            setAmount(e.target.value);
            setIdem("");
          } }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 1010
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Positive decimal, up to 8 decimal places." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 1186
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 997
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Currency",
          /* @__PURE__ */ jsxDEV("select", { required: true, value: currency, onChange: (e) => {
            setCurrency(e.target.value);
            setIdem("");
          }, children: (selected?.balances ?? []).map((b) => /* @__PURE__ */ jsxDEV("option", { value: b.currencyCode, children: b.currencyCode }, b.currencyCode, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 1399
          }, this)) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 1265
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Choose a currency balance available on this account." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 1487
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 1250
        }, this),
        selected && /* @__PURE__ */ jsxDEV("div", { className: "p6-info-box", children: [
          "Selected account: ",
          /* @__PURE__ */ jsxDEV("strong", { children: selected.accountNumber }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 1622
          }, this),
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 1663
          }, this),
          "Available balance: ",
          (selected.balances ?? []).map((x) => `${money(x.availableBalance, x.currencyCode)}`).join(" · ") || "Not returned"
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 1575
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p6-info-box", children: [
          /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 16 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 1840
          }, this),
          " This portfolio app uses test data only. Verify the selected account and amount before submitting."
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 1811
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", disabled: mutation.isPending || !accountId || !amount || Number(amount) <= 0, children: mutation.isPending ? "Processing…" : mode === "deposit" ? "Submit deposit" : "Submit withdrawal" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 1969
        }, this),
        mutation.isError && /* @__PURE__ */ jsxDEV("p", { className: "p6-error-text", role: "alert", children: [
          errorMessage(mutation.error),
          idem && " You may retry this exact request with the same idempotency key."
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 2211
        }, this),
        mutation.isSuccess && /* @__PURE__ */ jsxDEV("div", { className: "p6-success-box", children: [
          /* @__PURE__ */ jsxDEV(Check, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 2419
          }, this),
          " ",
          mutation.data?.message ?? "Request completed",
          mutation.data?.transaction?.id && /* @__PURE__ */ jsxDEV("div", { children: [
            "Transaction ID: ",
            mutation.data.transaction.id
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 2511
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 2387
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 65,
        columnNumber: 296
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 65,
        columnNumber: 254
      }, this),
      /* @__PURE__ */ jsxDEV("aside", { className: "portal-card p6-panel", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "How it works" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 2633
        }, this),
        /* @__PURE__ */ jsxDEV("ol", { className: "p6-steps", children: [
          /* @__PURE__ */ jsxDEV("li", { children: "Choose one of your accounts." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 2679
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Enter a positive amount and the account currency." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 2716
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Confirm and submit once." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 2774
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Review the returned transaction reference and updated balance." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 65,
            columnNumber: 2807
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 2654
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "muted", children: "The client sends an Idempotency-Key. If a network timeout occurs, retry the same request using the same key; do not create a new key for the same intended action." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 65,
          columnNumber: 2883
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 65,
        columnNumber: 2593
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 65,
      columnNumber: 222
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 65,
    columnNumber: 10
  }, this);
}
_s6(MoneyMovementPage, "ncXjGn7Nb9frf5e0fuev0rfZvOo=", false, function() {
  return [useAccounts, useQueryClient, useMutation];
});
_c8 = MoneyMovementPage;
export function DepositPage() {
  return /* @__PURE__ */ jsxDEV(MoneyMovementPage, { mode: "deposit" }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 68,
    columnNumber: 39
  }, this);
}
_c9 = DepositPage;
export function WithdrawalPage() {
  return /* @__PURE__ */ jsxDEV(MoneyMovementPage, { mode: "withdrawal" }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 69,
    columnNumber: 42
  }, this);
}
_c0 = WithdrawalPage;
export function TransferPage() {
  _s7();
  const accounts = useAccounts();
  const beneficiaries = useQuery({ queryKey: ["beneficiaries"], queryFn: async () => unwrap(await api.get("/beneficiaries", { params: { page: 1, limit: 100 } })).beneficiaries ?? [] });
  const qc = useQueryClient();
  const [sender, setSender] = useState("");
  const [receiver, setReceiver] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("BDT");
  const [idem, setIdem] = useState("");
  const mutation = useMutation({ mutationFn: async () => {
    const key = idem || crypto.randomUUID();
    setIdem(key);
    return unwrap(await api.post("/transfers", { senderAccount: sender, receiverAccount: receiver, amount, currency: currency.toUpperCase() }, { headers: { "Idempotency-Key": key } }));
  }, onSuccess: async (d) => {
    toast.success(d?.message ?? "Transfer request submitted.");
    setAmount("");
    setIdem("");
    await Promise.all([qc.invalidateQueries({ queryKey: ["customer", "accounts"] }), qc.invalidateQueries({ queryKey: ["customer", "transactions"] })]);
  }, onError: (e) => toast.error(errorMessage(e)) });
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: "Fund transfer", subtitle: "Transfer between accounts using the verified internal transfer endpoint." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 75,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p6-form-layout", children: [
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: /* @__PURE__ */ jsxDEV("form", { className: "p6-form", onSubmit: (e) => {
        e.preventDefault();
        mutation.mutate();
      }, children: [
        /* @__PURE__ */ jsxDEV("label", { children: [
          "From account",
          /* @__PURE__ */ jsxDEV("select", { required: true, value: sender, onChange: (e) => {
            setSender(e.target.value);
            setIdem("");
          }, children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: "Choose source account" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 75,
              columnNumber: 446
            }, this),
            (accounts.data ?? []).map((a) => /* @__PURE__ */ jsxDEV("option", { value: a.id, children: [
              a.accountNumber,
              " · ",
              a.accountType
            ] }, a.id, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 75,
              columnNumber: 527
            }, this))
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 355
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 336
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Receiver account ID",
          /* @__PURE__ */ jsxDEV("input", { required: true, value: receiver, onChange: (e) => {
            setReceiver(e.target.value.trim());
            setIdem("");
          }, placeholder: "Enter receiver account UUID" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 648
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "The transfer API expects the receiver account identifier, not its display account number." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 793
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 622
        }, this),
        beneficiaries.data?.some((b) => b.beneficiaryType === "INTERNAL" && b.provider === "INTERNAL") && /* @__PURE__ */ jsxDEV("label", { children: [
          "Saved internal beneficiaries",
          /* @__PURE__ */ jsxDEV("select", { value: "", onChange: (e) => {
            const x = beneficiaries.data.find((b) => b.id === e.target.value);
            if (x) setReceiver(x.accountReference);
          }, children: [
            /* @__PURE__ */ jsxDEV("option", { value: "", children: "Choose a saved beneficiary (optional)" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 75,
              columnNumber: 1204
            }, this),
            beneficiaries.data.filter((b) => b.beneficiaryType === "INTERNAL" && b.provider === "INTERNAL").map((b) => /* @__PURE__ */ jsxDEV("option", { value: b.id, children: [
              b.displayName,
              " · ",
              b.accountReference
            ] }, b.id, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 75,
              columnNumber: 1397
            }, this))
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 1050
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 1015
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Amount",
          /* @__PURE__ */ jsxDEV("input", { required: true, inputMode: "decimal", pattern: "^\\d+(\\.\\d{1,8})?$", min: "0.00000001", value: amount, onChange: (e) => {
            setAmount(e.target.value);
            setIdem("");
          }, placeholder: "0.00" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 1509
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 1496
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Currency",
          /* @__PURE__ */ jsxDEV("input", { required: true, value: currency, maxLength: 3, minLength: 3, pattern: "[A-Za-z]{3}", onChange: (e) => {
            setCurrency(e.target.value.toUpperCase());
            setIdem("");
          } }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 1708
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 1693
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p6-info-box", children: [
          /* @__PURE__ */ jsxDEV(ShieldCheck, { size: 16 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 1905
          }, this),
          " Transfers are final financial operations in this demo environment. Confirm receiver account and amount. Risk review may hold a transfer; a 202 response is not a completed money movement."
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 1876
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", disabled: mutation.isPending || !sender || !receiver || !amount || Number(amount) <= 0, children: mutation.isPending ? "Submitting…" : "Submit transfer" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 2123
        }, this),
        mutation.isError && /* @__PURE__ */ jsxDEV("p", { className: "p6-error-text", role: "alert", children: [
          errorMessage(mutation.error),
          idem && " Retry the same request with the same idempotency key."
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 2333
        }, this),
        mutation.isSuccess && /* @__PURE__ */ jsxDEV("div", { className: "p6-success-box", children: [
          /* @__PURE__ */ jsxDEV(Check, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 2531
          }, this),
          mutation.data?.message ?? "Transfer request accepted",
          mutation.data?.transaction?.id && /* @__PURE__ */ jsxDEV("div", { children: [
            "Transaction: ",
            mutation.data.transaction.id
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 2630
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 2499
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 75,
        columnNumber: 252
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 75,
        columnNumber: 210
      }, this),
      /* @__PURE__ */ jsxDEV("aside", { className: "portal-card p6-panel", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Before you transfer" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 2749
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { className: "p6-steps", children: [
          /* @__PURE__ */ jsxDEV("li", { children: "Sender must be one of your own accounts." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 2802
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Receiver account ID must identify a valid, active account." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 2851
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Currency must be supported by both accounts." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 2918
          }, this),
          /* @__PURE__ */ jsxDEV("li", { children: "Backend may place a transfer on hold for risk review." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 75,
            columnNumber: 2971
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 2777
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "muted", children: "Canonical API: POST /api/v1/transfers. Legacy transaction transfer route only authorizes; it does not move money." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 75,
          columnNumber: 3038
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 75,
        columnNumber: 2709
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 75,
      columnNumber: 178
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 75,
    columnNumber: 10
  }, this);
}
_s7(TransferPage, "Og2XMRkbHe6/+5E8I55Qa4LVvIA=", false, function() {
  return [useAccounts, useQuery, useQueryClient, useMutation];
});
_c1 = TransferPage;
export function BeneficiariesPage() {
  _s8();
  const qc = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ beneficiaryType: "INTERNAL", displayName: "", accountReference: "", provider: "INTERNAL", currencyCode: "BDT" });
  const q = useQuery({ queryKey: ["beneficiaries"], queryFn: async () => {
    const d = unwrap(await api.get("/beneficiaries", { params: { page: 1, limit: 100 } }));
    return d.beneficiaries ?? [];
  } });
  const save = useMutation({ mutationFn: async () => editing ? unwrap(await api.patch(`/beneficiaries/${editing.id}`, { displayName: form.displayName, accountReference: form.accountReference, provider: form.provider, currencyCode: form.currencyCode })) : unwrap(await api.post("/beneficiaries", form)), onSuccess: async () => {
    toast.success(editing ? "Beneficiary updated" : "Beneficiary created");
    setEditing(null);
    setForm({ beneficiaryType: "INTERNAL", displayName: "", accountReference: "", provider: "INTERNAL", currencyCode: "BDT" });
    await qc.invalidateQueries({ queryKey: ["beneficiaries"] });
  }, onError: (e) => toast.error(errorMessage(e)) });
  const del = useMutation({ mutationFn: (id) => api.delete(`/beneficiaries/${id}`), onSuccess: async () => {
    toast.success("Beneficiary deleted");
    await qc.invalidateQueries({ queryKey: ["beneficiaries"] });
  }, onError: (e) => toast.error(errorMessage(e)) });
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: "Beneficiaries", subtitle: "Create, update and remove your saved transfer recipients." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 83,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p6-form-layout", children: [
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: editing ? "Edit beneficiary" : "Add beneficiary" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 237
        }, this),
        /* @__PURE__ */ jsxDEV("form", { className: "p6-form", onSubmit: (e) => {
          e.preventDefault();
          save.mutate();
        }, children: [
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Type",
            /* @__PURE__ */ jsxDEV("select", { value: form.beneficiaryType, onChange: (e) => setForm({ ...form, beneficiaryType: e.target.value }), children: [
              /* @__PURE__ */ jsxDEV("option", { children: "INTERNAL" }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
                lineNumber: 83,
                columnNumber: 496
              }, this),
              /* @__PURE__ */ jsxDEV("option", { children: "EXTERNAL" }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
                lineNumber: 83,
                columnNumber: 521
              }, this)
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 387
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 376
          }, this),
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Display name",
            /* @__PURE__ */ jsxDEV("input", { required: true, maxLength: 100, value: form.displayName, onChange: (e) => setForm({ ...form, displayName: e.target.value }) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 582
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 563
          }, this),
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Account reference",
            /* @__PURE__ */ jsxDEV("input", { required: true, maxLength: 128, value: form.accountReference, onChange: (e) => setForm({ ...form, accountReference: e.target.value }) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 741
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 717
          }, this),
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Provider",
            /* @__PURE__ */ jsxDEV("select", { value: form.provider, onChange: (e) => setForm({ ...form, provider: e.target.value }), children: ["INTERNAL", "BKASH", "NAGAD", "ROCKET", "PAYPAL", "PAYONEER", "WISE"].map((x) => /* @__PURE__ */ jsxDEV("option", { children: x }, x, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 1079
            }, this)) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 901
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 886
          }, this),
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Currency code",
            /* @__PURE__ */ jsxDEV("input", { required: true, minLength: 3, maxLength: 3, pattern: "[A-Za-z]{3}", value: form.currencyCode, onChange: (e) => setForm({ ...form, currencyCode: e.target.value.toUpperCase() }) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 1146
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 1126
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p6-form-actions", children: [
            /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", disabled: save.isPending, children: save.isPending ? "Saving…" : editing ? "Save changes" : "Create beneficiary" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 1364
            }, this),
            editing && /* @__PURE__ */ jsxDEV("button", { type: "button", className: "btn btn-secondary", onClick: () => {
              setEditing(null);
              setForm({ beneficiaryType: "INTERNAL", displayName: "", accountReference: "", provider: "INTERNAL", currencyCode: "BDT" });
            }, children: "Cancel" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 1525
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 1331
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 296
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 83,
        columnNumber: 195
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p6-panel-head", children: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Saved beneficiaries" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 1853
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Your saved recipients" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 1881
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 1848
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 1817
        }, this),
        q.isLoading ? /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 1936
        }, this) : q.isError ? /* @__PURE__ */ jsxDEV(State, { kind: "error", message: errorMessage(q.error), retry: () => void q.refetch() }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 1960
        }, this) : q.data.length === 0 ? /* @__PURE__ */ jsxDEV(State, { kind: "empty", message: "You have not added any beneficiaries yet." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 2070
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p6-beneficiary-list", children: q.data.map((b) => /* @__PURE__ */ jsxDEV("div", { className: "p6-beneficiary", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: b.displayName }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 2262
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: b.accountReference }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 2294
            }, this),
            /* @__PURE__ */ jsxDEV("small", { children: [
              b.beneficiaryType,
              " · ",
              b.provider ?? "No provider",
              " · ",
              b.currencyCode
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 2327
            }, this),
            /* @__PURE__ */ jsxDEV(Status, { value: b.status }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 2412
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 2257
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p6-inline-actions", children: [
            /* @__PURE__ */ jsxDEV("button", { className: "btn btn-secondary btn-sm", onClick: () => {
              setEditing(b);
              setForm({ beneficiaryType: b.beneficiaryType, displayName: b.displayName, accountReference: b.accountReference, provider: b.provider ?? "INTERNAL", currencyCode: b.currencyCode });
            }, children: "Edit" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 2480
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn btn-danger btn-sm", disabled: del.isPending, onClick: () => {
              if (confirm(`Delete beneficiary ${b.displayName}?`)) del.mutate(b.id);
            }, children: "Delete" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 83,
              columnNumber: 2751
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 83,
            columnNumber: 2445
          }, this)
        ] }, b.id, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 2214
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 83,
          columnNumber: 2147
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 83,
        columnNumber: 1775
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 83,
      columnNumber: 163
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 83,
    columnNumber: 10
  }, this);
}
_s8(BeneficiariesPage, "MvWjlbS5hksjPP1Yr7rlpxuCw74=", false, function() {
  return [useQueryClient, useQuery, useMutation, useMutation];
});
_c10 = BeneficiariesPage;
export function NotificationsPage() {
  _s9();
  const qc = useQueryClient();
  const [unread, setUnread] = useState(false);
  const q = useQuery({ queryKey: ["notifications", unread], queryFn: async () => unwrap(await api.get("/notifications", { params: { page: 1, limit: 50, unreadOnly: String(unread) } })) });
  const mark = useMutation({ mutationFn: (id) => api.patch(`/notifications/${id}/read`), onSuccess: () => {
    toast.success("Notification marked as read");
    void qc.invalidateQueries({ queryKey: ["notifications"] });
  }, onError: (e) => toast.error(errorMessage(e)) });
  const rows = q.data?.notifications ?? [];
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: "Notifications", subtitle: "Review account and security updates.", action: /* @__PURE__ */ jsxDEV("label", { className: "p6-check-filter", children: [
      /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: unread, onChange: (e) => setUnread(e.target.checked) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 91,
        columnNumber: 183
      }, this),
      " Unread only"
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 91,
      columnNumber: 148
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 91,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p6-panel-head", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Inbox" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 91,
          columnNumber: 373
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          q.data?.unreadCount ?? 0,
          " unread notifications"
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 91,
          columnNumber: 387
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 91,
        columnNumber: 368
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 91,
        columnNumber: 337
      }, this),
      q.isLoading ? /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 91,
        columnNumber: 468
      }, this) : q.isError ? /* @__PURE__ */ jsxDEV(State, { kind: "error", message: errorMessage(q.error), retry: () => void q.refetch() }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 91,
        columnNumber: 492
      }, this) : rows.length === 0 ? /* @__PURE__ */ jsxDEV(State, { kind: "empty", message: "You are all caught up." }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 91,
        columnNumber: 600
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p6-notification-list", children: rows.map((n) => /* @__PURE__ */ jsxDEV("div", { className: `p6-notification ${n.status === "SENT" ? "unread" : ""}`, children: [
        /* @__PURE__ */ jsxDEV("span", { className: "p6-notification-icon", children: /* @__PURE__ */ jsxDEV(Bell, { size: 18 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 91,
          columnNumber: 848
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 91,
          columnNumber: 809
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("strong", { children: n.title }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 91,
            columnNumber: 878
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: n.message }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 91,
            columnNumber: 904
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: [
            date(n.createdAt),
            " · ",
            n.channel,
            " · ",
            n.status
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 91,
            columnNumber: 922
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 91,
          columnNumber: 873
        }, this),
        n.status === "SENT" && /* @__PURE__ */ jsxDEV("button", { className: "btn btn-secondary btn-sm", disabled: mark.isPending, onClick: () => mark.mutate(n.id), children: "Mark read" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 91,
          columnNumber: 1013
        }, this)
      ] }, n.id, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 91,
        columnNumber: 724
      }, this)) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 91,
        columnNumber: 658
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 91,
      columnNumber: 295
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 91,
    columnNumber: 10
  }, this);
}
_s9(NotificationsPage, "Oz26Ga8qpUXYxvya6kNMwDSHz8M=", false, function() {
  return [useQueryClient, useQuery, useMutation];
});
_c11 = NotificationsPage;
export function ProfilePage() {
  _s0();
  const qc = useQueryClient();
  const { refreshUser } = useAuth();
  const q = useQuery({ queryKey: ["profile"], queryFn: async () => unwrap(await api.get("/users/me")) });
  const [name, setName] = useState(void 0);
  const [phone, setPhone] = useState(void 0);
  const profile = q.data;
  const update = useMutation({ mutationFn: async () => unwrap(await api.patch("/users/me", { ...name !== void 0 ? { name } : {}, ...phone !== void 0 ? { phone: phone === "" ? null : phone } : {} })), onSuccess: async () => {
    toast.success("Profile updated");
    await qc.invalidateQueries({ queryKey: ["profile"] });
    setName(void 0);
    setPhone(void 0);
    await refreshUser();
  }, onError: (e) => toast.error(errorMessage(e)) });
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: "Profile & settings", subtitle: "View your profile and update the fields supported by the backend." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 100,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel p6-profile", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p6-profile-avatar", children: /* @__PURE__ */ jsxDEV(UserRound, { size: 28 }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 100,
        columnNumber: 264
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 100,
        columnNumber: 229
      }, this),
      q.isLoading ? /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 100,
        columnNumber: 308
      }, this) : q.isError ? /* @__PURE__ */ jsxDEV(State, { kind: "error", message: errorMessage(q.error), retry: () => void q.refetch() }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 100,
        columnNumber: 332
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p6-profile-meta", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: profile?.name ?? "Customer" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 455
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: profile?.email ?? "—" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 493
          }, this),
          /* @__PURE__ */ jsxDEV(Status, { value: profile?.status }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 523
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: [
            "Role: ",
            profile?.role ?? "CUSTOMER"
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 557
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 100,
          columnNumber: 422
        }, this),
        /* @__PURE__ */ jsxDEV("form", { className: "p6-form p6-profile-form", onSubmit: (e) => {
          e.preventDefault();
          update.mutate();
        }, children: [
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Name",
            /* @__PURE__ */ jsxDEV("input", { required: true, minLength: 2, maxLength: 100, value: name ?? profile?.name ?? "", onChange: (e) => setName(e.target.value) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 100,
              columnNumber: 722
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 711
          }, this),
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Phone",
            /* @__PURE__ */ jsxDEV("input", { minLength: 7, maxLength: 20, value: phone ?? profile?.phone ?? "", onChange: (e) => setPhone(e.target.value) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 100,
              columnNumber: 868
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 856
          }, this),
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Email",
            /* @__PURE__ */ jsxDEV("input", { disabled: true, value: profile?.email ?? "" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 100,
              columnNumber: 1007
            }, this),
            /* @__PURE__ */ jsxDEV("small", { children: "Email changes are not supported by the current backend." }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
              lineNumber: 100,
              columnNumber: 1054
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 995
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p6-info-box", children: "Only name and phone can be updated. Password, email and avatar editing endpoints are not present in the supplied backend source." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 1132
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", disabled: update.isPending, children: update.isPending ? "Saving…" : "Save profile" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 100,
            columnNumber: 1295
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 100,
          columnNumber: 613
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 100,
        columnNumber: 420
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 100,
      columnNumber: 176
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 100,
    columnNumber: 10
  }, this);
}
_s0(ProfilePage, "o2pI03QxKEGigplqDTxECJDFcms=", false, function() {
  return [useQueryClient, useAuth, useQuery, useMutation];
});
_c12 = ProfilePage;
export function DecisionExplanationsPage() {
  _s1();
  const q = useQuery({ queryKey: ["decision-explanations"], queryFn: async () => unwrap(await api.get("/customer/decision-explanations/me", { params: { page: 1, limit: 50 } })) });
  const rows = Array.isArray(q.data) ? q.data : q.data?.items ?? [];
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: "Decision explanations", subtitle: "Understand security and risk decisions associated with your transactions." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 106,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: q.isLoading ? /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 106,
      columnNumber: 244
    }, this) : q.isError ? /* @__PURE__ */ jsxDEV(State, { kind: "error", message: errorMessage(q.error), retry: () => void q.refetch() }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 106,
      columnNumber: 268
    }, this) : rows.length === 0 ? /* @__PURE__ */ jsxDEV(State, { kind: "empty", message: "There are no decision explanations for your account." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 106,
      columnNumber: 376
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p6-decision-list", children: rows.map((d, i) => /* @__PURE__ */ jsxDEV("div", { className: "p6-decision", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p6-panel-head", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: d.customerTitle ?? "Transaction decision" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 106,
            columnNumber: 636
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            d.publicReference ?? "Decision record",
            " · ",
            d.phase ?? "—",
            " · ",
            date(d.createdAt)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
            lineNumber: 106,
            columnNumber: 688
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 106,
          columnNumber: 631
        }, this),
        /* @__PURE__ */ jsxDEV(Status, { value: d.status ?? d.decision }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 106,
          columnNumber: 782
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 106,
        columnNumber: 600
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: d.customerMessage }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 106,
        columnNumber: 829
      }, this),
      Array.isArray(d.reasonCodes) && /* @__PURE__ */ jsxDEV("p", { className: "muted", children: [
        "Reason codes: ",
        d.reasonCodes.join(", ")
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 106,
        columnNumber: 888
      }, this),
      Array.isArray(d.requiredActions) && /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "Suggested actions" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 106,
          columnNumber: 996
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { children: d.requiredActions.map((a) => /* @__PURE__ */ jsxDEV("li", { children: a }, a, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 106,
          columnNumber: 1072
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 106,
          columnNumber: 1030
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 106,
        columnNumber: 991
      }, this),
      d.transactionImpact && /* @__PURE__ */ jsxDEV("div", { className: "p6-info-box", children: [
        "Transaction status: ",
        d.transactionImpact.transactionStatus ?? "—",
        " · Funds movement confirmed: ",
        String(d.transactionImpact.fundsMovementConfirmed ?? "Not specified")
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 106,
        columnNumber: 1130
      }, this)
    ] }, `${d.publicReference ?? i}`, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 106,
      columnNumber: 537
    }, this)) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 106,
      columnNumber: 464
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 106,
      columnNumber: 187
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 106,
    columnNumber: 10
  }, this);
}
_s1(DecisionExplanationsPage, "5aALmIgJptN1trFjLSH6ywbGvzg=", false, function() {
  return [useQuery];
});
_c13 = DecisionExplanationsPage;
export function FxRequestDetailsPage() {
  _s10();
  const { requestId = "" } = useParams();
  const q = useQuery({ queryKey: ["fx-request", requestId], queryFn: async () => unwrap(await api.get(`/fx-requests/${requestId}`)).fxRequest });
  if (q.isLoading) return /* @__PURE__ */ jsxDEV("section", { className: "portal-content", children: /* @__PURE__ */ jsxDEV(State, {}, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 112,
    columnNumber: 63
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 112,
    columnNumber: 27
  }, this);
  if (q.isError) return /* @__PURE__ */ jsxDEV("section", { className: "portal-content", children: /* @__PURE__ */ jsxDEV(State, { kind: q.error?.response?.status === 403 ? "denied" : "error", message: errorMessage(q.error), retry: () => void q.refetch() }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 113,
    columnNumber: 61
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 113,
    columnNumber: 25
  }, this);
  const d = q.data;
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content p6-content", children: [
    /* @__PURE__ */ jsxDEV(PageHeading, { title: "FX request details", subtitle: "Read-only foreign exchange request details." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 115,
      columnNumber: 57
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card p6-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p6-detail-grid", children: Object.entries(d ?? {}).filter(([, v]) => v === null || ["string", "number", "boolean"].includes(typeof v)).map(([k, v]) => /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("small", { children: k.replace(/[A-Z]/g, (m) => ` ${m}`).replace(/^./, (m) => m.toUpperCase()) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 115,
          columnNumber: 366
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: v === null ? "—" : String(v) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
          lineNumber: 115,
          columnNumber: 456
        }, this)
      ] }, k, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 115,
        columnNumber: 353
      }, this)) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 115,
        columnNumber: 196
      }, this),
      d?.id && /* @__PURE__ */ jsxDEV("p", { className: "muted", children: [
        "Request ID: ",
        d.id
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
        lineNumber: 115,
        columnNumber: 527
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
      lineNumber: 115,
      columnNumber: 154
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx",
    lineNumber: 115,
    columnNumber: 10
  }, this);
}
_s10(FxRequestDetailsPage, "lVcccvTiLEjzeMfuvHwvkRyd2zc=", false, function() {
  return [useParams, useQuery];
});
_c14 = FxRequestDetailsPage;
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c0, _c1, _c10, _c11, _c12, _c13, _c14;
$RefreshReg$(_c, "PageHeading");
$RefreshReg$(_c2, "State");
$RefreshReg$(_c3, "Status");
$RefreshReg$(_c4, "TableShell");
$RefreshReg$(_c5, "CustomerDashboardPage");
$RefreshReg$(_c6, "TransactionsPage");
$RefreshReg$(_c7, "TransactionDetailsPage");
$RefreshReg$(_c8, "MoneyMovementPage");
$RefreshReg$(_c9, "DepositPage");
$RefreshReg$(_c0, "WithdrawalPage");
$RefreshReg$(_c1, "TransferPage");
$RefreshReg$(_c10, "BeneficiariesPage");
$RefreshReg$(_c11, "NotificationsPage");
$RefreshReg$(_c12, "ProfilePage");
$RefreshReg$(_c13, "DecisionExplanationsPage");
$RefreshReg$(_c14, "FxRequestDetailsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/phase6/CustomerPages.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJ5SSxTQWdGMlEsVUFoRjNROztBQW5CekksU0FBU0EsU0FBU0MsZ0JBQWdCO0FBQ2xDLFNBQVNDLE1BQU1DLGlCQUFpQjtBQUNoQyxTQUFTQyxhQUFhQyxVQUFVQyxzQkFBc0I7QUFDdEQsU0FBU0MsV0FBVztBQUNwQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZUFBZUMsY0FBY0MsZ0JBQWdCQyxNQUFNQyxPQUFPQyxhQUFhQyxhQUFhQyxZQUFZQyxXQUFXQyxRQUFRQyxhQUFhQyxXQUFXQyxjQUFjO0FBTWxLLE1BQU1DLFNBQVNBLENBQUNDLE1BQVVBLEdBQUdDLE1BQU1BLFFBQVFELEdBQUdDLFFBQVEsQ0FBQztBQUN2RCxNQUFNQyxRQUFRQSxDQUFDQyxPQUFXQyxXQUFTLFVBQVU7QUFDM0MsUUFBTUMsSUFBRUMsT0FBT0gsS0FBSztBQUFHLE1BQUcsQ0FBQ0csT0FBT0MsU0FBU0YsQ0FBQyxFQUFHLFFBQU87QUFDdEQsTUFBSTtBQUFFLFdBQU8sSUFBSUcsS0FBS0MsYUFBYUMsUUFBVSxFQUFDQyxPQUFNLFlBQVdQLFVBQVNRLHVCQUFzQixFQUFDLENBQUMsRUFBRUMsT0FBT1IsQ0FBQztBQUFBLEVBQUcsUUFBUTtBQUFFLFdBQU8sR0FBR0QsUUFBUSxJQUFJQyxFQUFFUyxRQUFRLENBQUMsQ0FBQztBQUFBLEVBQUk7QUFDL0o7QUFDQSxNQUFNQyxPQUFPQSxDQUFDQyxNQUFVQSxJQUFJLElBQUlDLEtBQUtELENBQUMsRUFBRUUsZUFBZSxJQUFJO0FBQzNELE1BQU1DLGVBQWVBLENBQUNDLE1BQVVBLEdBQUdDLFVBQVVwQixNQUFNcUIsT0FBT0MsV0FBV0gsR0FBR0MsVUFBVXBCLE1BQU1zQixXQUFXSCxHQUFHRyxXQUFXO0FBQ2pILFNBQVNDLFlBQVksRUFBQ0MsT0FBTUMsVUFBU0MsT0FBdUQsR0FBRztBQUFFLFNBQU8sdUJBQUMsU0FBSSxXQUFVLGNBQWE7QUFBQSwyQkFBQyxTQUFJO0FBQUEsNkJBQUMsT0FBRSxXQUFVLFdBQVUsa0NBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxNQUFJLHVCQUFDLFFBQUlGLG1CQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVztBQUFBLE1BQUssdUJBQUMsT0FBRSxXQUFVLFNBQVNDLHNCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsU0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRztBQUFBLElBQU9DO0FBQUFBLE9BQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0k7QUFBUTtBQUFDQyxLQUF2UEo7QUFDVCxTQUFTSyxNQUFNLEVBQUNDLE9BQUssV0FBVVAsU0FBU1EsTUFBZ0YsR0FBRztBQUFFLFNBQU8sdUJBQUMsU0FBSSxXQUFXLGVBQWVELElBQUksSUFBSSxNQUFNQSxTQUFPLFlBQVUsV0FBUyxTQUFTO0FBQUEsMkJBQUMsVUFBTUEsbUJBQU8sWUFBVSx1QkFBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQixJQUFHQSxTQUFPLFdBQVMsdUJBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0IsSUFBRyx1QkFBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzQixLQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlIO0FBQUEsSUFBTyx1QkFBQyxZQUFRUCxxQkFBWSxFQUFDUyxTQUFRLDZCQUE0QkMsT0FBTSx3QkFBdUJYLE9BQU0sdUNBQXNDWSxRQUFPLHlEQUF3RCxFQUFFSixJQUFJLEtBQXhNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMk07QUFBQSxJQUFVQyxTQUFPLHVCQUFDLFlBQU8sV0FBVSxxQkFBb0IsU0FBU0EsT0FBTyx5QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRDtBQUFBLE9BQW5lO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNmU7QUFBUTtBQUFDSSxNQUFqbkJOO0FBQ1QsU0FBU08sY0FBYztBQUFBQyxLQUFBO0FBQUUsU0FBT3hELFNBQVMsRUFBQ3lELFVBQVMsQ0FBQyxZQUFXLFVBQVUsR0FBRUMsU0FBUSxZQUFTO0FBQUMsVUFBTUMsSUFBRXpDLE9BQU8sTUFBTWhCLElBQUkwRCxJQUFJLFdBQVcsQ0FBQztBQUFFLFdBQVFELEVBQUVFLFlBQVU7QUFBQSxFQUFpQixFQUFDLENBQUM7QUFBRztBQUFDTCxHQUExS0QsYUFBVztBQUFBLFVBQVl2RCxRQUFRO0FBQUE7QUFDeEMsU0FBUzhELGdCQUFnQkMsU0FBaUIsQ0FBQyxHQUFHO0FBQUFDLE1BQUE7QUFBRSxTQUFPaEUsU0FBUyxFQUFDeUQsVUFBUyxDQUFDLFlBQVcsZ0JBQWVNLE1BQU0sR0FBRUwsU0FBUSxZQUFTO0FBQUMsVUFBTUMsSUFBRXpDLE9BQU8sTUFBTWhCLElBQUkwRCxJQUFJLGlCQUFnQixFQUFDRyxRQUFPLEVBQUNFLE1BQUssR0FBRUMsT0FBTSxJQUFHLEdBQUdILE9BQU0sRUFBQyxDQUFDLENBQUM7QUFBRSxXQUFPLEVBQUNJLE1BQU1SLEVBQUVTLGdCQUFjLElBQVlDLFlBQVdWLEVBQUVVLFdBQVU7QUFBQSxFQUFFLEVBQUMsQ0FBQztBQUFHO0FBQUNMLElBQW5SRixpQkFBZTtBQUFBLFVBQStCOUQsUUFBUTtBQUFBO0FBQy9ELFNBQVNzRSxPQUFPLEVBQUNoRCxNQUFxQixHQUFHO0FBQUUsUUFBTWEsSUFBRWIsU0FBTztBQUFXLFNBQU8sdUJBQUMsVUFBSyxXQUFXLG9CQUFvQmEsRUFBRW9DLFlBQVksQ0FBQyxJQUFLcEMsWUFBRXFDLFdBQVcsS0FBSSxHQUFHLEtBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0U7QUFBUztBQUFDQyxNQUE1Skg7QUFDVCxTQUFTSSxXQUFXLEVBQUNDLFNBQTZCLEdBQUc7QUFBRSxTQUFPLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsaUNBQUMsV0FBTSxXQUFVLFlBQVlBLFlBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBc0MsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE2RTtBQUFRO0FBQUNDLE1BQTNJRjtBQUVGLGdCQUFTRyx3QkFBd0I7QUFBQUMsTUFBQTtBQUN2QyxRQUFNakIsV0FBU04sWUFBWTtBQUFHLFFBQU13QixLQUFHakIsZ0JBQWdCLEVBQUNJLE9BQU0sRUFBQyxDQUFDO0FBQUcsUUFBTSxFQUFDYyxLQUFJLElBQUU3RSxRQUFRO0FBQ3hGLFFBQU04RSxNQUFJRixHQUFHM0QsTUFBTStDLFFBQU07QUFDekIsUUFBTWUsV0FBU3ZGLFFBQVEsTUFBSTtBQUFDLFVBQU13RixNQUFJLG9CQUFJQyxJQUFtQjtBQUFFLEtBQUN2QixTQUFTekMsUUFBTSxJQUFJaUUsUUFBUSxDQUFBQyxPQUFJQSxFQUFFSixZQUFVLElBQUlHLFFBQVEsQ0FBQUUsTUFBR0osSUFBSUssSUFBSUQsRUFBRUUsZUFBY04sSUFBSXZCLElBQUkyQixFQUFFRSxZQUFZLEtBQUcsS0FBR2hFLE9BQU84RCxFQUFFRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7QUFBRSxXQUFPLENBQUMsR0FBR1AsSUFBSVEsUUFBUSxDQUFDO0FBQUEsRUFBRSxHQUFFLENBQUM5QixTQUFTekMsSUFBSSxDQUFDO0FBQ3ZQLFFBQU13RSxTQUFPWCxJQUFJWSxPQUFPLENBQUFDLE1BQUcsQ0FBQyxXQUFVLGtCQUFrQixFQUFFQyxTQUFTRCxFQUFFRSxJQUFJLEtBQUdGLEVBQUVHLFdBQVMsV0FBVztBQUNsRyxRQUFNQyxVQUFRakIsSUFBSVksT0FBTyxDQUFBQyxNQUFHLENBQUMsY0FBYSxxQkFBb0IsbUJBQW1CLEVBQUVDLFNBQVNELEVBQUVFLElBQUksS0FBR0YsRUFBRUcsV0FBUyxXQUFXO0FBQzNILFFBQU1FLGdCQUFjQSxDQUFDQyxVQUFhO0FBQUMsVUFBTUMsU0FBTyxvQkFBSWpCLElBQW1CO0FBQUVnQixVQUFNZixRQUFRLENBQUFTLE1BQUdPLE9BQU9iLElBQUlNLEVBQUVMLGVBQWNZLE9BQU96QyxJQUFJa0MsRUFBRUwsWUFBWSxLQUFHLEtBQUdoRSxPQUFPcUUsRUFBRVEsTUFBTSxDQUFDLENBQUM7QUFBRSxXQUFPLENBQUMsR0FBR0QsT0FBT1YsUUFBUSxDQUFDLEVBQUVSLElBQUksQ0FBQyxDQUFDb0IsR0FBRXBFLENBQUMsTUFBSWQsTUFBTWMsR0FBRW9FLENBQUMsQ0FBQyxFQUFFQyxLQUFLLEtBQUssS0FBRztBQUFBLEVBQUk7QUFFOU8sU0FBTyx1QkFBQyxhQUFRLFdBQVUsNkJBQTRCO0FBQUEsMkJBQUMsZUFBWSxPQUFPLFVBQVUsT0FBT3hCLE1BQU15QixTQUFPLFdBQVMsS0FBS3pCLEtBQUt5QixLQUFLQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBRyxFQUFFLElBQUksVUFBUyx5REFBd0QsUUFBUSx1QkFBQyxRQUFLLFdBQVUsbUJBQWtCLElBQUcsc0JBQXFCO0FBQUEsNkJBQUMsa0JBQWUsTUFBTSxNQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFBRTtBQUFBLFNBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0csS0FBN1E7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxUjtBQUFBLElBQzNVLHVCQUFDLFNBQUksV0FBVSxjQUFhO0FBQUEsNkJBQUMsYUFBUSxXQUFVLHlCQUF3QjtBQUFBLCtCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFPO0FBQUEsUUFBRSx1QkFBQyxVQUFLLDJCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUI7QUFBQSxRQUFPLHVCQUFDLFlBQVE3QyxtQkFBU3pDLE1BQU11RixVQUFRLE9BQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUFTLHVCQUFDLFdBQU0sK0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzQztBQUFBLFdBQS9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUs7QUFBQSxNQUFVLHVCQUFDLGFBQVEsV0FBVSx5QkFBd0I7QUFBQSwrQkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWM7QUFBQSxRQUFFLHVCQUFDLFVBQUssK0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQjtBQUFBLFFBQU8sdUJBQUMsWUFBUTVCLGFBQUc2QixZQUFVLE1BQUlULGNBQWNQLE1BQU0sS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQVMsdUJBQUMsV0FBTSxtREFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsV0FBMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrTTtBQUFBLE1BQVUsdUJBQUMsYUFBUSxXQUFVLHlCQUF3QjtBQUFBLCtCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYTtBQUFBLFFBQUUsdUJBQUMsVUFBSywrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsUUFBTyx1QkFBQyxZQUFRYixhQUFHNkIsWUFBVSxNQUFJVCxjQUFjRCxPQUFPLEtBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUFTLHVCQUFDLFdBQU0sb0VBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFdBQTNNO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbU47QUFBQSxNQUFVLHVCQUFDLGFBQVEsV0FBVSx5QkFBd0I7QUFBQSwrQkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUFFLHVCQUFDLFVBQUssbUNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQU8sdUJBQUMsWUFBUW5CLGFBQUczRCxNQUFNK0MsS0FBS3dDLFVBQVEsT0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQVMsdUJBQUMsV0FBTSxrREFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsV0FBakw7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5TDtBQUFBLFNBQS95QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXl6QjtBQUFBLElBQ3p6Qix1QkFBQyxTQUFJLFdBQVUsV0FBVTtBQUFBLDZCQUFDLGFBQVEsV0FBVSx3QkFBdUI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUEsaUNBQUMsU0FBSTtBQUFBLG1DQUFDLFFBQUcsZ0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0I7QUFBQSxZQUFLLHVCQUFDLE9BQUUsc0RBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxlQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRTtBQUFBLFVBQU0sdUJBQUMsUUFBSyxJQUFHLHNCQUFxQiwrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxhQUE3SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9LO0FBQUEsUUFBTzlDLFNBQVMrQyxZQUFVLHVCQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFNLElBQUcvQyxTQUFTZ0QsVUFBUSx1QkFBQyxTQUFNLE1BQUssU0FBUSxTQUFTdkUsYUFBYXVCLFNBQVNwQixLQUFLLEdBQUcsT0FBTyxNQUFJLEtBQUtvQixTQUFTaUQsUUFBUSxLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThGLElBQUc1QixTQUFTeUIsV0FBUyxJQUFFLHVCQUFDLFNBQU0sTUFBSyxTQUFRLFNBQVEsd0RBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0YsSUFBRyx1QkFBQyxTQUFJLFdBQVUsbUJBQW1CekIsbUJBQVNDLElBQUksQ0FBQyxDQUFDb0IsR0FBRXBFLENBQUMsTUFBSSx1QkFBQyxTQUFZO0FBQUEsaUNBQUMsVUFBTW9FLGVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUztBQUFBLFVBQU8sdUJBQUMsWUFBUWxGLGdCQUFNYyxHQUFFb0UsQ0FBQyxLQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLGFBQXZDQSxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQsQ0FBTSxLQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBIO0FBQUEsV0FBcGtCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMmtCO0FBQUEsTUFDcG1CLHVCQUFDLGFBQVEsV0FBVSx3QkFBdUI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsaUJBQWdCLGlDQUFDLFNBQUk7QUFBQSxpQ0FBQyxRQUFHLDZCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFBSyx1QkFBQyxPQUFFLDBDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsYUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RCxLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlHO0FBQUEsUUFBTSx1QkFBQyxTQUFJLFdBQVUsY0FBYTtBQUFBLGlDQUFDLFFBQUssSUFBRyxzQkFBcUI7QUFBQSxtQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFXO0FBQUEsWUFBRTtBQUFBLGVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsVUFBTyx1QkFBQyxRQUFLLElBQUcscUJBQW9CO0FBQUEsbUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBYztBQUFBLFlBQUU7QUFBQSxlQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLFVBQU8sdUJBQUMsUUFBSyxJQUFHLHdCQUF1QjtBQUFBLG1DQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWE7QUFBQSxZQUFFO0FBQUEsZUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUFPLHVCQUFDLFFBQUssSUFBRywyQkFBMEI7QUFBQSxtQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVU7QUFBQSxZQUFFO0FBQUEsZUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxhQUF0UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZSO0FBQUEsV0FBOWE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvYjtBQUFBLFNBRHBiO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDOGI7QUFBQSxJQUM5Yix1QkFBQyxhQUFRLFdBQVUsd0JBQXVCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBLCtCQUFDLFNBQUk7QUFBQSxpQ0FBQyxRQUFHLG1DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUEsVUFBSyx1QkFBQyxPQUFFLG9FQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsYUFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFFBQU0sdUJBQUMsUUFBSyxJQUFHLDBCQUF5QiwwQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFdBQTdLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0w7QUFBQSxNQUFPeEIsR0FBRzZCLFlBQVUsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU0sSUFBRzdCLEdBQUc4QixVQUFRLHVCQUFDLFNBQU0sTUFBSyxTQUFRLFNBQVN2RSxhQUFheUMsR0FBR3RDLEtBQUssR0FBRyxPQUFPLE1BQUksS0FBS3NDLEdBQUcrQixRQUFRLEtBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0YsSUFBRzdCLElBQUkwQixXQUFTLElBQUUsdUJBQUMsU0FBTSxNQUFLLFNBQVEsU0FBUSw0QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRCxJQUFHLHVCQUFDLGNBQVc7QUFBQSwrQkFBQyxXQUFNLGlDQUFDLFFBQUc7QUFBQSxpQ0FBQyxRQUFHLHlCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWE7QUFBQSxVQUFLLHVCQUFDLFFBQUcsb0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQUssdUJBQUMsUUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFRO0FBQUEsVUFBSyx1QkFBQyxRQUFHLHNCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVU7QUFBQSxVQUFLLHVCQUFDLFFBQUcsV0FBVSxlQUFjLHNCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLGFBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0csS0FBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSDtBQUFBLFFBQVEsdUJBQUMsV0FBTzFCLGNBQUlFLElBQUksQ0FBQVcsTUFBRyx1QkFBQyxRQUFjO0FBQUEsaUNBQUMsUUFBRyxpQ0FBQyxRQUFLLElBQUksMEJBQTBCQSxFQUFFaUIsRUFBRSxJQUFLakIsWUFBRWtCLGFBQVdsQixFQUFFaUIsR0FBR0UsTUFBTSxHQUFFLEVBQUUsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkUsS0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUFLLHVCQUFDLFFBQUluQixZQUFFRSxLQUFLeEIsV0FBVyxLQUFJLEdBQUcsS0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUFLLHVCQUFDLFFBQUl0QyxlQUFLNEQsRUFBRW9CLFNBQVMsS0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUFLLHVCQUFDLFFBQUcsaUNBQUMsVUFBTyxPQUFPcEIsRUFBRUcsVUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0IsS0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEI7QUFBQSxVQUFLLHVCQUFDLFFBQUcsV0FBVSxlQUFlNUUsZ0JBQU15RSxFQUFFUSxRQUFPUixFQUFFTCxZQUFZLEtBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTREO0FBQUEsYUFBalFLLEVBQUVpQixJQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK1EsQ0FBSyxLQUF2UztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlTO0FBQUEsV0FBL2E7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1YjtBQUFBLFNBQXgxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXMyQjtBQUFBLElBQ3QyQix1QkFBQyxPQUFFLFdBQVUsbUJBQWtCLHFLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9MO0FBQUEsT0FMN0s7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtpTDtBQUN6TDtBQUFDakMsSUFkZUQsdUJBQXFCO0FBQUEsVUFDckJ0QixhQUF3Qk8saUJBQXlDM0QsT0FBTztBQUFBO0FBQUEsTUFEeEUwRTtBQWdCVCxnQkFBU3NDLG1CQUFtQjtBQUFBQyxNQUFBO0FBQ2xDLFFBQU0sQ0FBQ0MsU0FBUUMsVUFBVSxJQUFFMUgsU0FBUyxFQUFDb0csTUFBSyxJQUFHQyxRQUFPLElBQUdzQixXQUFVLElBQUdDLFNBQVEsSUFBR0MsV0FBVSxJQUFHQyxXQUFVLEdBQUUsQ0FBQztBQUN6RyxRQUFNLENBQUN6RCxNQUFLMEQsT0FBTyxJQUFFL0gsU0FBUyxDQUFDO0FBQy9CLFFBQU1tRSxTQUFPNkQsT0FBT0MsWUFBWUQsT0FBT2pDLFFBQVEwQixPQUFPLEVBQUV4QixPQUFPLENBQUMsR0FBRTFELENBQUMsTUFBSUEsTUFBSSxFQUFFLENBQUM7QUFDOUUsUUFBTTRDLEtBQUdqQixnQkFBZ0IsRUFBQ0csTUFBS0MsT0FBTSxJQUFHLEdBQUdILE9BQU0sQ0FBQztBQUFHLFFBQU1JLE9BQUtZLEdBQUczRCxNQUFNK0MsUUFBTTtBQUFJLFFBQU0yRCxhQUFXL0MsR0FBRzNELE1BQU1pRCxZQUFZeUQsY0FBWTtBQUNySSxTQUFPLHVCQUFDLGFBQVEsV0FBVSw2QkFBNEI7QUFBQSwyQkFBQyxlQUFZLE9BQU0sZ0JBQWUsVUFBUyxtRUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwRztBQUFBLElBQ2hLLHVCQUFDLFNBQUksV0FBVSx3QkFBdUI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0JBQWlCO0FBQUEsK0JBQUMsV0FBTTtBQUFBO0FBQUEsVUFBSSx1QkFBQyxZQUFPLE9BQU9ULFFBQVFyQixNQUFNLFVBQVUsQ0FBQXpELE1BQUcrRSxXQUFXLEVBQUMsR0FBR0QsU0FBUXJCLE1BQUt6RCxFQUFFd0YsT0FBT3pHLE1BQUssQ0FBQyxHQUFHO0FBQUEsbUNBQUMsWUFBTyxPQUFNLElBQUcseUJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBCO0FBQUEsWUFBVSxDQUFDLFdBQVUsY0FBYSxxQkFBb0Isb0JBQW1CLHFCQUFvQixpQkFBZ0IsUUFBUSxFQUFFNkQsSUFBSSxDQUFBNkMsTUFBRyx1QkFBQyxZQUFnQkEsZUFBSkEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQixDQUFTO0FBQUEsZUFBNVE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOFE7QUFBQSxhQUF6UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtTO0FBQUEsUUFBUSx1QkFBQyxXQUFNO0FBQUE7QUFBQSxVQUFNLHVCQUFDLFlBQU8sT0FBT1gsUUFBUXBCLFFBQVEsVUFBVSxDQUFBMUQsTUFBRytFLFdBQVcsRUFBQyxHQUFHRCxTQUFRcEIsUUFBTzFELEVBQUV3RixPQUFPekcsTUFBSyxDQUFDLEdBQUc7QUFBQSxtQ0FBQyxZQUFPLE9BQU0sSUFBRyw0QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkI7QUFBQSxZQUFVLENBQUMsV0FBVSxjQUFhLGFBQVksVUFBUyxhQUFZLFVBQVUsRUFBRTZELElBQUksQ0FBQTZDLE1BQUcsdUJBQUMsWUFBZ0JBLGVBQUpBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUIsQ0FBUztBQUFBLGVBQTNPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZPO0FBQUEsYUFBMVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtUTtBQUFBLFFBQVEsdUJBQUMsV0FBTTtBQUFBO0FBQUEsVUFBSSx1QkFBQyxXQUFNLE1BQUssUUFBTyxPQUFPWCxRQUFRRSxXQUFXLFVBQVUsQ0FBQWhGLE1BQUcrRSxXQUFXLEVBQUMsR0FBR0QsU0FBUUUsV0FBVWhGLEVBQUV3RixPQUFPekcsTUFBSyxDQUFDLEtBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRHO0FBQUEsYUFBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5SDtBQUFBLFFBQVEsdUJBQUMsV0FBTTtBQUFBO0FBQUEsVUFBRSx1QkFBQyxXQUFNLE1BQUssUUFBTyxPQUFPK0YsUUFBUUcsU0FBUyxVQUFVLENBQUFqRixNQUFHK0UsV0FBVyxFQUFDLEdBQUdELFNBQVFHLFNBQVFqRixFQUFFd0YsT0FBT3pHLE1BQUssQ0FBQyxLQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RztBQUFBLGFBQWpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxRQUFRLHVCQUFDLFdBQU07QUFBQTtBQUFBLFVBQVUsdUJBQUMsV0FBTSxXQUFVLFdBQVUsT0FBTytGLFFBQVFJLFdBQVcsVUFBVSxDQUFBbEYsTUFBRytFLFdBQVcsRUFBQyxHQUFHRCxTQUFRSSxXQUFVbEYsRUFBRXdGLE9BQU96RyxNQUFLLENBQUMsS0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0g7QUFBQSxhQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVJO0FBQUEsUUFBUSx1QkFBQyxXQUFNO0FBQUE7QUFBQSxVQUFVLHVCQUFDLFdBQU0sV0FBVSxXQUFVLE9BQU8rRixRQUFRSyxXQUFXLFVBQVUsQ0FBQW5GLE1BQUcrRSxXQUFXLEVBQUMsR0FBR0QsU0FBUUssV0FBVW5GLEVBQUV3RixPQUFPekcsTUFBSyxDQUFDLEtBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9IO0FBQUEsYUFBckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1STtBQUFBLFdBQXZtQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQSttQztBQUFBLE1BQU0sdUJBQUMsU0FBSSxXQUFVLHFCQUFvQjtBQUFBLCtCQUFDLFlBQU8sV0FBVSxxQkFBb0IsU0FBUyxNQUFJO0FBQUNnRyxxQkFBVyxFQUFDdEIsTUFBSyxJQUFHQyxRQUFPLElBQUdzQixXQUFVLElBQUdDLFNBQVEsSUFBR0MsV0FBVSxJQUFHQyxXQUFVLEdBQUUsQ0FBQztBQUFFQyxrQkFBUSxDQUFDO0FBQUEsUUFBRSxHQUFHLDZCQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlLO0FBQUEsUUFBUyx1QkFBQyxZQUFPLFdBQVUsbUJBQWtCLFNBQVMsTUFBSSxLQUFLNUMsR0FBRytCLFFBQVEsR0FBRztBQUFBLGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFBRTtBQUFBLGFBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUc7QUFBQSxXQUFsVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJUO0FBQUEsU0FBdDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNDlDO0FBQUEsSUFDNTlDLHVCQUFDLGFBQVEsV0FBVSx3QkFBdUI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQWdCLGlDQUFDLFNBQUk7QUFBQSwrQkFBQyxRQUFHLG1DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxRQUFLLHVCQUFDLE9BQUcvQjtBQUFBQSxhQUFHM0QsTUFBTWlELFlBQVk0RCxTQUFPOUQsS0FBS3dDO0FBQUFBLFVBQU87QUFBQSxhQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsV0FBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRyxLQUExSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdKO0FBQUEsTUFBTzVCLEdBQUc2QixZQUFVLHVCQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFNLElBQUc3QixHQUFHOEIsVUFBUSx1QkFBQyxTQUFNLE1BQUssU0FBUSxTQUFTdkUsYUFBYXlDLEdBQUd0QyxLQUFLLEdBQUcsT0FBTyxNQUFJLEtBQUtzQyxHQUFHK0IsUUFBUSxLQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtGLElBQUczQyxLQUFLd0MsV0FBUyxJQUFFLHVCQUFDLFNBQU0sTUFBSyxTQUFRLFNBQVEsMENBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0UsSUFBRyx1QkFBQyxjQUFXO0FBQUEsK0JBQUMsV0FBTSxpQ0FBQyxRQUFHO0FBQUEsaUNBQUMsUUFBRyx5QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFhO0FBQUEsVUFBSyx1QkFBQyxRQUFHLG9CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVE7QUFBQSxVQUFLLHVCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQUssdUJBQUMsUUFBRyxzQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFVO0FBQUEsVUFBSyx1QkFBQyxRQUFHLHdCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQSxVQUFLLHVCQUFDLFFBQUcsV0FBVSxlQUFjLHNCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLGFBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEgsS0FBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSTtBQUFBLFFBQVEsdUJBQUMsV0FBT3hDLGVBQUtnQixJQUFJLENBQUFXLE1BQUcsdUJBQUMsUUFBYztBQUFBLGlDQUFDLFFBQUcsaUNBQUMsUUFBSyxJQUFJLDBCQUEwQkEsRUFBRWlCLEVBQUUsSUFBS2pCLFlBQUVrQixhQUFXbEIsRUFBRWlCLEdBQUdFLE1BQU0sR0FBRSxFQUFFLEtBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFLEtBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsVUFBSyx1QkFBQyxRQUFJbkIsWUFBRUUsS0FBS3hCLFdBQVcsS0FBSSxHQUFHLEtBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFBSyx1QkFBQyxRQUFJdEMsZUFBSzRELEVBQUVvQixTQUFTLEtBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUEsVUFBSyx1QkFBQyxRQUFHLGlDQUFDLFVBQU8sT0FBT3BCLEVBQUVHLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCLEtBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFBSyx1QkFBQyxRQUFJSCxZQUFFTCxnQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLFVBQUssdUJBQUMsUUFBRyxXQUFVLGVBQWVwRSxnQkFBTXlFLEVBQUVRLFFBQU9SLEVBQUVMLFlBQVksS0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQ7QUFBQSxhQUExUkssRUFBRWlCLElBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3UyxDQUFLLEtBQWpVO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbVU7QUFBQSxXQUE3ZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFlO0FBQUEsTUFBYyx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFNBQVE7QUFBQTtBQUFBLFVBQU05QztBQUFBQSxVQUFLO0FBQUEsVUFBSzZEO0FBQUFBLGFBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxRQUFPLHVCQUFDLFNBQUk7QUFBQSxpQ0FBQyxZQUFPLFdBQVUsNEJBQTJCLFVBQVU3RCxRQUFNLEtBQUdjLEdBQUdtRCxZQUFZLFNBQVMsTUFBSVAsUUFBUSxDQUFBeEYsTUFBR2dHLEtBQUtDLElBQUksR0FBRWpHLElBQUUsQ0FBQyxDQUFDLEdBQUc7QUFBQSxtQ0FBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0I7QUFBQSxZQUFFO0FBQUEsZUFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEo7QUFBQSxVQUFTLHVCQUFDLFlBQU8sV0FBVSw0QkFBMkIsVUFBVThCLFFBQU02RCxjQUFZL0MsR0FBR21ELFlBQVksU0FBUyxNQUFJUCxRQUFRLENBQUF4RixNQUFHQSxJQUFFLENBQUMsR0FBRztBQUFBO0FBQUEsWUFBSyx1QkFBQyxlQUFZLE1BQU0sSUFBSSxPQUFPLEVBQUNrRyxXQUFVLGlCQUFnQixLQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLGVBQXRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdMO0FBQUEsYUFBaFc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5VztBQUFBLFdBQWxjO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd2M7QUFBQSxNQUFNLHVCQUFDLE9BQUUsV0FBVSxxQkFBb0IsMElBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMko7QUFBQSxTQUF4K0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0K0M7QUFBQSxPQUZyK0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUUrK0M7QUFDdi9DO0FBQUNqQixJQVJlRCxrQkFBZ0I7QUFBQSxVQUl0QnJELGVBQWU7QUFBQTtBQUFBLE1BSlRxRDtBQVVULGdCQUFTbUIseUJBQXlCO0FBQUFDLE1BQUE7QUFDeEMsUUFBTSxFQUFDQyxnQkFBYyxHQUFFLElBQUUxSSxVQUFVO0FBQUcsUUFBTTJJLElBQUV6SSxTQUFTLEVBQUN5RCxVQUFTLENBQUMsZUFBYytFLGFBQWEsR0FBRTlFLFNBQVEsWUFBU3hDLE9BQU8sTUFBTWhCLElBQUkwRCxJQUFJLGlCQUFpQjRFLGFBQWEsRUFBRSxDQUFDLEVBQUVFLFlBQVcsQ0FBQztBQUNwTCxNQUFHRCxFQUFFN0IsVUFBVSxRQUFPLHVCQUFDLGFBQVEsV0FBVSxrQkFBaUIsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQU0sS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QztBQUNsRSxNQUFHNkIsRUFBRTVCLFFBQVEsUUFBTyx1QkFBQyxhQUFRLFdBQVUsa0JBQWlCLGlDQUFDLFNBQU0sTUFBTTRCLEVBQUVoRyxTQUFTZ0csRUFBRWhHLE1BQWNELFVBQVV5RCxXQUFTLE1BQUssV0FBUyxTQUFTLFNBQVMzRCxhQUFhbUcsRUFBRWhHLEtBQUssR0FBRyxPQUFPLE1BQUksS0FBS2dHLEVBQUUzQixRQUFRLEtBQTVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEksS0FBbEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFvTDtBQUN4TSxRQUFNaEIsSUFBRTJDLEVBQUVySDtBQUNWLFNBQU8sdUJBQUMsYUFBUSxXQUFVLDZCQUE0QjtBQUFBLDJCQUFDLGVBQVksT0FBTSx1QkFBc0IsVUFBUyxzREFBcUQsUUFBUSx1QkFBQyxRQUFLLFdBQVUscUJBQW9CLElBQUcsMEJBQXlCO0FBQUEsNkJBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0I7QUFBQSxNQUFFO0FBQUEsU0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2RyxLQUE1TjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9PO0FBQUEsSUFBRSx1QkFBQyxhQUFRLFdBQVUsd0JBQXVCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLG9CQUFtQjtBQUFBLCtCQUFDLFVBQU0wRSxZQUFFRSxNQUFNeEIsV0FBVyxLQUFJLEdBQUcsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQU8sdUJBQUMsWUFBUW5ELGdCQUFNeUUsRUFBRVEsUUFBT1IsRUFBRUwsWUFBWSxLQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFBUyx1QkFBQyxVQUFPLE9BQU9LLEVBQUVHLFVBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxXQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVKO0FBQUEsTUFBTSx1QkFBQyxTQUFJLFdBQVUsa0JBQWtCMkIsaUJBQU9qQyxRQUFRLEVBQUNnRCxXQUFVN0MsRUFBRWtCLFdBQVU0QixJQUFHOUMsRUFBRWlCLElBQUc4QixVQUFTL0MsRUFBRUwsY0FBYXFELE1BQUtoRCxFQUFFRSxNQUFLMUIsUUFBT3dCLEVBQUVHLFFBQU84QyxTQUFRN0csS0FBSzRELEVBQUVvQixTQUFTLEdBQUU4QixTQUFROUcsS0FBSzRELEVBQUVtRCxTQUFTLEdBQUVDLGFBQVlwRCxFQUFFcUQsWUFBVyxDQUFDLEVBQUV0RCxPQUFPLENBQUMsR0FBRTFELENBQUMsTUFBSUEsTUFBSU4sVUFBV00sTUFBSSxJQUFJLEVBQUVnRCxJQUFJLENBQUMsQ0FBQ2lFLEdBQUVqSCxDQUFDLE1BQUksdUJBQUMsU0FBWTtBQUFBLCtCQUFDLFdBQU9pSCxlQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVTtBQUFBLFFBQVEsdUJBQUMsWUFBUUMsaUJBQU9sSCxDQUFDLEtBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxXQUF4Q2lILEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRCxDQUFNLEtBQXpVO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMlU7QUFBQSxTQUFsaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3aEI7QUFBQSxPQUE3eUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF1ekI7QUFDL3pCO0FBQUNiLElBTmVELHdCQUFzQjtBQUFBLFVBQ1p4SSxXQUFxQkUsUUFBUTtBQUFBO0FBQUEsTUFEdkNzSTtBQVFoQixTQUFTZ0Isa0JBQWtCLEVBQUNDLEtBQWtDLEdBQUc7QUFBQUMsTUFBQTtBQUNoRSxRQUFNM0YsV0FBU04sWUFBWTtBQUFHLFFBQU1rRyxLQUFHeEosZUFBZTtBQUFHLFFBQU0sQ0FBQ3lKLFdBQVVDLFlBQVksSUFBRS9KLFNBQVMsRUFBRTtBQUFHLFFBQU0sQ0FBQzBHLFFBQU9zRCxTQUFTLElBQUVoSyxTQUFTLEVBQUU7QUFBRyxRQUFNLENBQUMyQixVQUFTc0ksV0FBVyxJQUFFakssU0FBUyxLQUFLO0FBQUcsUUFBTSxDQUFDa0ssTUFBS0MsT0FBTyxJQUFFbkssU0FBUyxFQUFFO0FBQzNOLFFBQU1vSyxXQUFTbkcsU0FBU3pDLE1BQU02SSxLQUFLLENBQUEzRSxNQUFHQSxFQUFFeUIsT0FBSzJDLFNBQVM7QUFDdEQsUUFBTVEsV0FBU25LLFlBQVksRUFBQ29LLFlBQVcsWUFBUztBQUFDLFVBQU1DLE1BQUlOLFFBQU1PLE9BQU9DLFdBQVc7QUFBRVAsWUFBUUssR0FBRztBQUFFLFdBQU9sSixPQUFPLE1BQU1oQixJQUFJcUssS0FBSyxhQUFhYixTQUFTLElBQUlILFNBQU8sWUFBVSxhQUFXLGFBQWEsSUFBRyxFQUFDakQsUUFBTy9FLFVBQVNBLFNBQVNpSixZQUFZLEVBQUMsR0FBRSxFQUFDQyxTQUFRLEVBQUMsbUJBQWtCTCxJQUFHLEVBQUMsQ0FBQyxDQUFDO0FBQUEsRUFBRSxHQUFFTSxXQUFVLFlBQVM7QUFBQ3RLLFVBQU11SyxRQUFRLEdBQUdwQixTQUFPLFlBQVUsWUFBVSxZQUFZLHFCQUFxQjtBQUFFSyxjQUFVLEVBQUU7QUFBRUcsWUFBUSxFQUFFO0FBQUUsVUFBTWEsUUFBUTNGLElBQUksQ0FBQ3dFLEdBQUdvQixrQkFBa0IsRUFBQ3BILFVBQVMsQ0FBQyxZQUFXLFVBQVUsRUFBQyxDQUFDLEdBQUVnRyxHQUFHb0Isa0JBQWtCLEVBQUNwSCxVQUFTLENBQUMsWUFBVyxjQUFjLEVBQUMsQ0FBQyxDQUFDLENBQUM7QUFBQSxFQUFFLEdBQUVxSCxTQUFRQSxDQUFBdkksTUFBR25DLE1BQU1xQyxNQUFNSCxhQUFhQyxDQUFDLENBQUMsRUFBQyxDQUFDO0FBQ3RrQixTQUFPLHVCQUFDLGFBQVEsV0FBVSw2QkFBNEI7QUFBQSwyQkFBQyxlQUFZLE9BQU9nSCxTQUFPLFlBQVUsa0JBQWdCLGtCQUFrQixVQUFTLGdGQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRKO0FBQUEsSUFBRSx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCO0FBQUEsNkJBQUMsYUFBUSxXQUFVLHdCQUF1QixpQ0FBQyxVQUFLLFdBQVUsV0FBVSxVQUFVLENBQUFoSCxNQUFHO0FBQUNBLFVBQUV3SSxlQUFlO0FBQUUsWUFBRyxDQUFDckIsVUFBVTtBQUFPUSxpQkFBU2MsT0FBTztBQUFBLE1BQUUsR0FBRztBQUFBLCtCQUFDLFdBQU07QUFBQTtBQUFBLFVBQU8sdUJBQUMsWUFBTyxVQUFRLE1BQUMsT0FBT3RCLFdBQVcsVUFBVSxDQUFBbkgsTUFBRztBQUFDLGtCQUFNMEksT0FBS3BILFNBQVN6QyxNQUFNNkksS0FBSyxDQUFBM0UsTUFBR0EsRUFBRXlCLE9BQUt4RSxFQUFFd0YsT0FBT3pHLEtBQUs7QUFBRXFJLHlCQUFhcEgsRUFBRXdGLE9BQU96RyxLQUFLO0FBQUV1SSx3QkFBWW9CLE1BQU0vRixXQUFXLENBQUMsR0FBR08sZ0JBQWMsS0FBSztBQUFFc0Usb0JBQVEsRUFBRTtBQUFBLFVBQUUsR0FBRztBQUFBLG1DQUFDLFlBQU8sT0FBTSxJQUFHLGlDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLGFBQVdsRyxTQUFTekMsUUFBTSxJQUFJK0QsSUFBSSxDQUFBRyxNQUFHLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUV5QixJQUFLekI7QUFBQUEsZ0JBQUU0RjtBQUFBQSxjQUFjO0FBQUEsY0FBSTVGLEVBQUU2RjtBQUFBQSxjQUFZO0FBQUEsY0FBSTdGLEVBQUVXO0FBQUFBLGlCQUE1RFgsRUFBRXlCLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0YsQ0FBUztBQUFBLGVBQTVXO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThXO0FBQUEsYUFBNVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxWTtBQUFBLFFBQVNsRCxTQUFTK0MsYUFBVyx1QkFBQyxXQUFNLGlDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUFVL0MsU0FBU2dELFdBQVMsdUJBQUMsU0FBTSxNQUFLLFNBQVEsU0FBU3ZFLGFBQWF1QixTQUFTcEIsS0FBSyxHQUFHLE9BQU8sTUFBSSxLQUFLb0IsU0FBU2lELFFBQVEsS0FBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RjtBQUFBLFFBQUcsdUJBQUMsV0FBTTtBQUFBO0FBQUEsVUFBTSx1QkFBQyxXQUFNLFVBQVEsTUFBQyxXQUFVLFdBQVUsU0FBUSx3QkFBb0IsS0FBSSxjQUFhLGFBQVksUUFBTyxPQUFPUixRQUFRLFVBQVUsQ0FBQS9ELE1BQUc7QUFBQ3FILHNCQUFVckgsRUFBRXdGLE9BQU96RyxLQUFLO0FBQUV5SSxvQkFBUSxFQUFFO0FBQUEsVUFBRSxLQUF2SztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SztBQUFBLFVBQUUsdUJBQUMsV0FBTSx5REFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLGFBQXhPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ1A7QUFBQSxRQUFRLHVCQUFDLFdBQU07QUFBQTtBQUFBLFVBQVEsdUJBQUMsWUFBTyxVQUFRLE1BQUMsT0FBT3hJLFVBQVUsVUFBVSxDQUFBZ0IsTUFBRztBQUFDc0gsd0JBQVl0SCxFQUFFd0YsT0FBT3pHLEtBQUs7QUFBRXlJLG9CQUFRLEVBQUU7QUFBQSxVQUFFLEdBQUtDLHFCQUFVOUUsWUFBVSxJQUFJQyxJQUFJLENBQUFJLE1BQUcsdUJBQUMsWUFBNEIsT0FBT0EsRUFBRUUsY0FBZUYsWUFBRUUsZ0JBQTFDRixFQUFFRSxjQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FLENBQVMsS0FBek07QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMk07QUFBQSxVQUFTLHVCQUFDLFdBQU0sb0VBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkQ7QUFBQSxhQUE5UjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNTO0FBQUEsUUFBU3VFLFlBQVUsdUJBQUMsU0FBSSxXQUFVLGVBQWM7QUFBQTtBQUFBLFVBQWtCLHVCQUFDLFlBQVFBLG1CQUFTa0IsaUJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFBUyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUc7QUFBQSxVQUFFO0FBQUEsV0FBcUJsQixTQUFTOUUsWUFBVSxJQUFJQyxJQUFJLENBQUE2QyxNQUFHLEdBQUczRyxNQUFNMkcsRUFBRXRDLGtCQUFpQnNDLEVBQUV2QyxZQUFZLENBQUMsRUFBRSxFQUFFZSxLQUFLLEtBQUssS0FBRztBQUFBLGFBQTVNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMk47QUFBQSxRQUFPLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCO0FBQUEsVUFBRTtBQUFBLGFBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUo7QUFBQSxRQUFNLHVCQUFDLFlBQU8sV0FBVSxtQkFBa0IsVUFBVTBELFNBQVNrQixhQUFXLENBQUMxQixhQUFXLENBQUNwRCxVQUFRN0UsT0FBTzZFLE1BQU0sS0FBRyxHQUFJNEQsbUJBQVNrQixZQUFVLGdCQUFjN0IsU0FBTyxZQUFVLG1CQUFpQix1QkFBOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrTTtBQUFBLFFBQVVXLFNBQVNyRCxXQUFTLHVCQUFDLE9BQUUsV0FBVSxpQkFBZ0IsTUFBSyxTQUFTdkU7QUFBQUEsdUJBQWE0SCxTQUFTekgsS0FBSztBQUFBLFVBQUdxSCxRQUFNO0FBQUEsYUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSjtBQUFBLFFBQU1JLFNBQVNtQixhQUFXLHVCQUFDLFNBQUksV0FBVSxrQkFBaUI7QUFBQSxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQU07QUFBQSxVQUFFO0FBQUEsVUFBRW5CLFNBQVM5SSxNQUFNc0IsV0FBUztBQUFBLFVBQXFCd0gsU0FBUzlJLE1BQU1zSCxhQUFhM0IsTUFBSSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxZQUFpQm1ELFNBQVM5SSxLQUFLc0gsWUFBWTNCO0FBQUFBLGVBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsYUFBMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpTDtBQUFBLFdBQXZvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThvRSxLQUF4ckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErckU7QUFBQSxNQUFVLHVCQUFDLFdBQU0sV0FBVSx3QkFBdUI7QUFBQSwrQkFBQyxRQUFHLDRCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUFLLHVCQUFDLFFBQUcsV0FBVSxZQUFXO0FBQUEsaUNBQUMsUUFBRyw0Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQUssdUJBQUMsUUFBRyxpRUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLFVBQUssdUJBQUMsUUFBRyx3Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLFVBQUssdUJBQUMsUUFBRyw4RUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRTtBQUFBLGFBQTNOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ087QUFBQSxRQUFLLHVCQUFDLE9BQUUsV0FBVSxTQUFRLGtMQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVMO0FBQUEsV0FBemQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2ZDtBQUFBLFNBQXRzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThzRjtBQUFBLE9BQTM1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWk2RjtBQUN6NkY7QUFBQ3lDLElBTFFGLG1CQUFpQjtBQUFBLFVBQ1YvRixhQUF3QnRELGdCQUV4QkYsV0FBVztBQUFBO0FBQUEsTUFIbEJ1SjtBQU9GLGdCQUFTZ0MsY0FBYTtBQUFDLFNBQU8sdUJBQUMscUJBQWtCLE1BQUssYUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFpQztBQUFFO0FBQUNDLE1BQXpERDtBQUNULGdCQUFTRSxpQkFBZ0I7QUFBQyxTQUFPLHVCQUFDLHFCQUFrQixNQUFLLGdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9DO0FBQUU7QUFBQ0MsTUFBL0REO0FBRVQsZ0JBQVNFLGVBQWU7QUFBQUMsTUFBQTtBQUM5QixRQUFNOUgsV0FBU04sWUFBWTtBQUFHLFFBQU1xSSxnQkFBYzVMLFNBQVMsRUFBQ3lELFVBQVMsQ0FBQyxlQUFlLEdBQUVDLFNBQVEsWUFBU3hDLE9BQU8sTUFBTWhCLElBQUkwRCxJQUFJLGtCQUFpQixFQUFDRyxRQUFPLEVBQUNFLE1BQUssR0FBRUMsT0FBTSxJQUFHLEVBQUMsQ0FBQyxDQUFDLEVBQUUwSCxpQkFBZSxHQUFFLENBQUM7QUFDOUwsUUFBTW5DLEtBQUd4SixlQUFlO0FBQUcsUUFBTSxDQUFDNEwsUUFBT0MsU0FBUyxJQUFFbE0sU0FBUyxFQUFFO0FBQUcsUUFBTSxDQUFDbU0sVUFBU0MsV0FBVyxJQUFFcE0sU0FBUyxFQUFFO0FBQUcsUUFBTSxDQUFDMEcsUUFBT3NELFNBQVMsSUFBRWhLLFNBQVMsRUFBRTtBQUFHLFFBQU0sQ0FBQzJCLFVBQVNzSSxXQUFXLElBQUVqSyxTQUFTLEtBQUs7QUFBRyxRQUFNLENBQUNrSyxNQUFLQyxPQUFPLElBQUVuSyxTQUFTLEVBQUU7QUFDbE8sUUFBTXNLLFdBQVNuSyxZQUFZLEVBQUNvSyxZQUFXLFlBQVM7QUFBQyxVQUFNQyxNQUFJTixRQUFNTyxPQUFPQyxXQUFXO0FBQUVQLFlBQVFLLEdBQUc7QUFBRSxXQUFPbEosT0FBTyxNQUFNaEIsSUFBSXFLLEtBQUssY0FBYSxFQUFDMEIsZUFBY0osUUFBT0ssaUJBQWdCSCxVQUFTekYsUUFBTy9FLFVBQVNBLFNBQVNpSixZQUFZLEVBQUMsR0FBRSxFQUFDQyxTQUFRLEVBQUMsbUJBQWtCTCxJQUFHLEVBQUMsQ0FBQyxDQUFDO0FBQUEsRUFBRSxHQUFFTSxXQUFVLE9BQU0vRyxNQUFHO0FBQUN2RCxVQUFNdUssUUFBUWhILEdBQUdqQixXQUFTLDZCQUE2QjtBQUFFa0gsY0FBVSxFQUFFO0FBQUVHLFlBQVEsRUFBRTtBQUFFLFVBQU1hLFFBQVEzRixJQUFJLENBQUN3RSxHQUFHb0Isa0JBQWtCLEVBQUNwSCxVQUFTLENBQUMsWUFBVyxVQUFVLEVBQUMsQ0FBQyxHQUFFZ0csR0FBR29CLGtCQUFrQixFQUFDcEgsVUFBUyxDQUFDLFlBQVcsY0FBYyxFQUFDLENBQUMsQ0FBQyxDQUFDO0FBQUEsRUFBRSxHQUFFcUgsU0FBUUEsQ0FBQXZJLE1BQUduQyxNQUFNcUMsTUFBTUgsYUFBYUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQztBQUNyaUIsU0FBTyx1QkFBQyxhQUFRLFdBQVUsNkJBQTRCO0FBQUEsMkJBQUMsZUFBWSxPQUFNLGlCQUFnQixVQUFTLDhFQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXNIO0FBQUEsSUFBRSx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCO0FBQUEsNkJBQUMsYUFBUSxXQUFVLHdCQUF1QixpQ0FBQyxVQUFLLFdBQVUsV0FBVSxVQUFVLENBQUFBLE1BQUc7QUFBQ0EsVUFBRXdJLGVBQWU7QUFBRWIsaUJBQVNjLE9BQU87QUFBQSxNQUFFLEdBQUc7QUFBQSwrQkFBQyxXQUFNO0FBQUE7QUFBQSxVQUFZLHVCQUFDLFlBQU8sVUFBUSxNQUFDLE9BQU9hLFFBQVEsVUFBVSxDQUFBdEosTUFBRztBQUFDdUosc0JBQVV2SixFQUFFd0YsT0FBT3pHLEtBQUs7QUFBRXlJLG9CQUFRLEVBQUU7QUFBQSxVQUFFLEdBQUc7QUFBQSxtQ0FBQyxZQUFPLE9BQU0sSUFBRyxxQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxhQUFXbEcsU0FBU3pDLFFBQU0sSUFBSStELElBQUksQ0FBQUcsTUFBRyx1QkFBQyxZQUFrQixPQUFPQSxFQUFFeUIsSUFBS3pCO0FBQUFBLGdCQUFFNEY7QUFBQUEsY0FBYztBQUFBLGNBQUk1RixFQUFFNkY7QUFBQUEsaUJBQTFDN0YsRUFBRXlCLElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUUsQ0FBUztBQUFBLGVBQTlPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdQO0FBQUEsYUFBblE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0UTtBQUFBLFFBQVEsdUJBQUMsV0FBTTtBQUFBO0FBQUEsVUFBbUIsdUJBQUMsV0FBTSxVQUFRLE1BQUMsT0FBT2dGLFVBQVUsVUFBVSxDQUFBeEosTUFBRztBQUFDeUosd0JBQVl6SixFQUFFd0YsT0FBT3pHLE1BQU02SyxLQUFLLENBQUM7QUFBRXBDLG9CQUFRLEVBQUU7QUFBQSxVQUFFLEdBQUcsYUFBWSxpQ0FBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEk7QUFBQSxVQUFFLHVCQUFDLFdBQU0seUdBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0c7QUFBQSxhQUF0UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThRO0FBQUEsUUFBUzZCLGNBQWN4SyxNQUFNZ0wsS0FBSyxDQUFDN0csTUFBY0EsRUFBRThHLG9CQUFrQixjQUFZOUcsRUFBRStHLGFBQVcsVUFBVSxLQUFHLHVCQUFDLFdBQU07QUFBQTtBQUFBLFVBQTRCLHVCQUFDLFlBQU8sT0FBTSxJQUFHLFVBQVUsQ0FBQS9KLE1BQUc7QUFBQyxrQkFBTXlGLElBQUU0RCxjQUFjeEssS0FBSzZJLEtBQUssQ0FBQzFFLE1BQWNBLEVBQUV3QixPQUFLeEUsRUFBRXdGLE9BQU96RyxLQUFLO0FBQUUsZ0JBQUcwRyxFQUFFZ0UsYUFBWWhFLEVBQUV1RSxnQkFBZ0I7QUFBQSxVQUFFLEdBQUc7QUFBQSxtQ0FBQyxZQUFPLE9BQU0sSUFBRyxxREFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUFVWCxjQUFjeEssS0FBS3lFLE9BQU8sQ0FBQ04sTUFBY0EsRUFBRThHLG9CQUFrQixjQUFZOUcsRUFBRStHLGFBQVcsVUFBVSxFQUFFbkgsSUFBSSxDQUFDSSxNQUFjLHVCQUFDLFlBQWtCLE9BQU9BLEVBQUV3QixJQUFLeEI7QUFBQUEsZ0JBQUVpSDtBQUFBQSxjQUFZO0FBQUEsY0FBSWpILEVBQUVnSDtBQUFBQSxpQkFBeENoSCxFQUFFd0IsSUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRSxDQUFTO0FBQUEsZUFBalo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbVo7QUFBQSxhQUF0YjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStiO0FBQUEsUUFBUyx1QkFBQyxXQUFNO0FBQUE7QUFBQSxVQUFNLHVCQUFDLFdBQU0sVUFBUSxNQUFDLFdBQVUsV0FBVSxTQUFRLHdCQUFvQixLQUFJLGNBQWEsT0FBT1QsUUFBUSxVQUFVLENBQUEvRCxNQUFHO0FBQUNxSCxzQkFBVXJILEVBQUV3RixPQUFPekcsS0FBSztBQUFFeUksb0JBQVEsRUFBRTtBQUFBLFVBQUUsR0FBRyxhQUFZLFVBQW5LO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlLO0FBQUEsYUFBdEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3TDtBQUFBLFFBQVEsdUJBQUMsV0FBTTtBQUFBO0FBQUEsVUFBUSx1QkFBQyxXQUFNLFVBQVEsTUFBQyxPQUFPeEksVUFBVSxXQUFXLEdBQUcsV0FBVyxHQUFHLFNBQVEsZUFBYyxVQUFVLENBQUFnQixNQUFHO0FBQUNzSCx3QkFBWXRILEVBQUV3RixPQUFPekcsTUFBTWtKLFlBQVksQ0FBQztBQUFFVCxvQkFBUSxFQUFFO0FBQUEsVUFBRSxLQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SjtBQUFBLGFBQXhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEs7QUFBQSxRQUFRLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsaUNBQUMsZUFBWSxNQUFNLE1BQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCO0FBQUEsVUFBRTtBQUFBLGFBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ1A7QUFBQSxRQUFNLHVCQUFDLFlBQU8sV0FBVSxtQkFBa0IsVUFBVUcsU0FBU2tCLGFBQVcsQ0FBQ1MsVUFBUSxDQUFDRSxZQUFVLENBQUN6RixVQUFRN0UsT0FBTzZFLE1BQU0sS0FBRyxHQUFJNEQsbUJBQVNrQixZQUFVLGdCQUFjLHFCQUFwSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNLO0FBQUEsUUFBVWxCLFNBQVNyRCxXQUFTLHVCQUFDLE9BQUUsV0FBVSxpQkFBZ0IsTUFBSyxTQUFTdkU7QUFBQUEsdUJBQWE0SCxTQUFTekgsS0FBSztBQUFBLFVBQUdxSCxRQUFNO0FBQUEsYUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3STtBQUFBLFFBQU1JLFNBQVNtQixhQUFXLHVCQUFDLFNBQUksV0FBVSxrQkFBaUI7QUFBQSxpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQU07QUFBQSxVQUFHbkIsU0FBUzlJLE1BQU1zQixXQUFTO0FBQUEsVUFBNkJ3SCxTQUFTOUksTUFBTXNILGFBQWEzQixNQUFJLHVCQUFDLFNBQUk7QUFBQTtBQUFBLFlBQWNtRCxTQUFTOUksS0FBS3NILFlBQVkzQjtBQUFBQSxlQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLGFBQTlLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUw7QUFBQSxXQUF0eUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2eUUsS0FBdjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBODFFO0FBQUEsTUFBVSx1QkFBQyxXQUFNLFdBQVUsd0JBQXVCO0FBQUEsK0JBQUMsUUFBRyxtQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsUUFBSyx1QkFBQyxRQUFHLFdBQVUsWUFBVztBQUFBLGlDQUFDLFFBQUcsd0RBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEM7QUFBQSxVQUFLLHVCQUFDLFFBQUcsMEVBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQ7QUFBQSxVQUFLLHVCQUFDLFFBQUcsNERBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUFLLHVCQUFDLFFBQUcscUVBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxhQUEzUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdRO0FBQUEsUUFBSyx1QkFBQyxPQUFFLFdBQVUsU0FBUSxpSUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSTtBQUFBLFdBQS9jO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbWQ7QUFBQSxTQUEzMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtMkY7QUFBQSxPQUExZ0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnaEc7QUFDeGhHO0FBQUM0RSxJQUxlRCxjQUFZO0FBQUEsVUFDWm5JLGFBQW1DdkQsVUFDekNDLGdCQUNNRixXQUFXO0FBQUE7QUFBQSxNQUhYMkw7QUFPVCxnQkFBU2Usb0JBQW9CO0FBQUFDLE1BQUE7QUFDbkMsUUFBTWpELEtBQUd4SixlQUFlO0FBQUcsUUFBTSxDQUFDME0sU0FBUUMsVUFBVSxJQUFFaE4sU0FBeUIsSUFBSTtBQUFHLFFBQU0sQ0FBQ2lOLE1BQUtDLE9BQU8sSUFBRWxOLFNBQVMsRUFBQ3lNLGlCQUFnQixZQUFXRyxhQUFZLElBQUdELGtCQUFpQixJQUFHRCxVQUFTLFlBQVc3RyxjQUFhLE1BQUssQ0FBQztBQUMxTixRQUFNZ0QsSUFBRXpJLFNBQVMsRUFBQ3lELFVBQVMsQ0FBQyxlQUFlLEdBQUVDLFNBQVEsWUFBUztBQUFDLFVBQU1DLElBQUV6QyxPQUFPLE1BQU1oQixJQUFJMEQsSUFBSSxrQkFBaUIsRUFBQ0csUUFBTyxFQUFDRSxNQUFLLEdBQUVDLE9BQU0sSUFBRyxFQUFDLENBQUMsQ0FBQztBQUFFLFdBQU9QLEVBQUVpSSxpQkFBZTtBQUFBLEVBQUcsRUFBQyxDQUFDO0FBQ3hLLFFBQU1tQixPQUFLaE4sWUFBWSxFQUFDb0ssWUFBVyxZQUFTd0MsVUFBUXpMLE9BQU8sTUFBTWhCLElBQUk4TSxNQUFNLGtCQUFrQkwsUUFBUTVGLEVBQUUsSUFBRyxFQUFDeUYsYUFBWUssS0FBS0wsYUFBWUQsa0JBQWlCTSxLQUFLTixrQkFBaUJELFVBQVNPLEtBQUtQLFVBQVM3RyxjQUFhb0gsS0FBS3BILGFBQVksQ0FBQyxDQUFDLElBQUV2RSxPQUFPLE1BQU1oQixJQUFJcUssS0FBSyxrQkFBaUJzQyxJQUFJLENBQUMsR0FBRW5DLFdBQVUsWUFBUztBQUFDdEssVUFBTXVLLFFBQVFnQyxVQUFRLHdCQUFzQixxQkFBcUI7QUFBRUMsZUFBVyxJQUFJO0FBQUVFLFlBQVEsRUFBQ1QsaUJBQWdCLFlBQVdHLGFBQVksSUFBR0Qsa0JBQWlCLElBQUdELFVBQVMsWUFBVzdHLGNBQWEsTUFBSyxDQUFDO0FBQUUsVUFBTWdFLEdBQUdvQixrQkFBa0IsRUFBQ3BILFVBQVMsQ0FBQyxlQUFlLEVBQUMsQ0FBQztBQUFBLEVBQUUsR0FBRXFILFNBQVFBLENBQUF2SSxNQUFHbkMsTUFBTXFDLE1BQU1ILGFBQWFDLENBQUMsQ0FBQyxFQUFDLENBQUM7QUFDamxCLFFBQU0wSyxNQUFJbE4sWUFBWSxFQUFDb0ssWUFBV0EsQ0FBQ3BELE9BQVk3RyxJQUFJZ04sT0FBTyxrQkFBa0JuRyxFQUFFLEVBQUUsR0FBRTJELFdBQVUsWUFBUztBQUFDdEssVUFBTXVLLFFBQVEscUJBQXFCO0FBQUUsVUFBTWxCLEdBQUdvQixrQkFBa0IsRUFBQ3BILFVBQVMsQ0FBQyxlQUFlLEVBQUMsQ0FBQztBQUFBLEVBQUUsR0FBRXFILFNBQVFBLENBQUF2SSxNQUFHbkMsTUFBTXFDLE1BQU1ILGFBQWFDLENBQUMsQ0FBQyxFQUFDLENBQUM7QUFDOU8sU0FBTyx1QkFBQyxhQUFRLFdBQVUsNkJBQTRCO0FBQUEsMkJBQUMsZUFBWSxPQUFNLGlCQUFnQixVQUFTLCtEQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVHO0FBQUEsSUFBRSx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCO0FBQUEsNkJBQUMsYUFBUSxXQUFVLHdCQUF1QjtBQUFBLCtCQUFDLFFBQUlvSyxvQkFBUSxxQkFBbUIscUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Q7QUFBQSxRQUFLLHVCQUFDLFVBQUssV0FBVSxXQUFVLFVBQVUsQ0FBQXBLLE1BQUc7QUFBQ0EsWUFBRXdJLGVBQWU7QUFBRWdDLGVBQUsvQixPQUFPO0FBQUEsUUFBRSxHQUFHO0FBQUEsaUNBQUMsV0FBTTtBQUFBO0FBQUEsWUFBSSx1QkFBQyxZQUFPLE9BQU82QixLQUFLUixpQkFBaUIsVUFBVSxDQUFBOUosTUFBR3VLLFFBQVEsRUFBQyxHQUFHRCxNQUFLUixpQkFBZ0I5SixFQUFFd0YsT0FBT3pHLE1BQUssQ0FBQyxHQUFHO0FBQUEscUNBQUMsWUFBTyx3QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGNBQVMsdUJBQUMsWUFBTyx3QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGlCQUE5STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1SjtBQUFBLGVBQWxLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJLO0FBQUEsVUFBUSx1QkFBQyxXQUFNO0FBQUE7QUFBQSxZQUFZLHVCQUFDLFdBQU0sVUFBUSxNQUFDLFdBQVcsS0FBSyxPQUFPdUwsS0FBS0wsYUFBYSxVQUFVLENBQUFqSyxNQUFHdUssUUFBUSxFQUFDLEdBQUdELE1BQUtMLGFBQVlqSyxFQUFFd0YsT0FBT3pHLE1BQUssQ0FBQyxLQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSDtBQUFBLGVBQXZJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlJO0FBQUEsVUFBUSx1QkFBQyxXQUFNO0FBQUE7QUFBQSxZQUFpQix1QkFBQyxXQUFNLFVBQVEsTUFBQyxXQUFXLEtBQUssT0FBT3VMLEtBQUtOLGtCQUFrQixVQUFVLENBQUFoSyxNQUFHdUssUUFBUSxFQUFDLEdBQUdELE1BQUtOLGtCQUFpQmhLLEVBQUV3RixPQUFPekcsTUFBSyxDQUFDLEtBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThIO0FBQUEsZUFBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0o7QUFBQSxVQUFRLHVCQUFDLFdBQU07QUFBQTtBQUFBLFlBQVEsdUJBQUMsWUFBTyxPQUFPdUwsS0FBS1AsVUFBVSxVQUFVLENBQUEvSixNQUFHdUssUUFBUSxFQUFDLEdBQUdELE1BQUtQLFVBQVMvSixFQUFFd0YsT0FBT3pHLE1BQUssQ0FBQyxHQUFJLFdBQUMsWUFBVyxTQUFRLFNBQVEsVUFBUyxVQUFTLFlBQVcsTUFBTSxFQUFFNkQsSUFBSSxDQUFBNkMsTUFBRyx1QkFBQyxZQUFnQkEsZUFBSkEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQixDQUFTLEtBQTVMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThMO0FBQUEsZUFBN007QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc047QUFBQSxVQUFRLHVCQUFDLFdBQU07QUFBQTtBQUFBLFlBQWEsdUJBQUMsV0FBTSxVQUFRLE1BQUMsV0FBVyxHQUFHLFdBQVcsR0FBRyxTQUFRLGVBQWMsT0FBTzZFLEtBQUtwSCxjQUFjLFVBQVUsQ0FBQWxELE1BQUd1SyxRQUFRLEVBQUMsR0FBR0QsTUFBS3BILGNBQWFsRCxFQUFFd0YsT0FBT3pHLE1BQU1rSixZQUFZLEVBQUMsQ0FBQyxLQUFwSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzSztBQUFBLGVBQTFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRMO0FBQUEsVUFBUSx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCO0FBQUEsbUNBQUMsWUFBTyxXQUFVLG1CQUFrQixVQUFVdUMsS0FBSzNCLFdBQVkyQixlQUFLM0IsWUFBVSxZQUFVdUIsVUFBUSxpQkFBZSx3QkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0k7QUFBQSxZQUFVQSxXQUFTLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUscUJBQW9CLFNBQVMsTUFBSTtBQUFDQyx5QkFBVyxJQUFJO0FBQUVFLHNCQUFRLEVBQUNULGlCQUFnQixZQUFXRyxhQUFZLElBQUdELGtCQUFpQixJQUFHRCxVQUFTLFlBQVc3RyxjQUFhLE1BQUssQ0FBQztBQUFBLFlBQUUsR0FBRyxzQkFBdE07QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNE07QUFBQSxlQUFwWTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4WTtBQUFBLGFBQWgyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXMyQztBQUFBLFdBQXY4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTg4QztBQUFBLE1BQVUsdUJBQUMsYUFBUSxXQUFVLHdCQUF1QjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQkFBZ0IsaUNBQUMsU0FBSTtBQUFBLGlDQUFDLFFBQUcsbUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUFLLHVCQUFDLE9BQUUscUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0I7QUFBQSxhQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZELEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0c7QUFBQSxRQUFPZ0QsRUFBRTdCLFlBQVUsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU0sSUFBRzZCLEVBQUU1QixVQUFRLHVCQUFDLFNBQU0sTUFBSyxTQUFRLFNBQVN2RSxhQUFhbUcsRUFBRWhHLEtBQUssR0FBRyxPQUFPLE1BQUksS0FBS2dHLEVBQUUzQixRQUFRLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0YsSUFBRzJCLEVBQUVySCxLQUFLdUYsV0FBUyxJQUFFLHVCQUFDLFNBQU0sTUFBSyxTQUFRLFNBQVEsK0NBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUUsSUFBRyx1QkFBQyxTQUFJLFdBQVUsdUJBQXVCOEIsWUFBRXJILEtBQUsrRCxJQUFJLENBQUNJLE1BQWMsdUJBQUMsU0FBSSxXQUFVLGtCQUE0QjtBQUFBLGlDQUFDLFNBQUk7QUFBQSxtQ0FBQyxZQUFRQSxZQUFFaUgsZUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QjtBQUFBLFlBQVMsdUJBQUMsVUFBTWpILFlBQUVnSCxvQkFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQjtBQUFBLFlBQU8sdUJBQUMsV0FBT2hIO0FBQUFBLGdCQUFFOEc7QUFBQUEsY0FBZ0I7QUFBQSxjQUFJOUcsRUFBRStHLFlBQVU7QUFBQSxjQUFjO0FBQUEsY0FBSS9HLEVBQUVFO0FBQUFBLGlCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQVEsdUJBQUMsVUFBTyxPQUFPRixFQUFFVSxVQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QjtBQUFBLGVBQWpMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1MO0FBQUEsVUFBTSx1QkFBQyxTQUFJLFdBQVUscUJBQW9CO0FBQUEsbUNBQUMsWUFBTyxXQUFVLDRCQUEyQixTQUFTLE1BQUk7QUFBQzJHLHlCQUFXckgsQ0FBQztBQUFFdUgsc0JBQVEsRUFBQ1QsaUJBQWdCOUcsRUFBRThHLGlCQUFnQkcsYUFBWWpILEVBQUVpSCxhQUFZRCxrQkFBaUJoSCxFQUFFZ0gsa0JBQWlCRCxVQUFTL0csRUFBRStHLFlBQVUsWUFBVzdHLGNBQWFGLEVBQUVFLGFBQVksQ0FBQztBQUFBLFlBQUUsR0FBRyxvQkFBblA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdVA7QUFBQSxZQUFTLHVCQUFDLFlBQU8sV0FBVSx5QkFBd0IsVUFBVXdILElBQUk3QixXQUFXLFNBQVMsTUFBSTtBQUFDLGtCQUFHK0IsUUFBUSxzQkFBc0I1SCxFQUFFaUgsV0FBVyxHQUFHLEVBQUVTLEtBQUlqQyxPQUFPekYsRUFBRXdCLEVBQUU7QUFBQSxZQUFFLEdBQUcsc0JBQXhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThKO0FBQUEsZUFBamM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMGM7QUFBQSxhQUF6b0J4QixFQUFFd0IsSUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvckIsQ0FBTSxLQUExdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0dkI7QUFBQSxXQUE3bEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvbUM7QUFBQSxTQUE1bEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzbUY7QUFBQSxPQUE5dkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFvd0Y7QUFDNXdGO0FBQUMyRixJQU5lRCxtQkFBaUI7QUFBQSxVQUN2QnhNLGdCQUNERCxVQUNHRCxhQUNEQSxXQUFXO0FBQUE7QUFBQSxPQUpOME07QUFRVCxnQkFBU1csb0JBQW9CO0FBQUFDLE1BQUE7QUFDbkMsUUFBTTVELEtBQUd4SixlQUFlO0FBQUcsUUFBTSxDQUFDcU4sUUFBT0MsU0FBUyxJQUFFM04sU0FBUyxLQUFLO0FBQ2xFLFFBQU02SSxJQUFFekksU0FBUyxFQUFDeUQsVUFBUyxDQUFDLGlCQUFnQjZKLE1BQU0sR0FBRTVKLFNBQVEsWUFBU3hDLE9BQU8sTUFBTWhCLElBQUkwRCxJQUFJLGtCQUFpQixFQUFDRyxRQUFPLEVBQUNFLE1BQUssR0FBRUMsT0FBTSxJQUFHc0osWUFBV25FLE9BQU9pRSxNQUFNLEVBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxDQUFDO0FBQ2xLLFFBQU1HLE9BQUsxTixZQUFZLEVBQUNvSyxZQUFXQSxDQUFDcEQsT0FBWTdHLElBQUk4TSxNQUFNLGtCQUFrQmpHLEVBQUUsT0FBTyxHQUFFMkQsV0FBVUEsTUFBSTtBQUFDdEssVUFBTXVLLFFBQVEsNkJBQTZCO0FBQUUsU0FBS2xCLEdBQUdvQixrQkFBa0IsRUFBQ3BILFVBQVMsQ0FBQyxlQUFlLEVBQUMsQ0FBQztBQUFBLEVBQUUsR0FBRXFILFNBQVFBLENBQUF2SSxNQUFHbkMsTUFBTXFDLE1BQU1ILGFBQWFDLENBQUMsQ0FBQyxFQUFDLENBQUM7QUFDclAsUUFBTTRCLE9BQUtzRSxFQUFFckgsTUFBTXNNLGlCQUFlO0FBQ2xDLFNBQU8sdUJBQUMsYUFBUSxXQUFVLDZCQUE0QjtBQUFBLDJCQUFDLGVBQVksT0FBTSxpQkFBZ0IsVUFBUyx3Q0FBdUMsUUFBUSx1QkFBQyxXQUFNLFdBQVUsbUJBQWtCO0FBQUEsNkJBQUMsV0FBTSxNQUFLLFlBQVcsU0FBU0osUUFBUSxVQUFVLENBQUEvSyxNQUFHZ0wsVUFBVWhMLEVBQUV3RixPQUFPNEYsT0FBTyxLQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlGO0FBQUEsTUFBRTtBQUFBLFNBQXRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0ksS0FBN047QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzTztBQUFBLElBQUUsdUJBQUMsYUFBUSxXQUFVLHdCQUF1QjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFBZ0IsaUNBQUMsU0FBSTtBQUFBLCtCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTO0FBQUEsUUFBSyx1QkFBQyxPQUFHbEY7QUFBQUEsWUFBRXJILE1BQU13TSxlQUFhO0FBQUEsVUFBRTtBQUFBLGFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxXQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFLEtBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEc7QUFBQSxNQUFPbkYsRUFBRTdCLFlBQVUsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU0sSUFBRzZCLEVBQUU1QixVQUFRLHVCQUFDLFNBQU0sTUFBSyxTQUFRLFNBQVN2RSxhQUFhbUcsRUFBRWhHLEtBQUssR0FBRyxPQUFPLE1BQUksS0FBS2dHLEVBQUUzQixRQUFRLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0YsSUFBRzNDLEtBQUt3QyxXQUFTLElBQUUsdUJBQUMsU0FBTSxNQUFLLFNBQVEsU0FBUSw0QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRCxJQUFHLHVCQUFDLFNBQUksV0FBVSx3QkFBd0J4QyxlQUFLZ0IsSUFBSSxDQUFDM0QsTUFBYyx1QkFBQyxTQUFJLFdBQVcsbUJBQW1CQSxFQUFFeUUsV0FBUyxTQUFPLFdBQVMsRUFBRSxJQUFlO0FBQUEsK0JBQUMsVUFBSyxXQUFVLHdCQUF1QixpQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQU8sdUJBQUMsU0FBSTtBQUFBLGlDQUFDLFlBQVF6RSxZQUFFb0IsU0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQjtBQUFBLFVBQVMsdUJBQUMsT0FBR3BCLFlBQUVrQixXQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWM7QUFBQSxVQUFJLHVCQUFDLFdBQU9SO0FBQUFBLGlCQUFLVixFQUFFMEYsU0FBUztBQUFBLFlBQUU7QUFBQSxZQUFJMUYsRUFBRXFNO0FBQUFBLFlBQVE7QUFBQSxZQUFJck0sRUFBRXlFO0FBQUFBLGVBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFEO0FBQUEsYUFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RztBQUFBLFFBQU96RSxFQUFFeUUsV0FBUyxVQUFRLHVCQUFDLFlBQU8sV0FBVSw0QkFBMkIsVUFBVXdILEtBQUtyQyxXQUFXLFNBQVMsTUFBSXFDLEtBQUt6QyxPQUFPeEosRUFBRXVGLEVBQUUsR0FBRyx5QkFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnSDtBQUFBLFdBQTdUdkYsRUFBRXVGLElBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ1osQ0FBTSxLQUFyZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVkO0FBQUEsU0FBN3lCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb3pCO0FBQUEsT0FBM2tDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBcWxDO0FBQzdsQztBQUFDc0csSUFOZUQsbUJBQWlCO0FBQUEsVUFDdkJuTixnQkFDREQsVUFDR0QsV0FBVztBQUFBO0FBQUEsT0FIUHFOO0FBUVQsZ0JBQVNVLGNBQWM7QUFBQUMsTUFBQTtBQUM3QixRQUFNdEUsS0FBR3hKLGVBQWU7QUFBRyxRQUFNLEVBQUMrTixZQUFXLElBQUU3TixRQUFRO0FBQ3ZELFFBQU1zSSxJQUFFekksU0FBUyxFQUFDeUQsVUFBUyxDQUFDLFNBQVMsR0FBRUMsU0FBUSxZQUFTeEMsT0FBTyxNQUFNaEIsSUFBSTBELElBQUksV0FBVyxDQUFDLEVBQUMsQ0FBQztBQUMzRixRQUFNLENBQUM2QyxNQUFLd0gsT0FBTyxJQUFFck8sU0FBMkJpQyxNQUFTO0FBQUcsUUFBTSxDQUFDcU0sT0FBTUMsUUFBUSxJQUFFdk8sU0FBMkJpQyxNQUFTO0FBQ3ZILFFBQU11TSxVQUFRM0YsRUFBRXJIO0FBQ2hCLFFBQU1pTixTQUFPdE8sWUFBWSxFQUFDb0ssWUFBVyxZQUFTakosT0FBTyxNQUFNaEIsSUFBSThNLE1BQU0sYUFBWSxFQUFDLEdBQUl2RyxTQUFPNUUsU0FBVSxFQUFDNEUsS0FBSSxJQUFFLENBQUMsR0FBRyxHQUFJeUgsVUFBUXJNLFNBQVUsRUFBQ3FNLE9BQU1BLFVBQVEsS0FBRyxPQUFLQSxNQUFLLElBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFFeEQsV0FBVSxZQUFTO0FBQUN0SyxVQUFNdUssUUFBUSxpQkFBaUI7QUFBRSxVQUFNbEIsR0FBR29CLGtCQUFrQixFQUFDcEgsVUFBUyxDQUFDLFNBQVMsRUFBQyxDQUFDO0FBQUV3SyxZQUFRcE0sTUFBUztBQUFFc00sYUFBU3RNLE1BQVM7QUFBRSxVQUFNbU0sWUFBWTtBQUFBLEVBQUUsR0FBRWxELFNBQVFBLENBQUF2SSxNQUFHbkMsTUFBTXFDLE1BQU1ILGFBQWFDLENBQUMsQ0FBQyxFQUFDLENBQUM7QUFDMVgsU0FBTyx1QkFBQyxhQUFRLFdBQVUsNkJBQTRCO0FBQUEsMkJBQUMsZUFBWSxPQUFNLHNCQUFxQixVQUFTLHVFQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9IO0FBQUEsSUFBRSx1QkFBQyxhQUFRLFdBQVUsbUNBQWtDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHFCQUFvQixpQ0FBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQixLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsTUFBT2tHLEVBQUU3QixZQUFVLHVCQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFNLElBQUc2QixFQUFFNUIsVUFBUSx1QkFBQyxTQUFNLE1BQUssU0FBUSxTQUFTdkUsYUFBYW1HLEVBQUVoRyxLQUFLLEdBQUcsT0FBTyxNQUFJLEtBQUtnRyxFQUFFM0IsUUFBUSxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdGLElBQUcsbUNBQUU7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUJBQWtCO0FBQUEsaUNBQUMsUUFBSXNILG1CQUFTM0gsUUFBTSxjQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBLFVBQUssdUJBQUMsT0FBRzJILG1CQUFTRSxTQUFPLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsVUFBSSx1QkFBQyxVQUFPLE9BQU9GLFNBQVNuSSxVQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBLFVBQUUsdUJBQUMsV0FBTTtBQUFBO0FBQUEsWUFBT21JLFNBQVNHLFFBQU07QUFBQSxlQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBLGFBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0w7QUFBQSxRQUFNLHVCQUFDLFVBQUssV0FBVSwyQkFBMEIsVUFBVSxDQUFBaE0sTUFBRztBQUFDQSxZQUFFd0ksZUFBZTtBQUFFc0QsaUJBQU9yRCxPQUFPO0FBQUEsUUFBRSxHQUFHO0FBQUEsaUNBQUMsV0FBTTtBQUFBO0FBQUEsWUFBSSx1QkFBQyxXQUFNLFVBQVEsTUFBQyxXQUFXLEdBQUcsV0FBVyxLQUFLLE9BQU92RSxRQUFNMkgsU0FBUzNILFFBQU0sSUFBSSxVQUFVLENBQUFsRSxNQUFHMEwsUUFBUTFMLEVBQUV3RixPQUFPekcsS0FBSyxLQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSDtBQUFBLGVBQTlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdJO0FBQUEsVUFBUSx1QkFBQyxXQUFNO0FBQUE7QUFBQSxZQUFLLHVCQUFDLFdBQU0sV0FBVyxHQUFHLFdBQVcsSUFBSSxPQUFPNE0sU0FBT0UsU0FBU0YsU0FBTyxJQUFJLFVBQVUsQ0FBQTNMLE1BQUc0TCxTQUFTNUwsRUFBRXdGLE9BQU96RyxLQUFLLEtBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRHO0FBQUEsZUFBeEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEg7QUFBQSxVQUFRLHVCQUFDLFdBQU07QUFBQTtBQUFBLFlBQUssdUJBQUMsV0FBTSxVQUFRLE1BQUMsT0FBTzhNLFNBQVNFLFNBQU8sTUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQSxZQUFFLHVCQUFDLFdBQU0sdUVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxlQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4SDtBQUFBLFVBQVEsdUJBQUMsU0FBSSxXQUFVLGVBQWMsZ0pBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZKO0FBQUEsVUFBTSx1QkFBQyxZQUFPLFdBQVUsbUJBQWtCLFVBQVVELE9BQU9qRCxXQUFZaUQsaUJBQU9qRCxZQUFVLFlBQVUsa0JBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJHO0FBQUEsYUFBNXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcXdCO0FBQUEsV0FBLzdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBczhCO0FBQUEsU0FBN3FDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaXJDO0FBQUEsT0FBdDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZzJDO0FBQ3gyQztBQUFDMkMsSUFQZUQsYUFBVztBQUFBLFVBQ2pCN04sZ0JBQXNDRSxTQUN2Q0gsVUFHS0QsV0FBVztBQUFBO0FBQUEsT0FMVCtOO0FBU1QsZ0JBQVNVLDJCQUEyQjtBQUFBQyxNQUFBO0FBQzFDLFFBQU1oRyxJQUFFekksU0FBUyxFQUFDeUQsVUFBUyxDQUFDLHVCQUF1QixHQUFFQyxTQUFRLFlBQVN4QyxPQUFPLE1BQU1oQixJQUFJMEQsSUFBSSxzQ0FBcUMsRUFBQ0csUUFBTyxFQUFDRSxNQUFLLEdBQUVDLE9BQU0sR0FBRSxFQUFDLENBQUMsQ0FBQyxFQUFDLENBQUM7QUFDN0osUUFBTUMsT0FBS3VLLE1BQU1DLFFBQVFsRyxFQUFFckgsSUFBSSxJQUFFcUgsRUFBRXJILE9BQUtxSCxFQUFFckgsTUFBTWdGLFNBQU87QUFDdkQsU0FBTyx1QkFBQyxhQUFRLFdBQVUsNkJBQTRCO0FBQUEsMkJBQUMsZUFBWSxPQUFNLHlCQUF3QixVQUFTLCtFQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStIO0FBQUEsSUFBRSx1QkFBQyxhQUFRLFdBQVUsd0JBQXdCcUMsWUFBRTdCLFlBQVUsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU0sSUFBRzZCLEVBQUU1QixVQUFRLHVCQUFDLFNBQU0sTUFBSyxTQUFRLFNBQVN2RSxhQUFhbUcsRUFBRWhHLEtBQUssR0FBRyxPQUFPLE1BQUksS0FBS2dHLEVBQUUzQixRQUFRLEtBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0YsSUFBRzNDLEtBQUt3QyxXQUFTLElBQUUsdUJBQUMsU0FBTSxNQUFLLFNBQVEsU0FBUSwwREFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRixJQUFHLHVCQUFDLFNBQUksV0FBVSxvQkFBb0J4QyxlQUFLZ0IsSUFBSSxDQUFDeEIsR0FBWWlMLE1BQVcsdUJBQUMsU0FBSSxXQUFVLGVBQThDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUFnQjtBQUFBLCtCQUFDLFNBQUk7QUFBQSxpQ0FBQyxRQUFJakwsWUFBRWtMLGlCQUFlLDBCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQUssdUJBQUMsT0FBR2xMO0FBQUFBLGNBQUVtTCxtQkFBaUI7QUFBQSxZQUFrQjtBQUFBLFlBQUluTCxFQUFFb0wsU0FBTztBQUFBLFlBQUk7QUFBQSxZQUFJN00sS0FBS3lCLEVBQUV1RCxTQUFTO0FBQUEsZUFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxhQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJJO0FBQUEsUUFBTSx1QkFBQyxVQUFPLE9BQU92RCxFQUFFc0MsVUFBUXRDLEVBQUVxTCxZQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9DO0FBQUEsV0FBcE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzTjtBQUFBLE1BQU0sdUJBQUMsT0FBR3JMLFlBQUVzTCxtQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNCO0FBQUEsTUFBS1AsTUFBTUMsUUFBUWhMLEVBQUV1TCxXQUFXLEtBQUcsdUJBQUMsT0FBRSxXQUFVLFNBQVE7QUFBQTtBQUFBLFFBQWV2TCxFQUFFdUwsWUFBWTFJLEtBQUssSUFBSTtBQUFBLFdBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkQ7QUFBQSxNQUFNa0ksTUFBTUMsUUFBUWhMLEVBQUV3TCxlQUFlLEtBQUcsdUJBQUMsU0FBSTtBQUFBLCtCQUFDLFlBQU8saUNBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQVMsdUJBQUMsUUFBSXhMLFlBQUV3TCxnQkFBZ0JoSyxJQUFJLENBQUNHLE1BQVksdUJBQUMsUUFBWUEsZUFBSkEsR0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsQ0FBSyxLQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsV0FBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRztBQUFBLE1BQVEzQixFQUFFeUwscUJBQW1CLHVCQUFDLFNBQUksV0FBVSxlQUFjO0FBQUE7QUFBQSxRQUFxQnpMLEVBQUV5TCxrQkFBa0JDLHFCQUFtQjtBQUFBLFFBQUk7QUFBQSxRQUE4QmhHLE9BQU8xRixFQUFFeUwsa0JBQWtCRSwwQkFBd0IsZUFBZTtBQUFBLFdBQTdMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0w7QUFBQSxTQUEzdEIsR0FBRzNMLEVBQUVtTCxtQkFBaUJGLENBQUMsSUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvd0IsQ0FBTSxLQUE5MEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnMUIsS0FBbGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeWxDO0FBQUEsT0FBendDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbXhDO0FBQzN4QztBQUFDSCxJQUplRCwwQkFBd0I7QUFBQSxVQUMvQnhPLFFBQVE7QUFBQTtBQUFBLE9BRER3TztBQU1ULGdCQUFTZSx1QkFBdUI7QUFBQUMsT0FBQTtBQUN0QyxRQUFNLEVBQUNDLFlBQVUsR0FBRSxJQUFFM1AsVUFBVTtBQUMvQixRQUFNMkksSUFBRXpJLFNBQVMsRUFBQ3lELFVBQVMsQ0FBQyxjQUFhZ00sU0FBUyxHQUFFL0wsU0FBUSxZQUFTeEMsT0FBTyxNQUFNaEIsSUFBSTBELElBQUksZ0JBQWdCNkwsU0FBUyxFQUFFLENBQUMsRUFBRUMsVUFBUyxDQUFDO0FBQ2xJLE1BQUdqSCxFQUFFN0IsVUFBVSxRQUFPLHVCQUFDLGFBQVEsV0FBVSxrQkFBaUIsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQU0sS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QztBQUNsRSxNQUFHNkIsRUFBRTVCLFFBQVEsUUFBTyx1QkFBQyxhQUFRLFdBQVUsa0JBQWlCLGlDQUFDLFNBQU0sTUFBTzRCLEVBQUVoRyxPQUFlRCxVQUFVeUQsV0FBUyxNQUFJLFdBQVMsU0FBUyxTQUFTM0QsYUFBYW1HLEVBQUVoRyxLQUFLLEdBQUcsT0FBTyxNQUFJLEtBQUtnRyxFQUFFM0IsUUFBUSxLQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW9JLEtBQXhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMEs7QUFDOUwsUUFBTW5ELElBQUU4RSxFQUFFckg7QUFDVixTQUFPLHVCQUFDLGFBQVEsV0FBVSw2QkFBNEI7QUFBQSwyQkFBQyxlQUFZLE9BQU0sc0JBQXFCLFVBQVMsaURBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEY7QUFBQSxJQUFFLHVCQUFDLGFBQVEsV0FBVSx3QkFBdUI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0JBQWtCd0csaUJBQU9qQyxRQUFRaEMsS0FBRyxDQUFDLENBQUMsRUFBRWtDLE9BQU8sQ0FBQyxHQUFFMUQsQ0FBQyxNQUFJQSxNQUFJLFFBQU0sQ0FBQyxVQUFTLFVBQVMsU0FBUyxFQUFFNEQsU0FBUyxPQUFPNUQsQ0FBQyxDQUFDLEVBQUVnRCxJQUFJLENBQUMsQ0FBQ2lFLEdBQUVqSCxDQUFDLE1BQUksdUJBQUMsU0FBWTtBQUFBLCtCQUFDLFdBQU9pSCxZQUFFdUcsUUFBUSxVQUFTLENBQUFDLE1BQUcsSUFBSUEsQ0FBQyxFQUFFLEVBQUVELFFBQVEsTUFBSyxDQUFBQyxNQUFHQSxFQUFFcEYsWUFBWSxDQUFDLEtBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUFRLHVCQUFDLFlBQVFySSxnQkFBSSxPQUFLLE1BQUlrSCxPQUFPbEgsQ0FBQyxLQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsV0FBbkhpSCxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0ksQ0FBTSxLQUEzUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZSO0FBQUEsTUFBT3pGLEdBQUdvRCxNQUFJLHVCQUFDLE9BQUUsV0FBVSxTQUFRO0FBQUE7QUFBQSxRQUFhcEQsRUFBRW9EO0FBQUFBLFdBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxTQUE1WDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlZO0FBQUEsT0FBaGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBMGhCO0FBQ2xpQjtBQUFDeUksS0FQZUQsc0JBQW9CO0FBQUEsVUFDZHpQLFdBQ2JFLFFBQVE7QUFBQTtBQUFBLE9BRkR1UDtBQUFvQixJQUFBeE0sSUFBQU8sS0FBQW1CLEtBQUFHLEtBQUFpTCxLQUFBQyxLQUFBQyxLQUFBQyxLQUFBekUsS0FBQUUsS0FBQXdFLEtBQUFDLE1BQUFDLE1BQUFDLE1BQUFDLE1BQUFDO0FBQUEsYUFBQXZOLElBQUE7QUFBQSxhQUFBTyxLQUFBO0FBQUEsYUFBQW1CLEtBQUE7QUFBQSxhQUFBRyxLQUFBO0FBQUEsYUFBQWlMLEtBQUE7QUFBQSxhQUFBQyxLQUFBO0FBQUEsYUFBQUMsS0FBQTtBQUFBLGFBQUFDLEtBQUE7QUFBQSxhQUFBekUsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBd0UsS0FBQTtBQUFBLGFBQUFDLE1BQUE7QUFBQSxhQUFBQyxNQUFBO0FBQUEsYUFBQUMsTUFBQTtBQUFBLGFBQUFDLE1BQUE7QUFBQSxhQUFBQyxNQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwiTGluayIsInVzZVBhcmFtcyIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsImFwaSIsInVzZUF1dGgiLCJ0b2FzdCIsIkFycm93RG93bkxlZnQiLCJBcnJvd1VwUmlnaHQiLCJBcnJvd0xlZnRSaWdodCIsIkJlbGwiLCJDaGVjayIsIkNoZXZyb25MZWZ0IiwiQ2lyY2xlQWxlcnQiLCJDcmVkaXRDYXJkIiwiUmVmcmVzaEN3IiwiU2VhcmNoIiwiU2hpZWxkQ2hlY2siLCJVc2VyUm91bmQiLCJXYWxsZXQiLCJ1bndyYXAiLCJyIiwiZGF0YSIsIm1vbmV5IiwidmFsdWUiLCJjdXJyZW5jeSIsIm4iLCJOdW1iZXIiLCJpc0Zpbml0ZSIsIkludGwiLCJOdW1iZXJGb3JtYXQiLCJ1bmRlZmluZWQiLCJzdHlsZSIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsImZvcm1hdCIsInRvRml4ZWQiLCJkYXRlIiwidiIsIkRhdGUiLCJ0b0xvY2FsZVN0cmluZyIsImVycm9yTWVzc2FnZSIsImUiLCJyZXNwb25zZSIsImVycm9yIiwibWVzc2FnZSIsIlBhZ2VIZWFkaW5nIiwidGl0bGUiLCJzdWJ0aXRsZSIsImFjdGlvbiIsIl9jIiwiU3RhdGUiLCJraW5kIiwicmV0cnkiLCJsb2FkaW5nIiwiZW1wdHkiLCJkZW5pZWQiLCJfYzIiLCJ1c2VBY2NvdW50cyIsIl9zIiwicXVlcnlLZXkiLCJxdWVyeUZuIiwiZCIsImdldCIsImFjY291bnRzIiwidXNlVHJhbnNhY3Rpb25zIiwicGFyYW1zIiwiX3MyIiwicGFnZSIsImxpbWl0Iiwicm93cyIsInRyYW5zYWN0aW9ucyIsInBhZ2luYXRpb24iLCJTdGF0dXMiLCJ0b0xvd2VyQ2FzZSIsInJlcGxhY2VBbGwiLCJfYzMiLCJUYWJsZVNoZWxsIiwiY2hpbGRyZW4iLCJfYzQiLCJDdXN0b21lckRhc2hib2FyZFBhZ2UiLCJfczMiLCJ0eCIsInVzZXIiLCJhbGwiLCJiYWxhbmNlcyIsIm1hcCIsIk1hcCIsImZvckVhY2giLCJhIiwiYiIsInNldCIsImN1cnJlbmN5Q29kZSIsImF2YWlsYWJsZUJhbGFuY2UiLCJlbnRyaWVzIiwiaW5mbG93IiwiZmlsdGVyIiwidCIsImluY2x1ZGVzIiwidHlwZSIsInN0YXR1cyIsIm91dGZsb3ciLCJzdW1CeUN1cnJlbmN5IiwiaXRlbXMiLCJ0b3RhbHMiLCJhbW91bnQiLCJjIiwiam9pbiIsIm5hbWUiLCJzcGxpdCIsImxlbmd0aCIsImlzTG9hZGluZyIsImlzRXJyb3IiLCJyZWZldGNoIiwiaWQiLCJyZWZlcmVuY2UiLCJzbGljZSIsImNyZWF0ZWRBdCIsIlRyYW5zYWN0aW9uc1BhZ2UiLCJfczQiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJtaW5BbW91bnQiLCJtYXhBbW91bnQiLCJzZXRQYWdlIiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJ0b3RhbFBhZ2VzIiwidGFyZ2V0IiwieCIsInRvdGFsIiwiaXNGZXRjaGluZyIsIk1hdGgiLCJtYXgiLCJ0cmFuc2Zvcm0iLCJUcmFuc2FjdGlvbkRldGFpbHNQYWdlIiwiX3M1IiwidHJhbnNhY3Rpb25JZCIsInEiLCJ0cmFuc2FjdGlvbiIsIlJlZmVyZW5jZSIsIklEIiwiQ3VycmVuY3kiLCJUeXBlIiwiQ3JlYXRlZCIsIlVwZGF0ZWQiLCJ1cGRhdGVkQXQiLCJEZXNjcmlwdGlvbiIsImRlc2NyaXB0aW9uIiwiayIsIlN0cmluZyIsIk1vbmV5TW92ZW1lbnRQYWdlIiwibW9kZSIsIl9zNiIsInFjIiwiYWNjb3VudElkIiwic2V0QWNjb3VudElkIiwic2V0QW1vdW50Iiwic2V0Q3VycmVuY3kiLCJpZGVtIiwic2V0SWRlbSIsInNlbGVjdGVkIiwiZmluZCIsIm11dGF0aW9uIiwibXV0YXRpb25GbiIsImtleSIsImNyeXB0byIsInJhbmRvbVVVSUQiLCJwb3N0IiwidG9VcHBlckNhc2UiLCJoZWFkZXJzIiwib25TdWNjZXNzIiwic3VjY2VzcyIsIlByb21pc2UiLCJpbnZhbGlkYXRlUXVlcmllcyIsIm9uRXJyb3IiLCJwcmV2ZW50RGVmYXVsdCIsIm11dGF0ZSIsIm5leHQiLCJhY2NvdW50TnVtYmVyIiwiYWNjb3VudFR5cGUiLCJpc1BlbmRpbmciLCJpc1N1Y2Nlc3MiLCJEZXBvc2l0UGFnZSIsIl9jOSIsIldpdGhkcmF3YWxQYWdlIiwiX2MwIiwiVHJhbnNmZXJQYWdlIiwiX3M3IiwiYmVuZWZpY2lhcmllcyIsInNlbmRlciIsInNldFNlbmRlciIsInJlY2VpdmVyIiwic2V0UmVjZWl2ZXIiLCJzZW5kZXJBY2NvdW50IiwicmVjZWl2ZXJBY2NvdW50IiwidHJpbSIsInNvbWUiLCJiZW5lZmljaWFyeVR5cGUiLCJwcm92aWRlciIsImFjY291bnRSZWZlcmVuY2UiLCJkaXNwbGF5TmFtZSIsIkJlbmVmaWNpYXJpZXNQYWdlIiwiX3M4IiwiZWRpdGluZyIsInNldEVkaXRpbmciLCJmb3JtIiwic2V0Rm9ybSIsInNhdmUiLCJwYXRjaCIsImRlbCIsImRlbGV0ZSIsImNvbmZpcm0iLCJOb3RpZmljYXRpb25zUGFnZSIsIl9zOSIsInVucmVhZCIsInNldFVucmVhZCIsInVucmVhZE9ubHkiLCJtYXJrIiwibm90aWZpY2F0aW9ucyIsImNoZWNrZWQiLCJ1bnJlYWRDb3VudCIsImNoYW5uZWwiLCJQcm9maWxlUGFnZSIsIl9zMCIsInJlZnJlc2hVc2VyIiwic2V0TmFtZSIsInBob25lIiwic2V0UGhvbmUiLCJwcm9maWxlIiwidXBkYXRlIiwiZW1haWwiLCJyb2xlIiwiRGVjaXNpb25FeHBsYW5hdGlvbnNQYWdlIiwiX3MxIiwiQXJyYXkiLCJpc0FycmF5IiwiaSIsImN1c3RvbWVyVGl0bGUiLCJwdWJsaWNSZWZlcmVuY2UiLCJwaGFzZSIsImRlY2lzaW9uIiwiY3VzdG9tZXJNZXNzYWdlIiwicmVhc29uQ29kZXMiLCJyZXF1aXJlZEFjdGlvbnMiLCJ0cmFuc2FjdGlvbkltcGFjdCIsInRyYW5zYWN0aW9uU3RhdHVzIiwiZnVuZHNNb3ZlbWVudENvbmZpcm1lZCIsIkZ4UmVxdWVzdERldGFpbHNQYWdlIiwiX3MxMCIsInJlcXVlc3RJZCIsImZ4UmVxdWVzdCIsInJlcGxhY2UiLCJtIiwiX2M1IiwiX2M2IiwiX2M3IiwiX2M4IiwiX2MxIiwiX2MxMCIsIl9jMTEiLCJfYzEyIiwiX2MxMyIsIl9jMTQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3VzdG9tZXJQYWdlcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmssIHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnksIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1xdWVyeVwiO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSBcIi4uLy4uLy4uL2xpYi9hcGkvYXBpQ2xpZW50XCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uLy4uL2FwcC9wcm92aWRlcnMvQXV0aFByb3ZpZGVyXCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCJzb25uZXJcIjtcbmltcG9ydCB7IEFycm93RG93bkxlZnQsIEFycm93VXBSaWdodCwgQXJyb3dMZWZ0UmlnaHQsIEJlbGwsIENoZWNrLCBDaGV2cm9uTGVmdCwgQ2lyY2xlQWxlcnQsIENyZWRpdENhcmQsIFJlZnJlc2hDdywgU2VhcmNoLCBTaGllbGRDaGVjaywgVXNlclJvdW5kLCBXYWxsZXQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG50eXBlIEFueVJlY29yZCA9IFJlY29yZDxzdHJpbmcsIGFueT47XG50eXBlIEFjY291bnQgPSB7IGlkOnN0cmluZzsgYWNjb3VudE51bWJlcjpzdHJpbmc7IGFjY291bnRUeXBlOnN0cmluZzsgc3RhdHVzOnN0cmluZzsgYmFsYW5jZXM/OiB7IGN1cnJlbmN5Q29kZTpzdHJpbmc7IGF2YWlsYWJsZUJhbGFuY2U6c3RyaW5nfG51bWJlcjsgbG9ja2VkQmFsYW5jZT86c3RyaW5nfG51bWJlciB9W10gfTtcbnR5cGUgVHggPSB7IGlkOnN0cmluZzsgcmVmZXJlbmNlPzpzdHJpbmc7IHR5cGU6c3RyaW5nOyBzdGF0dXM6c3RyaW5nOyBhbW91bnQ6c3RyaW5nfG51bWJlcjsgY3VycmVuY3lDb2RlOnN0cmluZzsgY3JlYXRlZEF0OnN0cmluZzsgc291cmNlQWNjb3VudD86QW55UmVjb3JkOyBkZXN0aW5hdGlvbkFjY291bnQ/OkFueVJlY29yZDsgZGVzY3JpcHRpb24/OnN0cmluZyB9O1xuY29uc3QgdW53cmFwID0gKHI6YW55KSA9PiByPy5kYXRhPy5kYXRhID8/IHI/LmRhdGEgPz8ge307XG5jb25zdCBtb25leSA9ICh2YWx1ZTphbnksIGN1cnJlbmN5PVwiQkRUXCIpID0+IHtcbiAgY29uc3Qgbj1OdW1iZXIodmFsdWUpOyBpZighTnVtYmVyLmlzRmluaXRlKG4pKSByZXR1cm4gXCLigJRcIjtcbiAgdHJ5IHsgcmV0dXJuIG5ldyBJbnRsLk51bWJlckZvcm1hdCh1bmRlZmluZWQse3N0eWxlOlwiY3VycmVuY3lcIixjdXJyZW5jeSxtYXhpbXVtRnJhY3Rpb25EaWdpdHM6Mn0pLmZvcm1hdChuKTsgfSBjYXRjaCB7IHJldHVybiBgJHtjdXJyZW5jeX0gJHtuLnRvRml4ZWQoMil9YDsgfVxufTtcbmNvbnN0IGRhdGUgPSAodjphbnkpID0+IHYgPyBuZXcgRGF0ZSh2KS50b0xvY2FsZVN0cmluZygpIDogXCLigJRcIjtcbmNvbnN0IGVycm9yTWVzc2FnZSA9IChlOmFueSkgPT4gZT8ucmVzcG9uc2U/LmRhdGE/LmVycm9yPy5tZXNzYWdlID8/IGU/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlID8/IGU/Lm1lc3NhZ2UgPz8gXCJTb21ldGhpbmcgd2VudCB3cm9uZy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIjtcbmZ1bmN0aW9uIFBhZ2VIZWFkaW5nKHt0aXRsZSxzdWJ0aXRsZSxhY3Rpb259Ont0aXRsZTpzdHJpbmc7c3VidGl0bGU6c3RyaW5nO2FjdGlvbj86UmVhY3ROb2RlfSkgeyByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJwNi1oZWFkaW5nXCI+PGRpdj48cCBjbGFzc05hbWU9XCJleWVicm93XCI+Q1VTVE9NRVIgV09SS1NQQUNFPC9wPjxoMT57dGl0bGV9PC9oMT48cCBjbGFzc05hbWU9XCJtdXRlZFwiPntzdWJ0aXRsZX08L3A+PC9kaXY+e2FjdGlvbn08L2Rpdj47IH1cbmZ1bmN0aW9uIFN0YXRlKHtraW5kPVwibG9hZGluZ1wiLG1lc3NhZ2UsIHJldHJ5fTp7a2luZD86XCJsb2FkaW5nXCJ8XCJlbXB0eVwifFwiZXJyb3JcInxcImRlbmllZFwiO21lc3NhZ2U/OnN0cmluZztyZXRyeT86KCk9PnZvaWR9KSB7IHJldHVybiA8ZGl2IGNsYXNzTmFtZT17YHA2LXN0YXRlIHA2LSR7a2luZH1gfSByb2xlPXtraW5kPT09XCJsb2FkaW5nXCI/XCJzdGF0dXNcIjpcImFsZXJ0XCJ9PjxzcGFuPntraW5kPT09XCJsb2FkaW5nXCI/PFJlZnJlc2hDdyBzaXplPXsyMH0vPjpraW5kPT09XCJkZW5pZWRcIj88U2hpZWxkQ2hlY2sgc2l6ZT17MjB9Lz46PENpcmNsZUFsZXJ0IHNpemU9ezIwfS8+fTwvc3Bhbj48c3Ryb25nPnttZXNzYWdlID8/ICh7bG9hZGluZzpcIkxvYWRpbmcgeW91ciBpbmZvcm1hdGlvbuKAplwiLGVtcHR5OlwiTm90aGluZyB0byBzaG93IHlldC5cIixlcnJvcjpcIldlIGNvdWxkIG5vdCBsb2FkIHRoaXMgaW5mb3JtYXRpb24uXCIsZGVuaWVkOlwiWW91IGRvIG5vdCBoYXZlIHBlcm1pc3Npb24gdG8gYWNjZXNzIHRoaXMgaW5mb3JtYXRpb24uXCJ9W2tpbmRdKX08L3N0cm9uZz57cmV0cnkmJjxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXtyZXRyeX0+VHJ5IGFnYWluPC9idXR0b24+fTwvZGl2PjsgfVxuZnVuY3Rpb24gdXNlQWNjb3VudHMoKSB7IHJldHVybiB1c2VRdWVyeSh7cXVlcnlLZXk6W1wiY3VzdG9tZXJcIixcImFjY291bnRzXCJdLHF1ZXJ5Rm46YXN5bmMoKT0+e2NvbnN0IGQ9dW53cmFwKGF3YWl0IGFwaS5nZXQoXCIvYWNjb3VudHNcIikpO3JldHVybiAoZC5hY2NvdW50cz8/W10pIGFzIEFjY291bnRbXTt9fSk7IH1cbmZ1bmN0aW9uIHVzZVRyYW5zYWN0aW9ucyhwYXJhbXM6QW55UmVjb3JkPXt9KSB7IHJldHVybiB1c2VRdWVyeSh7cXVlcnlLZXk6W1wiY3VzdG9tZXJcIixcInRyYW5zYWN0aW9uc1wiLHBhcmFtc10scXVlcnlGbjphc3luYygpPT57Y29uc3QgZD11bndyYXAoYXdhaXQgYXBpLmdldChcIi90cmFuc2FjdGlvbnNcIix7cGFyYW1zOntwYWdlOjEsbGltaXQ6MjAsLi4ucGFyYW1zfX0pKTtyZXR1cm4ge3Jvd3M6KGQudHJhbnNhY3Rpb25zPz9bXSkgYXMgVHhbXSxwYWdpbmF0aW9uOmQucGFnaW5hdGlvbn07fX0pOyB9XG5mdW5jdGlvbiBTdGF0dXMoe3ZhbHVlfTp7dmFsdWU/OnN0cmluZ30pIHsgY29uc3Qgdj12YWx1ZT8/XCJVTktOT1dOXCI7IHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2BwNi1zdGF0dXMgc3RhdHVzLSR7di50b0xvd2VyQ2FzZSgpfWB9Pnt2LnJlcGxhY2VBbGwoXCJfXCIsXCIgXCIpfTwvc3Bhbj47IH1cbmZ1bmN0aW9uIFRhYmxlU2hlbGwoe2NoaWxkcmVufTp7Y2hpbGRyZW46UmVhY3ROb2RlfSkgeyByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJwNi10YWJsZS13cmFwXCI+PHRhYmxlIGNsYXNzTmFtZT1cInA2LXRhYmxlXCI+e2NoaWxkcmVufTwvdGFibGU+PC9kaXY+OyB9XG5cbmV4cG9ydCBmdW5jdGlvbiBDdXN0b21lckRhc2hib2FyZFBhZ2UoKSB7XG4gY29uc3QgYWNjb3VudHM9dXNlQWNjb3VudHMoKTsgY29uc3QgdHg9dXNlVHJhbnNhY3Rpb25zKHtsaW1pdDo4fSk7IGNvbnN0IHt1c2VyfT11c2VBdXRoKCk7XG4gY29uc3QgYWxsPXR4LmRhdGE/LnJvd3M/P1tdO1xuIGNvbnN0IGJhbGFuY2VzPXVzZU1lbW8oKCk9Pntjb25zdCBtYXA9bmV3IE1hcDxzdHJpbmcsbnVtYmVyPigpOyhhY2NvdW50cy5kYXRhPz9bXSkuZm9yRWFjaChhPT4oYS5iYWxhbmNlcz8/W10pLmZvckVhY2goYj0+bWFwLnNldChiLmN1cnJlbmN5Q29kZSwobWFwLmdldChiLmN1cnJlbmN5Q29kZSk/PzApK051bWJlcihiLmF2YWlsYWJsZUJhbGFuY2UpKSkpO3JldHVybiBbLi4ubWFwLmVudHJpZXMoKV07fSxbYWNjb3VudHMuZGF0YV0pO1xuIGNvbnN0IGluZmxvdz1hbGwuZmlsdGVyKHQ9PltcIkRFUE9TSVRcIixcIkVYVEVSTkFMX0RFUE9TSVRcIl0uaW5jbHVkZXModC50eXBlKSYmdC5zdGF0dXM9PT1cIkNPTVBMRVRFRFwiKTtcbiBjb25zdCBvdXRmbG93PWFsbC5maWx0ZXIodD0+W1wiV0lUSERSQVdBTFwiLFwiSU5URVJOQUxfVFJBTlNGRVJcIixcIkVYVEVSTkFMX1RSQU5TRkVSXCJdLmluY2x1ZGVzKHQudHlwZSkmJnQuc3RhdHVzPT09XCJDT01QTEVURURcIik7XG4gY29uc3Qgc3VtQnlDdXJyZW5jeT0oaXRlbXM6VHhbXSk9Pntjb25zdCB0b3RhbHM9bmV3IE1hcDxzdHJpbmcsbnVtYmVyPigpO2l0ZW1zLmZvckVhY2godD0+dG90YWxzLnNldCh0LmN1cnJlbmN5Q29kZSwodG90YWxzLmdldCh0LmN1cnJlbmN5Q29kZSk/PzApK051bWJlcih0LmFtb3VudCkpKTtyZXR1cm4gWy4uLnRvdGFscy5lbnRyaWVzKCldLm1hcCgoW2Msdl0pPT5tb25leSh2LGMpKS5qb2luKFwiIMK3IFwiKXx8XCLigJRcIjt9O1xuXG4gcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvcnRhbC1jb250ZW50IHA2LWNvbnRlbnRcIj48UGFnZUhlYWRpbmcgdGl0bGU9e2BXZWxjb21lJHt0eXBlb2YgdXNlcj8ubmFtZT09PVwic3RyaW5nXCI/YCwgJHt1c2VyLm5hbWUuc3BsaXQoXCIgXCIpWzBdfWA6XCJcIn1gfSBzdWJ0aXRsZT1cIkEgbGl2ZSBvdmVydmlldyBvZiB5b3VyIGFjY291bnRzIGFuZCByZWNlbnQgYWN0aXZpdHkuXCIgYWN0aW9uPXs8TGluayBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnlcIiB0bz1cIi9jdXN0b21lci90cmFuc2ZlclwiPjxBcnJvd0xlZnRSaWdodCBzaXplPXsxNn0vPiBUcmFuc2ZlciBtb25leTwvTGluaz59Lz5cbiA8ZGl2IGNsYXNzTmFtZT1cInA2LW1ldHJpY3NcIj48YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1tZXRyaWNcIj48V2FsbGV0Lz48c3Bhbj5NeSBhY2NvdW50czwvc3Bhbj48c3Ryb25nPnthY2NvdW50cy5kYXRhPy5sZW5ndGg/P1wi4oCUXCJ9PC9zdHJvbmc+PHNtYWxsPkFjY291bnRzIGxpbmtlZCB0byB5b3VyIHByb2ZpbGU8L3NtYWxsPjwvYXJ0aWNsZT48YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1tZXRyaWNcIj48QXJyb3dEb3duTGVmdC8+PHNwYW4+UmVjZW50IGluY29taW5nPC9zcGFuPjxzdHJvbmc+e3R4LmlzTG9hZGluZz9cIuKAlFwiOnN1bUJ5Q3VycmVuY3koaW5mbG93KX08L3N0cm9uZz48c21hbGw+Q29tcGxldGVkIGRlcG9zaXRzIGluIHJldHVybmVkIHBhZ2U8L3NtYWxsPjwvYXJ0aWNsZT48YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1tZXRyaWNcIj48QXJyb3dVcFJpZ2h0Lz48c3Bhbj5SZWNlbnQgb3V0Z29pbmc8L3NwYW4+PHN0cm9uZz57dHguaXNMb2FkaW5nP1wi4oCUXCI6c3VtQnlDdXJyZW5jeShvdXRmbG93KX08L3N0cm9uZz48c21hbGw+Q29tcGxldGVkIHdpdGhkcmF3YWxzIGFuZCB0cmFuc2ZlcnMgaW4gcmV0dXJuZWQgcGFnZTwvc21hbGw+PC9hcnRpY2xlPjxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIHA2LW1ldHJpY1wiPjxBcnJvd0xlZnRSaWdodC8+PHNwYW4+UmVjZW50IHRyYW5zYWN0aW9uczwvc3Bhbj48c3Ryb25nPnt0eC5kYXRhPy5yb3dzLmxlbmd0aD8/XCLigJRcIn08L3N0cm9uZz48c21hbGw+TGF0ZXN0IHJlY29yZHMgcmV0dXJuZWQgYnkgdGhlIEFQSTwvc21hbGw+PC9hcnRpY2xlPjwvZGl2PlxuIDxkaXYgY2xhc3NOYW1lPVwicDYtZ3JpZFwiPjxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIHA2LXBhbmVsXCI+PGRpdiBjbGFzc05hbWU9XCJwNi1wYW5lbC1oZWFkXCI+PGRpdj48aDI+QWNjb3VudCBiYWxhbmNlczwvaDI+PHA+QXZhaWxhYmxlIGJhbGFuY2VzIGdyb3VwZWQgYnkgY3VycmVuY3k8L3A+PC9kaXY+PExpbmsgdG89XCIvY3VzdG9tZXIvYWNjb3VudHNcIj5WaWV3IGFjY291bnRzIOKGkjwvTGluaz48L2Rpdj57YWNjb3VudHMuaXNMb2FkaW5nPzxTdGF0ZS8+OmFjY291bnRzLmlzRXJyb3I/PFN0YXRlIGtpbmQ9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZShhY2NvdW50cy5lcnJvcil9IHJldHJ5PXsoKT0+dm9pZCBhY2NvdW50cy5yZWZldGNoKCl9Lz46YmFsYW5jZXMubGVuZ3RoPT09MD88U3RhdGUga2luZD1cImVtcHR5XCIgbWVzc2FnZT1cIk5vIGFjY291bnRzIHlldC4gQ3JlYXRlIGFuIGFjY291bnQgdG8gZ2V0IHN0YXJ0ZWQuXCIvPjo8ZGl2IGNsYXNzTmFtZT1cInA2LWJhbGFuY2UtbGlzdFwiPntiYWxhbmNlcy5tYXAoKFtjLHZdKT0+PGRpdiBrZXk9e2N9PjxzcGFuPntjfTwvc3Bhbj48c3Ryb25nPnttb25leSh2LGMpfTwvc3Ryb25nPjwvZGl2Pil9PC9kaXY+fTwvYXJ0aWNsZT5cbiA8YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1wYW5lbFwiPjxkaXYgY2xhc3NOYW1lPVwicDYtcGFuZWwtaGVhZFwiPjxkaXY+PGgyPlF1aWNrIGFjdGlvbnM8L2gyPjxwPkF2YWlsYWJsZSBjdXN0b21lciBhY3Rpb25zPC9wPjwvZGl2PjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwicDYtYWN0aW9uc1wiPjxMaW5rIHRvPVwiL2N1c3RvbWVyL2FjY291bnRzXCI+PENyZWRpdENhcmQvPiBNYW5hZ2UgYWNjb3VudHM8L0xpbms+PExpbmsgdG89XCIvY3VzdG9tZXIvZGVwb3NpdFwiPjxBcnJvd0Rvd25MZWZ0Lz4gRGVwb3NpdDwvTGluaz48TGluayB0bz1cIi9jdXN0b21lci93aXRoZHJhd2FsXCI+PEFycm93VXBSaWdodC8+IFdpdGhkcmF3PC9MaW5rPjxMaW5rIHRvPVwiL2N1c3RvbWVyL2JlbmVmaWNpYXJpZXNcIj48VXNlclJvdW5kLz4gQmVuZWZpY2lhcmllczwvTGluaz48L2Rpdj48L2FydGljbGU+PC9kaXY+XG4gPGFydGljbGUgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQgcDYtcGFuZWxcIj48ZGl2IGNsYXNzTmFtZT1cInA2LXBhbmVsLWhlYWRcIj48ZGl2PjxoMj5SZWNlbnQgdHJhbnNhY3Rpb25zPC9oMj48cD5MYXRlc3QgdHJhbnNhY3Rpb25zIHJldHVybmVkIGJ5IHlvdXIgYWNjb3VudCBoaXN0b3J5PC9wPjwvZGl2PjxMaW5rIHRvPVwiL2N1c3RvbWVyL3RyYW5zYWN0aW9uc1wiPlZpZXcgYWxsIOKGkjwvTGluaz48L2Rpdj57dHguaXNMb2FkaW5nPzxTdGF0ZS8+OnR4LmlzRXJyb3I/PFN0YXRlIGtpbmQ9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZSh0eC5lcnJvcil9IHJldHJ5PXsoKT0+dm9pZCB0eC5yZWZldGNoKCl9Lz46YWxsLmxlbmd0aD09PTA/PFN0YXRlIGtpbmQ9XCJlbXB0eVwiIG1lc3NhZ2U9XCJObyB0cmFuc2FjdGlvbnMgZm91bmQuXCIvPjo8VGFibGVTaGVsbD48dGhlYWQ+PHRyPjx0aD5SZWZlcmVuY2U8L3RoPjx0aD5UeXBlPC90aD48dGg+RGF0ZTwvdGg+PHRoPlN0YXR1czwvdGg+PHRoIGNsYXNzTmFtZT1cImFsaWduLXJpZ2h0XCI+QW1vdW50PC90aD48L3RyPjwvdGhlYWQ+PHRib2R5PnthbGwubWFwKHQ9Pjx0ciBrZXk9e3QuaWR9Pjx0ZD48TGluayB0bz17YC9jdXN0b21lci90cmFuc2FjdGlvbnMvJHt0LmlkfWB9Pnt0LnJlZmVyZW5jZT8/dC5pZC5zbGljZSgwLDEwKX08L0xpbms+PC90ZD48dGQ+e3QudHlwZS5yZXBsYWNlQWxsKFwiX1wiLFwiIFwiKX08L3RkPjx0ZD57ZGF0ZSh0LmNyZWF0ZWRBdCl9PC90ZD48dGQ+PFN0YXR1cyB2YWx1ZT17dC5zdGF0dXN9Lz48L3RkPjx0ZCBjbGFzc05hbWU9XCJhbGlnbi1yaWdodFwiPnttb25leSh0LmFtb3VudCx0LmN1cnJlbmN5Q29kZSl9PC90ZD48L3RyPil9PC90Ym9keT48L1RhYmxlU2hlbGw+fTwvYXJ0aWNsZT5cbiA8cCBjbGFzc05hbWU9XCJkZW1vLWRpc2NsYWltZXJcIj5EYXNoYm9hcmQgZmlndXJlcyBhcmUgY2FsY3VsYXRlZCBvbmx5IGZyb20gQVBJIHJlY29yZHMgY3VycmVudGx5IHJldHVybmVkLiBUcmFuc2FjdGlvbiBmbG93IHRvdGFscyByZWZsZWN0IHRoZSBsYXRlc3QgcGFnZSwgbm90IGEgY29tcGxldGUgc3RhdGVtZW50LjwvcD48L3NlY3Rpb24+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gVHJhbnNhY3Rpb25zUGFnZSgpIHtcbiBjb25zdCBbZmlsdGVycyxzZXRGaWx0ZXJzXT11c2VTdGF0ZSh7dHlwZTpcIlwiLHN0YXR1czpcIlwiLHN0YXJ0RGF0ZTpcIlwiLGVuZERhdGU6XCJcIixtaW5BbW91bnQ6XCJcIixtYXhBbW91bnQ6XCJcIn0pO1xuIGNvbnN0IFtwYWdlLHNldFBhZ2VdPXVzZVN0YXRlKDEpO1xuIGNvbnN0IHBhcmFtcz1PYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoZmlsdGVycykuZmlsdGVyKChbLHZdKT0+diE9PVwiXCIpKTtcbiBjb25zdCB0eD11c2VUcmFuc2FjdGlvbnMoe3BhZ2UsbGltaXQ6MjAsLi4ucGFyYW1zfSk7IGNvbnN0IHJvd3M9dHguZGF0YT8ucm93cz8/W107IGNvbnN0IHRvdGFsUGFnZXM9dHguZGF0YT8ucGFnaW5hdGlvbj8udG90YWxQYWdlcz8/MTtcbiByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9ydGFsLWNvbnRlbnQgcDYtY29udGVudFwiPjxQYWdlSGVhZGluZyB0aXRsZT1cIlRyYW5zYWN0aW9uc1wiIHN1YnRpdGxlPVwiU2VhcmNoIGFuZCByZXZpZXcgdHJhbnNhY3Rpb25zIGFzc29jaWF0ZWQgd2l0aCB5b3VyIGFjY291bnRzLlwiLz5cbiA8ZGl2IGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIHA2LXBhbmVsXCI+PGRpdiBjbGFzc05hbWU9XCJwNi1maWx0ZXItZ3JpZFwiPjxsYWJlbD5UeXBlPHNlbGVjdCB2YWx1ZT17ZmlsdGVycy50eXBlfSBvbkNoYW5nZT17ZT0+c2V0RmlsdGVycyh7Li4uZmlsdGVycyx0eXBlOmUudGFyZ2V0LnZhbHVlfSl9PjxvcHRpb24gdmFsdWU9XCJcIj5BbGwgdHlwZXM8L29wdGlvbj57W1wiREVQT1NJVFwiLFwiV0lUSERSQVdBTFwiLFwiSU5URVJOQUxfVFJBTlNGRVJcIixcIkVYVEVSTkFMX0RFUE9TSVRcIixcIkVYVEVSTkFMX1RSQU5TRkVSXCIsXCJGWF9DT05WRVJTSU9OXCIsXCJSRUZVTkRcIl0ubWFwKHg9PjxvcHRpb24ga2V5PXt4fT57eH08L29wdGlvbj4pfTwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsPlN0YXR1czxzZWxlY3QgdmFsdWU9e2ZpbHRlcnMuc3RhdHVzfSBvbkNoYW5nZT17ZT0+c2V0RmlsdGVycyh7Li4uZmlsdGVycyxzdGF0dXM6ZS50YXJnZXQudmFsdWV9KX0+PG9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBzdGF0dXNlczwvb3B0aW9uPntbXCJQRU5ESU5HXCIsXCJQUk9DRVNTSU5HXCIsXCJDT01QTEVURURcIixcIkZBSUxFRFwiLFwiQ0FOQ0VMTEVEXCIsXCJSRUZVTkRFRFwiXS5tYXAoeD0+PG9wdGlvbiBrZXk9e3h9Pnt4fTwvb3B0aW9uPil9PC9zZWxlY3Q+PC9sYWJlbD48bGFiZWw+RnJvbTxpbnB1dCB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtmaWx0ZXJzLnN0YXJ0RGF0ZX0gb25DaGFuZ2U9e2U9PnNldEZpbHRlcnMoey4uLmZpbHRlcnMsc3RhcnREYXRlOmUudGFyZ2V0LnZhbHVlfSl9Lz48L2xhYmVsPjxsYWJlbD5UbzxpbnB1dCB0eXBlPVwiZGF0ZVwiIHZhbHVlPXtmaWx0ZXJzLmVuZERhdGV9IG9uQ2hhbmdlPXtlPT5zZXRGaWx0ZXJzKHsuLi5maWx0ZXJzLGVuZERhdGU6ZS50YXJnZXQudmFsdWV9KX0vPjwvbGFiZWw+PGxhYmVsPk1pbiBhbW91bnQ8aW5wdXQgaW5wdXRNb2RlPVwiZGVjaW1hbFwiIHZhbHVlPXtmaWx0ZXJzLm1pbkFtb3VudH0gb25DaGFuZ2U9e2U9PnNldEZpbHRlcnMoey4uLmZpbHRlcnMsbWluQW1vdW50OmUudGFyZ2V0LnZhbHVlfSl9Lz48L2xhYmVsPjxsYWJlbD5NYXggYW1vdW50PGlucHV0IGlucHV0TW9kZT1cImRlY2ltYWxcIiB2YWx1ZT17ZmlsdGVycy5tYXhBbW91bnR9IG9uQ2hhbmdlPXtlPT5zZXRGaWx0ZXJzKHsuLi5maWx0ZXJzLG1heEFtb3VudDplLnRhcmdldC52YWx1ZX0pfS8+PC9sYWJlbD48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInA2LWZpbHRlci1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXNlY29uZGFyeVwiIG9uQ2xpY2s9eygpPT57c2V0RmlsdGVycyh7dHlwZTpcIlwiLHN0YXR1czpcIlwiLHN0YXJ0RGF0ZTpcIlwiLGVuZERhdGU6XCJcIixtaW5BbW91bnQ6XCJcIixtYXhBbW91bnQ6XCJcIn0pO3NldFBhZ2UoMSk7fX0+Q2xlYXIgZmlsdGVyczwvYnV0dG9uPjxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5XCIgb25DbGljaz17KCk9PnZvaWQgdHgucmVmZXRjaCgpfT48U2VhcmNoIHNpemU9ezE1fS8+IEFwcGx5IGZpbHRlcnM8L2J1dHRvbj48L2Rpdj48L2Rpdj5cbiA8YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1wYW5lbFwiPjxkaXYgY2xhc3NOYW1lPVwicDYtcGFuZWwtaGVhZFwiPjxkaXY+PGgyPlRyYW5zYWN0aW9uIGhpc3Rvcnk8L2gyPjxwPnt0eC5kYXRhPy5wYWdpbmF0aW9uPy50b3RhbD8/cm93cy5sZW5ndGh9IHJlY29yZHMgaW4gY3VycmVudCByZXN1bHQ8L3A+PC9kaXY+PC9kaXY+e3R4LmlzTG9hZGluZz88U3RhdGUvPjp0eC5pc0Vycm9yPzxTdGF0ZSBraW5kPVwiZXJyb3JcIiBtZXNzYWdlPXtlcnJvck1lc3NhZ2UodHguZXJyb3IpfSByZXRyeT17KCk9PnZvaWQgdHgucmVmZXRjaCgpfS8+OnJvd3MubGVuZ3RoPT09MD88U3RhdGUga2luZD1cImVtcHR5XCIgbWVzc2FnZT1cIk5vIHRyYW5zYWN0aW9ucyBtYXRjaCB0aGVzZSBmaWx0ZXJzLlwiLz46PFRhYmxlU2hlbGw+PHRoZWFkPjx0cj48dGg+UmVmZXJlbmNlPC90aD48dGg+VHlwZTwvdGg+PHRoPkNyZWF0ZWQ8L3RoPjx0aD5TdGF0dXM8L3RoPjx0aD5DdXJyZW5jeTwvdGg+PHRoIGNsYXNzTmFtZT1cImFsaWduLXJpZ2h0XCI+QW1vdW50PC90aD48L3RyPjwvdGhlYWQ+PHRib2R5Pntyb3dzLm1hcCh0PT48dHIga2V5PXt0LmlkfT48dGQ+PExpbmsgdG89e2AvY3VzdG9tZXIvdHJhbnNhY3Rpb25zLyR7dC5pZH1gfT57dC5yZWZlcmVuY2U/P3QuaWQuc2xpY2UoMCwxMil9PC9MaW5rPjwvdGQ+PHRkPnt0LnR5cGUucmVwbGFjZUFsbChcIl9cIixcIiBcIil9PC90ZD48dGQ+e2RhdGUodC5jcmVhdGVkQXQpfTwvdGQ+PHRkPjxTdGF0dXMgdmFsdWU9e3Quc3RhdHVzfS8+PC90ZD48dGQ+e3QuY3VycmVuY3lDb2RlfTwvdGQ+PHRkIGNsYXNzTmFtZT1cImFsaWduLXJpZ2h0XCI+e21vbmV5KHQuYW1vdW50LHQuY3VycmVuY3lDb2RlKX08L3RkPjwvdHI+KX08L3Rib2R5PjwvVGFibGVTaGVsbD59PGRpdiBjbGFzc05hbWU9XCJwNi1wYWdpbmF0aW9uXCI+PHNwYW4gY2xhc3NOYW1lPVwibXV0ZWRcIj5QYWdlIHtwYWdlfSBvZiB7dG90YWxQYWdlc308L3NwYW4+PGRpdj48YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGRpc2FibGVkPXtwYWdlPD0xfHx0eC5pc0ZldGNoaW5nfSBvbkNsaWNrPXsoKT0+c2V0UGFnZSh2PT5NYXRoLm1heCgxLHYtMSkpfT48Q2hldnJvbkxlZnQgc2l6ZT17MTR9Lz4gUHJldmlvdXM8L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGRpc2FibGVkPXtwYWdlPj10b3RhbFBhZ2VzfHx0eC5pc0ZldGNoaW5nfSBvbkNsaWNrPXsoKT0+c2V0UGFnZSh2PT52KzEpfT5OZXh0IDxDaGV2cm9uTGVmdCBzaXplPXsxNH0gc3R5bGU9e3t0cmFuc2Zvcm06XCJyb3RhdGUoMTgwZGVnKVwifX0vPjwvYnV0dG9uPjwvZGl2PjwvZGl2PjxwIGNsYXNzTmFtZT1cIm11dGVkIHA2LWZvb3Rub3RlXCI+T2Zmc2V0IHBhZ2luYXRpb24gaXMgdXNlZCBoZXJlIChwYWdlLCBsaW1pdCkuIFRoZSBBUEkgYWxzbyBzdXBwb3J0cyBjdXJzb3IgcGFnaW5hdGlvbjsgcGFnZSBhbmQgY3Vyc29yIGFyZSBuZXZlciBjb21iaW5lZC48L3A+PC9hcnRpY2xlPjwvc2VjdGlvbj47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBUcmFuc2FjdGlvbkRldGFpbHNQYWdlKCkge1xuIGNvbnN0IHt0cmFuc2FjdGlvbklkPVwiXCJ9PXVzZVBhcmFtcygpOyBjb25zdCBxPXVzZVF1ZXJ5KHtxdWVyeUtleTpbXCJ0cmFuc2FjdGlvblwiLHRyYW5zYWN0aW9uSWRdLHF1ZXJ5Rm46YXN5bmMoKT0+dW53cmFwKGF3YWl0IGFwaS5nZXQoYC90cmFuc2FjdGlvbnMvJHt0cmFuc2FjdGlvbklkfWApKS50cmFuc2FjdGlvbn0pO1xuIGlmKHEuaXNMb2FkaW5nKXJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJwb3J0YWwtY29udGVudFwiPjxTdGF0ZS8+PC9zZWN0aW9uPjtcbiBpZihxLmlzRXJyb3IpcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvcnRhbC1jb250ZW50XCI+PFN0YXRlIGtpbmQ9e3EuZXJyb3ImJigocS5lcnJvciBhcyBhbnkpLnJlc3BvbnNlPy5zdGF0dXM9PT00MDMpP1wiZGVuaWVkXCI6XCJlcnJvclwifSBtZXNzYWdlPXtlcnJvck1lc3NhZ2UocS5lcnJvcil9IHJldHJ5PXsoKT0+dm9pZCBxLnJlZmV0Y2goKX0vPjwvc2VjdGlvbj47XG4gY29uc3QgdD1xLmRhdGEgYXMgVHgmQW55UmVjb3JkO1xuIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJwb3J0YWwtY29udGVudCBwNi1jb250ZW50XCI+PFBhZ2VIZWFkaW5nIHRpdGxlPVwiVHJhbnNhY3Rpb24gZGV0YWlsc1wiIHN1YnRpdGxlPVwiUmVhZC1vbmx5IGRldGFpbHMgcmV0dXJuZWQgYnkgdGhlIHRyYW5zYWN0aW9uIEFQSS5cIiBhY3Rpb249ezxMaW5rIGNsYXNzTmFtZT1cImJ0biBidG4tc2Vjb25kYXJ5XCIgdG89XCIvY3VzdG9tZXIvdHJhbnNhY3Rpb25zXCI+PENoZXZyb25MZWZ0IHNpemU9ezE2fS8+IEJhY2sgdG8gdHJhbnNhY3Rpb25zPC9MaW5rPn0vPjxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIHA2LXBhbmVsXCI+PGRpdiBjbGFzc05hbWU9XCJwNi1kZXRhaWwtYW1vdW50XCI+PHNwYW4+e3QudHlwZT8ucmVwbGFjZUFsbChcIl9cIixcIiBcIil9PC9zcGFuPjxzdHJvbmc+e21vbmV5KHQuYW1vdW50LHQuY3VycmVuY3lDb2RlKX08L3N0cm9uZz48U3RhdHVzIHZhbHVlPXt0LnN0YXR1c30vPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwicDYtZGV0YWlsLWdyaWRcIj57T2JqZWN0LmVudHJpZXMoe1JlZmVyZW5jZTp0LnJlZmVyZW5jZSxJRDp0LmlkLEN1cnJlbmN5OnQuY3VycmVuY3lDb2RlLFR5cGU6dC50eXBlLFN0YXR1czp0LnN0YXR1cyxDcmVhdGVkOmRhdGUodC5jcmVhdGVkQXQpLFVwZGF0ZWQ6ZGF0ZSh0LnVwZGF0ZWRBdCksRGVzY3JpcHRpb246dC5kZXNjcmlwdGlvbn0pLmZpbHRlcigoWyx2XSk9PnYhPT11bmRlZmluZWQmJnYhPT1udWxsKS5tYXAoKFtrLHZdKT0+PGRpdiBrZXk9e2t9PjxzbWFsbD57a308L3NtYWxsPjxzdHJvbmc+e1N0cmluZyh2KX08L3N0cm9uZz48L2Rpdj4pfTwvZGl2PjwvYXJ0aWNsZT48L3NlY3Rpb24+O1xufVxuXG5mdW5jdGlvbiBNb25leU1vdmVtZW50UGFnZSh7bW9kZX06e21vZGU6XCJkZXBvc2l0XCJ8XCJ3aXRoZHJhd2FsXCJ9KSB7XG4gY29uc3QgYWNjb3VudHM9dXNlQWNjb3VudHMoKTsgY29uc3QgcWM9dXNlUXVlcnlDbGllbnQoKTsgY29uc3QgW2FjY291bnRJZCxzZXRBY2NvdW50SWRdPXVzZVN0YXRlKFwiXCIpOyBjb25zdCBbYW1vdW50LHNldEFtb3VudF09dXNlU3RhdGUoXCJcIik7IGNvbnN0IFtjdXJyZW5jeSxzZXRDdXJyZW5jeV09dXNlU3RhdGUoXCJCRFRcIik7IGNvbnN0IFtpZGVtLHNldElkZW1dPXVzZVN0YXRlKFwiXCIpO1xuIGNvbnN0IHNlbGVjdGVkPWFjY291bnRzLmRhdGE/LmZpbmQoYT0+YS5pZD09PWFjY291bnRJZCk7XG4gY29uc3QgbXV0YXRpb249dXNlTXV0YXRpb24oe211dGF0aW9uRm46YXN5bmMoKT0+e2NvbnN0IGtleT1pZGVtfHxjcnlwdG8ucmFuZG9tVVVJRCgpO3NldElkZW0oa2V5KTtyZXR1cm4gdW53cmFwKGF3YWl0IGFwaS5wb3N0KGAvYWNjb3VudHMvJHthY2NvdW50SWR9LyR7bW9kZT09PVwiZGVwb3NpdFwiP1wiZGVwb3NpdHNcIjpcIndpdGhkcmF3YWxzXCJ9YCx7YW1vdW50LGN1cnJlbmN5OmN1cnJlbmN5LnRvVXBwZXJDYXNlKCl9LHtoZWFkZXJzOntcIklkZW1wb3RlbmN5LUtleVwiOmtleX19KSk7fSxvblN1Y2Nlc3M6YXN5bmMoKT0+e3RvYXN0LnN1Y2Nlc3MoYCR7bW9kZT09PVwiZGVwb3NpdFwiP1wiRGVwb3NpdFwiOlwiV2l0aGRyYXdhbFwifSByZXF1ZXN0IGNvbXBsZXRlZC5gKTtzZXRBbW91bnQoXCJcIik7c2V0SWRlbShcIlwiKTthd2FpdCBQcm9taXNlLmFsbChbcWMuaW52YWxpZGF0ZVF1ZXJpZXMoe3F1ZXJ5S2V5OltcImN1c3RvbWVyXCIsXCJhY2NvdW50c1wiXX0pLHFjLmludmFsaWRhdGVRdWVyaWVzKHtxdWVyeUtleTpbXCJjdXN0b21lclwiLFwidHJhbnNhY3Rpb25zXCJdfSldKTt9LG9uRXJyb3I6ZT0+dG9hc3QuZXJyb3IoZXJyb3JNZXNzYWdlKGUpKX0pO1xuIHJldHVybiA8c2VjdGlvbiBjbGFzc05hbWU9XCJwb3J0YWwtY29udGVudCBwNi1jb250ZW50XCI+PFBhZ2VIZWFkaW5nIHRpdGxlPXttb2RlPT09XCJkZXBvc2l0XCI/XCJEZXBvc2l0IGZ1bmRzXCI6XCJXaXRoZHJhdyBmdW5kc1wifSBzdWJ0aXRsZT1cIlN1Ym1pdCBhIG1vbmV5IG1vdmVtZW50IHJlcXVlc3QgdXNpbmcgdGhlIGFjY291bnQtc2NvcGVkIGJhY2tlbmQgZW5kcG9pbnQuXCIvPjxkaXYgY2xhc3NOYW1lPVwicDYtZm9ybS1sYXlvdXRcIj48YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1wYW5lbFwiPjxmb3JtIGNsYXNzTmFtZT1cInA2LWZvcm1cIiBvblN1Ym1pdD17ZT0+e2UucHJldmVudERlZmF1bHQoKTtpZighYWNjb3VudElkKXJldHVybjttdXRhdGlvbi5tdXRhdGUoKTt9fT48bGFiZWw+QWNjb3VudDxzZWxlY3QgcmVxdWlyZWQgdmFsdWU9e2FjY291bnRJZH0gb25DaGFuZ2U9e2U9Pntjb25zdCBuZXh0PWFjY291bnRzLmRhdGE/LmZpbmQoYT0+YS5pZD09PWUudGFyZ2V0LnZhbHVlKTtzZXRBY2NvdW50SWQoZS50YXJnZXQudmFsdWUpO3NldEN1cnJlbmN5KG5leHQ/LmJhbGFuY2VzPy5bMF0/LmN1cnJlbmN5Q29kZT8/XCJCRFRcIik7c2V0SWRlbShcIlwiKTt9fT48b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGFuIGFjY291bnQ8L29wdGlvbj57KGFjY291bnRzLmRhdGE/P1tdKS5tYXAoYT0+PG9wdGlvbiBrZXk9e2EuaWR9IHZhbHVlPXthLmlkfT57YS5hY2NvdW50TnVtYmVyfSDCtyB7YS5hY2NvdW50VHlwZX0gwrcge2Euc3RhdHVzfTwvb3B0aW9uPil9PC9zZWxlY3Q+PC9sYWJlbD57YWNjb3VudHMuaXNMb2FkaW5nJiY8c21hbGw+TG9hZGluZyBhY2NvdW50c+KApjwvc21hbGw+fXthY2NvdW50cy5pc0Vycm9yJiY8U3RhdGUga2luZD1cImVycm9yXCIgbWVzc2FnZT17ZXJyb3JNZXNzYWdlKGFjY291bnRzLmVycm9yKX0gcmV0cnk9eygpPT52b2lkIGFjY291bnRzLnJlZmV0Y2goKX0vPn08bGFiZWw+QW1vdW50PGlucHV0IHJlcXVpcmVkIGlucHV0TW9kZT1cImRlY2ltYWxcIiBwYXR0ZXJuPVwiXlxcZCsoXFwuXFxkezEsOH0pPyRcIiBtaW49XCIwLjAwMDAwMDAxXCIgcGxhY2Vob2xkZXI9XCIwLjAwXCIgdmFsdWU9e2Ftb3VudH0gb25DaGFuZ2U9e2U9PntzZXRBbW91bnQoZS50YXJnZXQudmFsdWUpO3NldElkZW0oXCJcIik7fX0vPjxzbWFsbD5Qb3NpdGl2ZSBkZWNpbWFsLCB1cCB0byA4IGRlY2ltYWwgcGxhY2VzLjwvc21hbGw+PC9sYWJlbD48bGFiZWw+Q3VycmVuY3k8c2VsZWN0IHJlcXVpcmVkIHZhbHVlPXtjdXJyZW5jeX0gb25DaGFuZ2U9e2U9PntzZXRDdXJyZW5jeShlLnRhcmdldC52YWx1ZSk7c2V0SWRlbShcIlwiKTt9fT57KHNlbGVjdGVkPy5iYWxhbmNlcz8/W10pLm1hcChiPT48b3B0aW9uIGtleT17Yi5jdXJyZW5jeUNvZGV9IHZhbHVlPXtiLmN1cnJlbmN5Q29kZX0+e2IuY3VycmVuY3lDb2RlfTwvb3B0aW9uPil9PC9zZWxlY3Q+PHNtYWxsPkNob29zZSBhIGN1cnJlbmN5IGJhbGFuY2UgYXZhaWxhYmxlIG9uIHRoaXMgYWNjb3VudC48L3NtYWxsPjwvbGFiZWw+e3NlbGVjdGVkJiY8ZGl2IGNsYXNzTmFtZT1cInA2LWluZm8tYm94XCI+U2VsZWN0ZWQgYWNjb3VudDogPHN0cm9uZz57c2VsZWN0ZWQuYWNjb3VudE51bWJlcn08L3N0cm9uZz48YnIvPkF2YWlsYWJsZSBiYWxhbmNlOiB7KHNlbGVjdGVkLmJhbGFuY2VzPz9bXSkubWFwKHg9PmAke21vbmV5KHguYXZhaWxhYmxlQmFsYW5jZSx4LmN1cnJlbmN5Q29kZSl9YCkuam9pbihcIiDCtyBcIil8fFwiTm90IHJldHVybmVkXCJ9PC9kaXY+fTxkaXYgY2xhc3NOYW1lPVwicDYtaW5mby1ib3hcIj48U2hpZWxkQ2hlY2sgc2l6ZT17MTZ9Lz4gVGhpcyBwb3J0Zm9saW8gYXBwIHVzZXMgdGVzdCBkYXRhIG9ubHkuIFZlcmlmeSB0aGUgc2VsZWN0ZWQgYWNjb3VudCBhbmQgYW1vdW50IGJlZm9yZSBzdWJtaXR0aW5nLjwvZGl2PjxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5XCIgZGlzYWJsZWQ9e211dGF0aW9uLmlzUGVuZGluZ3x8IWFjY291bnRJZHx8IWFtb3VudHx8TnVtYmVyKGFtb3VudCk8PTB9PnttdXRhdGlvbi5pc1BlbmRpbmc/XCJQcm9jZXNzaW5n4oCmXCI6bW9kZT09PVwiZGVwb3NpdFwiP1wiU3VibWl0IGRlcG9zaXRcIjpcIlN1Ym1pdCB3aXRoZHJhd2FsXCJ9PC9idXR0b24+e211dGF0aW9uLmlzRXJyb3ImJjxwIGNsYXNzTmFtZT1cInA2LWVycm9yLXRleHRcIiByb2xlPVwiYWxlcnRcIj57ZXJyb3JNZXNzYWdlKG11dGF0aW9uLmVycm9yKX17aWRlbSYmXCIgWW91IG1heSByZXRyeSB0aGlzIGV4YWN0IHJlcXVlc3Qgd2l0aCB0aGUgc2FtZSBpZGVtcG90ZW5jeSBrZXkuXCJ9PC9wPn17bXV0YXRpb24uaXNTdWNjZXNzJiY8ZGl2IGNsYXNzTmFtZT1cInA2LXN1Y2Nlc3MtYm94XCI+PENoZWNrLz4ge211dGF0aW9uLmRhdGE/Lm1lc3NhZ2U/P1wiUmVxdWVzdCBjb21wbGV0ZWRcIn17bXV0YXRpb24uZGF0YT8udHJhbnNhY3Rpb24/LmlkJiY8ZGl2PlRyYW5zYWN0aW9uIElEOiB7bXV0YXRpb24uZGF0YS50cmFuc2FjdGlvbi5pZH08L2Rpdj59PC9kaXY+fTwvZm9ybT48L2FydGljbGU+PGFzaWRlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIHA2LXBhbmVsXCI+PGgyPkhvdyBpdCB3b3JrczwvaDI+PG9sIGNsYXNzTmFtZT1cInA2LXN0ZXBzXCI+PGxpPkNob29zZSBvbmUgb2YgeW91ciBhY2NvdW50cy48L2xpPjxsaT5FbnRlciBhIHBvc2l0aXZlIGFtb3VudCBhbmQgdGhlIGFjY291bnQgY3VycmVuY3kuPC9saT48bGk+Q29uZmlybSBhbmQgc3VibWl0IG9uY2UuPC9saT48bGk+UmV2aWV3IHRoZSByZXR1cm5lZCB0cmFuc2FjdGlvbiByZWZlcmVuY2UgYW5kIHVwZGF0ZWQgYmFsYW5jZS48L2xpPjwvb2w+PHAgY2xhc3NOYW1lPVwibXV0ZWRcIj5UaGUgY2xpZW50IHNlbmRzIGFuIElkZW1wb3RlbmN5LUtleS4gSWYgYSBuZXR3b3JrIHRpbWVvdXQgb2NjdXJzLCByZXRyeSB0aGUgc2FtZSByZXF1ZXN0IHVzaW5nIHRoZSBzYW1lIGtleTsgZG8gbm90IGNyZWF0ZSBhIG5ldyBrZXkgZm9yIHRoZSBzYW1lIGludGVuZGVkIGFjdGlvbi48L3A+PC9hc2lkZT48L2Rpdj48L3NlY3Rpb24+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gRGVwb3NpdFBhZ2UoKXtyZXR1cm4gPE1vbmV5TW92ZW1lbnRQYWdlIG1vZGU9XCJkZXBvc2l0XCIvPn1cbmV4cG9ydCBmdW5jdGlvbiBXaXRoZHJhd2FsUGFnZSgpe3JldHVybiA8TW9uZXlNb3ZlbWVudFBhZ2UgbW9kZT1cIndpdGhkcmF3YWxcIi8+fVxuXG5leHBvcnQgZnVuY3Rpb24gVHJhbnNmZXJQYWdlKCkge1xuIGNvbnN0IGFjY291bnRzPXVzZUFjY291bnRzKCk7IGNvbnN0IGJlbmVmaWNpYXJpZXM9dXNlUXVlcnkoe3F1ZXJ5S2V5OltcImJlbmVmaWNpYXJpZXNcIl0scXVlcnlGbjphc3luYygpPT51bndyYXAoYXdhaXQgYXBpLmdldChcIi9iZW5lZmljaWFyaWVzXCIse3BhcmFtczp7cGFnZToxLGxpbWl0OjEwMH19KSkuYmVuZWZpY2lhcmllcz8/W119KTtcbiBjb25zdCBxYz11c2VRdWVyeUNsaWVudCgpOyBjb25zdCBbc2VuZGVyLHNldFNlbmRlcl09dXNlU3RhdGUoXCJcIik7IGNvbnN0IFtyZWNlaXZlcixzZXRSZWNlaXZlcl09dXNlU3RhdGUoXCJcIik7IGNvbnN0IFthbW91bnQsc2V0QW1vdW50XT11c2VTdGF0ZShcIlwiKTsgY29uc3QgW2N1cnJlbmN5LHNldEN1cnJlbmN5XT11c2VTdGF0ZShcIkJEVFwiKTsgY29uc3QgW2lkZW0sc2V0SWRlbV09dXNlU3RhdGUoXCJcIik7XG4gY29uc3QgbXV0YXRpb249dXNlTXV0YXRpb24oe211dGF0aW9uRm46YXN5bmMoKT0+e2NvbnN0IGtleT1pZGVtfHxjcnlwdG8ucmFuZG9tVVVJRCgpO3NldElkZW0oa2V5KTtyZXR1cm4gdW53cmFwKGF3YWl0IGFwaS5wb3N0KFwiL3RyYW5zZmVyc1wiLHtzZW5kZXJBY2NvdW50OnNlbmRlcixyZWNlaXZlckFjY291bnQ6cmVjZWl2ZXIsYW1vdW50LGN1cnJlbmN5OmN1cnJlbmN5LnRvVXBwZXJDYXNlKCl9LHtoZWFkZXJzOntcIklkZW1wb3RlbmN5LUtleVwiOmtleX19KSk7fSxvblN1Y2Nlc3M6YXN5bmMgZD0+e3RvYXN0LnN1Y2Nlc3MoZD8ubWVzc2FnZT8/XCJUcmFuc2ZlciByZXF1ZXN0IHN1Ym1pdHRlZC5cIik7c2V0QW1vdW50KFwiXCIpO3NldElkZW0oXCJcIik7YXdhaXQgUHJvbWlzZS5hbGwoW3FjLmludmFsaWRhdGVRdWVyaWVzKHtxdWVyeUtleTpbXCJjdXN0b21lclwiLFwiYWNjb3VudHNcIl19KSxxYy5pbnZhbGlkYXRlUXVlcmllcyh7cXVlcnlLZXk6W1wiY3VzdG9tZXJcIixcInRyYW5zYWN0aW9uc1wiXX0pXSk7fSxvbkVycm9yOmU9PnRvYXN0LmVycm9yKGVycm9yTWVzc2FnZShlKSl9KTtcbiByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9ydGFsLWNvbnRlbnQgcDYtY29udGVudFwiPjxQYWdlSGVhZGluZyB0aXRsZT1cIkZ1bmQgdHJhbnNmZXJcIiBzdWJ0aXRsZT1cIlRyYW5zZmVyIGJldHdlZW4gYWNjb3VudHMgdXNpbmcgdGhlIHZlcmlmaWVkIGludGVybmFsIHRyYW5zZmVyIGVuZHBvaW50LlwiLz48ZGl2IGNsYXNzTmFtZT1cInA2LWZvcm0tbGF5b3V0XCI+PGFydGljbGUgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQgcDYtcGFuZWxcIj48Zm9ybSBjbGFzc05hbWU9XCJwNi1mb3JtXCIgb25TdWJtaXQ9e2U9PntlLnByZXZlbnREZWZhdWx0KCk7bXV0YXRpb24ubXV0YXRlKCk7fX0+PGxhYmVsPkZyb20gYWNjb3VudDxzZWxlY3QgcmVxdWlyZWQgdmFsdWU9e3NlbmRlcn0gb25DaGFuZ2U9e2U9PntzZXRTZW5kZXIoZS50YXJnZXQudmFsdWUpO3NldElkZW0oXCJcIik7fX0+PG9wdGlvbiB2YWx1ZT1cIlwiPkNob29zZSBzb3VyY2UgYWNjb3VudDwvb3B0aW9uPnsoYWNjb3VudHMuZGF0YT8/W10pLm1hcChhPT48b3B0aW9uIGtleT17YS5pZH0gdmFsdWU9e2EuaWR9PnthLmFjY291bnROdW1iZXJ9IMK3IHthLmFjY291bnRUeXBlfTwvb3B0aW9uPil9PC9zZWxlY3Q+PC9sYWJlbD48bGFiZWw+UmVjZWl2ZXIgYWNjb3VudCBJRDxpbnB1dCByZXF1aXJlZCB2YWx1ZT17cmVjZWl2ZXJ9IG9uQ2hhbmdlPXtlPT57c2V0UmVjZWl2ZXIoZS50YXJnZXQudmFsdWUudHJpbSgpKTtzZXRJZGVtKFwiXCIpO319IHBsYWNlaG9sZGVyPVwiRW50ZXIgcmVjZWl2ZXIgYWNjb3VudCBVVUlEXCIvPjxzbWFsbD5UaGUgdHJhbnNmZXIgQVBJIGV4cGVjdHMgdGhlIHJlY2VpdmVyIGFjY291bnQgaWRlbnRpZmllciwgbm90IGl0cyBkaXNwbGF5IGFjY291bnQgbnVtYmVyLjwvc21hbGw+PC9sYWJlbD57YmVuZWZpY2lhcmllcy5kYXRhPy5zb21lKChiOkFueVJlY29yZCk9PmIuYmVuZWZpY2lhcnlUeXBlPT09XCJJTlRFUk5BTFwiJiZiLnByb3ZpZGVyPT09XCJJTlRFUk5BTFwiKSYmPGxhYmVsPlNhdmVkIGludGVybmFsIGJlbmVmaWNpYXJpZXM8c2VsZWN0IHZhbHVlPVwiXCIgb25DaGFuZ2U9e2U9Pntjb25zdCB4PWJlbmVmaWNpYXJpZXMuZGF0YS5maW5kKChiOkFueVJlY29yZCk9PmIuaWQ9PT1lLnRhcmdldC52YWx1ZSk7aWYoeClzZXRSZWNlaXZlcih4LmFjY291bnRSZWZlcmVuY2UpO319PjxvcHRpb24gdmFsdWU9XCJcIj5DaG9vc2UgYSBzYXZlZCBiZW5lZmljaWFyeSAob3B0aW9uYWwpPC9vcHRpb24+e2JlbmVmaWNpYXJpZXMuZGF0YS5maWx0ZXIoKGI6QW55UmVjb3JkKT0+Yi5iZW5lZmljaWFyeVR5cGU9PT1cIklOVEVSTkFMXCImJmIucHJvdmlkZXI9PT1cIklOVEVSTkFMXCIpLm1hcCgoYjpBbnlSZWNvcmQpPT48b3B0aW9uIGtleT17Yi5pZH0gdmFsdWU9e2IuaWR9PntiLmRpc3BsYXlOYW1lfSDCtyB7Yi5hY2NvdW50UmVmZXJlbmNlfTwvb3B0aW9uPil9PC9zZWxlY3Q+PC9sYWJlbD59PGxhYmVsPkFtb3VudDxpbnB1dCByZXF1aXJlZCBpbnB1dE1vZGU9XCJkZWNpbWFsXCIgcGF0dGVybj1cIl5cXGQrKFxcLlxcZHsxLDh9KT8kXCIgbWluPVwiMC4wMDAwMDAwMVwiIHZhbHVlPXthbW91bnR9IG9uQ2hhbmdlPXtlPT57c2V0QW1vdW50KGUudGFyZ2V0LnZhbHVlKTtzZXRJZGVtKFwiXCIpO319IHBsYWNlaG9sZGVyPVwiMC4wMFwiLz48L2xhYmVsPjxsYWJlbD5DdXJyZW5jeTxpbnB1dCByZXF1aXJlZCB2YWx1ZT17Y3VycmVuY3l9IG1heExlbmd0aD17M30gbWluTGVuZ3RoPXszfSBwYXR0ZXJuPVwiW0EtWmEtel17M31cIiBvbkNoYW5nZT17ZT0+e3NldEN1cnJlbmN5KGUudGFyZ2V0LnZhbHVlLnRvVXBwZXJDYXNlKCkpO3NldElkZW0oXCJcIik7fX0vPjwvbGFiZWw+PGRpdiBjbGFzc05hbWU9XCJwNi1pbmZvLWJveFwiPjxTaGllbGRDaGVjayBzaXplPXsxNn0vPiBUcmFuc2ZlcnMgYXJlIGZpbmFsIGZpbmFuY2lhbCBvcGVyYXRpb25zIGluIHRoaXMgZGVtbyBlbnZpcm9ubWVudC4gQ29uZmlybSByZWNlaXZlciBhY2NvdW50IGFuZCBhbW91bnQuIFJpc2sgcmV2aWV3IG1heSBob2xkIGEgdHJhbnNmZXI7IGEgMjAyIHJlc3BvbnNlIGlzIG5vdCBhIGNvbXBsZXRlZCBtb25leSBtb3ZlbWVudC48L2Rpdj48YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeVwiIGRpc2FibGVkPXttdXRhdGlvbi5pc1BlbmRpbmd8fCFzZW5kZXJ8fCFyZWNlaXZlcnx8IWFtb3VudHx8TnVtYmVyKGFtb3VudCk8PTB9PnttdXRhdGlvbi5pc1BlbmRpbmc/XCJTdWJtaXR0aW5n4oCmXCI6XCJTdWJtaXQgdHJhbnNmZXJcIn08L2J1dHRvbj57bXV0YXRpb24uaXNFcnJvciYmPHAgY2xhc3NOYW1lPVwicDYtZXJyb3ItdGV4dFwiIHJvbGU9XCJhbGVydFwiPntlcnJvck1lc3NhZ2UobXV0YXRpb24uZXJyb3IpfXtpZGVtJiZcIiBSZXRyeSB0aGUgc2FtZSByZXF1ZXN0IHdpdGggdGhlIHNhbWUgaWRlbXBvdGVuY3kga2V5LlwifTwvcD59e211dGF0aW9uLmlzU3VjY2VzcyYmPGRpdiBjbGFzc05hbWU9XCJwNi1zdWNjZXNzLWJveFwiPjxDaGVjay8+e211dGF0aW9uLmRhdGE/Lm1lc3NhZ2U/P1wiVHJhbnNmZXIgcmVxdWVzdCBhY2NlcHRlZFwifXttdXRhdGlvbi5kYXRhPy50cmFuc2FjdGlvbj8uaWQmJjxkaXY+VHJhbnNhY3Rpb246IHttdXRhdGlvbi5kYXRhLnRyYW5zYWN0aW9uLmlkfTwvZGl2Pn08L2Rpdj59PC9mb3JtPjwvYXJ0aWNsZT48YXNpZGUgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQgcDYtcGFuZWxcIj48aDI+QmVmb3JlIHlvdSB0cmFuc2ZlcjwvaDI+PHVsIGNsYXNzTmFtZT1cInA2LXN0ZXBzXCI+PGxpPlNlbmRlciBtdXN0IGJlIG9uZSBvZiB5b3VyIG93biBhY2NvdW50cy48L2xpPjxsaT5SZWNlaXZlciBhY2NvdW50IElEIG11c3QgaWRlbnRpZnkgYSB2YWxpZCwgYWN0aXZlIGFjY291bnQuPC9saT48bGk+Q3VycmVuY3kgbXVzdCBiZSBzdXBwb3J0ZWQgYnkgYm90aCBhY2NvdW50cy48L2xpPjxsaT5CYWNrZW5kIG1heSBwbGFjZSBhIHRyYW5zZmVyIG9uIGhvbGQgZm9yIHJpc2sgcmV2aWV3LjwvbGk+PC91bD48cCBjbGFzc05hbWU9XCJtdXRlZFwiPkNhbm9uaWNhbCBBUEk6IFBPU1QgL2FwaS92MS90cmFuc2ZlcnMuIExlZ2FjeSB0cmFuc2FjdGlvbiB0cmFuc2ZlciByb3V0ZSBvbmx5IGF1dGhvcml6ZXM7IGl0IGRvZXMgbm90IG1vdmUgbW9uZXkuPC9wPjwvYXNpZGU+PC9kaXY+PC9zZWN0aW9uPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEJlbmVmaWNpYXJpZXNQYWdlKCkge1xuIGNvbnN0IHFjPXVzZVF1ZXJ5Q2xpZW50KCk7IGNvbnN0IFtlZGl0aW5nLHNldEVkaXRpbmddPXVzZVN0YXRlPEFueVJlY29yZHxudWxsPihudWxsKTsgY29uc3QgW2Zvcm0sc2V0Rm9ybV09dXNlU3RhdGUoe2JlbmVmaWNpYXJ5VHlwZTpcIklOVEVSTkFMXCIsZGlzcGxheU5hbWU6XCJcIixhY2NvdW50UmVmZXJlbmNlOlwiXCIscHJvdmlkZXI6XCJJTlRFUk5BTFwiLGN1cnJlbmN5Q29kZTpcIkJEVFwifSk7XG4gY29uc3QgcT11c2VRdWVyeSh7cXVlcnlLZXk6W1wiYmVuZWZpY2lhcmllc1wiXSxxdWVyeUZuOmFzeW5jKCk9Pntjb25zdCBkPXVud3JhcChhd2FpdCBhcGkuZ2V0KFwiL2JlbmVmaWNpYXJpZXNcIix7cGFyYW1zOntwYWdlOjEsbGltaXQ6MTAwfX0pKTtyZXR1cm4gZC5iZW5lZmljaWFyaWVzPz9bXTt9fSk7XG4gY29uc3Qgc2F2ZT11c2VNdXRhdGlvbih7bXV0YXRpb25Gbjphc3luYygpPT5lZGl0aW5nP3Vud3JhcChhd2FpdCBhcGkucGF0Y2goYC9iZW5lZmljaWFyaWVzLyR7ZWRpdGluZy5pZH1gLHtkaXNwbGF5TmFtZTpmb3JtLmRpc3BsYXlOYW1lLGFjY291bnRSZWZlcmVuY2U6Zm9ybS5hY2NvdW50UmVmZXJlbmNlLHByb3ZpZGVyOmZvcm0ucHJvdmlkZXIsY3VycmVuY3lDb2RlOmZvcm0uY3VycmVuY3lDb2RlfSkpOnVud3JhcChhd2FpdCBhcGkucG9zdChcIi9iZW5lZmljaWFyaWVzXCIsZm9ybSkpLG9uU3VjY2Vzczphc3luYygpPT57dG9hc3Quc3VjY2VzcyhlZGl0aW5nP1wiQmVuZWZpY2lhcnkgdXBkYXRlZFwiOlwiQmVuZWZpY2lhcnkgY3JlYXRlZFwiKTtzZXRFZGl0aW5nKG51bGwpO3NldEZvcm0oe2JlbmVmaWNpYXJ5VHlwZTpcIklOVEVSTkFMXCIsZGlzcGxheU5hbWU6XCJcIixhY2NvdW50UmVmZXJlbmNlOlwiXCIscHJvdmlkZXI6XCJJTlRFUk5BTFwiLGN1cnJlbmN5Q29kZTpcIkJEVFwifSk7YXdhaXQgcWMuaW52YWxpZGF0ZVF1ZXJpZXMoe3F1ZXJ5S2V5OltcImJlbmVmaWNpYXJpZXNcIl19KTt9LG9uRXJyb3I6ZT0+dG9hc3QuZXJyb3IoZXJyb3JNZXNzYWdlKGUpKX0pO1xuIGNvbnN0IGRlbD11c2VNdXRhdGlvbih7bXV0YXRpb25GbjooaWQ6c3RyaW5nKT0+YXBpLmRlbGV0ZShgL2JlbmVmaWNpYXJpZXMvJHtpZH1gKSxvblN1Y2Nlc3M6YXN5bmMoKT0+e3RvYXN0LnN1Y2Nlc3MoXCJCZW5lZmljaWFyeSBkZWxldGVkXCIpO2F3YWl0IHFjLmludmFsaWRhdGVRdWVyaWVzKHtxdWVyeUtleTpbXCJiZW5lZmljaWFyaWVzXCJdfSk7fSxvbkVycm9yOmU9PnRvYXN0LmVycm9yKGVycm9yTWVzc2FnZShlKSl9KTtcbiByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9ydGFsLWNvbnRlbnQgcDYtY29udGVudFwiPjxQYWdlSGVhZGluZyB0aXRsZT1cIkJlbmVmaWNpYXJpZXNcIiBzdWJ0aXRsZT1cIkNyZWF0ZSwgdXBkYXRlIGFuZCByZW1vdmUgeW91ciBzYXZlZCB0cmFuc2ZlciByZWNpcGllbnRzLlwiLz48ZGl2IGNsYXNzTmFtZT1cInA2LWZvcm0tbGF5b3V0XCI+PGFydGljbGUgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQgcDYtcGFuZWxcIj48aDI+e2VkaXRpbmc/XCJFZGl0IGJlbmVmaWNpYXJ5XCI6XCJBZGQgYmVuZWZpY2lhcnlcIn08L2gyPjxmb3JtIGNsYXNzTmFtZT1cInA2LWZvcm1cIiBvblN1Ym1pdD17ZT0+e2UucHJldmVudERlZmF1bHQoKTtzYXZlLm11dGF0ZSgpO319PjxsYWJlbD5UeXBlPHNlbGVjdCB2YWx1ZT17Zm9ybS5iZW5lZmljaWFyeVR5cGV9IG9uQ2hhbmdlPXtlPT5zZXRGb3JtKHsuLi5mb3JtLGJlbmVmaWNpYXJ5VHlwZTplLnRhcmdldC52YWx1ZX0pfT48b3B0aW9uPklOVEVSTkFMPC9vcHRpb24+PG9wdGlvbj5FWFRFUk5BTDwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsPkRpc3BsYXkgbmFtZTxpbnB1dCByZXF1aXJlZCBtYXhMZW5ndGg9ezEwMH0gdmFsdWU9e2Zvcm0uZGlzcGxheU5hbWV9IG9uQ2hhbmdlPXtlPT5zZXRGb3JtKHsuLi5mb3JtLGRpc3BsYXlOYW1lOmUudGFyZ2V0LnZhbHVlfSl9Lz48L2xhYmVsPjxsYWJlbD5BY2NvdW50IHJlZmVyZW5jZTxpbnB1dCByZXF1aXJlZCBtYXhMZW5ndGg9ezEyOH0gdmFsdWU9e2Zvcm0uYWNjb3VudFJlZmVyZW5jZX0gb25DaGFuZ2U9e2U9PnNldEZvcm0oey4uLmZvcm0sYWNjb3VudFJlZmVyZW5jZTplLnRhcmdldC52YWx1ZX0pfS8+PC9sYWJlbD48bGFiZWw+UHJvdmlkZXI8c2VsZWN0IHZhbHVlPXtmb3JtLnByb3ZpZGVyfSBvbkNoYW5nZT17ZT0+c2V0Rm9ybSh7Li4uZm9ybSxwcm92aWRlcjplLnRhcmdldC52YWx1ZX0pfT57W1wiSU5URVJOQUxcIixcIkJLQVNIXCIsXCJOQUdBRFwiLFwiUk9DS0VUXCIsXCJQQVlQQUxcIixcIlBBWU9ORUVSXCIsXCJXSVNFXCJdLm1hcCh4PT48b3B0aW9uIGtleT17eH0+e3h9PC9vcHRpb24+KX08L3NlbGVjdD48L2xhYmVsPjxsYWJlbD5DdXJyZW5jeSBjb2RlPGlucHV0IHJlcXVpcmVkIG1pbkxlbmd0aD17M30gbWF4TGVuZ3RoPXszfSBwYXR0ZXJuPVwiW0EtWmEtel17M31cIiB2YWx1ZT17Zm9ybS5jdXJyZW5jeUNvZGV9IG9uQ2hhbmdlPXtlPT5zZXRGb3JtKHsuLi5mb3JtLGN1cnJlbmN5Q29kZTplLnRhcmdldC52YWx1ZS50b1VwcGVyQ2FzZSgpfSl9Lz48L2xhYmVsPjxkaXYgY2xhc3NOYW1lPVwicDYtZm9ybS1hY3Rpb25zXCI+PGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnlcIiBkaXNhYmxlZD17c2F2ZS5pc1BlbmRpbmd9PntzYXZlLmlzUGVuZGluZz9cIlNhdmluZ+KAplwiOmVkaXRpbmc/XCJTYXZlIGNoYW5nZXNcIjpcIkNyZWF0ZSBiZW5lZmljaWFyeVwifTwvYnV0dG9uPntlZGl0aW5nJiY8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4gYnRuLXNlY29uZGFyeVwiIG9uQ2xpY2s9eygpPT57c2V0RWRpdGluZyhudWxsKTtzZXRGb3JtKHtiZW5lZmljaWFyeVR5cGU6XCJJTlRFUk5BTFwiLGRpc3BsYXlOYW1lOlwiXCIsYWNjb3VudFJlZmVyZW5jZTpcIlwiLHByb3ZpZGVyOlwiSU5URVJOQUxcIixjdXJyZW5jeUNvZGU6XCJCRFRcIn0pO319PkNhbmNlbDwvYnV0dG9uPn08L2Rpdj48L2Zvcm0+PC9hcnRpY2xlPjxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIHA2LXBhbmVsXCI+PGRpdiBjbGFzc05hbWU9XCJwNi1wYW5lbC1oZWFkXCI+PGRpdj48aDI+U2F2ZWQgYmVuZWZpY2lhcmllczwvaDI+PHA+WW91ciBzYXZlZCByZWNpcGllbnRzPC9wPjwvZGl2PjwvZGl2PntxLmlzTG9hZGluZz88U3RhdGUvPjpxLmlzRXJyb3I/PFN0YXRlIGtpbmQ9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZShxLmVycm9yKX0gcmV0cnk9eygpPT52b2lkIHEucmVmZXRjaCgpfS8+OnEuZGF0YS5sZW5ndGg9PT0wPzxTdGF0ZSBraW5kPVwiZW1wdHlcIiBtZXNzYWdlPVwiWW91IGhhdmUgbm90IGFkZGVkIGFueSBiZW5lZmljaWFyaWVzIHlldC5cIi8+OjxkaXYgY2xhc3NOYW1lPVwicDYtYmVuZWZpY2lhcnktbGlzdFwiPntxLmRhdGEubWFwKChiOkFueVJlY29yZCk9PjxkaXYgY2xhc3NOYW1lPVwicDYtYmVuZWZpY2lhcnlcIiBrZXk9e2IuaWR9PjxkaXY+PHN0cm9uZz57Yi5kaXNwbGF5TmFtZX08L3N0cm9uZz48c3Bhbj57Yi5hY2NvdW50UmVmZXJlbmNlfTwvc3Bhbj48c21hbGw+e2IuYmVuZWZpY2lhcnlUeXBlfSDCtyB7Yi5wcm92aWRlcj8/XCJObyBwcm92aWRlclwifSDCtyB7Yi5jdXJyZW5jeUNvZGV9PC9zbWFsbD48U3RhdHVzIHZhbHVlPXtiLnN0YXR1c30vPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwicDYtaW5saW5lLWFjdGlvbnNcIj48YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIG9uQ2xpY2s9eygpPT57c2V0RWRpdGluZyhiKTtzZXRGb3JtKHtiZW5lZmljaWFyeVR5cGU6Yi5iZW5lZmljaWFyeVR5cGUsZGlzcGxheU5hbWU6Yi5kaXNwbGF5TmFtZSxhY2NvdW50UmVmZXJlbmNlOmIuYWNjb3VudFJlZmVyZW5jZSxwcm92aWRlcjpiLnByb3ZpZGVyPz9cIklOVEVSTkFMXCIsY3VycmVuY3lDb2RlOmIuY3VycmVuY3lDb2RlfSk7fX0+RWRpdDwvYnV0dG9uPjxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1kYW5nZXIgYnRuLXNtXCIgZGlzYWJsZWQ9e2RlbC5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpPT57aWYoY29uZmlybShgRGVsZXRlIGJlbmVmaWNpYXJ5ICR7Yi5kaXNwbGF5TmFtZX0/YCkpZGVsLm11dGF0ZShiLmlkKTt9fT5EZWxldGU8L2J1dHRvbj48L2Rpdj48L2Rpdj4pfTwvZGl2Pn08L2FydGljbGU+PC9kaXY+PC9zZWN0aW9uPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE5vdGlmaWNhdGlvbnNQYWdlKCkge1xuIGNvbnN0IHFjPXVzZVF1ZXJ5Q2xpZW50KCk7IGNvbnN0IFt1bnJlYWQsc2V0VW5yZWFkXT11c2VTdGF0ZShmYWxzZSk7XG4gY29uc3QgcT11c2VRdWVyeSh7cXVlcnlLZXk6W1wibm90aWZpY2F0aW9uc1wiLHVucmVhZF0scXVlcnlGbjphc3luYygpPT51bndyYXAoYXdhaXQgYXBpLmdldChcIi9ub3RpZmljYXRpb25zXCIse3BhcmFtczp7cGFnZToxLGxpbWl0OjUwLHVucmVhZE9ubHk6U3RyaW5nKHVucmVhZCl9fSkpfSk7XG4gY29uc3QgbWFyaz11c2VNdXRhdGlvbih7bXV0YXRpb25GbjooaWQ6c3RyaW5nKT0+YXBpLnBhdGNoKGAvbm90aWZpY2F0aW9ucy8ke2lkfS9yZWFkYCksb25TdWNjZXNzOigpPT57dG9hc3Quc3VjY2VzcyhcIk5vdGlmaWNhdGlvbiBtYXJrZWQgYXMgcmVhZFwiKTt2b2lkIHFjLmludmFsaWRhdGVRdWVyaWVzKHtxdWVyeUtleTpbXCJub3RpZmljYXRpb25zXCJdfSk7fSxvbkVycm9yOmU9PnRvYXN0LmVycm9yKGVycm9yTWVzc2FnZShlKSl9KTtcbiBjb25zdCByb3dzPXEuZGF0YT8ubm90aWZpY2F0aW9ucz8/W107XG4gcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvcnRhbC1jb250ZW50IHA2LWNvbnRlbnRcIj48UGFnZUhlYWRpbmcgdGl0bGU9XCJOb3RpZmljYXRpb25zXCIgc3VidGl0bGU9XCJSZXZpZXcgYWNjb3VudCBhbmQgc2VjdXJpdHkgdXBkYXRlcy5cIiBhY3Rpb249ezxsYWJlbCBjbGFzc05hbWU9XCJwNi1jaGVjay1maWx0ZXJcIj48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17dW5yZWFkfSBvbkNoYW5nZT17ZT0+c2V0VW5yZWFkKGUudGFyZ2V0LmNoZWNrZWQpfS8+IFVucmVhZCBvbmx5PC9sYWJlbD59Lz48YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1wYW5lbFwiPjxkaXYgY2xhc3NOYW1lPVwicDYtcGFuZWwtaGVhZFwiPjxkaXY+PGgyPkluYm94PC9oMj48cD57cS5kYXRhPy51bnJlYWRDb3VudD8/MH0gdW5yZWFkIG5vdGlmaWNhdGlvbnM8L3A+PC9kaXY+PC9kaXY+e3EuaXNMb2FkaW5nPzxTdGF0ZS8+OnEuaXNFcnJvcj88U3RhdGUga2luZD1cImVycm9yXCIgbWVzc2FnZT17ZXJyb3JNZXNzYWdlKHEuZXJyb3IpfSByZXRyeT17KCk9PnZvaWQgcS5yZWZldGNoKCl9Lz46cm93cy5sZW5ndGg9PT0wPzxTdGF0ZSBraW5kPVwiZW1wdHlcIiBtZXNzYWdlPVwiWW91IGFyZSBhbGwgY2F1Z2h0IHVwLlwiLz46PGRpdiBjbGFzc05hbWU9XCJwNi1ub3RpZmljYXRpb24tbGlzdFwiPntyb3dzLm1hcCgobjpBbnlSZWNvcmQpPT48ZGl2IGNsYXNzTmFtZT17YHA2LW5vdGlmaWNhdGlvbiAke24uc3RhdHVzPT09XCJTRU5UXCI/XCJ1bnJlYWRcIjpcIlwifWB9IGtleT17bi5pZH0+PHNwYW4gY2xhc3NOYW1lPVwicDYtbm90aWZpY2F0aW9uLWljb25cIj48QmVsbCBzaXplPXsxOH0vPjwvc3Bhbj48ZGl2PjxzdHJvbmc+e24udGl0bGV9PC9zdHJvbmc+PHA+e24ubWVzc2FnZX08L3A+PHNtYWxsPntkYXRlKG4uY3JlYXRlZEF0KX0gwrcge24uY2hhbm5lbH0gwrcge24uc3RhdHVzfTwvc21hbGw+PC9kaXY+e24uc3RhdHVzPT09XCJTRU5UXCImJjxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtXCIgZGlzYWJsZWQ9e21hcmsuaXNQZW5kaW5nfSBvbkNsaWNrPXsoKT0+bWFyay5tdXRhdGUobi5pZCl9Pk1hcmsgcmVhZDwvYnV0dG9uPn08L2Rpdj4pfTwvZGl2Pn08L2FydGljbGU+PC9zZWN0aW9uPjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFByb2ZpbGVQYWdlKCkge1xuIGNvbnN0IHFjPXVzZVF1ZXJ5Q2xpZW50KCk7IGNvbnN0IHtyZWZyZXNoVXNlcn09dXNlQXV0aCgpO1xuIGNvbnN0IHE9dXNlUXVlcnkoe3F1ZXJ5S2V5OltcInByb2ZpbGVcIl0scXVlcnlGbjphc3luYygpPT51bndyYXAoYXdhaXQgYXBpLmdldChcIi91c2Vycy9tZVwiKSl9KTtcbiBjb25zdCBbbmFtZSxzZXROYW1lXT11c2VTdGF0ZTxzdHJpbmd8dW5kZWZpbmVkPih1bmRlZmluZWQpOyBjb25zdCBbcGhvbmUsc2V0UGhvbmVdPXVzZVN0YXRlPHN0cmluZ3x1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gY29uc3QgcHJvZmlsZT1xLmRhdGEgYXMgQW55UmVjb3JkfHVuZGVmaW5lZDtcbiBjb25zdCB1cGRhdGU9dXNlTXV0YXRpb24oe211dGF0aW9uRm46YXN5bmMoKT0+dW53cmFwKGF3YWl0IGFwaS5wYXRjaChcIi91c2Vycy9tZVwiLHsuLi4obmFtZSE9PXVuZGVmaW5lZD97bmFtZX06e30pLC4uLihwaG9uZSE9PXVuZGVmaW5lZD97cGhvbmU6cGhvbmU9PT1cIlwiP251bGw6cGhvbmV9Ont9KX0pKSxvblN1Y2Nlc3M6YXN5bmMoKT0+e3RvYXN0LnN1Y2Nlc3MoXCJQcm9maWxlIHVwZGF0ZWRcIik7YXdhaXQgcWMuaW52YWxpZGF0ZVF1ZXJpZXMoe3F1ZXJ5S2V5OltcInByb2ZpbGVcIl19KTtzZXROYW1lKHVuZGVmaW5lZCk7c2V0UGhvbmUodW5kZWZpbmVkKTthd2FpdCByZWZyZXNoVXNlcigpO30sb25FcnJvcjplPT50b2FzdC5lcnJvcihlcnJvck1lc3NhZ2UoZSkpfSk7XG4gcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvcnRhbC1jb250ZW50IHA2LWNvbnRlbnRcIj48UGFnZUhlYWRpbmcgdGl0bGU9XCJQcm9maWxlICYgc2V0dGluZ3NcIiBzdWJ0aXRsZT1cIlZpZXcgeW91ciBwcm9maWxlIGFuZCB1cGRhdGUgdGhlIGZpZWxkcyBzdXBwb3J0ZWQgYnkgdGhlIGJhY2tlbmQuXCIvPjxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIHA2LXBhbmVsIHA2LXByb2ZpbGVcIj48ZGl2IGNsYXNzTmFtZT1cInA2LXByb2ZpbGUtYXZhdGFyXCI+PFVzZXJSb3VuZCBzaXplPXsyOH0vPjwvZGl2PntxLmlzTG9hZGluZz88U3RhdGUvPjpxLmlzRXJyb3I/PFN0YXRlIGtpbmQ9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZShxLmVycm9yKX0gcmV0cnk9eygpPT52b2lkIHEucmVmZXRjaCgpfS8+Ojw+PGRpdiBjbGFzc05hbWU9XCJwNi1wcm9maWxlLW1ldGFcIj48aDI+e3Byb2ZpbGU/Lm5hbWU/P1wiQ3VzdG9tZXJcIn08L2gyPjxwPntwcm9maWxlPy5lbWFpbD8/XCLigJRcIn08L3A+PFN0YXR1cyB2YWx1ZT17cHJvZmlsZT8uc3RhdHVzfS8+PHNtYWxsPlJvbGU6IHtwcm9maWxlPy5yb2xlPz9cIkNVU1RPTUVSXCJ9PC9zbWFsbD48L2Rpdj48Zm9ybSBjbGFzc05hbWU9XCJwNi1mb3JtIHA2LXByb2ZpbGUtZm9ybVwiIG9uU3VibWl0PXtlPT57ZS5wcmV2ZW50RGVmYXVsdCgpO3VwZGF0ZS5tdXRhdGUoKTt9fT48bGFiZWw+TmFtZTxpbnB1dCByZXF1aXJlZCBtaW5MZW5ndGg9ezJ9IG1heExlbmd0aD17MTAwfSB2YWx1ZT17bmFtZT8/cHJvZmlsZT8ubmFtZT8/XCJcIn0gb25DaGFuZ2U9e2U9PnNldE5hbWUoZS50YXJnZXQudmFsdWUpfS8+PC9sYWJlbD48bGFiZWw+UGhvbmU8aW5wdXQgbWluTGVuZ3RoPXs3fSBtYXhMZW5ndGg9ezIwfSB2YWx1ZT17cGhvbmU/P3Byb2ZpbGU/LnBob25lPz9cIlwifSBvbkNoYW5nZT17ZT0+c2V0UGhvbmUoZS50YXJnZXQudmFsdWUpfS8+PC9sYWJlbD48bGFiZWw+RW1haWw8aW5wdXQgZGlzYWJsZWQgdmFsdWU9e3Byb2ZpbGU/LmVtYWlsPz9cIlwifS8+PHNtYWxsPkVtYWlsIGNoYW5nZXMgYXJlIG5vdCBzdXBwb3J0ZWQgYnkgdGhlIGN1cnJlbnQgYmFja2VuZC48L3NtYWxsPjwvbGFiZWw+PGRpdiBjbGFzc05hbWU9XCJwNi1pbmZvLWJveFwiPk9ubHkgbmFtZSBhbmQgcGhvbmUgY2FuIGJlIHVwZGF0ZWQuIFBhc3N3b3JkLCBlbWFpbCBhbmQgYXZhdGFyIGVkaXRpbmcgZW5kcG9pbnRzIGFyZSBub3QgcHJlc2VudCBpbiB0aGUgc3VwcGxpZWQgYmFja2VuZCBzb3VyY2UuPC9kaXY+PGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnlcIiBkaXNhYmxlZD17dXBkYXRlLmlzUGVuZGluZ30+e3VwZGF0ZS5pc1BlbmRpbmc/XCJTYXZpbmfigKZcIjpcIlNhdmUgcHJvZmlsZVwifTwvYnV0dG9uPjwvZm9ybT48Lz59PC9hcnRpY2xlPjwvc2VjdGlvbj47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBEZWNpc2lvbkV4cGxhbmF0aW9uc1BhZ2UoKSB7XG4gY29uc3QgcT11c2VRdWVyeSh7cXVlcnlLZXk6W1wiZGVjaXNpb24tZXhwbGFuYXRpb25zXCJdLHF1ZXJ5Rm46YXN5bmMoKT0+dW53cmFwKGF3YWl0IGFwaS5nZXQoXCIvY3VzdG9tZXIvZGVjaXNpb24tZXhwbGFuYXRpb25zL21lXCIse3BhcmFtczp7cGFnZToxLGxpbWl0OjUwfX0pKX0pO1xuIGNvbnN0IHJvd3M9QXJyYXkuaXNBcnJheShxLmRhdGEpP3EuZGF0YTpxLmRhdGE/Lml0ZW1zPz9bXTtcbiByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9ydGFsLWNvbnRlbnQgcDYtY29udGVudFwiPjxQYWdlSGVhZGluZyB0aXRsZT1cIkRlY2lzaW9uIGV4cGxhbmF0aW9uc1wiIHN1YnRpdGxlPVwiVW5kZXJzdGFuZCBzZWN1cml0eSBhbmQgcmlzayBkZWNpc2lvbnMgYXNzb2NpYXRlZCB3aXRoIHlvdXIgdHJhbnNhY3Rpb25zLlwiLz48YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1wYW5lbFwiPntxLmlzTG9hZGluZz88U3RhdGUvPjpxLmlzRXJyb3I/PFN0YXRlIGtpbmQ9XCJlcnJvclwiIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZShxLmVycm9yKX0gcmV0cnk9eygpPT52b2lkIHEucmVmZXRjaCgpfS8+OnJvd3MubGVuZ3RoPT09MD88U3RhdGUga2luZD1cImVtcHR5XCIgbWVzc2FnZT1cIlRoZXJlIGFyZSBubyBkZWNpc2lvbiBleHBsYW5hdGlvbnMgZm9yIHlvdXIgYWNjb3VudC5cIi8+OjxkaXYgY2xhc3NOYW1lPVwicDYtZGVjaXNpb24tbGlzdFwiPntyb3dzLm1hcCgoZDpBbnlSZWNvcmQsaTpudW1iZXIpPT48ZGl2IGNsYXNzTmFtZT1cInA2LWRlY2lzaW9uXCIga2V5PXtgJHtkLnB1YmxpY1JlZmVyZW5jZT8/aX1gfT48ZGl2IGNsYXNzTmFtZT1cInA2LXBhbmVsLWhlYWRcIj48ZGl2PjxoMj57ZC5jdXN0b21lclRpdGxlPz9cIlRyYW5zYWN0aW9uIGRlY2lzaW9uXCJ9PC9oMj48cD57ZC5wdWJsaWNSZWZlcmVuY2U/P1wiRGVjaXNpb24gcmVjb3JkXCJ9IMK3IHtkLnBoYXNlPz9cIuKAlFwifSDCtyB7ZGF0ZShkLmNyZWF0ZWRBdCl9PC9wPjwvZGl2PjxTdGF0dXMgdmFsdWU9e2Quc3RhdHVzPz9kLmRlY2lzaW9ufS8+PC9kaXY+PHA+e2QuY3VzdG9tZXJNZXNzYWdlfTwvcD57QXJyYXkuaXNBcnJheShkLnJlYXNvbkNvZGVzKSYmPHAgY2xhc3NOYW1lPVwibXV0ZWRcIj5SZWFzb24gY29kZXM6IHtkLnJlYXNvbkNvZGVzLmpvaW4oXCIsIFwiKX08L3A+fXtBcnJheS5pc0FycmF5KGQucmVxdWlyZWRBY3Rpb25zKSYmPGRpdj48c3Ryb25nPlN1Z2dlc3RlZCBhY3Rpb25zPC9zdHJvbmc+PHVsPntkLnJlcXVpcmVkQWN0aW9ucy5tYXAoKGE6c3RyaW5nKT0+IDxsaSBrZXk9e2F9PnthfTwvbGk+KX08L3VsPjwvZGl2Pn17ZC50cmFuc2FjdGlvbkltcGFjdCYmPGRpdiBjbGFzc05hbWU9XCJwNi1pbmZvLWJveFwiPlRyYW5zYWN0aW9uIHN0YXR1czoge2QudHJhbnNhY3Rpb25JbXBhY3QudHJhbnNhY3Rpb25TdGF0dXM/P1wi4oCUXCJ9IMK3IEZ1bmRzIG1vdmVtZW50IGNvbmZpcm1lZDoge1N0cmluZyhkLnRyYW5zYWN0aW9uSW1wYWN0LmZ1bmRzTW92ZW1lbnRDb25maXJtZWQ/P1wiTm90IHNwZWNpZmllZFwiKX08L2Rpdj59PC9kaXY+KX08L2Rpdj59PC9hcnRpY2xlPjwvc2VjdGlvbj47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBGeFJlcXVlc3REZXRhaWxzUGFnZSgpIHtcbiBjb25zdCB7cmVxdWVzdElkPVwiXCJ9PXVzZVBhcmFtcygpO1xuIGNvbnN0IHE9dXNlUXVlcnkoe3F1ZXJ5S2V5OltcImZ4LXJlcXVlc3RcIixyZXF1ZXN0SWRdLHF1ZXJ5Rm46YXN5bmMoKT0+dW53cmFwKGF3YWl0IGFwaS5nZXQoYC9meC1yZXF1ZXN0cy8ke3JlcXVlc3RJZH1gKSkuZnhSZXF1ZXN0fSk7XG4gaWYocS5pc0xvYWRpbmcpcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvcnRhbC1jb250ZW50XCI+PFN0YXRlLz48L3NlY3Rpb24+O1xuIGlmKHEuaXNFcnJvcilyZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9ydGFsLWNvbnRlbnRcIj48U3RhdGUga2luZD17KHEuZXJyb3IgYXMgYW55KT8ucmVzcG9uc2U/LnN0YXR1cz09PTQwMz9cImRlbmllZFwiOlwiZXJyb3JcIn0gbWVzc2FnZT17ZXJyb3JNZXNzYWdlKHEuZXJyb3IpfSByZXRyeT17KCk9PnZvaWQgcS5yZWZldGNoKCl9Lz48L3NlY3Rpb24+O1xuIGNvbnN0IGQ9cS5kYXRhIGFzIEFueVJlY29yZDtcbiByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9ydGFsLWNvbnRlbnQgcDYtY29udGVudFwiPjxQYWdlSGVhZGluZyB0aXRsZT1cIkZYIHJlcXVlc3QgZGV0YWlsc1wiIHN1YnRpdGxlPVwiUmVhZC1vbmx5IGZvcmVpZ24gZXhjaGFuZ2UgcmVxdWVzdCBkZXRhaWxzLlwiLz48YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBwNi1wYW5lbFwiPjxkaXYgY2xhc3NOYW1lPVwicDYtZGV0YWlsLWdyaWRcIj57T2JqZWN0LmVudHJpZXMoZD8/e30pLmZpbHRlcigoWyx2XSk9PnY9PT1udWxsfHxbXCJzdHJpbmdcIixcIm51bWJlclwiLFwiYm9vbGVhblwiXS5pbmNsdWRlcyh0eXBlb2YgdikpLm1hcCgoW2ssdl0pPT48ZGl2IGtleT17a30+PHNtYWxsPntrLnJlcGxhY2UoL1tBLVpdL2csbT0+YCAke219YCkucmVwbGFjZSgvXi4vLG09Pm0udG9VcHBlckNhc2UoKSl9PC9zbWFsbD48c3Ryb25nPnt2PT09bnVsbD9cIuKAlFwiOlN0cmluZyh2KX08L3N0cm9uZz48L2Rpdj4pfTwvZGl2PntkPy5pZCYmPHAgY2xhc3NOYW1lPVwibXV0ZWRcIj5SZXF1ZXN0IElEOiB7ZC5pZH08L3A+fTwvYXJ0aWNsZT48L3NlY3Rpb24+O1xufVxuIl0sImZpbGUiOiJEOi9OZXdfZm9sZGVyXygyKS9Tb2Z0d2FyZSBkZXZlbG9wbWVudCBQcm9qZWN0L2JhbmtpbmctcGxhdGZyb20vZnJvbnRlbmQvYmFua2luZy1wbGF0Zm9ybS1mcm9udGVuZC9zcmMvZmVhdHVyZXMvY3VzdG9tZXIvcGhhc2U2L0N1c3RvbWVyUGFnZXMudHN4In0=