import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Badge.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { clsx } from "/node_modules/.vite/deps/clsx.js?v=d15d18f8";
export function Badge({ variant = "neutral", className, ...props }) {
  return /* @__PURE__ */ jsxDEV("span", { className: clsx("badge", `badge-${variant}`, className), ...props }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Badge.tsx",
    lineNumber: 9,
    columnNumber: 10
  }, this);
}
_c = Badge;
const statusVariants = {
  active: "success",
  pending: "warning",
  success: "success",
  failed: "danger",
  suspended: "danger",
  review: "info"
};
export function StatusBadge({ status, label }) {
  const text = label ?? status.charAt(0).toUpperCase() + status.slice(1);
  return /* @__PURE__ */ jsxDEV(Badge, { variant: statusVariants[status], children: text }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Badge.tsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
}
_c2 = StatusBadge;
var _c, _c2;
$RefreshReg$(_c, "Badge");
$RefreshReg$(_c2, "StatusBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Badge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Badge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Badge.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVM7QUFQVCxTQUFTQSxZQUFZO0FBTWQsZ0JBQVNDLE1BQU0sRUFBRUMsVUFBVSxXQUFXQyxXQUFXLEdBQUdDLE1BQWtCLEdBQUc7QUFDOUUsU0FBTyx1QkFBQyxVQUFLLFdBQVdKLEtBQUssU0FBUyxTQUFTRSxPQUFPLElBQUlDLFNBQVMsR0FBRyxHQUFJQyxTQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlFO0FBQ2xGO0FBQUNDLEtBRmVKO0FBTWhCLE1BQU1LLGlCQUErQztBQUFBLEVBQ25EQyxRQUFRO0FBQUEsRUFDUkMsU0FBUztBQUFBLEVBQ1RDLFNBQVM7QUFBQSxFQUNUQyxRQUFRO0FBQUEsRUFDUkMsV0FBVztBQUFBLEVBQ1hDLFFBQVE7QUFDVjtBQUVPLGdCQUFTQyxZQUFZLEVBQUVDLFFBQVFDLE1BQTBDLEdBQUc7QUFDakYsUUFBTUMsT0FBT0QsU0FBU0QsT0FBT0csT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFBSUosT0FBT0ssTUFBTSxDQUFDO0FBQ3JFLFNBQU8sdUJBQUMsU0FBTSxTQUFTYixlQUFlUSxNQUFNLEdBQUlFLGtCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThDO0FBQ3ZEO0FBQUNJLE1BSGVQO0FBQVcsSUFBQVIsSUFBQWU7QUFBQSxhQUFBZixJQUFBO0FBQUEsYUFBQWUsS0FBQSIsIm5hbWVzIjpbImNsc3giLCJCYWRnZSIsInZhcmlhbnQiLCJjbGFzc05hbWUiLCJwcm9wcyIsIl9jIiwic3RhdHVzVmFyaWFudHMiLCJhY3RpdmUiLCJwZW5kaW5nIiwic3VjY2VzcyIsImZhaWxlZCIsInN1c3BlbmRlZCIsInJldmlldyIsIlN0YXR1c0JhZGdlIiwic3RhdHVzIiwibGFiZWwiLCJ0ZXh0IiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzbGljZSIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCYWRnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBIVE1MQXR0cmlidXRlcyB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY2xzeCB9IGZyb20gXCJjbHN4XCI7XG5cbmV4cG9ydCB0eXBlIEJhZGdlVmFyaWFudCA9IFwibmV1dHJhbFwiIHwgXCJpbmZvXCIgfCBcInN1Y2Nlc3NcIiB8IFwid2FybmluZ1wiIHwgXCJkYW5nZXJcIiB8IFwib3V0bGluZVwiO1xuXG50eXBlIEJhZGdlUHJvcHMgPSBIVE1MQXR0cmlidXRlczxIVE1MU3BhbkVsZW1lbnQ+ICYgeyB2YXJpYW50PzogQmFkZ2VWYXJpYW50IH07XG5cbmV4cG9ydCBmdW5jdGlvbiBCYWRnZSh7IHZhcmlhbnQgPSBcIm5ldXRyYWxcIiwgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBCYWRnZVByb3BzKSB7XG4gIHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2Nsc3goXCJiYWRnZVwiLCBgYmFkZ2UtJHt2YXJpYW50fWAsIGNsYXNzTmFtZSl9IHsuLi5wcm9wc30gLz47XG59XG5cbmV4cG9ydCB0eXBlIFN0YXR1cyA9IFwiYWN0aXZlXCIgfCBcInBlbmRpbmdcIiB8IFwic3VjY2Vzc1wiIHwgXCJmYWlsZWRcIiB8IFwic3VzcGVuZGVkXCIgfCBcInJldmlld1wiO1xuXG5jb25zdCBzdGF0dXNWYXJpYW50czogUmVjb3JkPFN0YXR1cywgQmFkZ2VWYXJpYW50PiA9IHtcbiAgYWN0aXZlOiBcInN1Y2Nlc3NcIixcbiAgcGVuZGluZzogXCJ3YXJuaW5nXCIsXG4gIHN1Y2Nlc3M6IFwic3VjY2Vzc1wiLFxuICBmYWlsZWQ6IFwiZGFuZ2VyXCIsXG4gIHN1c3BlbmRlZDogXCJkYW5nZXJcIixcbiAgcmV2aWV3OiBcImluZm9cIixcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBTdGF0dXNCYWRnZSh7IHN0YXR1cywgbGFiZWwgfTogeyBzdGF0dXM6IFN0YXR1czsgbGFiZWw/OiBzdHJpbmcgfSkge1xuICBjb25zdCB0ZXh0ID0gbGFiZWwgPz8gc3RhdHVzLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RhdHVzLnNsaWNlKDEpO1xuICByZXR1cm4gPEJhZGdlIHZhcmlhbnQ9e3N0YXR1c1ZhcmlhbnRzW3N0YXR1c119Pnt0ZXh0fTwvQmFkZ2U+O1xufVxuIl0sImZpbGUiOiJEOi9OZXdfZm9sZGVyXygyKS9Tb2Z0d2FyZSBkZXZlbG9wbWVudCBQcm9qZWN0L2JhbmtpbmctcGxhdGZyb20vZnJvbnRlbmQvYmFua2luZy1wbGF0Zm9ybS1mcm9udGVuZC9zcmMvY29tcG9uZW50cy91aS9CYWRnZS50c3gifQ==