import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/public/components/AuthShell.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { BarChart3, LockKeyhole, ShieldCheck, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
const copy = {
  login: { heading: /* @__PURE__ */ jsxDEV(Fragment, { children: [
    "Manage Your Money",
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 6,
      columnNumber: 40
    }, this),
    "Effortlessly"
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
    lineNumber: 6,
    columnNumber: 21
  }, this), description: "A secure and modern banking platform for your personal and business needs.", items: ["Secure & Trusted", "Fast Transactions", "Real-time Insights"] },
  register: { heading: /* @__PURE__ */ jsxDEV(Fragment, { children: [
    "Open Your",
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 7,
      columnNumber: 35
    }, this),
    "Banking Account",
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 7,
      columnNumber: 56
    }, this),
    "Today"
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
    lineNumber: 7,
    columnNumber: 24
  }, this), description: "Create a secure account and access a complete range of banking and financial services in one platform.", items: ["Secure & Verified", "Fast & Easy Registration", "Manage Money Anytime"] },
  verify: { heading: /* @__PURE__ */ jsxDEV(Fragment, { children: [
    "Verify Your",
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 8,
      columnNumber: 35
    }, this),
    "Email Address"
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
    lineNumber: 8,
    columnNumber: 22
  }, this), description: "Confirm your email to activate your banking account and access all features.", items: ["Secure verification", "Activate your account", "Protect your identity"] },
  forgot: { heading: /* @__PURE__ */ jsxDEV(Fragment, { children: [
    "Forgot Your",
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 9,
      columnNumber: 35
    }, this),
    "Password?"
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
    lineNumber: 9,
    columnNumber: 22
  }, this), description: "No worries! Enter your registered email address and we'll send you a link to reset your password.", items: ["Secure Reset Link", "Quick & Easy Process", "Keep Your Account Safe"] },
  reset: { heading: /* @__PURE__ */ jsxDEV(Fragment, { children: [
    "Reset Your",
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 10,
      columnNumber: 33
    }, this),
    "Password"
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
    lineNumber: 10,
    columnNumber: 21
  }, this), description: "Create a new, strong password to keep your account secure.", items: ["Stronger Security", "Keep Your Data Safe", "Regain Account Access"] }
};
export function AuthShell({ title, subtitle, children, variant = "login" }) {
  const data = copy[variant];
  return /* @__PURE__ */ jsxDEV("section", { className: `auth-shell auth-${variant}`, children: [
    /* @__PURE__ */ jsxDEV("aside", { className: "auth-promo", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "promo-copy", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "promo-kicker", children: "BANKING PLATFORM" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 16,
          columnNumber: 35
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: data.heading }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 16,
          columnNumber: 89
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: data.description }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 16,
          columnNumber: 112
        }, this),
        /* @__PURE__ */ jsxDEV("ul", { children: data.items.map((item, i) => /* @__PURE__ */ jsxDEV("li", { children: [
          /* @__PURE__ */ jsxDEV("span", { className: "promo-feature-icon", children: [/* @__PURE__ */ jsxDEV(ShieldCheck, { size: 20 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 17,
            columnNumber: 96
          }, this), /* @__PURE__ */ jsxDEV(Zap, { size: 20 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 17,
            columnNumber: 123
          }, this), /* @__PURE__ */ jsxDEV(BarChart3, { size: 20 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 17,
            columnNumber: 142
          }, this)][i] }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 17,
            columnNumber: 57
          }, this),
          item
        ] }, item, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 17,
          columnNumber: 42
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 17,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
        lineNumber: 16,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "promo-art", "aria-hidden": "true", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "art-orbit" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 19,
          columnNumber: 53
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "art-bank", children: [
          /* @__PURE__ */ jsxDEV(LandmarkIcon, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 19,
            columnNumber: 112
          }, this),
          /* @__PURE__ */ jsxDEV("b", { children: "BANK" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 19,
            columnNumber: 128
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 19,
          columnNumber: 86
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "art-card", children: [
          /* @__PURE__ */ jsxDEV("span", { children: "▰" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 19,
            columnNumber: 171
          }, this),
          /* @__PURE__ */ jsxDEV("i", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 19,
            columnNumber: 185
          }, this),
          /* @__PURE__ */ jsxDEV("i", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 19,
            columnNumber: 192
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 19,
          columnNumber: 145
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "art-coins", children: [
          /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 19,
            columnNumber: 232
          }, this),
          /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 19,
            columnNumber: 245
          }, this),
          /* @__PURE__ */ jsxDEV("span", {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
            lineNumber: 19,
            columnNumber: 258
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 19,
          columnNumber: 205
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "art-leaf" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 19,
          columnNumber: 277
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
        lineNumber: 19,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 15,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "auth-panel", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-panel-heading", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "auth-mini-mark", children: /* @__PURE__ */ jsxDEV(LockKeyhole, { size: 17 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 22,
          columnNumber: 76
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 22,
          columnNumber: 43
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { children: title }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 22,
          columnNumber: 108
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: subtitle }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
          lineNumber: 22,
          columnNumber: 124
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
        lineNumber: 22,
        columnNumber: 7
      }, this),
      children
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 21,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
_c = AuthShell;
function LandmarkIcon() {
  return /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 120 90", role: "img", children: [
    /* @__PURE__ */ jsxDEV("path", { d: "M8 27 60 4l52 23H8Z", fill: "currentColor" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 27,
      columnNumber: 70
    }, this),
    /* @__PURE__ */ jsxDEV("path", { d: "M17 33h86v8H17zM22 43h10v33H22zM52 43h10v33H52zM82 43h10v33H82zM12 78h96v8H12z", fill: "currentColor" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 27,
      columnNumber: 122
    }, this),
    /* @__PURE__ */ jsxDEV("path", { d: "M5 88h110v4H5z", fill: "currentColor" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
      lineNumber: 27,
      columnNumber: 233
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx",
    lineNumber: 27,
    columnNumber: 33
  }, this);
}
_c2 = LandmarkIcon;
var _c, _c2;
$RefreshReg$(_c, "AuthShell");
$RefreshReg$(_c2, "LandmarkIcon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/components/AuthShell.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS29CLG1CQUFtQixjQUFuQjtBQUpwQixTQUFTQSxXQUFXQyxhQUFhQyxhQUFhQyxXQUFXO0FBR3pELE1BQU1DLE9BQU87QUFBQSxFQUNYQyxPQUFPLEVBQUVDLFNBQVMsbUNBQUU7QUFBQTtBQUFBLElBQWlCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFBRTtBQUFBLE9BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0MsR0FBS0MsYUFBYSw4RUFBOEVDLE9BQU8sQ0FBQyxvQkFBb0IscUJBQXFCLG9CQUFvQixFQUFFO0FBQUEsRUFDN05DLFVBQVUsRUFBRUgsU0FBUyxtQ0FBRTtBQUFBO0FBQUEsSUFBUyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQUU7QUFBQSxJQUFlLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFBRTtBQUFBLE9BQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUMsR0FBS0MsYUFBYSwwR0FBMEdDLE9BQU8sQ0FBQyxxQkFBcUIsNEJBQTRCLHNCQUFzQixFQUFFO0FBQUEsRUFDM1FFLFFBQVEsRUFBRUosU0FBUyxtQ0FBRTtBQUFBO0FBQUEsSUFBVyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQUU7QUFBQSxPQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQStCLEdBQUtDLGFBQWEsZ0ZBQWdGQyxPQUFPLENBQUMsdUJBQXVCLHlCQUF5Qix1QkFBdUIsRUFBRTtBQUFBLEVBQ3JPRyxRQUFRLEVBQUVMLFNBQVMsbUNBQUU7QUFBQTtBQUFBLElBQVcsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUFFO0FBQUEsT0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEyQixHQUFLQyxhQUFhLHFHQUFxR0MsT0FBTyxDQUFDLHFCQUFxQix3QkFBd0Isd0JBQXdCLEVBQUU7QUFBQSxFQUNwUEksT0FBTyxFQUFFTixTQUFTLG1DQUFFO0FBQUE7QUFBQSxJQUFVLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFBRTtBQUFBLE9BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUIsR0FBS0MsYUFBYSw4REFBOERDLE9BQU8sQ0FBQyxxQkFBcUIsdUJBQXVCLHVCQUF1QixFQUFFO0FBQzFNO0FBQ08sZ0JBQVNLLFVBQVUsRUFBRUMsT0FBT0MsVUFBVUMsVUFBVUMsVUFBVSxRQUFlLEdBQUc7QUFDakYsUUFBTUMsT0FBT2QsS0FBS2EsT0FBTztBQUN6QixTQUFPLHVCQUFDLGFBQVEsV0FBVyxtQkFBbUJBLE9BQU8sSUFDbkQ7QUFBQSwyQkFBQyxXQUFNLFdBQVUsY0FDZjtBQUFBLDZCQUFDLFNBQUksV0FBVSxjQUFhO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGdCQUFlLGdDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsUUFBTyx1QkFBQyxRQUFJQyxlQUFLWixXQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUFLLHVCQUFDLE9BQUdZLGVBQUtYLGVBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQjtBQUFBLFFBQzVILHVCQUFDLFFBQUlXLGVBQUtWLE1BQU1XLElBQUksQ0FBQ0MsTUFBTUMsTUFBTSx1QkFBQyxRQUFjO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHNCQUFzQixXQUFDLHVCQUFDLGVBQVksTUFBTSxNQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQixHQUFJLHVCQUFDLE9BQUksTUFBTSxNQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWMsR0FBSSx1QkFBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0IsQ0FBRSxFQUFFQSxDQUFDLEtBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThHO0FBQUEsVUFBUUQ7QUFBQUEsYUFBNUhBLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSSxDQUFLLEtBQWhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0w7QUFBQSxXQURwTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxhQUFZLGVBQVksUUFBTztBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkI7QUFBQSxRQUFNLHVCQUFDLFNBQUksV0FBVSxZQUFXO0FBQUEsaUNBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQUUsdUJBQUMsT0FBRSxvQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFPO0FBQUEsYUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQU0sdUJBQUMsU0FBSSxXQUFVLFlBQVc7QUFBQSxpQ0FBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQU87QUFBQSxVQUFPLHVCQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRztBQUFBLFVBQUksdUJBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFHO0FBQUEsYUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQU0sdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSxpQ0FBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQU07QUFBQSxVQUFPLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBTTtBQUFBLFVBQU8sdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFNO0FBQUEsYUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQU0sdUJBQUMsU0FBSSxXQUFVLGNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFdBQXZTO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNlM7QUFBQSxTQUovUztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLGFBQVEsV0FBVSxjQUNqQjtBQUFBLDZCQUFDLFNBQUksV0FBVSxzQkFBcUI7QUFBQSwrQkFBQyxVQUFLLFdBQVUsa0JBQWlCLGlDQUFDLGVBQVksTUFBTSxNQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNCLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxRQUFPLHVCQUFDLFFBQUlOLG1CQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQUssdUJBQUMsT0FBR0Msc0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFhO0FBQUEsV0FBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxSTtBQUFBLE1BQ3BJQztBQUFBQSxTQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BVks7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdQO0FBQ0Y7QUFBQ00sS0FkZVQ7QUFlaEIsU0FBU1UsZUFBYztBQUFFLFNBQU8sdUJBQUMsU0FBSSxTQUFRLGNBQWEsTUFBSyxPQUFNO0FBQUEsMkJBQUMsVUFBSyxHQUFFLHVCQUFzQixNQUFLLGtCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlEO0FBQUEsSUFBRSx1QkFBQyxVQUFLLEdBQUUsa0ZBQWlGLE1BQUssa0JBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEc7QUFBQSxJQUFFLHVCQUFDLFVBQUssR0FBRSxrQkFBaUIsTUFBSyxrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0QztBQUFBLE9BQWxQO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb1A7QUFBTztBQUFDQyxNQUFuUkQ7QUFBWSxJQUFBRCxJQUFBRTtBQUFBLGFBQUFGLElBQUE7QUFBQSxhQUFBRSxLQUFBIiwibmFtZXMiOlsiQmFyQ2hhcnQzIiwiTG9ja0tleWhvbGUiLCJTaGllbGRDaGVjayIsIlphcCIsImNvcHkiLCJsb2dpbiIsImhlYWRpbmciLCJkZXNjcmlwdGlvbiIsIml0ZW1zIiwicmVnaXN0ZXIiLCJ2ZXJpZnkiLCJmb3Jnb3QiLCJyZXNldCIsIkF1dGhTaGVsbCIsInRpdGxlIiwic3VidGl0bGUiLCJjaGlsZHJlbiIsInZhcmlhbnQiLCJkYXRhIiwibWFwIiwiaXRlbSIsImkiLCJfYyIsIkxhbmRtYXJrSWNvbiIsIl9jMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRoU2hlbGwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBCYXJDaGFydDMsIExvY2tLZXlob2xlLCBTaGllbGRDaGVjaywgWmFwIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG50eXBlIFByb3BzID0geyB0aXRsZTogc3RyaW5nOyBzdWJ0aXRsZTogUmVhY3ROb2RlOyBjaGlsZHJlbjogUmVhY3ROb2RlOyB2YXJpYW50PzogXCJsb2dpblwiIHwgXCJyZWdpc3RlclwiIHwgXCJ2ZXJpZnlcIiB8IFwiZm9yZ290XCIgfCBcInJlc2V0XCIgfTtcbmNvbnN0IGNvcHkgPSB7XG4gIGxvZ2luOiB7IGhlYWRpbmc6IDw+TWFuYWdlIFlvdXIgTW9uZXk8YnIvPkVmZm9ydGxlc3NseTwvPiwgZGVzY3JpcHRpb246IFwiQSBzZWN1cmUgYW5kIG1vZGVybiBiYW5raW5nIHBsYXRmb3JtIGZvciB5b3VyIHBlcnNvbmFsIGFuZCBidXNpbmVzcyBuZWVkcy5cIiwgaXRlbXM6IFtcIlNlY3VyZSAmIFRydXN0ZWRcIiwgXCJGYXN0IFRyYW5zYWN0aW9uc1wiLCBcIlJlYWwtdGltZSBJbnNpZ2h0c1wiXSB9LFxuICByZWdpc3RlcjogeyBoZWFkaW5nOiA8Pk9wZW4gWW91cjxici8+QmFua2luZyBBY2NvdW50PGJyLz5Ub2RheTwvPiwgZGVzY3JpcHRpb246IFwiQ3JlYXRlIGEgc2VjdXJlIGFjY291bnQgYW5kIGFjY2VzcyBhIGNvbXBsZXRlIHJhbmdlIG9mIGJhbmtpbmcgYW5kIGZpbmFuY2lhbCBzZXJ2aWNlcyBpbiBvbmUgcGxhdGZvcm0uXCIsIGl0ZW1zOiBbXCJTZWN1cmUgJiBWZXJpZmllZFwiLCBcIkZhc3QgJiBFYXN5IFJlZ2lzdHJhdGlvblwiLCBcIk1hbmFnZSBNb25leSBBbnl0aW1lXCJdIH0sXG4gIHZlcmlmeTogeyBoZWFkaW5nOiA8PlZlcmlmeSBZb3VyPGJyLz5FbWFpbCBBZGRyZXNzPC8+LCBkZXNjcmlwdGlvbjogXCJDb25maXJtIHlvdXIgZW1haWwgdG8gYWN0aXZhdGUgeW91ciBiYW5raW5nIGFjY291bnQgYW5kIGFjY2VzcyBhbGwgZmVhdHVyZXMuXCIsIGl0ZW1zOiBbXCJTZWN1cmUgdmVyaWZpY2F0aW9uXCIsIFwiQWN0aXZhdGUgeW91ciBhY2NvdW50XCIsIFwiUHJvdGVjdCB5b3VyIGlkZW50aXR5XCJdIH0sXG4gIGZvcmdvdDogeyBoZWFkaW5nOiA8PkZvcmdvdCBZb3VyPGJyLz5QYXNzd29yZD88Lz4sIGRlc2NyaXB0aW9uOiBcIk5vIHdvcnJpZXMhIEVudGVyIHlvdXIgcmVnaXN0ZXJlZCBlbWFpbCBhZGRyZXNzIGFuZCB3ZSdsbCBzZW5kIHlvdSBhIGxpbmsgdG8gcmVzZXQgeW91ciBwYXNzd29yZC5cIiwgaXRlbXM6IFtcIlNlY3VyZSBSZXNldCBMaW5rXCIsIFwiUXVpY2sgJiBFYXN5IFByb2Nlc3NcIiwgXCJLZWVwIFlvdXIgQWNjb3VudCBTYWZlXCJdIH0sXG4gIHJlc2V0OiB7IGhlYWRpbmc6IDw+UmVzZXQgWW91cjxici8+UGFzc3dvcmQ8Lz4sIGRlc2NyaXB0aW9uOiBcIkNyZWF0ZSBhIG5ldywgc3Ryb25nIHBhc3N3b3JkIHRvIGtlZXAgeW91ciBhY2NvdW50IHNlY3VyZS5cIiwgaXRlbXM6IFtcIlN0cm9uZ2VyIFNlY3VyaXR5XCIsIFwiS2VlcCBZb3VyIERhdGEgU2FmZVwiLCBcIlJlZ2FpbiBBY2NvdW50IEFjY2Vzc1wiXSB9LFxufTtcbmV4cG9ydCBmdW5jdGlvbiBBdXRoU2hlbGwoeyB0aXRsZSwgc3VidGl0bGUsIGNoaWxkcmVuLCB2YXJpYW50ID0gXCJsb2dpblwiIH06IFByb3BzKSB7XG4gIGNvbnN0IGRhdGEgPSBjb3B5W3ZhcmlhbnRdO1xuICByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPXtgYXV0aC1zaGVsbCBhdXRoLSR7dmFyaWFudH1gfT5cbiAgICA8YXNpZGUgY2xhc3NOYW1lPVwiYXV0aC1wcm9tb1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9tby1jb3B5XCI+PHNwYW4gY2xhc3NOYW1lPVwicHJvbW8ta2lja2VyXCI+QkFOS0lORyBQTEFURk9STTwvc3Bhbj48aDE+e2RhdGEuaGVhZGluZ308L2gxPjxwPntkYXRhLmRlc2NyaXB0aW9ufTwvcD5cbiAgICAgICAgPHVsPntkYXRhLml0ZW1zLm1hcCgoaXRlbSwgaSkgPT4gPGxpIGtleT17aXRlbX0+PHNwYW4gY2xhc3NOYW1lPVwicHJvbW8tZmVhdHVyZS1pY29uXCI+e1s8U2hpZWxkQ2hlY2sgc2l6ZT17MjB9Lz4sIDxaYXAgc2l6ZT17MjB9Lz4sIDxCYXJDaGFydDMgc2l6ZT17MjB9Lz5dW2ldfTwvc3Bhbj57aXRlbX08L2xpPil9PC91bD5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9tby1hcnRcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48ZGl2IGNsYXNzTmFtZT1cImFydC1vcmJpdFwiPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiYXJ0LWJhbmtcIj48TGFuZG1hcmtJY29uLz48Yj5CQU5LPC9iPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiYXJ0LWNhcmRcIj48c3Bhbj7ilrA8L3NwYW4+PGk+PC9pPjxpPjwvaT48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImFydC1jb2luc1wiPjxzcGFuPjwvc3Bhbj48c3Bhbj48L3NwYW4+PHNwYW4+PC9zcGFuPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiYXJ0LWxlYWZcIj48L2Rpdj48L2Rpdj5cbiAgICA8L2FzaWRlPlxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImF1dGgtcGFuZWxcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1wYW5lbC1oZWFkaW5nXCI+PHNwYW4gY2xhc3NOYW1lPVwiYXV0aC1taW5pLW1hcmtcIj48TG9ja0tleWhvbGUgc2l6ZT17MTd9Lz48L3NwYW4+PGgyPnt0aXRsZX08L2gyPjxwPntzdWJ0aXRsZX08L3A+PC9kaXY+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9zZWN0aW9uPlxuICA8L3NlY3Rpb24+O1xufVxuZnVuY3Rpb24gTGFuZG1hcmtJY29uKCl7IHJldHVybiA8c3ZnIHZpZXdCb3g9XCIwIDAgMTIwIDkwXCIgcm9sZT1cImltZ1wiPjxwYXRoIGQ9XCJNOCAyNyA2MCA0bDUyIDIzSDhaXCIgZmlsbD1cImN1cnJlbnRDb2xvclwiLz48cGF0aCBkPVwiTTE3IDMzaDg2djhIMTd6TTIyIDQzaDEwdjMzSDIyek01MiA0M2gxMHYzM0g1MnpNODIgNDNoMTB2MzNIODJ6TTEyIDc4aDk2djhIMTJ6XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiLz48cGF0aCBkPVwiTTUgODhoMTEwdjRINXpcIiBmaWxsPVwiY3VycmVudENvbG9yXCIvPjwvc3ZnPjt9XG4iXSwiZmlsZSI6IkQ6L05ld19mb2xkZXJfKDIpL1NvZnR3YXJlIGRldmVsb3BtZW50IFByb2plY3QvYmFua2luZy1wbGF0ZnJvbS9mcm9udGVuZC9iYW5raW5nLXBsYXRmb3JtLWZyb250ZW5kL3NyYy9mZWF0dXJlcy9wdWJsaWMvY29tcG9uZW50cy9BdXRoU2hlbGwudHN4In0=