import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Button.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { clsx } from "/node_modules/.vite/deps/clsx.js?v=d15d18f8";
export function Button({
  children,
  className,
  variant = "primary",
  size = "md",
  loading = false,
  disabled,
  leftIcon,
  rightIcon,
  ...props
}) {
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      className: clsx("btn", `btn-${variant}`, `btn-${size}`, className),
      disabled: disabled || loading,
      "aria-busy": loading || void 0,
      ...props,
      children: [
        loading ? /* @__PURE__ */ jsxDEV("span", { className: "spinner", "aria-hidden": "true" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Button.tsx",
          lineNumber: 33,
          columnNumber: 18
        }, this) : leftIcon,
        children,
        !loading && rightIcon
      ]
    },
    void 0,
    true,
    {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Button.tsx",
      lineNumber: 27,
      columnNumber: 5
    },
    this
  );
}
_c = Button;
var _c;
$RefreshReg$(_c, "Button");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Button.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NpQjtBQS9CakIsU0FBU0EsWUFBWTtBQWFkLGdCQUFTQyxPQUFPO0FBQUEsRUFDckJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDLFVBQVU7QUFBQSxFQUNWQyxPQUFPO0FBQUEsRUFDUEMsVUFBVTtBQUFBLEVBQ1ZDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0EsR0FBR0M7QUFDUSxHQUFHO0FBQ2QsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsV0FBV1YsS0FBSyxPQUFPLE9BQU9JLE9BQU8sSUFBSSxPQUFPQyxJQUFJLElBQUlGLFNBQVM7QUFBQSxNQUNqRSxVQUFVSSxZQUFZRDtBQUFBQSxNQUN0QixhQUFXQSxXQUFXSztBQUFBQSxNQUN0QixHQUFJRDtBQUFBQSxNQUVISjtBQUFBQSxrQkFBVSx1QkFBQyxVQUFLLFdBQVUsV0FBVSxlQUFZLFVBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEMsSUFBTUU7QUFBQUEsUUFDNUROO0FBQUFBLFFBQ0EsQ0FBQ0ksV0FBV0c7QUFBQUE7QUFBQUE7QUFBQUEsSUFSZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQTtBQUVKO0FBQUNHLEtBdkJlWDtBQUFNLElBQUFXO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNsc3giLCJCdXR0b24iLCJjaGlsZHJlbiIsImNsYXNzTmFtZSIsInZhcmlhbnQiLCJzaXplIiwibG9hZGluZyIsImRpc2FibGVkIiwibGVmdEljb24iLCJyaWdodEljb24iLCJwcm9wcyIsInVuZGVmaW5lZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJ1dHRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBCdXR0b25IVE1MQXR0cmlidXRlcywgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjbHN4IH0gZnJvbSBcImNsc3hcIjtcblxuZXhwb3J0IHR5cGUgQnV0dG9uVmFyaWFudCA9IFwicHJpbWFyeVwiIHwgXCJzZWNvbmRhcnlcIiB8IFwib3V0bGluZVwiIHwgXCJnaG9zdFwiIHwgXCJkYW5nZXJcIjtcbmV4cG9ydCB0eXBlIEJ1dHRvblNpemUgPSBcInNtXCIgfCBcIm1kXCIgfCBcImxnXCIgfCBcImljb25cIjtcblxudHlwZSBCdXR0b25Qcm9wcyA9IEJ1dHRvbkhUTUxBdHRyaWJ1dGVzPEhUTUxCdXR0b25FbGVtZW50PiAmIHtcbiAgdmFyaWFudD86IEJ1dHRvblZhcmlhbnQ7XG4gIHNpemU/OiBCdXR0b25TaXplO1xuICBsb2FkaW5nPzogYm9vbGVhbjtcbiAgbGVmdEljb24/OiBSZWFjdE5vZGU7XG4gIHJpZ2h0SWNvbj86IFJlYWN0Tm9kZTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBCdXR0b24oe1xuICBjaGlsZHJlbixcbiAgY2xhc3NOYW1lLFxuICB2YXJpYW50ID0gXCJwcmltYXJ5XCIsXG4gIHNpemUgPSBcIm1kXCIsXG4gIGxvYWRpbmcgPSBmYWxzZSxcbiAgZGlzYWJsZWQsXG4gIGxlZnRJY29uLFxuICByaWdodEljb24sXG4gIC4uLnByb3BzXG59OiBCdXR0b25Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIGNsYXNzTmFtZT17Y2xzeChcImJ0blwiLCBgYnRuLSR7dmFyaWFudH1gLCBgYnRuLSR7c2l6ZX1gLCBjbGFzc05hbWUpfVxuICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkIHx8IGxvYWRpbmd9XG4gICAgICBhcmlhLWJ1c3k9e2xvYWRpbmcgfHwgdW5kZWZpbmVkfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtsb2FkaW5nID8gPHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+IDogbGVmdEljb259XG4gICAgICB7Y2hpbGRyZW59XG4gICAgICB7IWxvYWRpbmcgJiYgcmlnaHRJY29ufVxuICAgIDwvYnV0dG9uPlxuICApO1xufVxuIl0sImZpbGUiOiJEOi9OZXdfZm9sZGVyXygyKS9Tb2Z0d2FyZSBkZXZlbG9wbWVudCBQcm9qZWN0L2JhbmtpbmctcGxhdGZyb20vZnJvbnRlbmQvYmFua2luZy1wbGF0Zm9ybS1mcm9udGVuZC9zcmMvY29tcG9uZW50cy91aS9CdXR0b24udHN4In0=