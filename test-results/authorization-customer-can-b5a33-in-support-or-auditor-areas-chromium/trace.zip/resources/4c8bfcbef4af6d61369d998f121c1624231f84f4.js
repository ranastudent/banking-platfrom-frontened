import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/public/pages/VerifyEmailPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];
import { Link, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { Check, ArrowLeft } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { useAuth } from "/src/app/providers/AuthProvider.tsx";
import { AuthShell } from "/src/features/public/components/AuthShell.tsx";
import { normalizeApiError } from "/src/lib/api/apiError.ts";
export function VerifyEmailPage() {
  _s();
  const [params] = useSearchParams();
  const email = params.get("email") || "";
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [resendWait, setResendWait] = useState(58);
  const { verifyEmail } = useAuth();
  const navigate = useNavigate();
  useEffect(() => {
    const timer = window.setInterval(() => setResendWait((v) => v > 0 ? v - 1 : 0), 1e3);
    return () => window.clearInterval(timer);
  }, []);
  async function submit(e) {
    e.preventDefault();
    if (code.length !== 6) {
      toast.error("Enter the 6-digit verification code");
      return;
    }
    setBusy(true);
    try {
      await verifyEmail({ email, otp: code });
      toast.success("Email verified. You can now log in.");
      navigate("/login");
    } catch (err) {
      toast.error(normalizeApiError(err).message);
    } finally {
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxDEV(AuthShell, { title: "Email Verification", subtitle: /* @__PURE__ */ jsxDEV(Fragment, { children: [
    "We’ve sent a 6-digit verification code to",
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 13,
      columnNumber: 101
    }, this),
    /* @__PURE__ */ jsxDEV("strong", { className: "highlight-email", children: email || "your email address" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 13,
      columnNumber: 107
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
    lineNumber: 13,
    columnNumber: 58
  }, this), variant: "verify", children: /* @__PURE__ */ jsxDEV("form", { className: "auth-form verify-form", onSubmit: submit, children: [
    /* @__PURE__ */ jsxDEV("label", { children: "Enter the verification code" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 14,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("input", { className: "otp-input", inputMode: "numeric", autoComplete: "one-time-code", "aria-label": "Six digit verification code", maxLength: 6, pattern: "[0-9]{6}", required: true, value: code, onChange: (e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6)), placeholder: "••••••" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 14,
      columnNumber: 45
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "auth-submit", disabled: busy, children: busy ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "spinner" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
        lineNumber: 15,
        columnNumber: 61
      }, this),
      " Verifying..."
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 15,
      columnNumber: 59
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Check, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
        lineNumber: 15,
        columnNumber: 110
      }, this),
      " Verify Email"
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 15,
      columnNumber: 108
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 15,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-divider", children: /* @__PURE__ */ jsxDEV("span", { children: "Didn’t receive the code?" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 16,
      columnNumber: 33
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 16,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "resend-line", children: resendWait > 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      "Resend code in ",
      /* @__PURE__ */ jsxDEV("b", { children: [
        "00:",
        String(resendWait).padStart(2, "0")
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
        lineNumber: 16,
        columnNumber: 138
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 16,
      columnNumber: 121
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: "Please request a new code from the registration support flow." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 16,
      columnNumber: 191
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 16,
      columnNumber: 76
    }, this),
    /* @__PURE__ */ jsxDEV(Link, { className: "back-link", to: "/login", children: [
      /* @__PURE__ */ jsxDEV(ArrowLeft, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
        lineNumber: 17,
        columnNumber: 43
      }, this),
      " Back to Login"
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
      lineNumber: 17,
      columnNumber: 3
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
    lineNumber: 13,
    columnNumber: 205
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
}
_s(VerifyEmailPage, "gulrxaBEhMurr9YfCMPSDL7KBfY=", false, function() {
  return [useSearchParams, useAuth, useNavigate];
});
_c = VerifyEmailPage;
var _c;
$RefreshReg$(_c, "VerifyEmailPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/VerifyEmailPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWXdELG1CQUEyQyxjQUEzQzs7QUFaeEQsU0FBU0EsV0FBV0MsZ0JBQWdDO0FBQ3BELFNBQVNDLE1BQU1DLGFBQWFDLHVCQUF1QjtBQUNuRCxTQUFTQyxPQUFPQyxpQkFBaUI7QUFDakMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyx5QkFBeUI7QUFFM0IsZ0JBQVNDLGtCQUFpQjtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sQ0FBQ0MsTUFBTSxJQUFFVCxnQkFBZ0I7QUFBRSxRQUFNVSxRQUFNRCxPQUFPRSxJQUFJLE9BQU8sS0FBRztBQUFHLFFBQU0sQ0FBQ0MsTUFBS0MsT0FBTyxJQUFFaEIsU0FBUyxFQUFFO0FBQUUsUUFBTSxDQUFDaUIsTUFBS0MsT0FBTyxJQUFFbEIsU0FBUyxLQUFLO0FBQUUsUUFBTSxDQUFDbUIsWUFBV0MsYUFBYSxJQUFFcEIsU0FBUyxFQUFFO0FBQUUsUUFBTSxFQUFDcUIsWUFBVyxJQUFFZCxRQUFRO0FBQUUsUUFBTWUsV0FBU3BCLFlBQVk7QUFDblBILFlBQVUsTUFBSTtBQUFDLFVBQU13QixRQUFNQyxPQUFPQyxZQUFZLE1BQUlMLGNBQWMsQ0FBQU0sTUFBR0EsSUFBRSxJQUFFQSxJQUFFLElBQUUsQ0FBQyxHQUFFLEdBQUk7QUFBRSxXQUFPLE1BQUlGLE9BQU9HLGNBQWNKLEtBQUs7QUFBQSxFQUFFLEdBQUUsRUFBRTtBQUMvSCxpQkFBZUssT0FBT0MsR0FBWTtBQUFDQSxNQUFFQyxlQUFlO0FBQUUsUUFBR2YsS0FBS2dCLFdBQVMsR0FBRTtBQUFDekIsWUFBTTBCLE1BQU0scUNBQXFDO0FBQUU7QUFBQSxJQUFPO0FBQUNkLFlBQVEsSUFBSTtBQUFFLFFBQUc7QUFBQyxZQUFNRyxZQUFZLEVBQUNSLE9BQU1vQixLQUFJbEIsS0FBSSxDQUFDO0FBQUVULFlBQU00QixRQUFRLHFDQUFxQztBQUFFWixlQUFTLFFBQVE7QUFBQSxJQUFFLFNBQU9hLEtBQUk7QUFBQzdCLFlBQU0wQixNQUFNdkIsa0JBQWtCMEIsR0FBRyxFQUFFQyxPQUFPO0FBQUEsSUFBRSxVQUFDO0FBQVFsQixjQUFRLEtBQUs7QUFBQSxJQUFFO0FBQUEsRUFBQztBQUNwVixTQUFPLHVCQUFDLGFBQVUsT0FBTSxzQkFBcUIsVUFBVSxtQ0FBRTtBQUFBO0FBQUEsSUFBeUMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUFFLHVCQUFDLFlBQU8sV0FBVSxtQkFBbUJMLG1CQUFPLHdCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlFO0FBQUEsT0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUEwSCxHQUFLLFNBQVEsVUFBUyxpQ0FBQyxVQUFLLFdBQVUseUJBQXdCLFVBQVVlLFFBQ3hQO0FBQUEsMkJBQUMsV0FBTSwyQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtDO0FBQUEsSUFBUSx1QkFBQyxXQUFNLFdBQVUsYUFBWSxXQUFVLFdBQVUsY0FBYSxpQkFBZ0IsY0FBVywrQkFBOEIsV0FBVyxHQUFHLFNBQVEsWUFBVyxVQUFRLE1BQUMsT0FBT2IsTUFBTSxVQUFVLENBQUFjLE1BQUdiLFFBQVFhLEVBQUVRLE9BQU9DLE1BQU1DLFFBQVEsT0FBTSxFQUFFLEVBQUVDLE1BQU0sR0FBRSxDQUFDLENBQUMsR0FBRyxhQUFZLFlBQTdQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBcVE7QUFBQSxJQUMvUyx1QkFBQyxZQUFPLFdBQVUsZUFBYyxVQUFVdkIsTUFBT0EsaUJBQUssbUNBQUU7QUFBQSw2QkFBQyxVQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQUU7QUFBQSxTQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDLElBQUksbUNBQUU7QUFBQSw2QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTTtBQUFBLE1BQUU7QUFBQSxTQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUIsS0FBM0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErSDtBQUFBLElBQy9ILHVCQUFDLFNBQUksV0FBVSxnQkFBZSxpQ0FBQyxVQUFLLHdDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtRTtBQUFBLElBQU0sdUJBQUMsT0FBRSxXQUFVLGVBQWVFLHVCQUFXLElBQUUsbUNBQUU7QUFBQTtBQUFBLE1BQWUsdUJBQUMsT0FBRTtBQUFBO0FBQUEsUUFBSXNCLE9BQU90QixVQUFVLEVBQUV1QixTQUFTLEdBQUUsR0FBRztBQUFBLFdBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEM7QUFBQSxTQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStELElBQUksbUNBQUUsNkVBQUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRCxLQUEzSztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStLO0FBQUEsSUFDeFAsdUJBQUMsUUFBSyxXQUFVLGFBQVksSUFBRyxVQUFTO0FBQUEsNkJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxNQUFFO0FBQUEsU0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRTtBQUFBLE9BSm9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLdk0sS0FMTztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFDUjtBQUFDL0IsR0FWZUQsaUJBQWU7QUFBQSxVQUNmUCxpQkFBK0xJLFNBQXlCTCxXQUFXO0FBQUE7QUFBQSxLQURuT1E7QUFBZSxJQUFBaUM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VTZWFyY2hQYXJhbXMiLCJDaGVjayIsIkFycm93TGVmdCIsInRvYXN0IiwidXNlQXV0aCIsIkF1dGhTaGVsbCIsIm5vcm1hbGl6ZUFwaUVycm9yIiwiVmVyaWZ5RW1haWxQYWdlIiwiX3MiLCJwYXJhbXMiLCJlbWFpbCIsImdldCIsImNvZGUiLCJzZXRDb2RlIiwiYnVzeSIsInNldEJ1c3kiLCJyZXNlbmRXYWl0Iiwic2V0UmVzZW5kV2FpdCIsInZlcmlmeUVtYWlsIiwibmF2aWdhdGUiLCJ0aW1lciIsIndpbmRvdyIsInNldEludGVydmFsIiwidiIsImNsZWFySW50ZXJ2YWwiLCJzdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJsZW5ndGgiLCJlcnJvciIsIm90cCIsInN1Y2Nlc3MiLCJlcnIiLCJtZXNzYWdlIiwidGFyZ2V0IiwidmFsdWUiLCJyZXBsYWNlIiwic2xpY2UiLCJTdHJpbmciLCJwYWRTdGFydCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlZlcmlmeUVtYWlsUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdHlwZSBGb3JtRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgQ2hlY2ssIEFycm93TGVmdCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcInNvbm5lclwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi8uLi8uLi9hcHAvcHJvdmlkZXJzL0F1dGhQcm92aWRlclwiO1xuaW1wb3J0IHsgQXV0aFNoZWxsIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQXV0aFNoZWxsXCI7XG5pbXBvcnQgeyBub3JtYWxpemVBcGlFcnJvciB9IGZyb20gXCIuLi8uLi8uLi9saWIvYXBpL2FwaUVycm9yXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBWZXJpZnlFbWFpbFBhZ2UoKXtcbiBjb25zdCBbcGFyYW1zXT11c2VTZWFyY2hQYXJhbXMoKTtjb25zdCBlbWFpbD1wYXJhbXMuZ2V0KFwiZW1haWxcIil8fFwiXCI7Y29uc3QgW2NvZGUsc2V0Q29kZV09dXNlU3RhdGUoXCJcIik7Y29uc3QgW2J1c3ksc2V0QnVzeV09dXNlU3RhdGUoZmFsc2UpO2NvbnN0IFtyZXNlbmRXYWl0LHNldFJlc2VuZFdhaXRdPXVzZVN0YXRlKDU4KTtjb25zdCB7dmVyaWZ5RW1haWx9PXVzZUF1dGgoKTtjb25zdCBuYXZpZ2F0ZT11c2VOYXZpZ2F0ZSgpO1xuIHVzZUVmZmVjdCgoKT0+e2NvbnN0IHRpbWVyPXdpbmRvdy5zZXRJbnRlcnZhbCgoKT0+c2V0UmVzZW5kV2FpdCh2PT52PjA/di0xOjApLDEwMDApO3JldHVybiAoKT0+d2luZG93LmNsZWFySW50ZXJ2YWwodGltZXIpO30sW10pO1xuIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdChlOkZvcm1FdmVudCl7ZS5wcmV2ZW50RGVmYXVsdCgpO2lmKGNvZGUubGVuZ3RoIT09Nil7dG9hc3QuZXJyb3IoXCJFbnRlciB0aGUgNi1kaWdpdCB2ZXJpZmljYXRpb24gY29kZVwiKTtyZXR1cm47fXNldEJ1c3kodHJ1ZSk7dHJ5e2F3YWl0IHZlcmlmeUVtYWlsKHtlbWFpbCxvdHA6Y29kZX0pO3RvYXN0LnN1Y2Nlc3MoXCJFbWFpbCB2ZXJpZmllZC4gWW91IGNhbiBub3cgbG9nIGluLlwiKTtuYXZpZ2F0ZShcIi9sb2dpblwiKTt9Y2F0Y2goZXJyKXt0b2FzdC5lcnJvcihub3JtYWxpemVBcGlFcnJvcihlcnIpLm1lc3NhZ2UpO31maW5hbGx5e3NldEJ1c3koZmFsc2UpO319XG4gcmV0dXJuIDxBdXRoU2hlbGwgdGl0bGU9XCJFbWFpbCBWZXJpZmljYXRpb25cIiBzdWJ0aXRsZT17PD5XZeKAmXZlIHNlbnQgYSA2LWRpZ2l0IHZlcmlmaWNhdGlvbiBjb2RlIHRvPGJyLz48c3Ryb25nIGNsYXNzTmFtZT1cImhpZ2hsaWdodC1lbWFpbFwiPntlbWFpbHx8XCJ5b3VyIGVtYWlsIGFkZHJlc3NcIn08L3N0cm9uZz48Lz59IHZhcmlhbnQ9XCJ2ZXJpZnlcIj48Zm9ybSBjbGFzc05hbWU9XCJhdXRoLWZvcm0gdmVyaWZ5LWZvcm1cIiBvblN1Ym1pdD17c3VibWl0fT5cbiAgPGxhYmVsPkVudGVyIHRoZSB2ZXJpZmljYXRpb24gY29kZTwvbGFiZWw+PGlucHV0IGNsYXNzTmFtZT1cIm90cC1pbnB1dFwiIGlucHV0TW9kZT1cIm51bWVyaWNcIiBhdXRvQ29tcGxldGU9XCJvbmUtdGltZS1jb2RlXCIgYXJpYS1sYWJlbD1cIlNpeCBkaWdpdCB2ZXJpZmljYXRpb24gY29kZVwiIG1heExlbmd0aD17Nn0gcGF0dGVybj1cIlswLTldezZ9XCIgcmVxdWlyZWQgdmFsdWU9e2NvZGV9IG9uQ2hhbmdlPXtlPT5zZXRDb2RlKGUudGFyZ2V0LnZhbHVlLnJlcGxhY2UoL1xcRC9nLFwiXCIpLnNsaWNlKDAsNikpfSBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAolwiLz5cbiAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdXRoLXN1Ym1pdFwiIGRpc2FibGVkPXtidXN5fT57YnVzeT88PjxzcGFuIGNsYXNzTmFtZT1cInNwaW5uZXJcIi8+IFZlcmlmeWluZy4uLjwvPjo8PjxDaGVjay8+IFZlcmlmeSBFbWFpbDwvPn08L2J1dHRvbj5cbiAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWRpdmlkZXJcIj48c3Bhbj5EaWRu4oCZdCByZWNlaXZlIHRoZSBjb2RlPzwvc3Bhbj48L2Rpdj48cCBjbGFzc05hbWU9XCJyZXNlbmQtbGluZVwiPntyZXNlbmRXYWl0PjA/PD5SZXNlbmQgY29kZSBpbiA8Yj4wMDp7U3RyaW5nKHJlc2VuZFdhaXQpLnBhZFN0YXJ0KDIsXCIwXCIpfTwvYj48Lz46PD5QbGVhc2UgcmVxdWVzdCBhIG5ldyBjb2RlIGZyb20gdGhlIHJlZ2lzdHJhdGlvbiBzdXBwb3J0IGZsb3cuPC8+fTwvcD5cbiAgPExpbmsgY2xhc3NOYW1lPVwiYmFjay1saW5rXCIgdG89XCIvbG9naW5cIj48QXJyb3dMZWZ0Lz4gQmFjayB0byBMb2dpbjwvTGluaz5cbiA8L2Zvcm0+PC9BdXRoU2hlbGw+O1xufVxuIl0sImZpbGUiOiJEOi9OZXdfZm9sZGVyXygyKS9Tb2Z0d2FyZSBkZXZlbG9wbWVudCBQcm9qZWN0L2JhbmtpbmctcGxhdGZyb20vZnJvbnRlbmQvYmFua2luZy1wbGF0Zm9ybS1mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHVibGljL3BhZ2VzL1ZlcmlmeUVtYWlsUGFnZS50c3gifQ==