import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/customer/accounts/pages/AccountListPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useMemo = __vite__cjsImport1_react["useMemo"]; const useState = __vite__cjsImport1_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { Activity, ArrowUpRight, Copy, Eye, Layers3, Plus, RefreshCw, Wallet } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { Button } from "/src/components/ui/Button.tsx";
import { Badge } from "/src/components/ui/Badge.tsx";
import { normalizeApiError } from "/src/lib/api/apiError.ts";
import { useAccounts, useCreateAccount } from "/src/features/customer/accounts/hooks/useAccounts.ts";
const money = (value, currency, symbol) => {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return `${symbol ?? currency} —`;
  return `${symbol ?? currency} ${amount.toLocaleString(void 0, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};
const typeLabel = (type) => ({ SAVINGS: "Savings", CURRENT: "Current", FOREIGN_CURRENCY: "Foreign currency" })[type] ?? type;
const dateLabel = (value) => new Date(value).toLocaleDateString(void 0, { year: "numeric", month: "short", day: "2-digit" });
export function AccountListPage() {
  _s();
  const { data: accounts = [], isLoading, isError, error, refetch, isFetching } = useAccounts();
  const createAccount = useCreateAccount();
  const [filter, setFilter] = useState("ALL");
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [accountType, setAccountType] = useState("SAVINGS");
  const [currency, setCurrency] = useState("BDT");
  const filtered = useMemo(() => accounts.filter(
    (account) => (filter === "ALL" || account.accountType === filter) && `${account.accountNumber} ${account.accountType} ${account.status}`.toLowerCase().includes(search.toLowerCase())
  ), [accounts, filter, search]);
  const activeCount = accounts.filter((a) => a.status === "ACTIVE").length;
  const inactiveCount = accounts.length - activeCount;
  const balanceByCurrency = accounts.flatMap((a) => a.balances).reduce((acc, b) => {
    acc[b.currencyCode] = (acc[b.currencyCode] ?? 0) + Number(b.availableBalance || 0);
    return acc;
  }, {});
  async function copyAccount(value) {
    try {
      await navigator.clipboard.writeText(value);
      toast.success("Account number copied");
    } catch {
      toast.error("Could not copy account number");
    }
  }
  async function handleCreate(event) {
    event.preventDefault();
    try {
      await createAccount.mutateAsync({ accountType, currency: currency.trim().toUpperCase() });
      toast.success("Account created successfully");
      setShowCreate(false);
    } catch (err) {
      toast.error(normalizeApiError(err).message);
    }
  }
  return /* @__PURE__ */ jsxDEV("section", { className: "portal-content customer-page", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "portal-page-heading", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("p", { className: "eyebrow", children: "CUSTOMER ACCOUNTS" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 53,
          columnNumber: 47
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: "My Accounts" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 53,
          columnNumber: 91
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "muted", children: "Manage and view all your accounts in one place." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 53,
          columnNumber: 111
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 53,
        columnNumber: 42
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: () => setShowCreate(true), leftIcon: /* @__PURE__ */ jsxDEV(Plus, { size: 16 }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 53,
        columnNumber: 243
      }, this), children: "Open New Account" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 53,
        columnNumber: 189
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
      lineNumber: 53,
      columnNumber: 5
    }, this),
    isError && /* @__PURE__ */ jsxDEV("div", { className: "account-alert", role: "alert", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("strong", { children: "Unable to load your accounts" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 55,
          columnNumber: 66
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: normalizeApiError(error).message }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 55,
          columnNumber: 111
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 55,
        columnNumber: 61
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outline", size: "sm", onClick: () => void refetch(), children: "Try again" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 55,
        columnNumber: 158
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
      lineNumber: 55,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "account-stat-grid", children: [
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card account-stat", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "account-stat-icon blue", children: /* @__PURE__ */ jsxDEV(Layers3, { size: 20 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 58,
          columnNumber: 94
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 58,
          columnNumber: 53
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("small", { children: "Total Accounts" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 58,
            columnNumber: 127
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: isLoading ? "—" : accounts.length }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 58,
            columnNumber: 156
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 58,
          columnNumber: 122
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 58,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card account-stat", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "account-stat-icon green", children: /* @__PURE__ */ jsxDEV(Wallet, { size: 20 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 59,
          columnNumber: 95
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 59,
          columnNumber: 53
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("small", { children: "Available balances" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 59,
            columnNumber: 127
          }, this),
          isLoading ? /* @__PURE__ */ jsxDEV("strong", { children: "—" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 59,
            columnNumber: 173
          }, this) : Object.keys(balanceByCurrency).length ? Object.entries(balanceByCurrency).map(([code, value]) => /* @__PURE__ */ jsxDEV("strong", { className: "account-stat-balance", children: money(value, code) }, code, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 59,
            columnNumber: 291
          }, this)) : /* @__PURE__ */ jsxDEV("strong", { children: "0.00" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 59,
            columnNumber: 376
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 59,
          columnNumber: 122
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 59,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card account-stat", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "account-stat-icon blue", children: /* @__PURE__ */ jsxDEV(ArrowUpRight, { size: 20 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 60,
          columnNumber: 94
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 60,
          columnNumber: 53
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("small", { children: "Active Accounts" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 60,
            columnNumber: 132
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: isLoading ? "—" : activeCount }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 60,
            columnNumber: 162
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 60,
          columnNumber: 127
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 60,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("article", { className: "portal-card account-stat", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "account-stat-icon purple", children: /* @__PURE__ */ jsxDEV(Activity, { size: 20 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 61,
          columnNumber: 96
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 61,
          columnNumber: 53
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("small", { children: "Inactive Accounts" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 61,
            columnNumber: 130
          }, this),
          /* @__PURE__ */ jsxDEV("strong", { children: isLoading ? "—" : inactiveCount }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 61,
            columnNumber: 162
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 61,
          columnNumber: 125
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 61,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
      lineNumber: 57,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("article", { className: "portal-card account-list-card", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "account-list-toolbar", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Accounts List" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 65,
            columnNumber: 50
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Account details and available balances" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 65,
            columnNumber: 72
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 65,
          columnNumber: 45
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "account-toolbar-actions", children: [
          /* @__PURE__ */ jsxDEV("input", { "aria-label": "Search accounts", value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Search account number or type…" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 65,
            columnNumber: 164
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "ghost", size: "icon", "aria-label": "Refresh accounts", onClick: () => void refetch(), loading: isFetching, children: /* @__PURE__ */ jsxDEV(RefreshCw, { size: 16 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 65,
            columnNumber: 424
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 65,
            columnNumber: 306
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 65,
          columnNumber: 123
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 65,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "account-filter-row", role: "group", "aria-label": "Filter accounts", children: ["ALL", "SAVINGS", "CURRENT", "FOREIGN_CURRENCY"].map((value) => /* @__PURE__ */ jsxDEV("button", { className: `account-filter${filter === value ? " active" : ""}`, onClick: () => setFilter(value), children: value === "ALL" ? `All (${accounts.length})` : typeLabel(value) }, value, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 67,
        columnNumber: 86
      }, this)) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 66,
        columnNumber: 7
      }, this),
      isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "account-state", role: "status", children: "Loading your accounts…" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 69,
        columnNumber: 20
      }, this) : filtered.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "account-state", children: [
        /* @__PURE__ */ jsxDEV(Wallet, { size: 28 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 151
        }, this),
        /* @__PURE__ */ jsxDEV("strong", { children: accounts.length ? "No matching accounts" : "No accounts yet" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 171
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: accounts.length ? "Try another filter or search term." : "Open your first account to get started." }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 250
        }, this),
        !accounts.length && /* @__PURE__ */ jsxDEV(Button, { size: "sm", onClick: () => setShowCreate(true), leftIcon: /* @__PURE__ */ jsxDEV(Plus, { size: 15 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 448
        }, this), children: "Open Account" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 384
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 69,
        columnNumber: 120
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "account-table-wrap", children: /* @__PURE__ */ jsxDEV("table", { className: "account-table", children: [
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("th", { children: "#" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 579
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Account Number" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 589
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Account Type" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 612
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Currency" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 633
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Available Balance" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 650
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Status" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 676
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Opened On" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 691
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Actions" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 709
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 575
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 568
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: filtered.map((account, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
          /* @__PURE__ */ jsxDEV("td", { children: index + 1 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 800
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "account-number", children: account.accountNumber }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
              lineNumber: 69,
              columnNumber: 824
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "table-icon-button", onClick: () => void copyAccount(account.accountNumber), "aria-label": `Copy account ${account.accountNumber}`, children: /* @__PURE__ */ jsxDEV(Copy, { size: 14 }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
              lineNumber: 69,
              columnNumber: 1034
            }, this) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
              lineNumber: 69,
              columnNumber: 887
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 820
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("span", { className: `account-type-pill type-${account.accountType.toLowerCase()}`, children: typeLabel(account.accountType) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1070
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1066
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: account.balances.map((b) => b.currencyCode).join(", ") || "—" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1194
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "account-balance-cell", children: account.balances.map((b) => /* @__PURE__ */ jsxDEV("span", { children: money(b.availableBalance, b.currencyCode, b.currency?.symbol) }, b.id, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1332
          }, this)) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1266
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(Badge, { variant: account.status === "ACTIVE" ? "success" : account.status === "FROZEN" ? "warning" : "danger", children: account.status }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1430
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1426
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: dateLabel(account.createdAt) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1569
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(Link, { className: "table-icon-button", to: `/customer/accounts/${account.id}`, "aria-label": `View account ${account.accountNumber}`, children: /* @__PURE__ */ jsxDEV(Eye, { size: 16 }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1741
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1612
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 69,
            columnNumber: 1608
          }, this)
        ] }, account.id, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 779
        }, this)) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 69,
          columnNumber: 738
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 69,
        columnNumber: 535
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 69,
        columnNumber: 499
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
      lineNumber: 64,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "account-disclaimer", children: "Balances are retrieved from your authenticated account records. Currency balances are displayed separately and are not combined across currencies." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
      lineNumber: 71,
      columnNumber: 5
    }, this),
    showCreate && /* @__PURE__ */ jsxDEV("div", { className: "account-modal-backdrop", role: "presentation", onMouseDown: (e) => {
      if (e.target === e.currentTarget) setShowCreate(false);
    }, children: /* @__PURE__ */ jsxDEV("section", { className: "account-modal", role: "dialog", "aria-modal": "true", "aria-labelledby": "create-account-title", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "account-modal-heading", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { id: "create-account-title", children: "Open a new account" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 73,
            columnNumber: 309
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Choose an account type and a supported 3-letter currency code." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 73,
            columnNumber: 362
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 73,
          columnNumber: 304
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "table-icon-button", onClick: () => setShowCreate(false), "aria-label": "Close dialog", children: "×" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 73,
          columnNumber: 437
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 73,
        columnNumber: 265
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreate, children: [
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Account type",
          /* @__PURE__ */ jsxDEV("select", { value: accountType, onChange: (e) => setAccountType(e.target.value), children: [
            /* @__PURE__ */ jsxDEV("option", { value: "SAVINGS", children: "Savings" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
              lineNumber: 73,
              columnNumber: 719
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "CURRENT", children: "Current" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
              lineNumber: 73,
              columnNumber: 759
            }, this),
            /* @__PURE__ */ jsxDEV("option", { value: "FOREIGN_CURRENCY", children: "Foreign currency" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
              lineNumber: 73,
              columnNumber: 799
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 73,
            columnNumber: 603
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 73,
          columnNumber: 584
        }, this),
        /* @__PURE__ */ jsxDEV("label", { children: [
          "Currency code",
          /* @__PURE__ */ jsxDEV("input", { required: true, minLength: 3, maxLength: 3, pattern: "[A-Za-z]{3}", value: currency, onChange: (e) => setCurrency(e.target.value.toUpperCase()), placeholder: "BDT" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 73,
            columnNumber: 894
          }, this),
          /* @__PURE__ */ jsxDEV("small", { children: "Currency must exist and be active in the backend." }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 73,
            columnNumber: 1057
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 73,
          columnNumber: 874
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "account-modal-actions", children: [
          /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "outline", onClick: () => setShowCreate(false), children: "Cancel" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 73,
            columnNumber: 1168
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { type: "submit", loading: createAccount.isPending, children: "Create Account" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
            lineNumber: 73,
            columnNumber: 1260
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
          lineNumber: 73,
          columnNumber: 1129
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
        lineNumber: 73,
        columnNumber: 554
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
      lineNumber: 73,
      columnNumber: 159
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
      lineNumber: 73,
      columnNumber: 20
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx",
    lineNumber: 52,
    columnNumber: 10
  }, this);
}
_s(AccountListPage, "HG54IPbNBGQmniAwOTufLko5/Q4=", false, function() {
  return [useAccounts, useCreateAccount];
});
_c = AccountListPage;
var _c;
$RefreshReg$(_c, "AccountListPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/customer/accounts/pages/AccountListPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0Q4Qzs7QUFwRDlDLFNBQVNBLFNBQVNDLGdCQUFnQjtBQUNsQyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFVBQVVDLGNBQWNDLE1BQU1DLEtBQUtDLFNBQVNDLE1BQU1DLFdBQVdDLGNBQWM7QUFDcEYsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGFBQWFDLHdCQUF3QjtBQUc5QyxNQUFNQyxRQUFRQSxDQUFDQyxPQUF3QkMsVUFBa0JDLFdBQW9CO0FBQzNFLFFBQU1DLFNBQVNDLE9BQU9KLEtBQUs7QUFDM0IsTUFBSSxDQUFDSSxPQUFPQyxTQUFTRixNQUFNLEVBQUcsUUFBTyxHQUFHRCxVQUFVRCxRQUFRO0FBQzFELFNBQU8sR0FBR0MsVUFBVUQsUUFBUSxJQUFJRSxPQUFPRyxlQUFlQyxRQUFXLEVBQUVDLHVCQUF1QixHQUFHQyx1QkFBdUIsRUFBRSxDQUFDLENBQUM7QUFDMUg7QUFDQSxNQUFNQyxZQUFZQSxDQUFDQyxVQUF1QixFQUFFQyxTQUFTLFdBQVdDLFNBQVMsV0FBV0Msa0JBQWtCLG1CQUFtQixHQUFFSCxJQUFrRCxLQUFLQTtBQUNsTCxNQUFNSSxZQUFZQSxDQUFDZixVQUFrQixJQUFJZ0IsS0FBS2hCLEtBQUssRUFBRWlCLG1CQUFtQlYsUUFBVyxFQUFFVyxNQUFNLFdBQVdDLE9BQU8sU0FBU0MsS0FBSyxVQUFVLENBQUM7QUFFL0gsZ0JBQVNDLGtCQUFrQjtBQUFBQyxLQUFBO0FBQ2hDLFFBQU0sRUFBRUMsTUFBTUMsV0FBVyxJQUFJQyxXQUFXQyxTQUFTQyxPQUFPQyxTQUFTQyxXQUFXLElBQUloQyxZQUFZO0FBQzVGLFFBQU1pQyxnQkFBZ0JoQyxpQkFBaUI7QUFDdkMsUUFBTSxDQUFDaUMsUUFBUUMsU0FBUyxJQUFJakQsU0FBOEIsS0FBSztBQUMvRCxRQUFNLENBQUNrRCxRQUFRQyxTQUFTLElBQUluRCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDb0QsWUFBWUMsYUFBYSxJQUFJckQsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ3NELGFBQWFDLGNBQWMsSUFBSXZELFNBQThDLFNBQVM7QUFDN0YsUUFBTSxDQUFDa0IsVUFBVXNDLFdBQVcsSUFBSXhELFNBQVMsS0FBSztBQUU5QyxRQUFNeUQsV0FBVzFELFFBQVEsTUFBTTBDLFNBQVNPO0FBQUFBLElBQU8sQ0FBQ1UsYUFDN0NWLFdBQVcsU0FBU1UsUUFBUUosZ0JBQWdCTixXQUM3QyxHQUFHVSxRQUFRQyxhQUFhLElBQUlELFFBQVFKLFdBQVcsSUFBSUksUUFBUUUsTUFBTSxHQUFHQyxZQUFZLEVBQUVDLFNBQVNaLE9BQU9XLFlBQVksQ0FBQztBQUFBLEVBQ2pILEdBQUcsQ0FBQ3BCLFVBQVVPLFFBQVFFLE1BQU0sQ0FBQztBQUM3QixRQUFNYSxjQUFjdEIsU0FBU08sT0FBTyxDQUFDZ0IsTUFBTUEsRUFBRUosV0FBVyxRQUFRLEVBQUVLO0FBQ2xFLFFBQU1DLGdCQUFnQnpCLFNBQVN3QixTQUFTRjtBQUN4QyxRQUFNSSxvQkFBb0IxQixTQUFTMkIsUUFBUSxDQUFDSixNQUFNQSxFQUFFSyxRQUFRLEVBQUVDLE9BQStCLENBQUNDLEtBQUtDLE1BQU07QUFDdkdELFFBQUlDLEVBQUVDLFlBQVksS0FBS0YsSUFBSUMsRUFBRUMsWUFBWSxLQUFLLEtBQUtwRCxPQUFPbUQsRUFBRUUsb0JBQW9CLENBQUM7QUFDakYsV0FBT0g7QUFBQUEsRUFDVCxHQUFHLENBQUMsQ0FBQztBQUVMLGlCQUFlSSxZQUFZMUQsT0FBZTtBQUN4QyxRQUFJO0FBQUUsWUFBTTJELFVBQVVDLFVBQVVDLFVBQVU3RCxLQUFLO0FBQUdQLFlBQU1xRSxRQUFRLHVCQUF1QjtBQUFBLElBQUcsUUFDcEY7QUFBRXJFLFlBQU1rQyxNQUFNLCtCQUErQjtBQUFBLElBQUc7QUFBQSxFQUN4RDtBQUNBLGlCQUFlb0MsYUFBYUMsT0FBeUM7QUFDbkVBLFVBQU1DLGVBQWU7QUFDckIsUUFBSTtBQUNGLFlBQU1uQyxjQUFjb0MsWUFBWSxFQUFFN0IsYUFBYXBDLFVBQVVBLFNBQVNrRSxLQUFLLEVBQUVDLFlBQVksRUFBRSxDQUFDO0FBQ3hGM0UsWUFBTXFFLFFBQVEsOEJBQThCO0FBQzVDMUIsb0JBQWMsS0FBSztBQUFBLElBQ3JCLFNBQVNpQyxLQUFLO0FBQUU1RSxZQUFNa0MsTUFBTS9CLGtCQUFrQnlFLEdBQUcsRUFBRUMsT0FBTztBQUFBLElBQUc7QUFBQSxFQUMvRDtBQUVBLFNBQU8sdUJBQUMsYUFBUSxXQUFVLGdDQUN4QjtBQUFBLDJCQUFDLFNBQUksV0FBVSx1QkFBc0I7QUFBQSw2QkFBQyxTQUFJO0FBQUEsK0JBQUMsT0FBRSxXQUFVLFdBQVUsaUNBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0M7QUFBQSxRQUFJLHVCQUFDLFFBQUcsMkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlO0FBQUEsUUFBSyx1QkFBQyxPQUFFLFdBQVUsU0FBUSwrREFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRTtBQUFBLFdBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkk7QUFBQSxNQUFNLHVCQUFDLFVBQU8sU0FBUyxNQUFNbEMsY0FBYyxJQUFJLEdBQUcsVUFBVSx1QkFBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsR0FBSSxnQ0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RjtBQUFBLFNBQWpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMFI7QUFBQSxJQUV6UlYsV0FBVyx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCLE1BQUssU0FBUTtBQUFBLDZCQUFDLFNBQUk7QUFBQSwrQkFBQyxZQUFPLDRDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUFTLHVCQUFDLE9BQUc5Qiw0QkFBa0IrQixLQUFLLEVBQUUyQyxXQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsV0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRjtBQUFBLE1BQU0sdUJBQUMsVUFBTyxTQUFRLFdBQVUsTUFBSyxNQUFLLFNBQVMsTUFBTSxLQUFLMUMsUUFBUSxHQUFHLHlCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRFO0FBQUEsU0FBek47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrTztBQUFBLElBRTlPLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLDZCQUFDLGFBQVEsV0FBVSw0QkFBMkI7QUFBQSwrQkFBQyxVQUFLLFdBQVUsMEJBQXlCLGlDQUFDLFdBQVEsTUFBTSxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0IsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFFBQU8sdUJBQUMsU0FBSTtBQUFBLGlDQUFDLFdBQU0sOEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUI7QUFBQSxVQUFRLHVCQUFDLFlBQVFILHNCQUFZLE1BQU1ELFNBQVN3QixVQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLGFBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Y7QUFBQSxXQUF4TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThNO0FBQUEsTUFDOU0sdUJBQUMsYUFBUSxXQUFVLDRCQUEyQjtBQUFBLCtCQUFDLFVBQUssV0FBVSwyQkFBMEIsaUNBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZEO0FBQUEsUUFBTyx1QkFBQyxTQUFJO0FBQUEsaUNBQUMsV0FBTSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QjtBQUFBLFVBQVN2QixZQUFZLHVCQUFDLFlBQU8saUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUyxJQUFZOEMsT0FBT0MsS0FBS3RCLGlCQUFpQixFQUFFRixTQUFTdUIsT0FBT0UsUUFBUXZCLGlCQUFpQixFQUFFd0IsSUFBSSxDQUFDLENBQUNDLE1BQUszRSxLQUFLLE1BQU0sdUJBQUMsWUFBTyxXQUFVLHdCQUFtQ0QsZ0JBQU1DLE9BQU8yRSxJQUFJLEtBQXhCQSxNQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RSxDQUFTLElBQUksdUJBQUMsWUFBTyxvQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFZO0FBQUEsYUFBelE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtUjtBQUFBLFdBQXJZO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMlk7QUFBQSxNQUMzWSx1QkFBQyxhQUFRLFdBQVUsNEJBQTJCO0FBQUEsK0JBQUMsVUFBSyxXQUFVLDBCQUF5QixpQ0FBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUIsS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBQU8sdUJBQUMsU0FBSTtBQUFBLGlDQUFDLFdBQU0sK0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUFRLHVCQUFDLFlBQVFsRCxzQkFBWSxNQUFNcUIsZUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxhQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FBMU07QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnTjtBQUFBLE1BQ2hOLHVCQUFDLGFBQVEsV0FBVSw0QkFBMkI7QUFBQSwrQkFBQyxVQUFLLFdBQVUsNEJBQTJCLGlDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxRQUFPLHVCQUFDLFNBQUk7QUFBQSxpQ0FBQyxXQUFNLGlDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsVUFBUSx1QkFBQyxZQUFRckIsc0JBQVksTUFBTXdCLGlCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QztBQUFBLGFBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUY7QUFBQSxXQUE1TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtOO0FBQUEsU0FKcE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsaUNBQ2pCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdCQUF1QjtBQUFBLCtCQUFDLFNBQUk7QUFBQSxpQ0FBQyxRQUFHLDZCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQUEsVUFBSyx1QkFBQyxPQUFFLHNEQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlDO0FBQUEsYUFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQU0sdUJBQUMsU0FBSSxXQUFVLDJCQUEwQjtBQUFBLGlDQUFDLFdBQU0sY0FBVyxtQkFBa0IsT0FBT2hCLFFBQVEsVUFBVSxDQUFDMkMsTUFBTTFDLFVBQVUwQyxFQUFFQyxPQUFPN0UsS0FBSyxHQUFHLGFBQVksb0NBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJJO0FBQUEsVUFBRSx1QkFBQyxVQUFPLFNBQVEsU0FBUSxNQUFLLFFBQU8sY0FBVyxvQkFBbUIsU0FBUyxNQUFNLEtBQUs0QixRQUFRLEdBQUcsU0FBU0MsWUFBWSxpQ0FBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0IsS0FBMUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEk7QUFBQSxhQUFsVTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJVO0FBQUEsV0FBL2I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxYztBQUFBLE1BQ3JjLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsTUFBSyxTQUFRLGNBQVcsbUJBQ3hELFdBQUMsT0FBTyxXQUFXLFdBQVcsa0JBQWtCLEVBQVk2QyxJQUFJLENBQUMxRSxVQUFVLHVCQUFDLFlBQW1CLFdBQVcsaUJBQWlCK0IsV0FBVy9CLFFBQVEsWUFBWSxFQUFFLElBQUksU0FBUyxNQUFNZ0MsVUFBVWhDLEtBQUssR0FBSUEsb0JBQVUsUUFBUSxRQUFRd0IsU0FBU3dCLE1BQU0sTUFBTXRDLFVBQVVWLEtBQUssS0FBeEtBLE9BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1TCxDQUFTLEtBRC9RO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0N5QixZQUFZLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsTUFBSyxVQUFTLHNDQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FLElBQVNlLFNBQVNRLFdBQVcsSUFBSSx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUEsK0JBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQUUsdUJBQUMsWUFBUXhCLG1CQUFTd0IsU0FBUyx5QkFBeUIscUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUFTLHVCQUFDLFVBQU14QixtQkFBU3dCLFNBQVMsdUNBQXVDLDZDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBHO0FBQUEsUUFBUSxDQUFDeEIsU0FBU3dCLFVBQVUsdUJBQUMsVUFBTyxNQUFLLE1BQUssU0FBUyxNQUFNWixjQUFjLElBQUksR0FBRyxVQUFVLHVCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZSxHQUFJLDRCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStGO0FBQUEsV0FBdFc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnWCxJQUFTLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsaUNBQUMsV0FBTSxXQUFVLGlCQUFnQjtBQUFBLCtCQUFDLFdBQU0saUNBQUMsUUFBRztBQUFBLGlDQUFDLFFBQUcsaUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBSztBQUFBLFVBQUssdUJBQUMsUUFBRyw4QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQUssdUJBQUMsUUFBRyw0QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQjtBQUFBLFVBQUssdUJBQUMsUUFBRyx3QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFZO0FBQUEsVUFBSyx1QkFBQyxRQUFHLGlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsVUFBSyx1QkFBQyxRQUFHLHNCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVU7QUFBQSxVQUFLLHVCQUFDLFFBQUcseUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQUssdUJBQUMsUUFBRyx1QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsYUFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzSixLQUE3SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtLO0FBQUEsUUFBUSx1QkFBQyxXQUFPSSxtQkFBU2tDLElBQUksQ0FBQ2pDLFNBQVFxQyxVQUFVLHVCQUFDLFFBQW9CO0FBQUEsaUNBQUMsUUFBSUEsa0JBQVEsS0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsVUFBSyx1QkFBQyxRQUFHO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGtCQUFrQnJDLGtCQUFRQyxpQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxZQUFPLHVCQUFDLFlBQU8sV0FBVSxxQkFBb0IsU0FBUyxNQUFNLEtBQUtnQixZQUFZakIsUUFBUUMsYUFBYSxHQUFHLGNBQVksZ0JBQWdCRCxRQUFRQyxhQUFhLElBQUksaUNBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZSxLQUFsSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvSztBQUFBLGVBQXZPO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdQO0FBQUEsVUFBSyx1QkFBQyxRQUFHLGlDQUFDLFVBQUssV0FBVywwQkFBMEJELFFBQVFKLFlBQVlPLFlBQVksQ0FBQyxJQUFLbEMsb0JBQVUrQixRQUFRSixXQUFXLEtBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdILEtBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJIO0FBQUEsVUFBSyx1QkFBQyxRQUFJSSxrQkFBUVcsU0FBU3NCLElBQUksQ0FBQ25CLE1BQU1BLEVBQUVDLFlBQVksRUFBRXVCLEtBQUssSUFBSSxLQUFLLE9BQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFBSyx1QkFBQyxRQUFHLFdBQVUsd0JBQXdCdEMsa0JBQVFXLFNBQVNzQixJQUFJLENBQUNuQixNQUFNLHVCQUFDLFVBQWlCeEQsZ0JBQU13RCxFQUFFRSxrQkFBaUJGLEVBQUVDLGNBQWFELEVBQUV0RCxVQUFVQyxNQUFNLEtBQWpFcUQsRUFBRXlCLElBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEUsQ0FBTyxLQUF2SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SjtBQUFBLFVBQUssdUJBQUMsUUFBRyxpQ0FBQyxTQUFNLFNBQVN2QyxRQUFRRSxXQUFXLFdBQVcsWUFBWUYsUUFBUUUsV0FBVyxXQUFXLFlBQVksVUFBV0Ysa0JBQVFFLFVBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThILEtBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBJO0FBQUEsVUFBSyx1QkFBQyxRQUFJNUIsb0JBQVUwQixRQUFRd0MsU0FBUyxLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQUssdUJBQUMsUUFBRyxpQ0FBQyxRQUFLLFdBQVUscUJBQW9CLElBQUksc0JBQXNCeEMsUUFBUXVDLEVBQUUsSUFBSSxjQUFZLGdCQUFnQnZDLFFBQVFDLGFBQWEsSUFBSSxpQ0FBQyxPQUFJLE1BQU0sTUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjLEtBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlKLEtBQXJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRKO0FBQUEsYUFBNzhCRCxRQUFRdUMsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyOUIsQ0FBSyxLQUF4Z0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwZ0M7QUFBQSxXQUFydEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2dEMsS0FBandDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeXdDO0FBQUEsU0FMcnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBQ0EsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQixrS0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvTDtBQUFBLElBRW5MN0MsY0FBYyx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCLE1BQUssZ0JBQWUsYUFBYSxDQUFDeUMsTUFBTTtBQUFFLFVBQUlBLEVBQUVDLFdBQVdELEVBQUVNLGNBQWU5QyxlQUFjLEtBQUs7QUFBQSxJQUFHLEdBQUcsaUNBQUMsYUFBUSxXQUFVLGlCQUFnQixNQUFLLFVBQVMsY0FBVyxRQUFPLG1CQUFnQix3QkFBdUI7QUFBQSw2QkFBQyxTQUFJLFdBQVUseUJBQXdCO0FBQUEsK0JBQUMsU0FBSTtBQUFBLGlDQUFDLFFBQUcsSUFBRyx3QkFBdUIsa0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdEO0FBQUEsVUFBSyx1QkFBQyxPQUFFLDhFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsYUFBM0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErSDtBQUFBLFFBQU0sdUJBQUMsWUFBTyxXQUFVLHFCQUFvQixTQUFTLE1BQU1BLGNBQWMsS0FBSyxHQUFHLGNBQVcsZ0JBQWUsaUJBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0c7QUFBQSxXQUFsUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJSO0FBQUEsTUFBTSx1QkFBQyxVQUFLLFVBQVUyQixjQUFjO0FBQUEsK0JBQUMsV0FBTTtBQUFBO0FBQUEsVUFBWSx1QkFBQyxZQUFPLE9BQU8xQixhQUFhLFVBQVUsQ0FBQ3VDLE1BQU10QyxlQUFlc0MsRUFBRUMsT0FBTzdFLEtBQTRDLEdBQUc7QUFBQSxtQ0FBQyxZQUFPLE9BQU0sV0FBVSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQSxZQUFTLHVCQUFDLFlBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQVMsdUJBQUMsWUFBTyxPQUFNLG9CQUFtQixnQ0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxlQUFyUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4UDtBQUFBLGFBQWpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMFI7QUFBQSxRQUFRLHVCQUFDLFdBQU07QUFBQTtBQUFBLFVBQWEsdUJBQUMsV0FBTSxVQUFRLE1BQUMsV0FBVyxHQUFHLFdBQVcsR0FBRyxTQUFRLGVBQWMsT0FBT0MsVUFBVSxVQUFVLENBQUMyRSxNQUFNckMsWUFBWXFDLEVBQUVDLE9BQU83RSxNQUFNb0UsWUFBWSxDQUFDLEdBQUcsYUFBWSxTQUEzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnSztBQUFBLFVBQUUsdUJBQUMsV0FBTSxpRUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLGFBQTlPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc1A7QUFBQSxRQUFRLHVCQUFDLFNBQUksV0FBVSx5QkFBd0I7QUFBQSxpQ0FBQyxVQUFPLE1BQUssVUFBUyxTQUFRLFdBQVUsU0FBUyxNQUFNaEMsY0FBYyxLQUFLLEdBQUcsc0JBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFBUyx1QkFBQyxVQUFPLE1BQUssVUFBUyxTQUFTTixjQUFjcUQsV0FBVyw4QkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxhQUF6TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtOO0FBQUEsV0FBaHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc3hCO0FBQUEsU0FBanFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd3FDLEtBQXJ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQSt6QztBQUFBLE9BckJ6MEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCUDtBQUNGO0FBQUM3RCxHQXhEZUQsaUJBQWU7QUFBQSxVQUNtRHhCLGFBQzFEQyxnQkFBZ0I7QUFBQTtBQUFBLEtBRnhCdUI7QUFBZSxJQUFBK0Q7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlTWVtbyIsInVzZVN0YXRlIiwiTGluayIsIkFjdGl2aXR5IiwiQXJyb3dVcFJpZ2h0IiwiQ29weSIsIkV5ZSIsIkxheWVyczMiLCJQbHVzIiwiUmVmcmVzaEN3IiwiV2FsbGV0IiwidG9hc3QiLCJCdXR0b24iLCJCYWRnZSIsIm5vcm1hbGl6ZUFwaUVycm9yIiwidXNlQWNjb3VudHMiLCJ1c2VDcmVhdGVBY2NvdW50IiwibW9uZXkiLCJ2YWx1ZSIsImN1cnJlbmN5Iiwic3ltYm9sIiwiYW1vdW50IiwiTnVtYmVyIiwiaXNGaW5pdGUiLCJ0b0xvY2FsZVN0cmluZyIsInVuZGVmaW5lZCIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsInR5cGVMYWJlbCIsInR5cGUiLCJTQVZJTkdTIiwiQ1VSUkVOVCIsIkZPUkVJR05fQ1VSUkVOQ1kiLCJkYXRlTGFiZWwiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwieWVhciIsIm1vbnRoIiwiZGF5IiwiQWNjb3VudExpc3RQYWdlIiwiX3MiLCJkYXRhIiwiYWNjb3VudHMiLCJpc0xvYWRpbmciLCJpc0Vycm9yIiwiZXJyb3IiLCJyZWZldGNoIiwiaXNGZXRjaGluZyIsImNyZWF0ZUFjY291bnQiLCJmaWx0ZXIiLCJzZXRGaWx0ZXIiLCJzZWFyY2giLCJzZXRTZWFyY2giLCJzaG93Q3JlYXRlIiwic2V0U2hvd0NyZWF0ZSIsImFjY291bnRUeXBlIiwic2V0QWNjb3VudFR5cGUiLCJzZXRDdXJyZW5jeSIsImZpbHRlcmVkIiwiYWNjb3VudCIsImFjY291bnROdW1iZXIiLCJzdGF0dXMiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiYWN0aXZlQ291bnQiLCJhIiwibGVuZ3RoIiwiaW5hY3RpdmVDb3VudCIsImJhbGFuY2VCeUN1cnJlbmN5IiwiZmxhdE1hcCIsImJhbGFuY2VzIiwicmVkdWNlIiwiYWNjIiwiYiIsImN1cnJlbmN5Q29kZSIsImF2YWlsYWJsZUJhbGFuY2UiLCJjb3B5QWNjb3VudCIsIm5hdmlnYXRvciIsImNsaXBib2FyZCIsIndyaXRlVGV4dCIsInN1Y2Nlc3MiLCJoYW5kbGVDcmVhdGUiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwibXV0YXRlQXN5bmMiLCJ0cmltIiwidG9VcHBlckNhc2UiLCJlcnIiLCJtZXNzYWdlIiwiT2JqZWN0Iiwia2V5cyIsImVudHJpZXMiLCJtYXAiLCJjb2RlIiwiZSIsInRhcmdldCIsImluZGV4Iiwiam9pbiIsImlkIiwiY3JlYXRlZEF0IiwiY3VycmVudFRhcmdldCIsImlzUGVuZGluZyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFjY291bnRMaXN0UGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgQWN0aXZpdHksIEFycm93VXBSaWdodCwgQ29weSwgRXllLCBMYXllcnMzLCBQbHVzLCBSZWZyZXNoQ3csIFdhbGxldCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcInNvbm5lclwiO1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbXBvbmVudHMvdWkvQnV0dG9uXCI7XG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb21wb25lbnRzL3VpL0JhZGdlXCI7XG5pbXBvcnQgeyBub3JtYWxpemVBcGlFcnJvciB9IGZyb20gXCIuLi8uLi8uLi8uLi9saWIvYXBpL2FwaUVycm9yXCI7XG5pbXBvcnQgeyB1c2VBY2NvdW50cywgdXNlQ3JlYXRlQWNjb3VudCB9IGZyb20gXCIuLi9ob29rcy91c2VBY2NvdW50c1wiO1xuaW1wb3J0IHR5cGUgeyBBY2NvdW50VHlwZSwgQ3JlYXRlQWNjb3VudFBheWxvYWQgfSBmcm9tIFwiLi4vYWNjb3VudC50eXBlc1wiO1xuXG5jb25zdCBtb25leSA9ICh2YWx1ZTogc3RyaW5nIHwgbnVtYmVyLCBjdXJyZW5jeTogc3RyaW5nLCBzeW1ib2w/OiBzdHJpbmcpID0+IHtcbiAgY29uc3QgYW1vdW50ID0gTnVtYmVyKHZhbHVlKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoYW1vdW50KSkgcmV0dXJuIGAke3N5bWJvbCA/PyBjdXJyZW5jeX0g4oCUYDtcbiAgcmV0dXJuIGAke3N5bWJvbCA/PyBjdXJyZW5jeX0gJHthbW91bnQudG9Mb2NhbGVTdHJpbmcodW5kZWZpbmVkLCB7IG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMiwgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyIH0pfWA7XG59O1xuY29uc3QgdHlwZUxhYmVsID0gKHR5cGU6IEFjY291bnRUeXBlKSA9PiAoeyBTQVZJTkdTOiBcIlNhdmluZ3NcIiwgQ1VSUkVOVDogXCJDdXJyZW50XCIsIEZPUkVJR05fQ1VSUkVOQ1k6IFwiRm9yZWlnbiBjdXJyZW5jeVwiIH1bdHlwZSBhcyBcIlNBVklOR1NcIiB8IFwiQ1VSUkVOVFwiIHwgXCJGT1JFSUdOX0NVUlJFTkNZXCJdID8/IHR5cGUpO1xuY29uc3QgZGF0ZUxhYmVsID0gKHZhbHVlOiBzdHJpbmcpID0+IG5ldyBEYXRlKHZhbHVlKS50b0xvY2FsZURhdGVTdHJpbmcodW5kZWZpbmVkLCB7IHllYXI6IFwibnVtZXJpY1wiLCBtb250aDogXCJzaG9ydFwiLCBkYXk6IFwiMi1kaWdpdFwiIH0pO1xuXG5leHBvcnQgZnVuY3Rpb24gQWNjb3VudExpc3RQYWdlKCkge1xuICBjb25zdCB7IGRhdGE6IGFjY291bnRzID0gW10sIGlzTG9hZGluZywgaXNFcnJvciwgZXJyb3IsIHJlZmV0Y2gsIGlzRmV0Y2hpbmcgfSA9IHVzZUFjY291bnRzKCk7XG4gIGNvbnN0IGNyZWF0ZUFjY291bnQgPSB1c2VDcmVhdGVBY2NvdW50KCk7XG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZTxcIkFMTFwiIHwgQWNjb3VudFR5cGU+KFwiQUxMXCIpO1xuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtzaG93Q3JlYXRlLCBzZXRTaG93Q3JlYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2FjY291bnRUeXBlLCBzZXRBY2NvdW50VHlwZV0gPSB1c2VTdGF0ZTxDcmVhdGVBY2NvdW50UGF5bG9hZFtcImFjY291bnRUeXBlXCJdPihcIlNBVklOR1NcIik7XG4gIGNvbnN0IFtjdXJyZW5jeSwgc2V0Q3VycmVuY3ldID0gdXNlU3RhdGUoXCJCRFRcIik7XG5cbiAgY29uc3QgZmlsdGVyZWQgPSB1c2VNZW1vKCgpID0+IGFjY291bnRzLmZpbHRlcigoYWNjb3VudCkgPT5cbiAgICAoZmlsdGVyID09PSBcIkFMTFwiIHx8IGFjY291bnQuYWNjb3VudFR5cGUgPT09IGZpbHRlcikgJiZcbiAgICBgJHthY2NvdW50LmFjY291bnROdW1iZXJ9ICR7YWNjb3VudC5hY2NvdW50VHlwZX0gJHthY2NvdW50LnN0YXR1c31gLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpXG4gICksIFthY2NvdW50cywgZmlsdGVyLCBzZWFyY2hdKTtcbiAgY29uc3QgYWN0aXZlQ291bnQgPSBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuc3RhdHVzID09PSBcIkFDVElWRVwiKS5sZW5ndGg7XG4gIGNvbnN0IGluYWN0aXZlQ291bnQgPSBhY2NvdW50cy5sZW5ndGggLSBhY3RpdmVDb3VudDtcbiAgY29uc3QgYmFsYW5jZUJ5Q3VycmVuY3kgPSBhY2NvdW50cy5mbGF0TWFwKChhKSA9PiBhLmJhbGFuY2VzKS5yZWR1Y2U8UmVjb3JkPHN0cmluZywgbnVtYmVyPj4oKGFjYywgYikgPT4ge1xuICAgIGFjY1tiLmN1cnJlbmN5Q29kZV0gPSAoYWNjW2IuY3VycmVuY3lDb2RlXSA/PyAwKSArIE51bWJlcihiLmF2YWlsYWJsZUJhbGFuY2UgfHwgMCk7XG4gICAgcmV0dXJuIGFjYztcbiAgfSwge30pO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGNvcHlBY2NvdW50KHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0cnkgeyBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh2YWx1ZSk7IHRvYXN0LnN1Y2Nlc3MoXCJBY2NvdW50IG51bWJlciBjb3BpZWRcIik7IH1cbiAgICBjYXRjaCB7IHRvYXN0LmVycm9yKFwiQ291bGQgbm90IGNvcHkgYWNjb3VudCBudW1iZXJcIik7IH1cbiAgfVxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVDcmVhdGUoZXZlbnQ6IFJlYWN0LkZvcm1FdmVudDxIVE1MRm9ybUVsZW1lbnQ+KSB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY3JlYXRlQWNjb3VudC5tdXRhdGVBc3luYyh7IGFjY291bnRUeXBlLCBjdXJyZW5jeTogY3VycmVuY3kudHJpbSgpLnRvVXBwZXJDYXNlKCkgfSk7XG4gICAgICB0b2FzdC5zdWNjZXNzKFwiQWNjb3VudCBjcmVhdGVkIHN1Y2Nlc3NmdWxseVwiKTtcbiAgICAgIHNldFNob3dDcmVhdGUoZmFsc2UpO1xuICAgIH0gY2F0Y2ggKGVycikgeyB0b2FzdC5lcnJvcihub3JtYWxpemVBcGlFcnJvcihlcnIpLm1lc3NhZ2UpOyB9XG4gIH1cblxuICByZXR1cm4gPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9ydGFsLWNvbnRlbnQgY3VzdG9tZXItcGFnZVwiPlxuICAgIDxkaXYgY2xhc3NOYW1lPVwicG9ydGFsLXBhZ2UtaGVhZGluZ1wiPjxkaXY+PHAgY2xhc3NOYW1lPVwiZXllYnJvd1wiPkNVU1RPTUVSIEFDQ09VTlRTPC9wPjxoMT5NeSBBY2NvdW50czwvaDE+PHAgY2xhc3NOYW1lPVwibXV0ZWRcIj5NYW5hZ2UgYW5kIHZpZXcgYWxsIHlvdXIgYWNjb3VudHMgaW4gb25lIHBsYWNlLjwvcD48L2Rpdj48QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dDcmVhdGUodHJ1ZSl9IGxlZnRJY29uPXs8UGx1cyBzaXplPXsxNn0vPn0+T3BlbiBOZXcgQWNjb3VudDwvQnV0dG9uPjwvZGl2PlxuXG4gICAge2lzRXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LWFsZXJ0XCIgcm9sZT1cImFsZXJ0XCI+PGRpdj48c3Ryb25nPlVuYWJsZSB0byBsb2FkIHlvdXIgYWNjb3VudHM8L3N0cm9uZz48cD57bm9ybWFsaXplQXBpRXJyb3IoZXJyb3IpLm1lc3NhZ2V9PC9wPjwvZGl2PjxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiB2b2lkIHJlZmV0Y2goKX0+VHJ5IGFnYWluPC9CdXR0b24+PC9kaXY+fVxuXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LXN0YXQtZ3JpZFwiPlxuICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwicG9ydGFsLWNhcmQgYWNjb3VudC1zdGF0XCI+PHNwYW4gY2xhc3NOYW1lPVwiYWNjb3VudC1zdGF0LWljb24gYmx1ZVwiPjxMYXllcnMzIHNpemU9ezIwfS8+PC9zcGFuPjxkaXY+PHNtYWxsPlRvdGFsIEFjY291bnRzPC9zbWFsbD48c3Ryb25nPntpc0xvYWRpbmcgPyBcIuKAlFwiIDogYWNjb3VudHMubGVuZ3RofTwvc3Ryb25nPjwvZGl2PjwvYXJ0aWNsZT5cbiAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIGFjY291bnQtc3RhdFwiPjxzcGFuIGNsYXNzTmFtZT1cImFjY291bnQtc3RhdC1pY29uIGdyZWVuXCI+PFdhbGxldCBzaXplPXsyMH0vPjwvc3Bhbj48ZGl2PjxzbWFsbD5BdmFpbGFibGUgYmFsYW5jZXM8L3NtYWxsPntpc0xvYWRpbmcgPyA8c3Ryb25nPuKAlDwvc3Ryb25nPiA6IE9iamVjdC5rZXlzKGJhbGFuY2VCeUN1cnJlbmN5KS5sZW5ndGggPyBPYmplY3QuZW50cmllcyhiYWxhbmNlQnlDdXJyZW5jeSkubWFwKChbY29kZSx2YWx1ZV0pID0+IDxzdHJvbmcgY2xhc3NOYW1lPVwiYWNjb3VudC1zdGF0LWJhbGFuY2VcIiBrZXk9e2NvZGV9Pnttb25leSh2YWx1ZSwgY29kZSl9PC9zdHJvbmc+KSA6IDxzdHJvbmc+MC4wMDwvc3Ryb25nPn08L2Rpdj48L2FydGljbGU+XG4gICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBhY2NvdW50LXN0YXRcIj48c3BhbiBjbGFzc05hbWU9XCJhY2NvdW50LXN0YXQtaWNvbiBibHVlXCI+PEFycm93VXBSaWdodCBzaXplPXsyMH0vPjwvc3Bhbj48ZGl2PjxzbWFsbD5BY3RpdmUgQWNjb3VudHM8L3NtYWxsPjxzdHJvbmc+e2lzTG9hZGluZyA/IFwi4oCUXCIgOiBhY3RpdmVDb3VudH08L3N0cm9uZz48L2Rpdj48L2FydGljbGU+XG4gICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3J0YWwtY2FyZCBhY2NvdW50LXN0YXRcIj48c3BhbiBjbGFzc05hbWU9XCJhY2NvdW50LXN0YXQtaWNvbiBwdXJwbGVcIj48QWN0aXZpdHkgc2l6ZT17MjB9Lz48L3NwYW4+PGRpdj48c21hbGw+SW5hY3RpdmUgQWNjb3VudHM8L3NtYWxsPjxzdHJvbmc+e2lzTG9hZGluZyA/IFwi4oCUXCIgOiBpbmFjdGl2ZUNvdW50fTwvc3Ryb25nPjwvZGl2PjwvYXJ0aWNsZT5cbiAgICA8L2Rpdj5cblxuICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInBvcnRhbC1jYXJkIGFjY291bnQtbGlzdC1jYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtbGlzdC10b29sYmFyXCI+PGRpdj48aDI+QWNjb3VudHMgTGlzdDwvaDI+PHA+QWNjb3VudCBkZXRhaWxzIGFuZCBhdmFpbGFibGUgYmFsYW5jZXM8L3A+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LXRvb2xiYXItYWN0aW9uc1wiPjxpbnB1dCBhcmlhLWxhYmVsPVwiU2VhcmNoIGFjY291bnRzXCIgdmFsdWU9e3NlYXJjaH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2goZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIlNlYXJjaCBhY2NvdW50IG51bWJlciBvciB0eXBl4oCmXCIvPjxCdXR0b24gdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cImljb25cIiBhcmlhLWxhYmVsPVwiUmVmcmVzaCBhY2NvdW50c1wiIG9uQ2xpY2s9eygpID0+IHZvaWQgcmVmZXRjaCgpfSBsb2FkaW5nPXtpc0ZldGNoaW5nfT48UmVmcmVzaEN3IHNpemU9ezE2fS8+PC9CdXR0b24+PC9kaXY+PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtZmlsdGVyLXJvd1wiIHJvbGU9XCJncm91cFwiIGFyaWEtbGFiZWw9XCJGaWx0ZXIgYWNjb3VudHNcIj5cbiAgICAgICAgeyhbXCJBTExcIiwgXCJTQVZJTkdTXCIsIFwiQ1VSUkVOVFwiLCBcIkZPUkVJR05fQ1VSUkVOQ1lcIl0gYXMgY29uc3QpLm1hcCgodmFsdWUpID0+IDxidXR0b24ga2V5PXt2YWx1ZX0gY2xhc3NOYW1lPXtgYWNjb3VudC1maWx0ZXIke2ZpbHRlciA9PT0gdmFsdWUgPyBcIiBhY3RpdmVcIiA6IFwiXCJ9YH0gb25DbGljaz17KCkgPT4gc2V0RmlsdGVyKHZhbHVlKX0+e3ZhbHVlID09PSBcIkFMTFwiID8gYEFsbCAoJHthY2NvdW50cy5sZW5ndGh9KWAgOiB0eXBlTGFiZWwodmFsdWUpfTwvYnV0dG9uPil9XG4gICAgICA8L2Rpdj5cbiAgICAgIHtpc0xvYWRpbmcgPyA8ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtc3RhdGVcIiByb2xlPVwic3RhdHVzXCI+TG9hZGluZyB5b3VyIGFjY291bnRz4oCmPC9kaXY+IDogZmlsdGVyZWQubGVuZ3RoID09PSAwID8gPGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LXN0YXRlXCI+PFdhbGxldCBzaXplPXsyOH0vPjxzdHJvbmc+e2FjY291bnRzLmxlbmd0aCA/IFwiTm8gbWF0Y2hpbmcgYWNjb3VudHNcIiA6IFwiTm8gYWNjb3VudHMgeWV0XCJ9PC9zdHJvbmc+PHNwYW4+e2FjY291bnRzLmxlbmd0aCA/IFwiVHJ5IGFub3RoZXIgZmlsdGVyIG9yIHNlYXJjaCB0ZXJtLlwiIDogXCJPcGVuIHlvdXIgZmlyc3QgYWNjb3VudCB0byBnZXQgc3RhcnRlZC5cIn08L3NwYW4+eyFhY2NvdW50cy5sZW5ndGggJiYgPEJ1dHRvbiBzaXplPVwic21cIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q3JlYXRlKHRydWUpfSBsZWZ0SWNvbj17PFBsdXMgc2l6ZT17MTV9Lz59Pk9wZW4gQWNjb3VudDwvQnV0dG9uPn08L2Rpdj4gOiA8ZGl2IGNsYXNzTmFtZT1cImFjY291bnQtdGFibGUtd3JhcFwiPjx0YWJsZSBjbGFzc05hbWU9XCJhY2NvdW50LXRhYmxlXCI+PHRoZWFkPjx0cj48dGg+IzwvdGg+PHRoPkFjY291bnQgTnVtYmVyPC90aD48dGg+QWNjb3VudCBUeXBlPC90aD48dGg+Q3VycmVuY3k8L3RoPjx0aD5BdmFpbGFibGUgQmFsYW5jZTwvdGg+PHRoPlN0YXR1czwvdGg+PHRoPk9wZW5lZCBPbjwvdGg+PHRoPkFjdGlvbnM8L3RoPjwvdHI+PC90aGVhZD48dGJvZHk+e2ZpbHRlcmVkLm1hcCgoYWNjb3VudCxpbmRleCkgPT4gPHRyIGtleT17YWNjb3VudC5pZH0+PHRkPntpbmRleCArIDF9PC90ZD48dGQ+PHNwYW4gY2xhc3NOYW1lPVwiYWNjb3VudC1udW1iZXJcIj57YWNjb3VudC5hY2NvdW50TnVtYmVyfTwvc3Bhbj48YnV0dG9uIGNsYXNzTmFtZT1cInRhYmxlLWljb24tYnV0dG9uXCIgb25DbGljaz17KCkgPT4gdm9pZCBjb3B5QWNjb3VudChhY2NvdW50LmFjY291bnROdW1iZXIpfSBhcmlhLWxhYmVsPXtgQ29weSBhY2NvdW50ICR7YWNjb3VudC5hY2NvdW50TnVtYmVyfWB9PjxDb3B5IHNpemU9ezE0fS8+PC9idXR0b24+PC90ZD48dGQ+PHNwYW4gY2xhc3NOYW1lPXtgYWNjb3VudC10eXBlLXBpbGwgdHlwZS0ke2FjY291bnQuYWNjb3VudFR5cGUudG9Mb3dlckNhc2UoKX1gfT57dHlwZUxhYmVsKGFjY291bnQuYWNjb3VudFR5cGUpfTwvc3Bhbj48L3RkPjx0ZD57YWNjb3VudC5iYWxhbmNlcy5tYXAoKGIpID0+IGIuY3VycmVuY3lDb2RlKS5qb2luKFwiLCBcIikgfHwgXCLigJRcIn08L3RkPjx0ZCBjbGFzc05hbWU9XCJhY2NvdW50LWJhbGFuY2UtY2VsbFwiPnthY2NvdW50LmJhbGFuY2VzLm1hcCgoYikgPT4gPHNwYW4ga2V5PXtiLmlkfT57bW9uZXkoYi5hdmFpbGFibGVCYWxhbmNlLGIuY3VycmVuY3lDb2RlLGIuY3VycmVuY3k/LnN5bWJvbCl9PC9zcGFuPil9PC90ZD48dGQ+PEJhZGdlIHZhcmlhbnQ9e2FjY291bnQuc3RhdHVzID09PSBcIkFDVElWRVwiID8gXCJzdWNjZXNzXCIgOiBhY2NvdW50LnN0YXR1cyA9PT0gXCJGUk9aRU5cIiA/IFwid2FybmluZ1wiIDogXCJkYW5nZXJcIn0+e2FjY291bnQuc3RhdHVzfTwvQmFkZ2U+PC90ZD48dGQ+e2RhdGVMYWJlbChhY2NvdW50LmNyZWF0ZWRBdCl9PC90ZD48dGQ+PExpbmsgY2xhc3NOYW1lPVwidGFibGUtaWNvbi1idXR0b25cIiB0bz17YC9jdXN0b21lci9hY2NvdW50cy8ke2FjY291bnQuaWR9YH0gYXJpYS1sYWJlbD17YFZpZXcgYWNjb3VudCAke2FjY291bnQuYWNjb3VudE51bWJlcn1gfT48RXllIHNpemU9ezE2fS8+PC9MaW5rPjwvdGQ+PC90cj4pfTwvdGJvZHk+PC90YWJsZT48L2Rpdj59XG4gICAgPC9hcnRpY2xlPlxuICAgIDxwIGNsYXNzTmFtZT1cImFjY291bnQtZGlzY2xhaW1lclwiPkJhbGFuY2VzIGFyZSByZXRyaWV2ZWQgZnJvbSB5b3VyIGF1dGhlbnRpY2F0ZWQgYWNjb3VudCByZWNvcmRzLiBDdXJyZW5jeSBiYWxhbmNlcyBhcmUgZGlzcGxheWVkIHNlcGFyYXRlbHkgYW5kIGFyZSBub3QgY29tYmluZWQgYWNyb3NzIGN1cnJlbmNpZXMuPC9wPlxuXG4gICAge3Nob3dDcmVhdGUgJiYgPGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LW1vZGFsLWJhY2tkcm9wXCIgcm9sZT1cInByZXNlbnRhdGlvblwiIG9uTW91c2VEb3duPXsoZSkgPT4geyBpZiAoZS50YXJnZXQgPT09IGUuY3VycmVudFRhcmdldCkgc2V0U2hvd0NyZWF0ZShmYWxzZSk7IH19PjxzZWN0aW9uIGNsYXNzTmFtZT1cImFjY291bnQtbW9kYWxcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1tb2RhbD1cInRydWVcIiBhcmlhLWxhYmVsbGVkYnk9XCJjcmVhdGUtYWNjb3VudC10aXRsZVwiPjxkaXYgY2xhc3NOYW1lPVwiYWNjb3VudC1tb2RhbC1oZWFkaW5nXCI+PGRpdj48aDIgaWQ9XCJjcmVhdGUtYWNjb3VudC10aXRsZVwiPk9wZW4gYSBuZXcgYWNjb3VudDwvaDI+PHA+Q2hvb3NlIGFuIGFjY291bnQgdHlwZSBhbmQgYSBzdXBwb3J0ZWQgMy1sZXR0ZXIgY3VycmVuY3kgY29kZS48L3A+PC9kaXY+PGJ1dHRvbiBjbGFzc05hbWU9XCJ0YWJsZS1pY29uLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dDcmVhdGUoZmFsc2UpfSBhcmlhLWxhYmVsPVwiQ2xvc2UgZGlhbG9nXCI+w5c8L2J1dHRvbj48L2Rpdj48Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ3JlYXRlfT48bGFiZWw+QWNjb3VudCB0eXBlPHNlbGVjdCB2YWx1ZT17YWNjb3VudFR5cGV9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0QWNjb3VudFR5cGUoZS50YXJnZXQudmFsdWUgYXMgQ3JlYXRlQWNjb3VudFBheWxvYWRbXCJhY2NvdW50VHlwZVwiXSl9PjxvcHRpb24gdmFsdWU9XCJTQVZJTkdTXCI+U2F2aW5nczwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJDVVJSRU5UXCI+Q3VycmVudDwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJGT1JFSUdOX0NVUlJFTkNZXCI+Rm9yZWlnbiBjdXJyZW5jeTwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+PGxhYmVsPkN1cnJlbmN5IGNvZGU8aW5wdXQgcmVxdWlyZWQgbWluTGVuZ3RoPXszfSBtYXhMZW5ndGg9ezN9IHBhdHRlcm49XCJbQS1aYS16XXszfVwiIHZhbHVlPXtjdXJyZW5jeX0gb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXJyZW5jeShlLnRhcmdldC52YWx1ZS50b1VwcGVyQ2FzZSgpKX0gcGxhY2Vob2xkZXI9XCJCRFRcIi8+PHNtYWxsPkN1cnJlbmN5IG11c3QgZXhpc3QgYW5kIGJlIGFjdGl2ZSBpbiB0aGUgYmFja2VuZC48L3NtYWxsPjwvbGFiZWw+PGRpdiBjbGFzc05hbWU9XCJhY2NvdW50LW1vZGFsLWFjdGlvbnNcIj48QnV0dG9uIHR5cGU9XCJidXR0b25cIiB2YXJpYW50PVwib3V0bGluZVwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dDcmVhdGUoZmFsc2UpfT5DYW5jZWw8L0J1dHRvbj48QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBsb2FkaW5nPXtjcmVhdGVBY2NvdW50LmlzUGVuZGluZ30+Q3JlYXRlIEFjY291bnQ8L0J1dHRvbj48L2Rpdj48L2Zvcm0+PC9zZWN0aW9uPjwvZGl2Pn1cbiAgPC9zZWN0aW9uPjtcbn1cbiJdLCJmaWxlIjoiRDovTmV3X2ZvbGRlcl8oMikvU29mdHdhcmUgZGV2ZWxvcG1lbnQgUHJvamVjdC9iYW5raW5nLXBsYXRmcm9tL2Zyb250ZW5kL2JhbmtpbmctcGxhdGZvcm0tZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL2N1c3RvbWVyL2FjY291bnRzL3BhZ2VzL0FjY291bnRMaXN0UGFnZS50c3gifQ==