import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/public/pages/ResetPasswordPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useState = __vite__cjsImport1_react["useState"];
import { Link, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { Eye, EyeOff, Lock, RefreshCw, CheckCircle2, ArrowLeft } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { authApi } from "/src/features/auth/authApi.ts";
import { AuthShell } from "/src/features/public/components/AuthShell.tsx";
import { normalizeApiError } from "/src/lib/api/apiError.ts";
export function ResetPasswordPage() {
  _s();
  const [params] = useSearchParams();
  const token = params.get("token") || "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  const rules = [{ label: "At least 8 characters", ok: password.length >= 8 }, { label: "At least one uppercase letter (A–Z)", ok: /[A-Z]/.test(password) }, { label: "At least one lowercase letter (a–z)", ok: /[a-z]/.test(password) }, { label: "At least one number (0–9)", ok: /\d/.test(password) }];
  async function submit(e) {
    e.preventDefault();
    if (!token) {
      toast.error("Reset token is missing. Please use the link from your email.");
      return;
    }
    if (!rules.every((r) => r.ok)) {
      toast.error("Please meet all password requirements");
      return;
    }
    if (password !== confirm) {
      toast.error("Passwords do not match");
      return;
    }
    setBusy(true);
    try {
      await authApi.resetPassword({ token, password });
      toast.success("Password reset successful. Please log in.");
      navigate("/login");
    } catch (err) {
      toast.error(normalizeApiError(err).message);
    } finally {
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxDEV(AuthShell, { title: "Reset Password", subtitle: "Enter a new password for your account.", variant: "reset", children: /* @__PURE__ */ jsxDEV("form", { className: "auth-form reset-form", onSubmit: submit, children: [
    /* @__PURE__ */ jsxDEV("label", { children: [
      "New Password",
      /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
        /* @__PURE__ */ jsxDEV(Lock, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 14,
          columnNumber: 55
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: show ? "text" : "password", required: true, autoComplete: "new-password", value: password, onChange: (e) => setPassword(e.target.value), placeholder: "Enter new password" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 14,
          columnNumber: 63
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "password-toggle", onClick: () => setShow(!show), children: show ? /* @__PURE__ */ jsxDEV(EyeOff, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 14,
          columnNumber: 328
        }, this) : /* @__PURE__ */ jsxDEV(Eye, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 14,
          columnNumber: 341
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 14,
          columnNumber: 239
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
        lineNumber: 14,
        columnNumber: 22
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
      lineNumber: 14,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Confirm Password",
      /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
        /* @__PURE__ */ jsxDEV(Lock, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 15,
          columnNumber: 59
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: show ? "text" : "password", required: true, autoComplete: "new-password", value: confirm, onChange: (e) => setConfirm(e.target.value), placeholder: "Confirm new password" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 15,
          columnNumber: 67
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "password-toggle", onClick: () => setShow(!show), children: show ? /* @__PURE__ */ jsxDEV(EyeOff, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 15,
          columnNumber: 332
        }, this) : /* @__PURE__ */ jsxDEV(Eye, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 15,
          columnNumber: 345
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 15,
          columnNumber: 243
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
        lineNumber: 15,
        columnNumber: 26
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
      lineNumber: 15,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "password-rules", children: [
      /* @__PURE__ */ jsxDEV("strong", { children: "Password must include:" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
        lineNumber: 16,
        columnNumber: 35
      }, this),
      rules.map((r) => /* @__PURE__ */ jsxDEV("span", { className: r.ok ? "rule-ok" : "", children: [
        /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 15 }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
          lineNumber: 16,
          columnNumber: 146
        }, this),
        r.label
      ] }, r.label, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
        lineNumber: 16,
        columnNumber: 92
      }, this))
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
      lineNumber: 16,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "auth-submit", disabled: busy, children: busy ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "spinner" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
        lineNumber: 17,
        columnNumber: 61
      }, this),
      " Resetting..."
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
      lineNumber: 17,
      columnNumber: 59
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(RefreshCw, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
        lineNumber: 17,
        columnNumber: 110
      }, this),
      " Reset Password"
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
      lineNumber: 17,
      columnNumber: 108
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
      lineNumber: 17,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV(Link, { className: "back-link", to: "/login", children: [
      /* @__PURE__ */ jsxDEV(ArrowLeft, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
        lineNumber: 18,
        columnNumber: 43
      }, this),
      " Back to Login"
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
      lineNumber: 18,
      columnNumber: 3
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
    lineNumber: 13,
    columnNumber: 110
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
}
_s(ResetPasswordPage, "lBspogEiBEb0TDx23UP60AJw9LE=", false, function() {
  return [useSearchParams, useNavigate];
});
_c = ResetPasswordPage;
var _c;
$RefreshReg$(_c, "ResetPasswordPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ResetPasswordPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYXNELFNBR0UsVUFIRjs7QUFidEQsU0FBU0EsZ0JBQWdDO0FBQ3pDLFNBQVNDLE1BQU1DLGFBQWFDLHVCQUF1QjtBQUNuRCxTQUFTQyxLQUFLQyxRQUFRQyxNQUFNQyxXQUFXQyxjQUFjQyxpQkFBaUI7QUFDdEUsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyx5QkFBeUI7QUFFM0IsZ0JBQVNDLG9CQUFtQjtBQUFBQyxLQUFBO0FBQ2xDLFFBQU0sQ0FBQ0MsTUFBTSxJQUFFYixnQkFBZ0I7QUFBRSxRQUFNYyxRQUFNRCxPQUFPRSxJQUFJLE9BQU8sS0FBRztBQUFHLFFBQU0sQ0FBQ0MsVUFBU0MsV0FBVyxJQUFFcEIsU0FBUyxFQUFFO0FBQUUsUUFBTSxDQUFDcUIsU0FBUUMsVUFBVSxJQUFFdEIsU0FBUyxFQUFFO0FBQUUsUUFBTSxDQUFDdUIsTUFBS0MsT0FBTyxJQUFFeEIsU0FBUyxLQUFLO0FBQUUsUUFBTSxDQUFDeUIsTUFBS0MsT0FBTyxJQUFFMUIsU0FBUyxLQUFLO0FBQUUsUUFBTTJCLFdBQVN6QixZQUFZO0FBQzVQLFFBQU0wQixRQUFNLENBQUMsRUFBQ0MsT0FBTSx5QkFBd0JDLElBQUdYLFNBQVNZLFVBQVEsRUFBQyxHQUFFLEVBQUNGLE9BQU0sdUNBQXNDQyxJQUFHLFFBQVFFLEtBQUtiLFFBQVEsRUFBQyxHQUFFLEVBQUNVLE9BQU0sdUNBQXNDQyxJQUFHLFFBQVFFLEtBQUtiLFFBQVEsRUFBQyxHQUFFLEVBQUNVLE9BQU0sNkJBQTRCQyxJQUFHLEtBQUtFLEtBQUtiLFFBQVEsRUFBQyxDQUFDO0FBQzdRLGlCQUFlYyxPQUFPQyxHQUFZO0FBQUNBLE1BQUVDLGVBQWU7QUFBRSxRQUFHLENBQUNsQixPQUFNO0FBQUNQLFlBQU0wQixNQUFNLDhEQUE4RDtBQUFFO0FBQUEsSUFBTztBQUFDLFFBQUcsQ0FBQ1IsTUFBTVMsTUFBTSxDQUFBQyxNQUFHQSxFQUFFUixFQUFFLEdBQUU7QUFBQ3BCLFlBQU0wQixNQUFNLHVDQUF1QztBQUFFO0FBQUEsSUFBTztBQUFDLFFBQUdqQixhQUFXRSxTQUFRO0FBQUNYLFlBQU0wQixNQUFNLHdCQUF3QjtBQUFFO0FBQUEsSUFBTztBQUFDVixZQUFRLElBQUk7QUFBRSxRQUFHO0FBQUMsWUFBTWYsUUFBUTRCLGNBQWMsRUFBQ3RCLE9BQU1FLFNBQVEsQ0FBQztBQUFFVCxZQUFNOEIsUUFBUSwyQ0FBMkM7QUFBRWIsZUFBUyxRQUFRO0FBQUEsSUFBRSxTQUFPYyxLQUFJO0FBQUMvQixZQUFNMEIsTUFBTXZCLGtCQUFrQjRCLEdBQUcsRUFBRUMsT0FBTztBQUFBLElBQUUsVUFBQztBQUFRaEIsY0FBUSxLQUFLO0FBQUEsSUFBRTtBQUFBLEVBQUM7QUFDaGhCLFNBQU8sdUJBQUMsYUFBVSxPQUFNLGtCQUFpQixVQUFTLDBDQUF5QyxTQUFRLFNBQVEsaUNBQUMsVUFBSyxXQUFVLHdCQUF1QixVQUFVTyxRQUMzSjtBQUFBLDJCQUFDLFdBQU07QUFBQTtBQUFBLE1BQVksdUJBQUMsU0FBSSxXQUFVLG1CQUFrQjtBQUFBLCtCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFLO0FBQUEsUUFBRSx1QkFBQyxXQUFNLE1BQU1WLE9BQUssU0FBTyxZQUFZLFVBQVEsTUFBQyxjQUFhLGdCQUFlLE9BQU9KLFVBQVUsVUFBVSxDQUFBZSxNQUFHZCxZQUFZYyxFQUFFUyxPQUFPQyxLQUFLLEdBQUcsYUFBWSx3QkFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxSztBQUFBLFFBQUUsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxtQkFBa0IsU0FBUyxNQUFJcEIsUUFBUSxDQUFDRCxJQUFJLEdBQUlBLGlCQUFLLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFPLElBQUcsdUJBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUksS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFdBQXJUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOFQ7QUFBQSxTQUFqVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVWO0FBQUEsSUFDdlYsdUJBQUMsV0FBTTtBQUFBO0FBQUEsTUFBZ0IsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQjtBQUFBLCtCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFLO0FBQUEsUUFBRSx1QkFBQyxXQUFNLE1BQU1BLE9BQUssU0FBTyxZQUFZLFVBQVEsTUFBQyxjQUFhLGdCQUFlLE9BQU9GLFNBQVMsVUFBVSxDQUFBYSxNQUFHWixXQUFXWSxFQUFFUyxPQUFPQyxLQUFLLEdBQUcsYUFBWSwwQkFBL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxSztBQUFBLFFBQUUsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxtQkFBa0IsU0FBUyxNQUFJcEIsUUFBUSxDQUFDRCxJQUFJLEdBQUlBLGlCQUFLLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFPLElBQUcsdUJBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUksS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFdBQXJUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOFQ7QUFBQSxTQUFyVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJWO0FBQUEsSUFDM1YsdUJBQUMsU0FBSSxXQUFVLGtCQUFpQjtBQUFBLDZCQUFDLFlBQU8sc0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4QjtBQUFBLE1BQVVLLE1BQU1pQixJQUFJLENBQUFQLE1BQUcsdUJBQUMsVUFBbUIsV0FBV0EsRUFBRVIsS0FBRyxZQUFVLElBQUk7QUFBQSwrQkFBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxRQUFHUSxFQUFFVDtBQUFBQSxXQUFuRVMsRUFBRVQsT0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9GLENBQU87QUFBQSxTQUFoTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtMO0FBQUEsSUFDbEwsdUJBQUMsWUFBTyxXQUFVLGVBQWMsVUFBVUosTUFBT0EsaUJBQUssbUNBQUU7QUFBQSw2QkFBQyxVQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQUU7QUFBQSxTQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDLElBQUksbUNBQUU7QUFBQSw2QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVTtBQUFBLE1BQUU7QUFBQSxTQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkIsS0FBakk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxSTtBQUFBLElBQ3JJLHVCQUFDLFFBQUssV0FBVSxhQUFZLElBQUcsVUFBUztBQUFBLDZCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFVO0FBQUEsTUFBRTtBQUFBLFNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0U7QUFBQSxPQUx3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBTTNHLEtBTk87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBQ1I7QUFBQ1YsR0FYZUQsbUJBQWlCO0FBQUEsVUFDakJYLGlCQUFpT0QsV0FBVztBQUFBO0FBQUEsS0FENU9ZO0FBQWlCLElBQUFnQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkxpbmsiLCJ1c2VOYXZpZ2F0ZSIsInVzZVNlYXJjaFBhcmFtcyIsIkV5ZSIsIkV5ZU9mZiIsIkxvY2siLCJSZWZyZXNoQ3ciLCJDaGVja0NpcmNsZTIiLCJBcnJvd0xlZnQiLCJ0b2FzdCIsImF1dGhBcGkiLCJBdXRoU2hlbGwiLCJub3JtYWxpemVBcGlFcnJvciIsIlJlc2V0UGFzc3dvcmRQYWdlIiwiX3MiLCJwYXJhbXMiLCJ0b2tlbiIsImdldCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJjb25maXJtIiwic2V0Q29uZmlybSIsInNob3ciLCJzZXRTaG93IiwiYnVzeSIsInNldEJ1c3kiLCJuYXZpZ2F0ZSIsInJ1bGVzIiwibGFiZWwiLCJvayIsImxlbmd0aCIsInRlc3QiLCJzdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJlcnJvciIsImV2ZXJ5IiwiciIsInJlc2V0UGFzc3dvcmQiLCJzdWNjZXNzIiwiZXJyIiwibWVzc2FnZSIsInRhcmdldCIsInZhbHVlIiwibWFwIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVzZXRQYXNzd29yZFBhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB0eXBlIEZvcm1FdmVudCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBFeWUsIEV5ZU9mZiwgTG9jaywgUmVmcmVzaEN3LCBDaGVja0NpcmNsZTIsIEFycm93TGVmdCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcInNvbm5lclwiO1xuaW1wb3J0IHsgYXV0aEFwaSB9IGZyb20gXCIuLi8uLi8uLi9mZWF0dXJlcy9hdXRoL2F1dGhBcGlcIjtcbmltcG9ydCB7IEF1dGhTaGVsbCB9IGZyb20gXCIuLi9jb21wb25lbnRzL0F1dGhTaGVsbFwiO1xuaW1wb3J0IHsgbm9ybWFsaXplQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vLi4vbGliL2FwaS9hcGlFcnJvclwiO1xuXG5leHBvcnQgZnVuY3Rpb24gUmVzZXRQYXNzd29yZFBhZ2UoKXtcbiBjb25zdCBbcGFyYW1zXT11c2VTZWFyY2hQYXJhbXMoKTtjb25zdCB0b2tlbj1wYXJhbXMuZ2V0KFwidG9rZW5cIil8fFwiXCI7Y29uc3QgW3Bhc3N3b3JkLHNldFBhc3N3b3JkXT11c2VTdGF0ZShcIlwiKTtjb25zdCBbY29uZmlybSxzZXRDb25maXJtXT11c2VTdGF0ZShcIlwiKTtjb25zdCBbc2hvdyxzZXRTaG93XT11c2VTdGF0ZShmYWxzZSk7Y29uc3QgW2J1c3ksc2V0QnVzeV09dXNlU3RhdGUoZmFsc2UpO2NvbnN0IG5hdmlnYXRlPXVzZU5hdmlnYXRlKCk7XG4gY29uc3QgcnVsZXM9W3tsYWJlbDpcIkF0IGxlYXN0IDggY2hhcmFjdGVyc1wiLG9rOnBhc3N3b3JkLmxlbmd0aD49OH0se2xhYmVsOlwiQXQgbGVhc3Qgb25lIHVwcGVyY2FzZSBsZXR0ZXIgKEHigJNaKVwiLG9rOi9bQS1aXS8udGVzdChwYXNzd29yZCl9LHtsYWJlbDpcIkF0IGxlYXN0IG9uZSBsb3dlcmNhc2UgbGV0dGVyIChh4oCTeilcIixvazovW2Etel0vLnRlc3QocGFzc3dvcmQpfSx7bGFiZWw6XCJBdCBsZWFzdCBvbmUgbnVtYmVyICgw4oCTOSlcIixvazovXFxkLy50ZXN0KHBhc3N3b3JkKX1dO1xuIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdChlOkZvcm1FdmVudCl7ZS5wcmV2ZW50RGVmYXVsdCgpO2lmKCF0b2tlbil7dG9hc3QuZXJyb3IoXCJSZXNldCB0b2tlbiBpcyBtaXNzaW5nLiBQbGVhc2UgdXNlIHRoZSBsaW5rIGZyb20geW91ciBlbWFpbC5cIik7cmV0dXJuO31pZighcnVsZXMuZXZlcnkocj0+ci5vaykpe3RvYXN0LmVycm9yKFwiUGxlYXNlIG1lZXQgYWxsIHBhc3N3b3JkIHJlcXVpcmVtZW50c1wiKTtyZXR1cm47fWlmKHBhc3N3b3JkIT09Y29uZmlybSl7dG9hc3QuZXJyb3IoXCJQYXNzd29yZHMgZG8gbm90IG1hdGNoXCIpO3JldHVybjt9c2V0QnVzeSh0cnVlKTt0cnl7YXdhaXQgYXV0aEFwaS5yZXNldFBhc3N3b3JkKHt0b2tlbixwYXNzd29yZH0pO3RvYXN0LnN1Y2Nlc3MoXCJQYXNzd29yZCByZXNldCBzdWNjZXNzZnVsLiBQbGVhc2UgbG9nIGluLlwiKTtuYXZpZ2F0ZShcIi9sb2dpblwiKTt9Y2F0Y2goZXJyKXt0b2FzdC5lcnJvcihub3JtYWxpemVBcGlFcnJvcihlcnIpLm1lc3NhZ2UpO31maW5hbGx5e3NldEJ1c3koZmFsc2UpO319XG4gcmV0dXJuIDxBdXRoU2hlbGwgdGl0bGU9XCJSZXNldCBQYXNzd29yZFwiIHN1YnRpdGxlPVwiRW50ZXIgYSBuZXcgcGFzc3dvcmQgZm9yIHlvdXIgYWNjb3VudC5cIiB2YXJpYW50PVwicmVzZXRcIj48Zm9ybSBjbGFzc05hbWU9XCJhdXRoLWZvcm0gcmVzZXQtZm9ybVwiIG9uU3VibWl0PXtzdWJtaXR9PlxuICA8bGFiZWw+TmV3IFBhc3N3b3JkPGRpdiBjbGFzc05hbWU9XCJhdXRoLWlucHV0LXdyYXBcIj48TG9jay8+PGlucHV0IHR5cGU9e3Nob3c/XCJ0ZXh0XCI6XCJwYXNzd29yZFwifSByZXF1aXJlZCBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIiB2YWx1ZT17cGFzc3dvcmR9IG9uQ2hhbmdlPXtlPT5zZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiRW50ZXIgbmV3IHBhc3N3b3JkXCIvPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInBhc3N3b3JkLXRvZ2dsZVwiIG9uQ2xpY2s9eygpPT5zZXRTaG93KCFzaG93KX0+e3Nob3c/PEV5ZU9mZi8+OjxFeWUvPn08L2J1dHRvbj48L2Rpdj48L2xhYmVsPlxuICA8bGFiZWw+Q29uZmlybSBQYXNzd29yZDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1pbnB1dC13cmFwXCI+PExvY2svPjxpbnB1dCB0eXBlPXtzaG93P1widGV4dFwiOlwicGFzc3dvcmRcIn0gcmVxdWlyZWQgYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCIgdmFsdWU9e2NvbmZpcm19IG9uQ2hhbmdlPXtlPT5zZXRDb25maXJtKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJDb25maXJtIG5ldyBwYXNzd29yZFwiLz48YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJwYXNzd29yZC10b2dnbGVcIiBvbkNsaWNrPXsoKT0+c2V0U2hvdyghc2hvdyl9PntzaG93PzxFeWVPZmYvPjo8RXllLz59PC9idXR0b24+PC9kaXY+PC9sYWJlbD5cbiAgPGRpdiBjbGFzc05hbWU9XCJwYXNzd29yZC1ydWxlc1wiPjxzdHJvbmc+UGFzc3dvcmQgbXVzdCBpbmNsdWRlOjwvc3Ryb25nPntydWxlcy5tYXAocj0+PHNwYW4ga2V5PXtyLmxhYmVsfSBjbGFzc05hbWU9e3Iub2s/XCJydWxlLW9rXCI6XCJcIn0+PENoZWNrQ2lyY2xlMiBzaXplPXsxNX0vPntyLmxhYmVsfTwvc3Bhbj4pfTwvZGl2PlxuICA8YnV0dG9uIGNsYXNzTmFtZT1cImF1dGgtc3VibWl0XCIgZGlzYWJsZWQ9e2J1c3l9PntidXN5Pzw+PHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lclwiLz4gUmVzZXR0aW5nLi4uPC8+Ojw+PFJlZnJlc2hDdy8+IFJlc2V0IFBhc3N3b3JkPC8+fTwvYnV0dG9uPlxuICA8TGluayBjbGFzc05hbWU9XCJiYWNrLWxpbmtcIiB0bz1cIi9sb2dpblwiPjxBcnJvd0xlZnQvPiBCYWNrIHRvIExvZ2luPC9MaW5rPlxuIDwvZm9ybT48L0F1dGhTaGVsbD47XG59XG4iXSwiZmlsZSI6IkQ6L05ld19mb2xkZXJfKDIpL1NvZnR3YXJlIGRldmVsb3BtZW50IFByb2plY3QvYmFua2luZy1wbGF0ZnJvbS9mcm9udGVuZC9iYW5raW5nLXBsYXRmb3JtLWZyb250ZW5kL3NyYy9mZWF0dXJlcy9wdWJsaWMvcGFnZXMvUmVzZXRQYXNzd29yZFBhZ2UudHN4In0=