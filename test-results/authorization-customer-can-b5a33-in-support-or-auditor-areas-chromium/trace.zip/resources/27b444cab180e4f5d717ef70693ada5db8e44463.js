import axios from "/node_modules/.vite/deps/axios.js?v=d15d18f8";
export class ApiError extends Error {
  constructor(details) {
    super(details.message);
    this.name = "ApiError";
    this.status = details.status;
    this.code = details.code;
    this.requestId = details.requestId;
    this.fieldErrors = details.fieldErrors;
  }
}
export function normalizeApiError(error) {
  if (error instanceof ApiError) return error;
  if (!axios.isAxiosError(error)) {
    return new ApiError({
      status: null,
      code: null,
      message: error instanceof Error ? error.message : "An unexpected error occurred.",
      requestId: null,
      fieldErrors: {}
    });
  }
  const body = error.response?.data;
  const details = body?.error ?? body;
  const rawFields = details?.errors ?? details?.fieldErrors;
  const fieldErrors = {};
  if (Array.isArray(rawFields)) {
    for (const item of rawFields) {
      const key = item?.path?.join?.(".") ?? item?.field ?? "form";
      fieldErrors[key] = item?.message ?? "Invalid value";
    }
  } else if (rawFields && typeof rawFields === "object") {
    for (const [key, value] of Object.entries(rawFields)) {
      fieldErrors[key] = typeof value === "string" ? value : "Invalid value";
    }
  }
  const status = error.response?.status ?? null;
  const fallback = !error.response ? "Unable to reach the server. Check your connection and try again." : status === 401 ? "Your session is invalid or has expired. Please sign in again." : status === 403 ? "You do not have permission to perform this action." : status === 404 ? "The requested resource was not found." : status === 409 ? "This request conflicts with the current resource state." : status === 429 ? "Too many requests. Please wait before trying again." : status !== null && status >= 500 ? "The server is temporarily unavailable. Please try again later." : "Please check the submitted information and try again.";
  return new ApiError({
    status,
    code: details?.code ?? null,
    message: details?.message ?? body?.message ?? fallback,
    requestId: body?.requestId ?? details?.requestId ?? null,
    fieldErrors
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaUVycm9yLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcblxuZXhwb3J0IHR5cGUgQXBpRXJyb3JEZXRhaWxzID0ge1xuICBzdGF0dXM6IG51bWJlciB8IG51bGw7XG4gIGNvZGU6IHN0cmluZyB8IG51bGw7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgcmVxdWVzdElkOiBzdHJpbmcgfCBudWxsO1xuICBmaWVsZEVycm9yczogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbn07XG5cbmV4cG9ydCBjbGFzcyBBcGlFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgc3RhdHVzOiBudW1iZXIgfCBudWxsO1xuICBjb2RlOiBzdHJpbmcgfCBudWxsO1xuICByZXF1ZXN0SWQ6IHN0cmluZyB8IG51bGw7XG4gIGZpZWxkRXJyb3JzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuXG4gIGNvbnN0cnVjdG9yKGRldGFpbHM6IEFwaUVycm9yRGV0YWlscykge1xuICAgIHN1cGVyKGRldGFpbHMubWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gXCJBcGlFcnJvclwiO1xuICAgIHRoaXMuc3RhdHVzID0gZGV0YWlscy5zdGF0dXM7XG4gICAgdGhpcy5jb2RlID0gZGV0YWlscy5jb2RlO1xuICAgIHRoaXMucmVxdWVzdElkID0gZGV0YWlscy5yZXF1ZXN0SWQ7XG4gICAgdGhpcy5maWVsZEVycm9ycyA9IGRldGFpbHMuZmllbGRFcnJvcnM7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZUFwaUVycm9yKGVycm9yOiB1bmtub3duKTogQXBpRXJyb3Ige1xuICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBBcGlFcnJvcikgcmV0dXJuIGVycm9yO1xuICBpZiAoIWF4aW9zLmlzQXhpb3NFcnJvcihlcnJvcikpIHtcbiAgICByZXR1cm4gbmV3IEFwaUVycm9yKHtcbiAgICAgIHN0YXR1czogbnVsbCwgY29kZTogbnVsbCxcbiAgICAgIG1lc3NhZ2U6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLlwiLFxuICAgICAgcmVxdWVzdElkOiBudWxsLCBmaWVsZEVycm9yczoge30sXG4gICAgfSk7XG4gIH1cbiAgY29uc3QgYm9keSA9IGVycm9yLnJlc3BvbnNlPy5kYXRhIGFzIFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQ7XG4gIGNvbnN0IGRldGFpbHMgPSBib2R5Py5lcnJvciA/PyBib2R5O1xuICBjb25zdCByYXdGaWVsZHMgPSBkZXRhaWxzPy5lcnJvcnMgPz8gZGV0YWlscz8uZmllbGRFcnJvcnM7XG4gIGNvbnN0IGZpZWxkRXJyb3JzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gIGlmIChBcnJheS5pc0FycmF5KHJhd0ZpZWxkcykpIHtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgcmF3RmllbGRzKSB7XG4gICAgICBjb25zdCBrZXkgPSBpdGVtPy5wYXRoPy5qb2luPy4oXCIuXCIpID8/IGl0ZW0/LmZpZWxkID8/IFwiZm9ybVwiO1xuICAgICAgZmllbGRFcnJvcnNba2V5XSA9IGl0ZW0/Lm1lc3NhZ2UgPz8gXCJJbnZhbGlkIHZhbHVlXCI7XG4gICAgfVxuICB9IGVsc2UgaWYgKHJhd0ZpZWxkcyAmJiB0eXBlb2YgcmF3RmllbGRzID09PSBcIm9iamVjdFwiKSB7XG4gICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMocmF3RmllbGRzKSkge1xuICAgICAgZmllbGRFcnJvcnNba2V5XSA9IHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIiA/IHZhbHVlIDogXCJJbnZhbGlkIHZhbHVlXCI7XG4gICAgfVxuICB9XG4gIGNvbnN0IHN0YXR1cyA9IGVycm9yLnJlc3BvbnNlPy5zdGF0dXMgPz8gbnVsbDtcbiAgY29uc3QgZmFsbGJhY2sgPSAhZXJyb3IucmVzcG9uc2UgPyBcIlVuYWJsZSB0byByZWFjaCB0aGUgc2VydmVyLiBDaGVjayB5b3VyIGNvbm5lY3Rpb24gYW5kIHRyeSBhZ2Fpbi5cIlxuICAgIDogc3RhdHVzID09PSA0MDEgPyBcIllvdXIgc2Vzc2lvbiBpcyBpbnZhbGlkIG9yIGhhcyBleHBpcmVkLiBQbGVhc2Ugc2lnbiBpbiBhZ2Fpbi5cIlxuICAgIDogc3RhdHVzID09PSA0MDMgPyBcIllvdSBkbyBub3QgaGF2ZSBwZXJtaXNzaW9uIHRvIHBlcmZvcm0gdGhpcyBhY3Rpb24uXCJcbiAgICA6IHN0YXR1cyA9PT0gNDA0ID8gXCJUaGUgcmVxdWVzdGVkIHJlc291cmNlIHdhcyBub3QgZm91bmQuXCJcbiAgICA6IHN0YXR1cyA9PT0gNDA5ID8gXCJUaGlzIHJlcXVlc3QgY29uZmxpY3RzIHdpdGggdGhlIGN1cnJlbnQgcmVzb3VyY2Ugc3RhdGUuXCJcbiAgICA6IHN0YXR1cyA9PT0gNDI5ID8gXCJUb28gbWFueSByZXF1ZXN0cy4gUGxlYXNlIHdhaXQgYmVmb3JlIHRyeWluZyBhZ2Fpbi5cIlxuICAgIDogc3RhdHVzICE9PSBudWxsICYmIHN0YXR1cyA+PSA1MDAgPyBcIlRoZSBzZXJ2ZXIgaXMgdGVtcG9yYXJpbHkgdW5hdmFpbGFibGUuIFBsZWFzZSB0cnkgYWdhaW4gbGF0ZXIuXCJcbiAgICA6IFwiUGxlYXNlIGNoZWNrIHRoZSBzdWJtaXR0ZWQgaW5mb3JtYXRpb24gYW5kIHRyeSBhZ2Fpbi5cIjtcbiAgcmV0dXJuIG5ldyBBcGlFcnJvcih7XG4gICAgc3RhdHVzLFxuICAgIGNvZGU6IGRldGFpbHM/LmNvZGUgPz8gbnVsbCxcbiAgICBtZXNzYWdlOiBkZXRhaWxzPy5tZXNzYWdlID8/IGJvZHk/Lm1lc3NhZ2UgPz8gZmFsbGJhY2ssXG4gICAgcmVxdWVzdElkOiBib2R5Py5yZXF1ZXN0SWQgPz8gZGV0YWlscz8ucmVxdWVzdElkID8/IG51bGwsXG4gICAgZmllbGRFcnJvcnMsXG4gIH0pO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLFdBQVc7QUFVWCxhQUFNLGlCQUFpQixNQUFNO0FBQUEsRUFNbEMsWUFBWSxTQUEwQjtBQUNwQyxVQUFNLFFBQVEsT0FBTztBQUNyQixTQUFLLE9BQU87QUFDWixTQUFLLFNBQVMsUUFBUTtBQUN0QixTQUFLLE9BQU8sUUFBUTtBQUNwQixTQUFLLFlBQVksUUFBUTtBQUN6QixTQUFLLGNBQWMsUUFBUTtBQUFBLEVBQzdCO0FBQ0Y7QUFFTyxnQkFBUyxrQkFBa0IsT0FBMEI7QUFDMUQsTUFBSSxpQkFBaUIsU0FBVSxRQUFPO0FBQ3RDLE1BQUksQ0FBQyxNQUFNLGFBQWEsS0FBSyxHQUFHO0FBQzlCLFdBQU8sSUFBSSxTQUFTO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQU0sTUFBTTtBQUFBLE1BQ3BCLFNBQVMsaUJBQWlCLFFBQVEsTUFBTSxVQUFVO0FBQUEsTUFDbEQsV0FBVztBQUFBLE1BQU0sYUFBYSxDQUFDO0FBQUEsSUFDakMsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLE9BQU8sTUFBTSxVQUFVO0FBQzdCLFFBQU0sVUFBVSxNQUFNLFNBQVM7QUFDL0IsUUFBTSxZQUFZLFNBQVMsVUFBVSxTQUFTO0FBQzlDLFFBQU0sY0FBc0MsQ0FBQztBQUM3QyxNQUFJLE1BQU0sUUFBUSxTQUFTLEdBQUc7QUFDNUIsZUFBVyxRQUFRLFdBQVc7QUFDNUIsWUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxNQUFNLFNBQVM7QUFDdEQsa0JBQVksR0FBRyxJQUFJLE1BQU0sV0FBVztBQUFBLElBQ3RDO0FBQUEsRUFDRixXQUFXLGFBQWEsT0FBTyxjQUFjLFVBQVU7QUFDckQsZUFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLE9BQU8sUUFBUSxTQUFTLEdBQUc7QUFDcEQsa0JBQVksR0FBRyxJQUFJLE9BQU8sVUFBVSxXQUFXLFFBQVE7QUFBQSxJQUN6RDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVMsTUFBTSxVQUFVLFVBQVU7QUFDekMsUUFBTSxXQUFXLENBQUMsTUFBTSxXQUFXLHFFQUMvQixXQUFXLE1BQU0sa0VBQ2pCLFdBQVcsTUFBTSx1REFDakIsV0FBVyxNQUFNLDBDQUNqQixXQUFXLE1BQU0sNERBQ2pCLFdBQVcsTUFBTSx3REFDakIsV0FBVyxRQUFRLFVBQVUsTUFBTSxtRUFDbkM7QUFDSixTQUFPLElBQUksU0FBUztBQUFBLElBQ2xCO0FBQUEsSUFDQSxNQUFNLFNBQVMsUUFBUTtBQUFBLElBQ3ZCLFNBQVMsU0FBUyxXQUFXLE1BQU0sV0FBVztBQUFBLElBQzlDLFdBQVcsTUFBTSxhQUFhLFNBQVMsYUFBYTtBQUFBLElBQ3BEO0FBQUEsRUFDRixDQUFDO0FBQ0g7IiwibmFtZXMiOltdfQ==