import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/public/pages/RegisterPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useState = __vite__cjsImport1_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { Eye, EyeOff, Mail, Lock, UserRound, Phone, UserPlus } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { useAuth } from "/src/app/providers/AuthProvider.tsx";
import { AuthShell } from "/src/features/public/components/AuthShell.tsx";
import { normalizeApiError } from "/src/lib/api/apiError.ts";
export function RegisterPage() {
  _s();
  const { register } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [terms, setTerms] = useState(false);
  const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault();
    if (password !== confirm) {
      toast.error("Passwords do not match");
      return;
    }
    if (password.length < 8) {
      toast.error("Password must contain at least 8 characters");
      return;
    }
    if (!terms) {
      toast.error("Please accept the Terms of Service and Privacy Policy");
      return;
    }
    setBusy(true);
    try {
      await register({ name: name.trim(), email: email.trim(), ...phone.trim() ? { phone: phone.trim() } : {}, password });
      toast.success("Account created. Verify your email to continue.");
      navigate(`/verify-email?email=${encodeURIComponent(email.trim())}`);
    } catch (err) {
      toast.error(normalizeApiError(err).message);
    } finally {
      setBusy(false);
    }
  }
  return /* @__PURE__ */ jsxDEV(AuthShell, { title: "Create Your Account", subtitle: "Join our secure banking platform", variant: "register", children: /* @__PURE__ */ jsxDEV("form", { className: "auth-form register-form", onSubmit: submit, children: [
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Full Name ",
      /* @__PURE__ */ jsxDEV("b", { children: "*" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 13,
        columnNumber: 20
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
        /* @__PURE__ */ jsxDEV(UserRound, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 13,
          columnNumber: 61
        }, this),
        /* @__PURE__ */ jsxDEV("input", { required: true, autoComplete: "name", value: name, onChange: (e) => setName(e.target.value), placeholder: "Enter your full name" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 13,
          columnNumber: 74
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 13,
        columnNumber: 28
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 13,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Email Address ",
      /* @__PURE__ */ jsxDEV("b", { children: "*" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 14,
        columnNumber: 24
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
        /* @__PURE__ */ jsxDEV(Mail, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 14,
          columnNumber: 65
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "email", required: true, autoComplete: "email", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "Enter your email address" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 14,
          columnNumber: 73
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 14,
        columnNumber: 32
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 14,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Phone Number ",
      /* @__PURE__ */ jsxDEV("small", { children: "(Optional)" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 15,
        columnNumber: 23
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
        /* @__PURE__ */ jsxDEV(Phone, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 15,
          columnNumber: 81
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "tel", autoComplete: "tel", value: phone, onChange: (e) => setPhone(e.target.value), placeholder: "+8801XXXXXXXXX" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 15,
          columnNumber: 90
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 15,
        columnNumber: 48
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 15,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Password ",
      /* @__PURE__ */ jsxDEV("b", { children: "*" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 16,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
        /* @__PURE__ */ jsxDEV(Lock, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 16,
          columnNumber: 60
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: show ? "text" : "password", required: true, autoComplete: "new-password", value: password, onChange: (e) => setPassword(e.target.value), placeholder: "Create a strong password" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 16,
          columnNumber: 68
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "password-toggle", onClick: () => setShow(!show), children: show ? /* @__PURE__ */ jsxDEV(EyeOff, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 16,
          columnNumber: 339
        }, this) : /* @__PURE__ */ jsxDEV(Eye, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 16,
          columnNumber: 352
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 16,
          columnNumber: 250
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 16,
        columnNumber: 27
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 16,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("label", { children: [
      "Confirm Password ",
      /* @__PURE__ */ jsxDEV("b", { children: "*" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 17,
        columnNumber: 27
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
        /* @__PURE__ */ jsxDEV(Lock, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 17,
          columnNumber: 68
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: show ? "text" : "password", required: true, autoComplete: "new-password", value: confirm, onChange: (e) => setConfirm(e.target.value), placeholder: "Re-enter your password" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 17,
          columnNumber: 76
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", className: "password-toggle", onClick: () => setShow(!show), children: show ? /* @__PURE__ */ jsxDEV(EyeOff, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 17,
          columnNumber: 343
        }, this) : /* @__PURE__ */ jsxDEV(Eye, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 17,
          columnNumber: 356
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 17,
          columnNumber: 254
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 17,
        columnNumber: 35
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 17,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("label", { className: "check-label terms-check", children: [
      /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: terms, onChange: (e) => setTerms(e.target.checked) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 18,
        columnNumber: 46
      }, this),
      " ",
      /* @__PURE__ */ jsxDEV("span", { children: [
        "I agree to the ",
        /* @__PURE__ */ jsxDEV("a", { href: "#terms", children: "Terms of Service" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 18,
          columnNumber: 154
        }, this),
        " and ",
        /* @__PURE__ */ jsxDEV("a", { href: "#privacy", children: "Privacy Policy" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
          lineNumber: 18,
          columnNumber: 196
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 18,
        columnNumber: 133
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 18,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "auth-submit", disabled: busy, children: busy ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("span", { className: "spinner" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 19,
        columnNumber: 61
      }, this),
      " Creating account..."
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 19,
      columnNumber: 59
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(UserPlus, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 19,
        columnNumber: 117
      }, this),
      " Create Account"
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 19,
      columnNumber: 115
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 19,
      columnNumber: 3
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-divider", children: /* @__PURE__ */ jsxDEV("span", { children: [
      "Already have an account? ",
      /* @__PURE__ */ jsxDEV(Link, { to: "/login", children: "Log In" }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
        lineNumber: 20,
        columnNumber: 64
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 20,
      columnNumber: 33
    }, this) }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
      lineNumber: 20,
      columnNumber: 3
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
    lineNumber: 12,
    columnNumber: 112
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
}
_s(RegisterPage, "H82tltrPqRKmqA6Nu7pvKtNOMkI=", false, function() {
  return [useAuth, useNavigate];
});
_c = RegisterPage;
var _c;
$RefreshReg$(_c, "RegisterPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/RegisterPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWW1CLFNBTXFDLFVBTnJDOztBQVpuQixTQUFTQSxnQkFBZ0M7QUFDekMsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLFNBQVNDLEtBQUtDLFFBQVFDLE1BQU1DLE1BQU1DLFdBQVdDLE9BQU9DLGdCQUFnQjtBQUNwRSxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHlCQUF5QjtBQUUzQixnQkFBU0MsZUFBYztBQUFBQyxLQUFBO0FBQzdCLFFBQU0sRUFBQ0MsU0FBUSxJQUFFTCxRQUFRO0FBQUUsUUFBTU0sV0FBU2YsWUFBWTtBQUFFLFFBQU0sQ0FBQ2dCLE1BQUtDLE9BQU8sSUFBRW5CLFNBQVMsRUFBRTtBQUFFLFFBQU0sQ0FBQ29CLE9BQU1DLFFBQVEsSUFBRXJCLFNBQVMsRUFBRTtBQUFFLFFBQU0sQ0FBQ3NCLE9BQU1DLFFBQVEsSUFBRXZCLFNBQVMsRUFBRTtBQUFFLFFBQU0sQ0FBQ3dCLFVBQVNDLFdBQVcsSUFBRXpCLFNBQVMsRUFBRTtBQUFFLFFBQU0sQ0FBQzBCLFNBQVFDLFVBQVUsSUFBRTNCLFNBQVMsRUFBRTtBQUFFLFFBQU0sQ0FBQzRCLE1BQUtDLE9BQU8sSUFBRTdCLFNBQVMsS0FBSztBQUFFLFFBQU0sQ0FBQzhCLE9BQU1DLFFBQVEsSUFBRS9CLFNBQVMsS0FBSztBQUFFLFFBQU0sQ0FBQ2dDLE1BQUtDLE9BQU8sSUFBRWpDLFNBQVMsS0FBSztBQUNuVyxpQkFBZWtDLE9BQU9DLEdBQVk7QUFBQ0EsTUFBRUMsZUFBZTtBQUFFLFFBQUdaLGFBQVdFLFNBQVE7QUFBQ2hCLFlBQU0yQixNQUFNLHdCQUF3QjtBQUFFO0FBQUEsSUFBTztBQUFDLFFBQUdiLFNBQVNjLFNBQU8sR0FBRTtBQUFDNUIsWUFBTTJCLE1BQU0sNkNBQTZDO0FBQUU7QUFBQSxJQUFPO0FBQUMsUUFBRyxDQUFDUCxPQUFNO0FBQUNwQixZQUFNMkIsTUFBTSx1REFBdUQ7QUFBRTtBQUFBLElBQU87QUFBQ0osWUFBUSxJQUFJO0FBQUUsUUFBRztBQUFDLFlBQU1qQixTQUFTLEVBQUNFLE1BQUtBLEtBQUtxQixLQUFLLEdBQUVuQixPQUFNQSxNQUFNbUIsS0FBSyxHQUFFLEdBQUlqQixNQUFNaUIsS0FBSyxJQUFFLEVBQUNqQixPQUFNQSxNQUFNaUIsS0FBSyxFQUFDLElBQUUsQ0FBQyxHQUFHZixTQUFRLENBQUM7QUFBRWQsWUFBTThCLFFBQVEsaURBQWlEO0FBQUV2QixlQUFTLHVCQUF1QndCLG1CQUFtQnJCLE1BQU1tQixLQUFLLENBQUMsQ0FBQyxFQUFFO0FBQUEsSUFBRSxTQUFPRyxLQUFJO0FBQUNoQyxZQUFNMkIsTUFBTXhCLGtCQUFrQjZCLEdBQUcsRUFBRUMsT0FBTztBQUFBLElBQUUsVUFBQztBQUFRVixjQUFRLEtBQUs7QUFBQSxJQUFFO0FBQUEsRUFBQztBQUM3bkIsU0FBTyx1QkFBQyxhQUFVLE9BQU0sdUJBQXNCLFVBQVMsb0NBQW1DLFNBQVEsWUFBVyxpQ0FBQyxVQUFLLFdBQVUsMkJBQTBCLFVBQVVDLFFBQ2hLO0FBQUEsMkJBQUMsV0FBTTtBQUFBO0FBQUEsTUFBVSx1QkFBQyxPQUFFLGlCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSTtBQUFBLE1BQUksdUJBQUMsU0FBSSxXQUFVLG1CQUFrQjtBQUFBLCtCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFVO0FBQUEsUUFBRSx1QkFBQyxXQUFNLFVBQVEsTUFBQyxjQUFhLFFBQU8sT0FBT2hCLE1BQU0sVUFBVSxDQUFBaUIsTUFBR2hCLFFBQVFnQixFQUFFUyxPQUFPQyxLQUFLLEdBQUcsYUFBWSwwQkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5SDtBQUFBLFdBQXRLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0s7QUFBQSxTQUFqTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVNO0FBQUEsSUFDdk0sdUJBQUMsV0FBTTtBQUFBO0FBQUEsTUFBYyx1QkFBQyxPQUFFLGlCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSTtBQUFBLE1BQUksdUJBQUMsU0FBSSxXQUFVLG1CQUFrQjtBQUFBLCtCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFLO0FBQUEsUUFBRSx1QkFBQyxXQUFNLE1BQUssU0FBUSxVQUFRLE1BQUMsY0FBYSxTQUFRLE9BQU96QixPQUFPLFVBQVUsQ0FBQWUsTUFBR2QsU0FBU2MsRUFBRVMsT0FBT0MsS0FBSyxHQUFHLGFBQVksOEJBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkk7QUFBQSxXQUFyTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVMO0FBQUEsU0FBcE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwTjtBQUFBLElBQzFOLHVCQUFDLFdBQU07QUFBQTtBQUFBLE1BQWEsdUJBQUMsV0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCO0FBQUEsTUFBUSx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCO0FBQUEsK0JBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU07QUFBQSxRQUFFLHVCQUFDLFdBQU0sTUFBSyxPQUFNLGNBQWEsT0FBTSxPQUFPdkIsT0FBTyxVQUFVLENBQUFhLE1BQUdaLFNBQVNZLEVBQUVTLE9BQU9DLEtBQUssR0FBRyxhQUFZLG9CQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNIO0FBQUEsV0FBL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSztBQUFBLFNBQTlNO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb047QUFBQSxJQUNwTix1QkFBQyxXQUFNO0FBQUE7QUFBQSxNQUFTLHVCQUFDLE9BQUUsaUJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFJO0FBQUEsTUFBSSx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCO0FBQUEsK0JBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUs7QUFBQSxRQUFFLHVCQUFDLFdBQU0sTUFBTWpCLE9BQUssU0FBTyxZQUFZLFVBQVEsTUFBQyxjQUFhLGdCQUFlLE9BQU9KLFVBQVUsVUFBVSxDQUFBVyxNQUFHVixZQUFZVSxFQUFFUyxPQUFPQyxLQUFLLEdBQUcsYUFBWSw4QkFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEySztBQUFBLFFBQUUsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxtQkFBa0IsU0FBUyxNQUFJaEIsUUFBUSxDQUFDRCxJQUFJLEdBQUlBLGlCQUFLLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFPLElBQUcsdUJBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUksS0FBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRztBQUFBLFdBQTNUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb1U7QUFBQSxTQUE1VjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtXO0FBQUEsSUFDbFcsdUJBQUMsV0FBTTtBQUFBO0FBQUEsTUFBaUIsdUJBQUMsT0FBRSxpQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUk7QUFBQSxNQUFJLHVCQUFDLFNBQUksV0FBVSxtQkFBa0I7QUFBQSwrQkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBSztBQUFBLFFBQUUsdUJBQUMsV0FBTSxNQUFNQSxPQUFLLFNBQU8sWUFBWSxVQUFRLE1BQUMsY0FBYSxnQkFBZSxPQUFPRixTQUFTLFVBQVUsQ0FBQVMsTUFBR1IsV0FBV1EsRUFBRVMsT0FBT0MsS0FBSyxHQUFHLGFBQVksNEJBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUs7QUFBQSxRQUFFLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsbUJBQWtCLFNBQVMsTUFBSWhCLFFBQVEsQ0FBQ0QsSUFBSSxHQUFJQSxpQkFBSyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTyxJQUFHLHVCQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFJLEtBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0c7QUFBQSxXQUF2VDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdVO0FBQUEsU0FBaFc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzVztBQUFBLElBQ3RXLHVCQUFDLFdBQU0sV0FBVSwyQkFBMEI7QUFBQSw2QkFBQyxXQUFNLE1BQUssWUFBVyxTQUFTRSxPQUFPLFVBQVUsQ0FBQUssTUFBR0osU0FBU0ksRUFBRVMsT0FBT0UsT0FBTyxLQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFO0FBQUEsTUFBRTtBQUFBLE1BQUMsdUJBQUMsVUFBSztBQUFBO0FBQUEsUUFBZSx1QkFBQyxPQUFFLE1BQUssVUFBUyxnQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQUk7QUFBQSxRQUFLLHVCQUFDLE9BQUUsTUFBSyxZQUFXLDhCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsV0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRztBQUFBLFNBQWpPO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd087QUFBQSxJQUN4Tyx1QkFBQyxZQUFPLFdBQVUsZUFBYyxVQUFVZCxNQUFPQSxpQkFBSyxtQ0FBRTtBQUFBLDZCQUFDLFVBQUssV0FBVSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFBRTtBQUFBLFNBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQsSUFBSSxtQ0FBRTtBQUFBLDZCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFTO0FBQUEsTUFBRTtBQUFBLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE0QixLQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJJO0FBQUEsSUFDM0ksdUJBQUMsU0FBSSxXQUFVLGdCQUFlLGlDQUFDLFVBQUs7QUFBQTtBQUFBLE1BQXlCLHVCQUFDLFFBQUssSUFBRyxVQUFTLHNCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsU0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RCxLQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1HO0FBQUEsT0FSUztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUzdHLEtBVE87QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVNBO0FBQ1I7QUFBQ2pCLEdBYmVELGNBQVk7QUFBQSxVQUNWSCxTQUF5QlQsV0FBVztBQUFBO0FBQUEsS0FEdENZO0FBQVksSUFBQWlDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwiRXllIiwiRXllT2ZmIiwiTWFpbCIsIkxvY2siLCJVc2VyUm91bmQiLCJQaG9uZSIsIlVzZXJQbHVzIiwidG9hc3QiLCJ1c2VBdXRoIiwiQXV0aFNoZWxsIiwibm9ybWFsaXplQXBpRXJyb3IiLCJSZWdpc3RlclBhZ2UiLCJfcyIsInJlZ2lzdGVyIiwibmF2aWdhdGUiLCJuYW1lIiwic2V0TmFtZSIsImVtYWlsIiwic2V0RW1haWwiLCJwaG9uZSIsInNldFBob25lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImNvbmZpcm0iLCJzZXRDb25maXJtIiwic2hvdyIsInNldFNob3ciLCJ0ZXJtcyIsInNldFRlcm1zIiwiYnVzeSIsInNldEJ1c3kiLCJzdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJlcnJvciIsImxlbmd0aCIsInRyaW0iLCJzdWNjZXNzIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiZXJyIiwibWVzc2FnZSIsInRhcmdldCIsInZhbHVlIiwiY2hlY2tlZCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdGVyUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBFeWUsIEV5ZU9mZiwgTWFpbCwgTG9jaywgVXNlclJvdW5kLCBQaG9uZSwgVXNlclBsdXMgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCJzb25uZXJcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vLi4vYXBwL3Byb3ZpZGVycy9BdXRoUHJvdmlkZXJcIjtcbmltcG9ydCB7IEF1dGhTaGVsbCB9IGZyb20gXCIuLi9jb21wb25lbnRzL0F1dGhTaGVsbFwiO1xuaW1wb3J0IHsgbm9ybWFsaXplQXBpRXJyb3IgfSBmcm9tIFwiLi4vLi4vLi4vbGliL2FwaS9hcGlFcnJvclwiO1xuXG5leHBvcnQgZnVuY3Rpb24gUmVnaXN0ZXJQYWdlKCl7XG4gY29uc3Qge3JlZ2lzdGVyfT11c2VBdXRoKCk7Y29uc3QgbmF2aWdhdGU9dXNlTmF2aWdhdGUoKTtjb25zdCBbbmFtZSxzZXROYW1lXT11c2VTdGF0ZShcIlwiKTtjb25zdCBbZW1haWwsc2V0RW1haWxdPXVzZVN0YXRlKFwiXCIpO2NvbnN0IFtwaG9uZSxzZXRQaG9uZV09dXNlU3RhdGUoXCJcIik7Y29uc3QgW3Bhc3N3b3JkLHNldFBhc3N3b3JkXT11c2VTdGF0ZShcIlwiKTtjb25zdCBbY29uZmlybSxzZXRDb25maXJtXT11c2VTdGF0ZShcIlwiKTtjb25zdCBbc2hvdyxzZXRTaG93XT11c2VTdGF0ZShmYWxzZSk7Y29uc3QgW3Rlcm1zLHNldFRlcm1zXT11c2VTdGF0ZShmYWxzZSk7Y29uc3QgW2J1c3ksc2V0QnVzeV09dXNlU3RhdGUoZmFsc2UpO1xuIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdChlOkZvcm1FdmVudCl7ZS5wcmV2ZW50RGVmYXVsdCgpO2lmKHBhc3N3b3JkIT09Y29uZmlybSl7dG9hc3QuZXJyb3IoXCJQYXNzd29yZHMgZG8gbm90IG1hdGNoXCIpO3JldHVybjt9aWYocGFzc3dvcmQubGVuZ3RoPDgpe3RvYXN0LmVycm9yKFwiUGFzc3dvcmQgbXVzdCBjb250YWluIGF0IGxlYXN0IDggY2hhcmFjdGVyc1wiKTtyZXR1cm47fWlmKCF0ZXJtcyl7dG9hc3QuZXJyb3IoXCJQbGVhc2UgYWNjZXB0IHRoZSBUZXJtcyBvZiBTZXJ2aWNlIGFuZCBQcml2YWN5IFBvbGljeVwiKTtyZXR1cm47fXNldEJ1c3kodHJ1ZSk7dHJ5e2F3YWl0IHJlZ2lzdGVyKHtuYW1lOm5hbWUudHJpbSgpLGVtYWlsOmVtYWlsLnRyaW0oKSwuLi4ocGhvbmUudHJpbSgpP3twaG9uZTpwaG9uZS50cmltKCl9Ont9KSxwYXNzd29yZH0pO3RvYXN0LnN1Y2Nlc3MoXCJBY2NvdW50IGNyZWF0ZWQuIFZlcmlmeSB5b3VyIGVtYWlsIHRvIGNvbnRpbnVlLlwiKTtuYXZpZ2F0ZShgL3ZlcmlmeS1lbWFpbD9lbWFpbD0ke2VuY29kZVVSSUNvbXBvbmVudChlbWFpbC50cmltKCkpfWApO31jYXRjaChlcnIpe3RvYXN0LmVycm9yKG5vcm1hbGl6ZUFwaUVycm9yKGVycikubWVzc2FnZSk7fWZpbmFsbHl7c2V0QnVzeShmYWxzZSk7fX1cbiByZXR1cm4gPEF1dGhTaGVsbCB0aXRsZT1cIkNyZWF0ZSBZb3VyIEFjY291bnRcIiBzdWJ0aXRsZT1cIkpvaW4gb3VyIHNlY3VyZSBiYW5raW5nIHBsYXRmb3JtXCIgdmFyaWFudD1cInJlZ2lzdGVyXCI+PGZvcm0gY2xhc3NOYW1lPVwiYXV0aC1mb3JtIHJlZ2lzdGVyLWZvcm1cIiBvblN1Ym1pdD17c3VibWl0fT5cbiAgPGxhYmVsPkZ1bGwgTmFtZSA8Yj4qPC9iPjxkaXYgY2xhc3NOYW1lPVwiYXV0aC1pbnB1dC13cmFwXCI+PFVzZXJSb3VuZC8+PGlucHV0IHJlcXVpcmVkIGF1dG9Db21wbGV0ZT1cIm5hbWVcIiB2YWx1ZT17bmFtZX0gb25DaGFuZ2U9e2U9PnNldE5hbWUoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgZnVsbCBuYW1lXCIvPjwvZGl2PjwvbGFiZWw+XG4gIDxsYWJlbD5FbWFpbCBBZGRyZXNzIDxiPio8L2I+PGRpdiBjbGFzc05hbWU9XCJhdXRoLWlucHV0LXdyYXBcIj48TWFpbC8+PGlucHV0IHR5cGU9XCJlbWFpbFwiIHJlcXVpcmVkIGF1dG9Db21wbGV0ZT1cImVtYWlsXCIgdmFsdWU9e2VtYWlsfSBvbkNoYW5nZT17ZT0+c2V0RW1haWwoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgZW1haWwgYWRkcmVzc1wiLz48L2Rpdj48L2xhYmVsPlxuICA8bGFiZWw+UGhvbmUgTnVtYmVyIDxzbWFsbD4oT3B0aW9uYWwpPC9zbWFsbD48ZGl2IGNsYXNzTmFtZT1cImF1dGgtaW5wdXQtd3JhcFwiPjxQaG9uZS8+PGlucHV0IHR5cGU9XCJ0ZWxcIiBhdXRvQ29tcGxldGU9XCJ0ZWxcIiB2YWx1ZT17cGhvbmV9IG9uQ2hhbmdlPXtlPT5zZXRQaG9uZShlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiKzg4MDFYWFhYWFhYWFhcIi8+PC9kaXY+PC9sYWJlbD5cbiAgPGxhYmVsPlBhc3N3b3JkIDxiPio8L2I+PGRpdiBjbGFzc05hbWU9XCJhdXRoLWlucHV0LXdyYXBcIj48TG9jay8+PGlucHV0IHR5cGU9e3Nob3c/XCJ0ZXh0XCI6XCJwYXNzd29yZFwifSByZXF1aXJlZCBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIiB2YWx1ZT17cGFzc3dvcmR9IG9uQ2hhbmdlPXtlPT5zZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9IHBsYWNlaG9sZGVyPVwiQ3JlYXRlIGEgc3Ryb25nIHBhc3N3b3JkXCIvPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInBhc3N3b3JkLXRvZ2dsZVwiIG9uQ2xpY2s9eygpPT5zZXRTaG93KCFzaG93KX0+e3Nob3c/PEV5ZU9mZi8+OjxFeWUvPn08L2J1dHRvbj48L2Rpdj48L2xhYmVsPlxuICA8bGFiZWw+Q29uZmlybSBQYXNzd29yZCA8Yj4qPC9iPjxkaXYgY2xhc3NOYW1lPVwiYXV0aC1pbnB1dC13cmFwXCI+PExvY2svPjxpbnB1dCB0eXBlPXtzaG93P1widGV4dFwiOlwicGFzc3dvcmRcIn0gcmVxdWlyZWQgYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCIgdmFsdWU9e2NvbmZpcm19IG9uQ2hhbmdlPXtlPT5zZXRDb25maXJtKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJSZS1lbnRlciB5b3VyIHBhc3N3b3JkXCIvPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cInBhc3N3b3JkLXRvZ2dsZVwiIG9uQ2xpY2s9eygpPT5zZXRTaG93KCFzaG93KX0+e3Nob3c/PEV5ZU9mZi8+OjxFeWUvPn08L2J1dHRvbj48L2Rpdj48L2xhYmVsPlxuICA8bGFiZWwgY2xhc3NOYW1lPVwiY2hlY2stbGFiZWwgdGVybXMtY2hlY2tcIj48aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgY2hlY2tlZD17dGVybXN9IG9uQ2hhbmdlPXtlPT5zZXRUZXJtcyhlLnRhcmdldC5jaGVja2VkKX0vPiA8c3Bhbj5JIGFncmVlIHRvIHRoZSA8YSBocmVmPVwiI3Rlcm1zXCI+VGVybXMgb2YgU2VydmljZTwvYT4gYW5kIDxhIGhyZWY9XCIjcHJpdmFjeVwiPlByaXZhY3kgUG9saWN5PC9hPjwvc3Bhbj48L2xhYmVsPlxuICA8YnV0dG9uIGNsYXNzTmFtZT1cImF1dGgtc3VibWl0XCIgZGlzYWJsZWQ9e2J1c3l9PntidXN5Pzw+PHNwYW4gY2xhc3NOYW1lPVwic3Bpbm5lclwiLz4gQ3JlYXRpbmcgYWNjb3VudC4uLjwvPjo8PjxVc2VyUGx1cy8+IENyZWF0ZSBBY2NvdW50PC8+fTwvYnV0dG9uPlxuICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtZGl2aWRlclwiPjxzcGFuPkFscmVhZHkgaGF2ZSBhbiBhY2NvdW50PyA8TGluayB0bz1cIi9sb2dpblwiPkxvZyBJbjwvTGluaz48L3NwYW4+PC9kaXY+XG4gPC9mb3JtPjwvQXV0aFNoZWxsPjtcbn1cbiJdLCJmaWxlIjoiRDovTmV3X2ZvbGRlcl8oMikvU29mdHdhcmUgZGV2ZWxvcG1lbnQgUHJvamVjdC9iYW5raW5nLXBsYXRmcm9tL2Zyb250ZW5kL2JhbmtpbmctcGxhdGZvcm0tZnJvbnRlbmQvc3JjL2ZlYXR1cmVzL3B1YmxpYy9wYWdlcy9SZWdpc3RlclBhZ2UudHN4In0=