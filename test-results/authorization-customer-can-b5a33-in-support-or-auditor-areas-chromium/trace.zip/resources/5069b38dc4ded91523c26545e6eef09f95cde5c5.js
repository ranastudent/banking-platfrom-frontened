import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/public/pages/ForgotPasswordPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
export function ForgotPasswordPage() {
  return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ForgotPasswordPage.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = ForgotPasswordPage;
var _c;
$RefreshReg$(_c, "ForgotPasswordPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ForgotPasswordPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ForgotPasswordPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/ForgotPasswordPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT1M7QUFQVCxTQUFTQSxnQkFBZ0I7QUFNbEIsZ0JBQVNDLHFCQUFxQjtBQUNuQyxTQUFPLHVCQUFDLFlBQVMsSUFBRyxVQUFTLFNBQU8sUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE2QjtBQUN0QztBQUFDQyxLQUZlRDtBQUFrQixJQUFBQztBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOYXZpZ2F0ZSIsIkZvcmdvdFBhc3N3b3JkUGFnZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkZvcmdvdFBhc3N3b3JkUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuXG4vKipcbiAqIFBhc3N3b3JkIHJlY292ZXJ5IGlzIG5vdyBhIHRocmVlLXN0ZXAgbW9kYWwgbGF1bmNoZWQgZnJvbSB0aGUgbG9naW4gcGFnZS5cbiAqIEtlZXAgdGhpcyByb3V0ZSBhcyBhIGNvbXBhdGliaWxpdHkgcmVkaXJlY3QgZm9yIG9sZCBib29rbWFya3MuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBGb3Jnb3RQYXNzd29yZFBhZ2UoKSB7XG4gIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+O1xufVxuIl0sImZpbGUiOiJEOi9OZXdfZm9sZGVyXygyKS9Tb2Z0d2FyZSBkZXZlbG9wbWVudCBQcm9qZWN0L2JhbmtpbmctcGxhdGZyb20vZnJvbnRlbmQvYmFua2luZy1wbGF0Zm9ybS1mcm9udGVuZC9zcmMvZmVhdHVyZXMvcHVibGljL3BhZ2VzL0ZvcmdvdFBhc3N3b3JkUGFnZS50c3gifQ==