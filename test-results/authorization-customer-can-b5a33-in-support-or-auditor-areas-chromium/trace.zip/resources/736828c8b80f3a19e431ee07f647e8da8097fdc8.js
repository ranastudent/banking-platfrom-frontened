import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/Dialog.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import __vite__cjsImport2_reactDom from "/node_modules/.vite/deps/react-dom.js?v=d15d18f8"; const createPortal = __vite__cjsImport2_reactDom["createPortal"];
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { Button } from "/src/components/ui/Button.tsx";
export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  footer
}) {
  _s();
  const dialogRef = useRef(null);
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);
  if (typeof document === "undefined") return null;
  return createPortal(
    /* @__PURE__ */ jsxDEV(
      "dialog",
      {
        ref: dialogRef,
        className: "dialog",
        "aria-labelledby": "dialog-title",
        "aria-describedby": description ? "dialog-description" : void 0,
        onCancel: (event) => {
          event.preventDefault();
          onOpenChange(false);
        },
        onClick: (event) => {
          if (event.target === dialogRef.current) onOpenChange(false);
        },
        onClose: () => onOpenChange(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "dialog-panel", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "dialog-header", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { id: "dialog-title", children: title }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
                lineNumber: 44,
                columnNumber: 13
              }, this),
              description && /* @__PURE__ */ jsxDEV("p", { id: "dialog-description", children: description }, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
                lineNumber: 45,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
              lineNumber: 43,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { type: "button", variant: "ghost", size: "icon", "aria-label": "Close dialog", onClick: () => onOpenChange(false), children: /* @__PURE__ */ jsxDEV(X, { size: 18 }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
              lineNumber: 48,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
              lineNumber: 47,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
            lineNumber: 42,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "dialog-body", children }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
            lineNumber: 51,
            columnNumber: 9
          }, this),
          footer && /* @__PURE__ */ jsxDEV("div", { className: "dialog-footer", children: footer }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
            lineNumber: 52,
            columnNumber: 20
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
          lineNumber: 41,
          columnNumber: 7
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx",
        lineNumber: 30,
        columnNumber: 5
      },
      this
    ),
    document.body
  );
}
_s(Dialog, "9PxoOcTjzEwd023cmhgaBdjzFyE=");
_c = Dialog;
var _c;
$RefreshReg$(_c, "Dialog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/components/ui/Dialog.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNZOztBQTNDWixTQUFTQSxXQUFXQyxjQUE4QjtBQUNsRCxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsU0FBUztBQUNsQixTQUFTQyxjQUFjO0FBV2hCLGdCQUFTQyxPQUFPO0FBQUEsRUFDckJDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQWNDO0FBQUFBLEVBQU9DO0FBQUFBLEVBQWFDO0FBQUFBLEVBQVVDO0FBQ3ZDLEdBQUc7QUFBQUMsS0FBQTtBQUNkLFFBQU1DLFlBQVlaLE9BQTBCLElBQUk7QUFFaERELFlBQVUsTUFBTTtBQUNkLFVBQU1jLFNBQVNELFVBQVVFO0FBQ3pCLFFBQUksQ0FBQ0QsT0FBUTtBQUNiLFFBQUlSLFFBQVEsQ0FBQ1EsT0FBT1IsS0FBTVEsUUFBT0UsVUFBVTtBQUMzQyxRQUFJLENBQUNWLFFBQVFRLE9BQU9SLEtBQU1RLFFBQU9HLE1BQU07QUFBQSxFQUN6QyxHQUFHLENBQUNYLElBQUksQ0FBQztBQUVULE1BQUksT0FBT1ksYUFBYSxZQUFhLFFBQU87QUFFNUMsU0FBT2hCO0FBQUFBLElBQ0w7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLEtBQUtXO0FBQUFBLFFBQ0wsV0FBVTtBQUFBLFFBQ1YsbUJBQWdCO0FBQUEsUUFDaEIsb0JBQWtCSixjQUFjLHVCQUF1QlU7QUFBQUEsUUFDdkQsVUFBVSxDQUFDQyxVQUFVO0FBQUVBLGdCQUFNQyxlQUFlO0FBQUdkLHVCQUFhLEtBQUs7QUFBQSxRQUFHO0FBQUEsUUFDcEUsU0FBUyxDQUFDYSxVQUFVO0FBQ2xCLGNBQUlBLE1BQU1FLFdBQVdULFVBQVVFLFFBQVNSLGNBQWEsS0FBSztBQUFBLFFBQzVEO0FBQUEsUUFDQSxTQUFTLE1BQU1BLGFBQWEsS0FBSztBQUFBLFFBRWpDLGlDQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLElBQUcsZ0JBQWdCQyxtQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxjQUM1QkMsZUFBZSx1QkFBQyxPQUFFLElBQUcsc0JBQXNCQSx5QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxpQkFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsVUFBTyxNQUFLLFVBQVMsU0FBUSxTQUFRLE1BQUssUUFBTyxjQUFXLGdCQUFlLFNBQVMsTUFBTUYsYUFBYSxLQUFLLEdBQzNHLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFBZUcsWUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxVQUN0Q0MsVUFBVSx1QkFBQyxTQUFJLFdBQVUsaUJBQWlCQSxvQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxhQVhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQTtBQUFBLE1BdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdCQTtBQUFBLElBQ0FPLFNBQVNLO0FBQUFBLEVBQ1g7QUFDRjtBQUFDWCxHQTFDZVAsUUFBTTtBQUFBLEtBQU5BO0FBQU0sSUFBQW1CO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJlZiIsImNyZWF0ZVBvcnRhbCIsIlgiLCJCdXR0b24iLCJEaWFsb2ciLCJvcGVuIiwib25PcGVuQ2hhbmdlIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImNoaWxkcmVuIiwiZm9vdGVyIiwiX3MiLCJkaWFsb2dSZWYiLCJkaWFsb2ciLCJjdXJyZW50Iiwic2hvd01vZGFsIiwiY2xvc2UiLCJkb2N1bWVudCIsInVuZGVmaW5lZCIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJib2R5IiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRGlhbG9nLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdHlwZSBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZVBvcnRhbCB9IGZyb20gXCJyZWFjdC1kb21cIjtcbmltcG9ydCB7IFggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi9CdXR0b25cIjtcblxudHlwZSBEaWFsb2dQcm9wcyA9IHtcbiAgb3BlbjogYm9vbGVhbjtcbiAgb25PcGVuQ2hhbmdlOiAob3BlbjogYm9vbGVhbikgPT4gdm9pZDtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIGNoaWxkcmVuOiBSZWFjdE5vZGU7XG4gIGZvb3Rlcj86IFJlYWN0Tm9kZTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBEaWFsb2coe1xuICBvcGVuLCBvbk9wZW5DaGFuZ2UsIHRpdGxlLCBkZXNjcmlwdGlvbiwgY2hpbGRyZW4sIGZvb3Rlcixcbn06IERpYWxvZ1Byb3BzKSB7XG4gIGNvbnN0IGRpYWxvZ1JlZiA9IHVzZVJlZjxIVE1MRGlhbG9nRWxlbWVudD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBkaWFsb2cgPSBkaWFsb2dSZWYuY3VycmVudDtcbiAgICBpZiAoIWRpYWxvZykgcmV0dXJuO1xuICAgIGlmIChvcGVuICYmICFkaWFsb2cub3BlbikgZGlhbG9nLnNob3dNb2RhbCgpO1xuICAgIGlmICghb3BlbiAmJiBkaWFsb2cub3BlbikgZGlhbG9nLmNsb3NlKCk7XG4gIH0sIFtvcGVuXSk7XG5cbiAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIGNyZWF0ZVBvcnRhbChcbiAgICA8ZGlhbG9nXG4gICAgICByZWY9e2RpYWxvZ1JlZn1cbiAgICAgIGNsYXNzTmFtZT1cImRpYWxvZ1wiXG4gICAgICBhcmlhLWxhYmVsbGVkYnk9XCJkaWFsb2ctdGl0bGVcIlxuICAgICAgYXJpYS1kZXNjcmliZWRieT17ZGVzY3JpcHRpb24gPyBcImRpYWxvZy1kZXNjcmlwdGlvblwiIDogdW5kZWZpbmVkfVxuICAgICAgb25DYW5jZWw9eyhldmVudCkgPT4geyBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyBvbk9wZW5DaGFuZ2UoZmFsc2UpOyB9fVxuICAgICAgb25DbGljaz17KGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChldmVudC50YXJnZXQgPT09IGRpYWxvZ1JlZi5jdXJyZW50KSBvbk9wZW5DaGFuZ2UoZmFsc2UpO1xuICAgICAgfX1cbiAgICAgIG9uQ2xvc2U9eygpID0+IG9uT3BlbkNoYW5nZShmYWxzZSl9XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkaWFsb2ctcGFuZWxcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkaWFsb2ctaGVhZGVyXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMiBpZD1cImRpYWxvZy10aXRsZVwiPnt0aXRsZX08L2gyPlxuICAgICAgICAgICAge2Rlc2NyaXB0aW9uICYmIDxwIGlkPVwiZGlhbG9nLWRlc2NyaXB0aW9uXCI+e2Rlc2NyaXB0aW9ufTwvcD59XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cImdob3N0XCIgc2l6ZT1cImljb25cIiBhcmlhLWxhYmVsPVwiQ2xvc2UgZGlhbG9nXCIgb25DbGljaz17KCkgPT4gb25PcGVuQ2hhbmdlKGZhbHNlKX0+XG4gICAgICAgICAgICA8WCBzaXplPXsxOH0gLz5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlhbG9nLWJvZHlcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgICAgIHtmb290ZXIgJiYgPGRpdiBjbGFzc05hbWU9XCJkaWFsb2ctZm9vdGVyXCI+e2Zvb3Rlcn08L2Rpdj59XG4gICAgICA8L2Rpdj5cbiAgICA8L2RpYWxvZz4sXG4gICAgZG9jdW1lbnQuYm9keSxcbiAgKTtcbn1cbiJdLCJmaWxlIjoiRDovTmV3X2ZvbGRlcl8oMikvU29mdHdhcmUgZGV2ZWxvcG1lbnQgUHJvamVjdC9iYW5raW5nLXBsYXRmcm9tL2Zyb250ZW5kL2JhbmtpbmctcGxhdGZvcm0tZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvdWkvRGlhbG9nLnRzeCJ9