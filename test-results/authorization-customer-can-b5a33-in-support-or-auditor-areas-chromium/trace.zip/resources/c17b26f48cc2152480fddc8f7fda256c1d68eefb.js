import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { BrowserRouter, Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import { ThemeProvider } from "/src/app/providers/ThemeProvider.tsx";
import { AuthProvider, useAuth } from "/src/app/providers/AuthProvider.tsx";
import { Toaster } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { PublicLayout } from "/src/features/public/components/PublicLayout.tsx";
import { AboutPage } from "/src/features/public/pages/AboutPage.tsx";
import { LoginPage } from "/src/features/public/pages/LoginPage.tsx";
import { RegisterPage } from "/src/features/public/pages/RegisterPage.tsx";
import { VerifyEmailPage } from "/src/features/public/pages/VerifyEmailPage.tsx";
import { ForgotPasswordPage } from "/src/features/public/pages/ForgotPasswordPage.tsx";
import { ResetPasswordPage } from "/src/features/public/pages/ResetPasswordPage.tsx";
import { RequireAuth, RequireRole, roleHome } from "/src/app/router/RoleRoutes.tsx";
import { PlaceholderPage, PortalDashboard, PortalLayout } from "/src/components/layout/PortalLayout.tsx";
import { CustomerDashboardPage, TransactionsPage, TransactionDetailsPage, DepositPage, WithdrawalPage, TransferPage, BeneficiariesPage, NotificationsPage, ProfilePage, DecisionExplanationsPage, FxRequestDetailsPage } from "/src/features/customer/phase6/CustomerPages.tsx";
import { AccountListPage } from "/src/features/customer/accounts/pages/AccountListPage.tsx";
import { AccountDetailsPage } from "/src/features/customer/accounts/pages/AccountDetailsPage.tsx";
function EntryRedirect() {
  _s();
  const { user, isAuthenticated, isInitializing } = useAuth();
  if (isInitializing) return /* @__PURE__ */ jsxDEV("div", { className: "route-state", role: "status", children: "Restoring your secure session…" }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 20,
    columnNumber: 30
  }, this);
  return /* @__PURE__ */ jsxDEV(Navigate, { to: isAuthenticated && user ? roleHome(user.role) : "/login", replace: true }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}
_s(EntryRedirect, "td/CuRkBiI1NdY+3CfCfuP3+SWE=", false, function() {
  return [useAuth];
});
_c = EntryRedirect;
function ForbiddenPage() {
  return /* @__PURE__ */ jsxDEV("main", { className: "system-page", children: /* @__PURE__ */ jsxDEV("div", { className: "system-card", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "system-code", children: "403" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 24,
      columnNumber: 69
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { children: "Access restricted" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 24,
      columnNumber: 109
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "Your account does not have permission to view this page." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 24,
      columnNumber: 135
    }, this),
    /* @__PURE__ */ jsxDEV("a", { className: "btn btn-primary", href: "/", children: "Return to home" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 24,
      columnNumber: 198
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 24,
    columnNumber: 40
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 24,
    columnNumber: 10
  }, this);
}
_c2 = ForbiddenPage;
function MissingPage() {
  return /* @__PURE__ */ jsxDEV("main", { className: "system-page", children: /* @__PURE__ */ jsxDEV("div", { className: "system-card", children: [
    /* @__PURE__ */ jsxDEV("span", { className: "system-code", children: "404" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 27,
      columnNumber: 69
    }, this),
    /* @__PURE__ */ jsxDEV("h1", { children: "Page not found" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 27,
      columnNumber: 109
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: "The page you requested does not exist." }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 27,
      columnNumber: 132
    }, this),
    /* @__PURE__ */ jsxDEV("a", { className: "btn btn-primary", href: "/", children: "Return to home" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 27,
      columnNumber: 177
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 27,
    columnNumber: 40
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 27,
    columnNumber: 10
  }, this);
}
_c3 = MissingPage;
const page = (title) => /* @__PURE__ */ jsxDEV(PlaceholderPage, { title }, void 0, false, {
  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
  lineNumber: 29,
  columnNumber: 33
}, this);
function App() {
  return /* @__PURE__ */ jsxDEV(ThemeProvider, { children: /* @__PURE__ */ jsxDEV(AuthProvider, { children: /* @__PURE__ */ jsxDEV(BrowserRouter, { children: [
    /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(PublicLayout, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 37,
        columnNumber: 29
      }, this), children: [
        /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(AboutPage, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 38,
          columnNumber: 40
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 38,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/about", element: /* @__PURE__ */ jsxDEV(AboutPage, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 39,
          columnNumber: 45
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 39,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(LoginPage, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 40,
          columnNumber: 45
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 40,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/register", element: /* @__PURE__ */ jsxDEV(RegisterPage, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 41,
          columnNumber: 48
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 41,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/verify-email", element: /* @__PURE__ */ jsxDEV(VerifyEmailPage, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 42,
          columnNumber: 52
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 42,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/forgot-password", element: /* @__PURE__ */ jsxDEV(ForgotPasswordPage, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 43,
          columnNumber: 55
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 43,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/reset-password", element: /* @__PURE__ */ jsxDEV(ResetPasswordPage, {}, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 44,
          columnNumber: 54
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 44,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 37,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(RequireAuth, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 46,
        columnNumber: 29
      }, this), children: [
        /* @__PURE__ */ jsxDEV(Route, { path: "/customer", element: /* @__PURE__ */ jsxDEV(RequireRole, { allowed: ["CUSTOMER"] }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 47,
          columnNumber: 48
        }, this), children: /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(PortalLayout, { role: "CUSTOMER" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 48,
          columnNumber: 33
        }, this), children: [
          /* @__PURE__ */ jsxDEV(Route, { index: true, element: /* @__PURE__ */ jsxDEV(Navigate, { to: "dashboard", replace: true }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 49,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 49,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "dashboard", element: /* @__PURE__ */ jsxDEV(CustomerDashboardPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 50,
            columnNumber: 52
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 50,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "accounts", element: /* @__PURE__ */ jsxDEV(AccountListPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 51,
            columnNumber: 51
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 51,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "accounts/:accountId", element: /* @__PURE__ */ jsxDEV(AccountDetailsPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 51,
            columnNumber: 117
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 51,
            columnNumber: 74
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "transactions", element: /* @__PURE__ */ jsxDEV(TransactionsPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 52,
            columnNumber: 55
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 52,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "transactions/:transactionId", element: /* @__PURE__ */ jsxDEV(TransactionDetailsPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 52,
            columnNumber: 130
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 52,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "transfer", element: /* @__PURE__ */ jsxDEV(TransferPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 53,
            columnNumber: 51
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 53,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "deposit", element: /* @__PURE__ */ jsxDEV(DepositPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 53,
            columnNumber: 102
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 53,
            columnNumber: 71
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "withdrawal", element: /* @__PURE__ */ jsxDEV(WithdrawalPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 53,
            columnNumber: 155
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 53,
            columnNumber: 121
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "beneficiaries", element: /* @__PURE__ */ jsxDEV(BeneficiariesPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 54,
            columnNumber: 56
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 54,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "notifications", element: /* @__PURE__ */ jsxDEV(NotificationsPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 55,
            columnNumber: 56
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 55,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "profile", element: /* @__PURE__ */ jsxDEV(ProfilePage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 56,
            columnNumber: 50
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 56,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "decision-explanations", element: /* @__PURE__ */ jsxDEV(DecisionExplanationsPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 56,
            columnNumber: 114
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 56,
            columnNumber: 69
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "fx-requests/:requestId", element: /* @__PURE__ */ jsxDEV(FxRequestDetailsPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 56,
            columnNumber: 192
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 56,
            columnNumber: 146
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 48,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 47,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/admin", element: /* @__PURE__ */ jsxDEV(RequireRole, { allowed: ["ADMIN"] }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 59,
          columnNumber: 45
        }, this), children: /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(PortalLayout, { role: "ADMIN" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 60,
          columnNumber: 33
        }, this), children: [
          /* @__PURE__ */ jsxDEV(Route, { index: true, element: /* @__PURE__ */ jsxDEV(Navigate, { to: "dashboard", replace: true }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 61,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 61,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "dashboard", element: /* @__PURE__ */ jsxDEV(PortalDashboard, { role: "ADMIN" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 62,
            columnNumber: 52
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 62,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "users", element: page("Users & Status") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 63,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "accounts", element: page("Accounts") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 64,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "transactions", element: /* @__PURE__ */ jsxDEV(TransactionsPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 65,
            columnNumber: 55
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 65,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "transactions/:transactionId", element: /* @__PURE__ */ jsxDEV(TransactionDetailsPage, {}, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 65,
            columnNumber: 130
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 65,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "currencies", element: page("Currencies") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 66,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "exchange-rates", element: page("Exchange Rates") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 67,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "reserves", element: page("Currency Reserves") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 68,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "fx-approvals", element: page("FX Approvals") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 69,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "risk-reviews", element: page("Risk Reviews") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 70,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "fraud", element: page("Fraud Management") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 71,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "monitoring", element: page("Monitoring") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 72,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "audit-logs", element: page("Audit Logs") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 73,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 60,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 59,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/support", element: /* @__PURE__ */ jsxDEV(RequireRole, { allowed: ["SUPPORT"] }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 76,
          columnNumber: 47
        }, this), children: /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(PortalLayout, { role: "SUPPORT" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 77,
          columnNumber: 33
        }, this), children: [
          /* @__PURE__ */ jsxDEV(Route, { index: true, element: /* @__PURE__ */ jsxDEV(Navigate, { to: "dashboard", replace: true }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 78,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 78,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "dashboard", element: /* @__PURE__ */ jsxDEV(PortalDashboard, { role: "SUPPORT" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 79,
            columnNumber: 52
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 79,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "customers", element: page("Customer Lookup") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 80,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "accounts", element: page("Account Assistance") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 81,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "transactions", element: page("Transaction Assistance") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 82,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "beneficiaries", element: page("Beneficiary Assistance") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 83,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "tickets", element: page("Support Tickets") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 84,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "operations", element: page("Support Operations") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 85,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "fx-requests", element: page("FX Requests (Read)") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 86,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "audit-logs", element: page("Support Audit Logs") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 87,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 77,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 76,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "/auditor", element: /* @__PURE__ */ jsxDEV(RequireRole, { allowed: ["AUDITOR"] }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 90,
          columnNumber: 47
        }, this), children: /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(PortalLayout, { role: "AUDITOR" }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 91,
          columnNumber: 33
        }, this), children: [
          /* @__PURE__ */ jsxDEV(Route, { index: true, element: /* @__PURE__ */ jsxDEV(Navigate, { to: "dashboard", replace: true }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 92,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 92,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "dashboard", element: /* @__PURE__ */ jsxDEV(PortalDashboard, { role: "AUDITOR" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 93,
            columnNumber: 52
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 93,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "audit-logs", element: page("Audit Logs (Read Only)") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 94,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "transactions", element: page("Transactions (Read Only)") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 95,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "account-activity", element: page("Account Activity") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 96,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "approvals", element: page("Approval Records") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 97,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "fx-requests", element: page("FX Requests (Read Only)") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 98,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "currencies", element: page("Currencies (Read Only)") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 99,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(Route, { path: "reserves", element: page("Reserves (Read Only)") }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
            lineNumber: 100,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 91,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
          lineNumber: 90,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 46,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/403", element: /* @__PURE__ */ jsxDEV(ForbiddenPage, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 104,
        columnNumber: 41
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 104,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/entry", element: /* @__PURE__ */ jsxDEV(EntryRedirect, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 105,
        columnNumber: 43
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 105,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV(MissingPage, {}, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 106,
        columnNumber: 38
      }, this) }, void 0, false, {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
        lineNumber: 106,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 36,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Toaster, { richColors: true, position: "top-right" }, void 0, false, {
      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
      lineNumber: 108,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 35,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 34,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx",
    lineNumber: 33,
    columnNumber: 5
  }, this);
}
_c4 = App;
export default App;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "EntryRedirect");
$RefreshReg$(_c2, "ForbiddenPage");
$RefreshReg$(_c3, "MissingPage");
$RefreshReg$(_c4, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/App.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUI2Qjs7QUFuQjdCLFNBQVNBLGVBQWVDLFVBQVVDLE9BQU9DLGNBQWM7QUFDdkQsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLGNBQWNDLGVBQWU7QUFDdEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyx5QkFBeUI7QUFDbEMsU0FBU0MsYUFBYUMsYUFBYUMsZ0JBQWdCO0FBQ25ELFNBQVNDLGlCQUFpQkMsaUJBQWlCQyxvQkFBb0I7QUFDL0QsU0FBU0MsdUJBQXVCQyxrQkFBa0JDLHdCQUF3QkMsYUFBYUMsZ0JBQWdCQyxjQUFjQyxtQkFBbUJDLG1CQUFtQkMsYUFBYUMsMEJBQTBCQyw0QkFBNEI7QUFDOU4sU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLDBCQUEwQjtBQUVuQyxTQUFTQyxnQkFBZ0I7QUFBQUMsS0FBQTtBQUN2QixRQUFNLEVBQUVDLE1BQU1DLGlCQUFpQkMsZUFBZSxJQUFJaEMsUUFBUTtBQUMxRCxNQUFJZ0MsZUFBZ0IsUUFBTyx1QkFBQyxTQUFJLFdBQVUsZUFBYyxNQUFLLFVBQVMsOENBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUU7QUFDcEcsU0FBTyx1QkFBQyxZQUFTLElBQUlELG1CQUFtQkQsT0FBT25CLFNBQVNtQixLQUFLRyxJQUFJLElBQUksVUFBVSxTQUFPLFFBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBK0U7QUFDeEY7QUFBQ0osR0FKUUQsZUFBYTtBQUFBLFVBQzhCNUIsT0FBTztBQUFBO0FBQUEsS0FEbEQ0QjtBQUtULFNBQVNNLGdCQUFnQjtBQUN2QixTQUFPLHVCQUFDLFVBQUssV0FBVSxlQUFjLGlDQUFDLFNBQUksV0FBVSxlQUFjO0FBQUEsMkJBQUMsVUFBSyxXQUFVLGVBQWMsbUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUFPLHVCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQjtBQUFBLElBQUssdUJBQUMsT0FBRSx3RUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJEO0FBQUEsSUFBSSx1QkFBQyxPQUFFLFdBQVUsbUJBQWtCLE1BQUssS0FBSSw4QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLE9BQXBOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBd04sS0FBdFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0UDtBQUNyUTtBQUFDQyxNQUZRRDtBQUdULFNBQVNFLGNBQWM7QUFDckIsU0FBTyx1QkFBQyxVQUFLLFdBQVUsZUFBYyxpQ0FBQyxTQUFJLFdBQVUsZUFBYztBQUFBLDJCQUFDLFVBQUssV0FBVSxlQUFjLG1CQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFBTyx1QkFBQyxRQUFHLDhCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0I7QUFBQSxJQUFLLHVCQUFDLE9BQUUsc0RBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QztBQUFBLElBQUksdUJBQUMsT0FBRSxXQUFVLG1CQUFrQixNQUFLLEtBQUksOEJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Q7QUFBQSxPQUEvTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1NLEtBQWpPO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBdU87QUFDaFA7QUFBQ0MsTUFGUUQ7QUFHVCxNQUFNRSxPQUFPQSxDQUFDQyxVQUFpQix1QkFBQyxtQkFBZ0IsU0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUE4QjtBQUU3RCxTQUFTQyxNQUFNO0FBQ2IsU0FDRSx1QkFBQyxpQkFDQyxpQ0FBQyxnQkFDQyxpQ0FBQyxpQkFDQztBQUFBLDJCQUFDLFVBQ0M7QUFBQSw2QkFBQyxTQUFNLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhLEdBQzNCO0FBQUEsK0JBQUMsU0FBTSxNQUFLLEtBQUksU0FBUyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVSxLQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsUUFDdkMsdUJBQUMsU0FBTSxNQUFLLFVBQVMsU0FBUyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVSxLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsUUFDNUMsdUJBQUMsU0FBTSxNQUFLLFVBQVMsU0FBUyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVSxLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRDO0FBQUEsUUFDNUMsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWEsS0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQ2xELHVCQUFDLFNBQU0sTUFBSyxpQkFBZ0IsU0FBUyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdCLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxRQUN6RCx1QkFBQyxTQUFNLE1BQUssb0JBQW1CLFNBQVMsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsUUFDL0QsdUJBQUMsU0FBTSxNQUFLLG1CQUFrQixTQUFTLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0IsS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFdBUC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxTQUFTLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWSxHQUMxQjtBQUFBLCtCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsZUFBWSxTQUFTLENBQUMsVUFBVSxLQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DLEdBQ2xFLGlDQUFDLFNBQU0sU0FBUyx1QkFBQyxnQkFBYSxNQUFLLGNBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkIsR0FDM0M7QUFBQSxpQ0FBQyxTQUFNLE9BQUssTUFBQyxTQUFTLHVCQUFDLFlBQVMsSUFBRyxhQUFZLFNBQU8sUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0MsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUN6RCx1QkFBQyxTQUFNLE1BQUssYUFBWSxTQUFTLHVCQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNCLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsVUFDMUQsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBUyx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQixLQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQUUsdUJBQUMsU0FBTSxNQUFLLHVCQUFzQixTQUFTLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsVUFDdEgsdUJBQUMsU0FBTSxNQUFLLGdCQUFlLFNBQVMsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUIsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUFFLHVCQUFDLFNBQU0sTUFBSywrQkFBOEIsU0FBUyx1QkFBQyw0QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QixLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQ3ZJLHVCQUFDLFNBQU0sTUFBSyxZQUFXLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYSxLQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQUUsdUJBQUMsU0FBTSxNQUFLLFdBQVUsU0FBUyx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFZLEtBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFBRSx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUFTLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWUsS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUN0Six1QkFBQyxTQUFNLE1BQUssaUJBQWdCLFNBQVMsdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0IsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUMxRCx1QkFBQyxTQUFNLE1BQUssaUJBQWdCLFNBQVMsdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0IsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUMxRCx1QkFBQyxTQUFNLE1BQUssV0FBVSxTQUFTLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVksS0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUFFLHVCQUFDLFNBQU0sTUFBSyx5QkFBd0IsU0FBUyx1QkFBQyw4QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QixLQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQUUsdUJBQUMsU0FBTSxNQUFLLDBCQUF5QixTQUFTLHVCQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCLEtBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsYUFSbk07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQSx1QkFBQyxTQUFNLE1BQUssVUFBUyxTQUFTLHVCQUFDLGVBQVksU0FBUyxDQUFDLE9BQU8sS0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxHQUM1RCxpQ0FBQyxTQUFNLFNBQVMsdUJBQUMsZ0JBQWEsTUFBSyxXQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCLEdBQ3hDO0FBQUEsaUNBQUMsU0FBTSxPQUFLLE1BQUMsU0FBUyx1QkFBQyxZQUFTLElBQUcsYUFBWSxTQUFPLFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDLEtBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxtQkFBZ0IsTUFBSyxXQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QixLQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRTtBQUFBLFVBQ2pFLHVCQUFDLFNBQU0sTUFBSyxTQUFRLFNBQVNGLEtBQUssZ0JBQWdCLEtBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsVUFDcEQsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBU0EsS0FBSyxVQUFVLEtBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsU0FBTSxNQUFLLGdCQUFlLFNBQVMsdUJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUIsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUFFLHVCQUFDLFNBQU0sTUFBSywrQkFBOEIsU0FBUyx1QkFBQyw0QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QixLQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQ3ZJLHVCQUFDLFNBQU0sTUFBSyxjQUFhLFNBQVNBLEtBQUssWUFBWSxLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLFVBQ3JELHVCQUFDLFNBQU0sTUFBSyxrQkFBaUIsU0FBU0EsS0FBSyxnQkFBZ0IsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxVQUM3RCx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTQSxLQUFLLG1CQUFtQixLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLFVBQzFELHVCQUFDLFNBQU0sTUFBSyxnQkFBZSxTQUFTQSxLQUFLLGNBQWMsS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUN6RCx1QkFBQyxTQUFNLE1BQUssZ0JBQWUsU0FBU0EsS0FBSyxjQUFjLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQsdUJBQUMsU0FBTSxNQUFLLFNBQVEsU0FBU0EsS0FBSyxrQkFBa0IsS0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Q7QUFBQSxVQUN0RCx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUFTQSxLQUFLLFlBQVksS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxVQUNyRCx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUFTQSxLQUFLLFlBQVksS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQ7QUFBQSxhQWJ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFNLE1BQUssWUFBVyxTQUFTLHVCQUFDLGVBQVksU0FBUyxDQUFDLFNBQVMsS0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQyxHQUNoRSxpQ0FBQyxTQUFNLFNBQVMsdUJBQUMsZ0JBQWEsTUFBSyxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCLEdBQzFDO0FBQUEsaUNBQUMsU0FBTSxPQUFLLE1BQUMsU0FBUyx1QkFBQyxZQUFTLElBQUcsYUFBWSxTQUFPLFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDLEtBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBUyx1QkFBQyxtQkFBZ0IsTUFBSyxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQixLQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRTtBQUFBLFVBQ25FLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVNBLEtBQUssaUJBQWlCLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBU0EsS0FBSyxvQkFBb0IsS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkQ7QUFBQSxVQUMzRCx1QkFBQyxTQUFNLE1BQUssZ0JBQWUsU0FBU0EsS0FBSyx3QkFBd0IsS0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxVQUNuRSx1QkFBQyxTQUFNLE1BQUssaUJBQWdCLFNBQVNBLEtBQUssd0JBQXdCLEtBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDcEUsdUJBQUMsU0FBTSxNQUFLLFdBQVUsU0FBU0EsS0FBSyxpQkFBaUIsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxVQUN2RCx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUFTQSxLQUFLLG9CQUFvQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQzdELHVCQUFDLFNBQU0sTUFBSyxlQUFjLFNBQVNBLEtBQUssb0JBQW9CLEtBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsVUFDOUQsdUJBQUMsU0FBTSxNQUFLLGNBQWEsU0FBU0EsS0FBSyxvQkFBb0IsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxhQVYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUNBLHVCQUFDLFNBQU0sTUFBSyxZQUFXLFNBQVMsdUJBQUMsZUFBWSxTQUFTLENBQUMsU0FBUyxLQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDLEdBQ2hFLGlDQUFDLFNBQU0sU0FBUyx1QkFBQyxnQkFBYSxNQUFLLGFBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEIsR0FDMUM7QUFBQSxpQ0FBQyxTQUFNLE9BQUssTUFBQyxTQUFTLHVCQUFDLFlBQVMsSUFBRyxhQUFZLFNBQU8sUUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0MsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUN6RCx1QkFBQyxTQUFNLE1BQUssYUFBWSxTQUFTLHVCQUFDLG1CQUFnQixNQUFLLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCLEtBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbkUsdUJBQUMsU0FBTSxNQUFLLGNBQWEsU0FBU0EsS0FBSyx3QkFBd0IsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxVQUNqRSx1QkFBQyxTQUFNLE1BQUssZ0JBQWUsU0FBU0EsS0FBSywwQkFBMEIsS0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxVQUNyRSx1QkFBQyxTQUFNLE1BQUssb0JBQW1CLFNBQVNBLEtBQUssa0JBQWtCLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsVUFDakUsdUJBQUMsU0FBTSxNQUFLLGFBQVksU0FBU0EsS0FBSyxrQkFBa0IsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUMxRCx1QkFBQyxTQUFNLE1BQUssZUFBYyxTQUFTQSxLQUFLLHlCQUF5QixLQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRTtBQUFBLFVBQ25FLHVCQUFDLFNBQU0sTUFBSyxjQUFhLFNBQVNBLEtBQUssd0JBQXdCLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFO0FBQUEsVUFDakUsdUJBQUMsU0FBTSxNQUFLLFlBQVcsU0FBU0EsS0FBSyxzQkFBc0IsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxhQVQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeURBO0FBQUEsTUFDQSx1QkFBQyxTQUFNLE1BQUssUUFBTyxTQUFTLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZDO0FBQUEsTUFDN0MsdUJBQUMsU0FBTSxNQUFLLFVBQVMsU0FBUyx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWMsS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQztBQUFBLE1BQy9DLHVCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZLEtBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0M7QUFBQSxTQXRFMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVFQTtBQUFBLElBQ0EsdUJBQUMsV0FBUSxZQUFVLE1BQUMsVUFBUyxlQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdDO0FBQUEsT0F6RTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwRUEsS0EzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTRFQSxLQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOEVBO0FBRUo7QUFBQ0csTUFsRlFEO0FBbUZULGVBQWVBO0FBQUksSUFBQUUsSUFBQVAsS0FBQUUsS0FBQUk7QUFBQSxhQUFBQyxJQUFBO0FBQUEsYUFBQVAsS0FBQTtBQUFBLGFBQUFFLEtBQUE7QUFBQSxhQUFBSSxLQUFBIiwibmFtZXMiOlsiQnJvd3NlclJvdXRlciIsIk5hdmlnYXRlIiwiUm91dGUiLCJSb3V0ZXMiLCJUaGVtZVByb3ZpZGVyIiwiQXV0aFByb3ZpZGVyIiwidXNlQXV0aCIsIlRvYXN0ZXIiLCJQdWJsaWNMYXlvdXQiLCJBYm91dFBhZ2UiLCJMb2dpblBhZ2UiLCJSZWdpc3RlclBhZ2UiLCJWZXJpZnlFbWFpbFBhZ2UiLCJGb3Jnb3RQYXNzd29yZFBhZ2UiLCJSZXNldFBhc3N3b3JkUGFnZSIsIlJlcXVpcmVBdXRoIiwiUmVxdWlyZVJvbGUiLCJyb2xlSG9tZSIsIlBsYWNlaG9sZGVyUGFnZSIsIlBvcnRhbERhc2hib2FyZCIsIlBvcnRhbExheW91dCIsIkN1c3RvbWVyRGFzaGJvYXJkUGFnZSIsIlRyYW5zYWN0aW9uc1BhZ2UiLCJUcmFuc2FjdGlvbkRldGFpbHNQYWdlIiwiRGVwb3NpdFBhZ2UiLCJXaXRoZHJhd2FsUGFnZSIsIlRyYW5zZmVyUGFnZSIsIkJlbmVmaWNpYXJpZXNQYWdlIiwiTm90aWZpY2F0aW9uc1BhZ2UiLCJQcm9maWxlUGFnZSIsIkRlY2lzaW9uRXhwbGFuYXRpb25zUGFnZSIsIkZ4UmVxdWVzdERldGFpbHNQYWdlIiwiQWNjb3VudExpc3RQYWdlIiwiQWNjb3VudERldGFpbHNQYWdlIiwiRW50cnlSZWRpcmVjdCIsIl9zIiwidXNlciIsImlzQXV0aGVudGljYXRlZCIsImlzSW5pdGlhbGl6aW5nIiwicm9sZSIsIkZvcmJpZGRlblBhZ2UiLCJfYzIiLCJNaXNzaW5nUGFnZSIsIl9jMyIsInBhZ2UiLCJ0aXRsZSIsIkFwcCIsIl9jNCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnJvd3NlclJvdXRlciwgTmF2aWdhdGUsIFJvdXRlLCBSb3V0ZXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgVGhlbWVQcm92aWRlciB9IGZyb20gXCIuL2FwcC9wcm92aWRlcnMvVGhlbWVQcm92aWRlclwiO1xuaW1wb3J0IHsgQXV0aFByb3ZpZGVyLCB1c2VBdXRoIH0gZnJvbSBcIi4vYXBwL3Byb3ZpZGVycy9BdXRoUHJvdmlkZXJcIjtcbmltcG9ydCB7IFRvYXN0ZXIgfSBmcm9tIFwic29ubmVyXCI7XG5pbXBvcnQgeyBQdWJsaWNMYXlvdXQgfSBmcm9tIFwiLi9mZWF0dXJlcy9wdWJsaWMvY29tcG9uZW50cy9QdWJsaWNMYXlvdXRcIjtcbmltcG9ydCB7IEFib3V0UGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3B1YmxpYy9wYWdlcy9BYm91dFBhZ2VcIjtcbmltcG9ydCB7IExvZ2luUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3B1YmxpYy9wYWdlcy9Mb2dpblBhZ2VcIjtcbmltcG9ydCB7IFJlZ2lzdGVyUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3B1YmxpYy9wYWdlcy9SZWdpc3RlclBhZ2VcIjtcbmltcG9ydCB7IFZlcmlmeUVtYWlsUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3B1YmxpYy9wYWdlcy9WZXJpZnlFbWFpbFBhZ2VcIjtcbmltcG9ydCB7IEZvcmdvdFBhc3N3b3JkUGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL3B1YmxpYy9wYWdlcy9Gb3Jnb3RQYXNzd29yZFBhZ2VcIjtcbmltcG9ydCB7IFJlc2V0UGFzc3dvcmRQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvcHVibGljL3BhZ2VzL1Jlc2V0UGFzc3dvcmRQYWdlXCI7XG5pbXBvcnQgeyBSZXF1aXJlQXV0aCwgUmVxdWlyZVJvbGUsIHJvbGVIb21lIH0gZnJvbSBcIi4vYXBwL3JvdXRlci9Sb2xlUm91dGVzXCI7XG5pbXBvcnQgeyBQbGFjZWhvbGRlclBhZ2UsIFBvcnRhbERhc2hib2FyZCwgUG9ydGFsTGF5b3V0IH0gZnJvbSBcIi4vY29tcG9uZW50cy9sYXlvdXQvUG9ydGFsTGF5b3V0XCI7XG5pbXBvcnQgeyBDdXN0b21lckRhc2hib2FyZFBhZ2UsIFRyYW5zYWN0aW9uc1BhZ2UsIFRyYW5zYWN0aW9uRGV0YWlsc1BhZ2UsIERlcG9zaXRQYWdlLCBXaXRoZHJhd2FsUGFnZSwgVHJhbnNmZXJQYWdlLCBCZW5lZmljaWFyaWVzUGFnZSwgTm90aWZpY2F0aW9uc1BhZ2UsIFByb2ZpbGVQYWdlLCBEZWNpc2lvbkV4cGxhbmF0aW9uc1BhZ2UsIEZ4UmVxdWVzdERldGFpbHNQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvY3VzdG9tZXIvcGhhc2U2L0N1c3RvbWVyUGFnZXNcIjtcbmltcG9ydCB7IEFjY291bnRMaXN0UGFnZSB9IGZyb20gXCIuL2ZlYXR1cmVzL2N1c3RvbWVyL2FjY291bnRzL3BhZ2VzL0FjY291bnRMaXN0UGFnZVwiO1xuaW1wb3J0IHsgQWNjb3VudERldGFpbHNQYWdlIH0gZnJvbSBcIi4vZmVhdHVyZXMvY3VzdG9tZXIvYWNjb3VudHMvcGFnZXMvQWNjb3VudERldGFpbHNQYWdlXCI7XG5cbmZ1bmN0aW9uIEVudHJ5UmVkaXJlY3QoKSB7XG4gIGNvbnN0IHsgdXNlciwgaXNBdXRoZW50aWNhdGVkLCBpc0luaXRpYWxpemluZyB9ID0gdXNlQXV0aCgpO1xuICBpZiAoaXNJbml0aWFsaXppbmcpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInJvdXRlLXN0YXRlXCIgcm9sZT1cInN0YXR1c1wiPlJlc3RvcmluZyB5b3VyIHNlY3VyZSBzZXNzaW9u4oCmPC9kaXY+O1xuICByZXR1cm4gPE5hdmlnYXRlIHRvPXtpc0F1dGhlbnRpY2F0ZWQgJiYgdXNlciA/IHJvbGVIb21lKHVzZXIucm9sZSkgOiBcIi9sb2dpblwifSByZXBsYWNlIC8+O1xufVxuZnVuY3Rpb24gRm9yYmlkZGVuUGFnZSgpIHtcbiAgcmV0dXJuIDxtYWluIGNsYXNzTmFtZT1cInN5c3RlbS1wYWdlXCI+PGRpdiBjbGFzc05hbWU9XCJzeXN0ZW0tY2FyZFwiPjxzcGFuIGNsYXNzTmFtZT1cInN5c3RlbS1jb2RlXCI+NDAzPC9zcGFuPjxoMT5BY2Nlc3MgcmVzdHJpY3RlZDwvaDE+PHA+WW91ciBhY2NvdW50IGRvZXMgbm90IGhhdmUgcGVybWlzc2lvbiB0byB2aWV3IHRoaXMgcGFnZS48L3A+PGEgY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5XCIgaHJlZj1cIi9cIj5SZXR1cm4gdG8gaG9tZTwvYT48L2Rpdj48L21haW4+O1xufVxuZnVuY3Rpb24gTWlzc2luZ1BhZ2UoKSB7XG4gIHJldHVybiA8bWFpbiBjbGFzc05hbWU9XCJzeXN0ZW0tcGFnZVwiPjxkaXYgY2xhc3NOYW1lPVwic3lzdGVtLWNhcmRcIj48c3BhbiBjbGFzc05hbWU9XCJzeXN0ZW0tY29kZVwiPjQwNDwvc3Bhbj48aDE+UGFnZSBub3QgZm91bmQ8L2gxPjxwPlRoZSBwYWdlIHlvdSByZXF1ZXN0ZWQgZG9lcyBub3QgZXhpc3QuPC9wPjxhIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeVwiIGhyZWY9XCIvXCI+UmV0dXJuIHRvIGhvbWU8L2E+PC9kaXY+PC9tYWluPjtcbn1cbmNvbnN0IHBhZ2UgPSAodGl0bGU6c3RyaW5nKSA9PiA8UGxhY2Vob2xkZXJQYWdlIHRpdGxlPXt0aXRsZX0vPjtcblxuZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gKFxuICAgIDxUaGVtZVByb3ZpZGVyPlxuICAgICAgPEF1dGhQcm92aWRlcj5cbiAgICAgICAgPEJyb3dzZXJSb3V0ZXI+XG4gICAgICAgICAgPFJvdXRlcz5cbiAgICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UHVibGljTGF5b3V0IC8+fT5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEFib3V0UGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvYWJvdXRcIiBlbGVtZW50PXs8QWJvdXRQYWdlIC8+fSAvPlxuICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxMb2dpblBhZ2UgLz59IC8+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3JlZ2lzdGVyXCIgZWxlbWVudD17PFJlZ2lzdGVyUGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvdmVyaWZ5LWVtYWlsXCIgZWxlbWVudD17PFZlcmlmeUVtYWlsUGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvZm9yZ290LXBhc3N3b3JkXCIgZWxlbWVudD17PEZvcmdvdFBhc3N3b3JkUGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVzZXQtcGFzc3dvcmRcIiBlbGVtZW50PXs8UmVzZXRQYXNzd29yZFBhZ2UgLz59IC8+XG4gICAgICAgICAgICA8L1JvdXRlPlxuICAgICAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxSZXF1aXJlQXV0aC8+fT5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY3VzdG9tZXJcIiBlbGVtZW50PXs8UmVxdWlyZVJvbGUgYWxsb3dlZD17W1wiQ1VTVE9NRVJcIl19Lz59PlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UG9ydGFsTGF5b3V0IHJvbGU9XCJDVVNUT01FUlwiLz59PlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIGluZGV4IGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cImRhc2hib2FyZFwiIHJlcGxhY2UvPn0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJkYXNoYm9hcmRcIiBlbGVtZW50PXs8Q3VzdG9tZXJEYXNoYm9hcmRQYWdlLz59Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiYWNjb3VudHNcIiBlbGVtZW50PXs8QWNjb3VudExpc3RQYWdlLz59Lz48Um91dGUgcGF0aD1cImFjY291bnRzLzphY2NvdW50SWRcIiBlbGVtZW50PXs8QWNjb3VudERldGFpbHNQYWdlLz59Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwidHJhbnNhY3Rpb25zXCIgZWxlbWVudD17PFRyYW5zYWN0aW9uc1BhZ2UvPn0vPjxSb3V0ZSBwYXRoPVwidHJhbnNhY3Rpb25zLzp0cmFuc2FjdGlvbklkXCIgZWxlbWVudD17PFRyYW5zYWN0aW9uRGV0YWlsc1BhZ2UvPn0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJ0cmFuc2ZlclwiIGVsZW1lbnQ9ezxUcmFuc2ZlclBhZ2UvPn0vPjxSb3V0ZSBwYXRoPVwiZGVwb3NpdFwiIGVsZW1lbnQ9ezxEZXBvc2l0UGFnZS8+fS8+PFJvdXRlIHBhdGg9XCJ3aXRoZHJhd2FsXCIgZWxlbWVudD17PFdpdGhkcmF3YWxQYWdlLz59Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiYmVuZWZpY2lhcmllc1wiIGVsZW1lbnQ9ezxCZW5lZmljaWFyaWVzUGFnZS8+fS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIm5vdGlmaWNhdGlvbnNcIiBlbGVtZW50PXs8Tm90aWZpY2F0aW9uc1BhZ2UvPn0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJwcm9maWxlXCIgZWxlbWVudD17PFByb2ZpbGVQYWdlLz59Lz48Um91dGUgcGF0aD1cImRlY2lzaW9uLWV4cGxhbmF0aW9uc1wiIGVsZW1lbnQ9ezxEZWNpc2lvbkV4cGxhbmF0aW9uc1BhZ2UvPn0vPjxSb3V0ZSBwYXRoPVwiZngtcmVxdWVzdHMvOnJlcXVlc3RJZFwiIGVsZW1lbnQ9ezxGeFJlcXVlc3REZXRhaWxzUGFnZS8+fS8+XG4gICAgICAgICAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvYWRtaW5cIiBlbGVtZW50PXs8UmVxdWlyZVJvbGUgYWxsb3dlZD17W1wiQURNSU5cIl19Lz59PlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UG9ydGFsTGF5b3V0IHJvbGU9XCJBRE1JTlwiLz59PlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIGluZGV4IGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cImRhc2hib2FyZFwiIHJlcGxhY2UvPn0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJkYXNoYm9hcmRcIiBlbGVtZW50PXs8UG9ydGFsRGFzaGJvYXJkIHJvbGU9XCJBRE1JTlwiLz59Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwidXNlcnNcIiBlbGVtZW50PXtwYWdlKFwiVXNlcnMgJiBTdGF0dXNcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiYWNjb3VudHNcIiBlbGVtZW50PXtwYWdlKFwiQWNjb3VudHNcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwidHJhbnNhY3Rpb25zXCIgZWxlbWVudD17PFRyYW5zYWN0aW9uc1BhZ2UvPn0vPjxSb3V0ZSBwYXRoPVwidHJhbnNhY3Rpb25zLzp0cmFuc2FjdGlvbklkXCIgZWxlbWVudD17PFRyYW5zYWN0aW9uRGV0YWlsc1BhZ2UvPn0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJjdXJyZW5jaWVzXCIgZWxlbWVudD17cGFnZShcIkN1cnJlbmNpZXNcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiZXhjaGFuZ2UtcmF0ZXNcIiBlbGVtZW50PXtwYWdlKFwiRXhjaGFuZ2UgUmF0ZXNcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwicmVzZXJ2ZXNcIiBlbGVtZW50PXtwYWdlKFwiQ3VycmVuY3kgUmVzZXJ2ZXNcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiZngtYXBwcm92YWxzXCIgZWxlbWVudD17cGFnZShcIkZYIEFwcHJvdmFsc1wiKX0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJyaXNrLXJldmlld3NcIiBlbGVtZW50PXtwYWdlKFwiUmlzayBSZXZpZXdzXCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cImZyYXVkXCIgZWxlbWVudD17cGFnZShcIkZyYXVkIE1hbmFnZW1lbnRcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwibW9uaXRvcmluZ1wiIGVsZW1lbnQ9e3BhZ2UoXCJNb25pdG9yaW5nXCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cImF1ZGl0LWxvZ3NcIiBlbGVtZW50PXtwYWdlKFwiQXVkaXQgTG9nc1wiKX0vPlxuICAgICAgICAgICAgICAgIDwvUm91dGU+XG4gICAgICAgICAgICAgIDwvUm91dGU+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL3N1cHBvcnRcIiBlbGVtZW50PXs8UmVxdWlyZVJvbGUgYWxsb3dlZD17W1wiU1VQUE9SVFwiXX0vPn0+XG4gICAgICAgICAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxQb3J0YWxMYXlvdXQgcm9sZT1cIlNVUFBPUlRcIi8+fT5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBpbmRleCBlbGVtZW50PXs8TmF2aWdhdGUgdG89XCJkYXNoYm9hcmRcIiByZXBsYWNlLz59Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiZGFzaGJvYXJkXCIgZWxlbWVudD17PFBvcnRhbERhc2hib2FyZCByb2xlPVwiU1VQUE9SVFwiLz59Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiY3VzdG9tZXJzXCIgZWxlbWVudD17cGFnZShcIkN1c3RvbWVyIExvb2t1cFwiKX0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJhY2NvdW50c1wiIGVsZW1lbnQ9e3BhZ2UoXCJBY2NvdW50IEFzc2lzdGFuY2VcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwidHJhbnNhY3Rpb25zXCIgZWxlbWVudD17cGFnZShcIlRyYW5zYWN0aW9uIEFzc2lzdGFuY2VcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiYmVuZWZpY2lhcmllc1wiIGVsZW1lbnQ9e3BhZ2UoXCJCZW5lZmljaWFyeSBBc3Npc3RhbmNlXCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cInRpY2tldHNcIiBlbGVtZW50PXtwYWdlKFwiU3VwcG9ydCBUaWNrZXRzXCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIm9wZXJhdGlvbnNcIiBlbGVtZW50PXtwYWdlKFwiU3VwcG9ydCBPcGVyYXRpb25zXCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cImZ4LXJlcXVlc3RzXCIgZWxlbWVudD17cGFnZShcIkZYIFJlcXVlc3RzIChSZWFkKVwiKX0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJhdWRpdC1sb2dzXCIgZWxlbWVudD17cGFnZShcIlN1cHBvcnQgQXVkaXQgTG9nc1wiKX0vPlxuICAgICAgICAgICAgICAgIDwvUm91dGU+XG4gICAgICAgICAgICAgIDwvUm91dGU+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2F1ZGl0b3JcIiBlbGVtZW50PXs8UmVxdWlyZVJvbGUgYWxsb3dlZD17W1wiQVVESVRPUlwiXX0vPn0+XG4gICAgICAgICAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxQb3J0YWxMYXlvdXQgcm9sZT1cIkFVRElUT1JcIi8+fT5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBpbmRleCBlbGVtZW50PXs8TmF2aWdhdGUgdG89XCJkYXNoYm9hcmRcIiByZXBsYWNlLz59Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiZGFzaGJvYXJkXCIgZWxlbWVudD17PFBvcnRhbERhc2hib2FyZCByb2xlPVwiQVVESVRPUlwiLz59Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiYXVkaXQtbG9nc1wiIGVsZW1lbnQ9e3BhZ2UoXCJBdWRpdCBMb2dzIChSZWFkIE9ubHkpXCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cInRyYW5zYWN0aW9uc1wiIGVsZW1lbnQ9e3BhZ2UoXCJUcmFuc2FjdGlvbnMgKFJlYWQgT25seSlcIil9Lz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiYWNjb3VudC1hY3Rpdml0eVwiIGVsZW1lbnQ9e3BhZ2UoXCJBY2NvdW50IEFjdGl2aXR5XCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cImFwcHJvdmFsc1wiIGVsZW1lbnQ9e3BhZ2UoXCJBcHByb3ZhbCBSZWNvcmRzXCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cImZ4LXJlcXVlc3RzXCIgZWxlbWVudD17cGFnZShcIkZYIFJlcXVlc3RzIChSZWFkIE9ubHkpXCIpfS8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cImN1cnJlbmNpZXNcIiBlbGVtZW50PXtwYWdlKFwiQ3VycmVuY2llcyAoUmVhZCBPbmx5KVwiKX0vPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCJyZXNlcnZlc1wiIGVsZW1lbnQ9e3BhZ2UoXCJSZXNlcnZlcyAoUmVhZCBPbmx5KVwiKX0vPlxuICAgICAgICAgICAgICAgIDwvUm91dGU+XG4gICAgICAgICAgICAgIDwvUm91dGU+XG4gICAgICAgICAgICA8L1JvdXRlPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvNDAzXCIgZWxlbWVudD17PEZvcmJpZGRlblBhZ2UvPn0vPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvZW50cnlcIiBlbGVtZW50PXs8RW50cnlSZWRpcmVjdC8+fS8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8TWlzc2luZ1BhZ2UvPn0vPlxuICAgICAgICAgIDwvUm91dGVzPlxuICAgICAgICAgIDxUb2FzdGVyIHJpY2hDb2xvcnMgcG9zaXRpb249XCJ0b3AtcmlnaHRcIiAvPlxuICAgICAgICA8L0Jyb3dzZXJSb3V0ZXI+XG4gICAgICA8L0F1dGhQcm92aWRlcj5cbiAgICA8L1RoZW1lUHJvdmlkZXI+XG4gICk7XG59XG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwiZmlsZSI6IkQ6L05ld19mb2xkZXJfKDIpL1NvZnR3YXJlIGRldmVsb3BtZW50IFByb2plY3QvYmFua2luZy1wbGF0ZnJvbS9mcm9udGVuZC9iYW5raW5nLXBsYXRmb3JtLWZyb250ZW5kL3NyYy9BcHAudHN4In0=