import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/public/pages/LoginPage.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d15d18f8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=d15d18f8"; const useState = __vite__cjsImport1_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=d15d18f8";
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  ArrowRight,
  KeyRound,
  ShieldCheck
} from "/node_modules/.vite/deps/lucide-react.js?v=d15d18f8";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=d15d18f8";
import { useAuth } from "/src/app/providers/AuthProvider.tsx";
import { AuthShell } from "/src/features/public/components/AuthShell.tsx";
import { normalizeApiError } from "/src/lib/api/apiError.ts";
import { roleHome } from "/src/app/router/RoleRoutes.tsx";
import { authApi } from "/src/features/auth/authApi.ts";
import { Dialog } from "/src/components/ui/Dialog.tsx";
export function LoginPage() {
  _s();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [remember, setRemember] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [resetStep, setResetStep] = useState("email");
  const [resetEmail, setResetEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [resetBusy, setResetBusy] = useState(false);
  const [resetError, setResetError] = useState("");
  const [resetMessage, setResetMessage] = useState("");
  async function submit(e) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    try {
      const user = await login({
        email: email.trim(),
        password
      });
      toast.success("Login successful");
      navigate(roleHome(user.role), {
        replace: true
      });
    } catch (err) {
      toast.error(normalizeApiError(err).message);
    } finally {
      setBusy(false);
    }
  }
  function clearResetState() {
    setResetStep("email");
    setResetEmail("");
    setOtp("");
    setResetToken("");
    setNewPassword("");
    setConfirmPassword("");
    setShowNewPassword(false);
    setResetError("");
    setResetMessage("");
    setResetBusy(false);
  }
  function openReset() {
    clearResetState();
    setResetEmail(email.trim());
    setResetOpen(true);
  }
  function closeReset(open) {
    setResetOpen(open);
    if (!open) {
      clearResetState();
    }
  }
  async function requestOtp(e) {
    e.preventDefault();
    if (resetBusy) return;
    const cleanEmail = resetEmail.trim().toLowerCase();
    if (!cleanEmail) {
      setResetError("Please enter your registered email address.");
      return;
    }
    setResetError("");
    setResetMessage("");
    setResetBusy(true);
    try {
      await authApi.requestPasswordReset(cleanEmail);
      setResetEmail(cleanEmail);
      setOtp("");
      setResetStep("otp");
      setResetMessage(
        "If an eligible account exists for this email, a verification code has been sent."
      );
    } catch (err) {
      setResetError(normalizeApiError(err).message);
    } finally {
      setResetBusy(false);
    }
  }
  async function verifyOtp(e) {
    e.preventDefault();
    if (resetBusy) return;
    const cleanOtp = otp.trim();
    if (!/^\d{6}$/.test(cleanOtp)) {
      setResetError("Please enter a valid 6-digit verification code.");
      return;
    }
    setResetError("");
    setResetMessage("");
    setResetBusy(true);
    try {
      const result = await authApi.verifyPasswordResetOtp(
        resetEmail.trim(),
        cleanOtp
      );
      if (!result?.resetToken) {
        throw new Error(
          "The verification response did not contain a reset token. Please try again."
        );
      }
      setResetToken(result.resetToken);
      setResetStep("password");
      setOtp("");
      setResetError("");
      setResetMessage(
        "Your email has been verified. You can now create a new password."
      );
    } catch (err) {
      setResetError(normalizeApiError(err).message);
    } finally {
      setResetBusy(false);
    }
  }
  async function submitNewPassword(e) {
    e.preventDefault();
    if (resetBusy) return;
    if (newPassword.length < 8 || newPassword.length > 128) {
      setResetError(
        "Password must contain between 8 and 128 characters."
      );
      return;
    }
    if (newPassword !== confirmPassword) {
      setResetError("Your passwords do not match.");
      return;
    }
    if (!resetToken) {
      setResetError(
        "Your password reset session has expired. Please request a new verification code."
      );
      setResetStep("email");
      setOtp("");
      return;
    }
    setResetError("");
    setResetMessage("");
    setResetBusy(true);
    try {
      await authApi.resetPassword({
        token: resetToken,
        password: newPassword
      });
      setResetOpen(false);
      clearResetState();
      setPassword("");
      toast.success(
        "Password reset successful. Please sign in with your new password."
      );
    } catch (err) {
      setResetError(normalizeApiError(err).message);
    } finally {
      setResetBusy(false);
    }
  }
  const resetTitle = resetStep === "email" ? "Forgot your password?" : resetStep === "otp" ? "Verify your email" : "Create a new password";
  const resetDescription = resetStep === "email" ? "Enter the email address associated with your banking account." : resetStep === "otp" ? `Enter the 6-digit verification code sent to ${resetEmail}.` : "Choose a strong new password for your banking account.";
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      AuthShell,
      {
        title: "Log In to Your Account",
        subtitle: "Access your banking account securely",
        variant: "login",
        children: /* @__PURE__ */ jsxDEV("form", { className: "auth-form", onSubmit: submit, children: [
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Email Address",
            /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
              /* @__PURE__ */ jsxDEV(Mail, {}, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                lineNumber: 303,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "email",
                  autoComplete: "email",
                  required: true,
                  value: email,
                  onChange: (e) => setEmail(e.target.value),
                  placeholder: "Enter your email"
                },
                void 0,
                false,
                {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                  lineNumber: 305,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
              lineNumber: 302,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 299,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("label", { children: [
            "Password",
            /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
              /* @__PURE__ */ jsxDEV(Lock, {}, void 0, false, {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                lineNumber: 320,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: show ? "text" : "password",
                  autoComplete: "current-password",
                  required: true,
                  value: password,
                  onChange: (e) => setPassword(e.target.value),
                  placeholder: "Enter your password"
                },
                void 0,
                false,
                {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                  lineNumber: 322,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  className: "password-toggle",
                  onClick: () => setShow((prev) => !prev),
                  "aria-label": "Toggle password visibility",
                  children: show ? /* @__PURE__ */ jsxDEV(EyeOff, {}, void 0, false, {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 337,
                    columnNumber: 25
                  }, this) : /* @__PURE__ */ jsxDEV(Eye, {}, void 0, false, {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 337,
                    columnNumber: 38
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                  lineNumber: 331,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
              lineNumber: 319,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 316,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-options", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "check-label", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: remember,
                  onChange: (e) => setRemember(e.target.checked)
                },
                void 0,
                false,
                {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                  lineNumber: 344,
                  columnNumber: 15
                },
                this
              ),
              "Remember me"
            ] }, void 0, true, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
              lineNumber: 343,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "link-button",
                onClick: openReset,
                children: "Forgot Password?"
              },
              void 0,
              false,
              {
                fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                lineNumber: 353,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 342,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "auth-submit", disabled: busy, children: busy ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "spinner" }, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
              lineNumber: 365,
              columnNumber: 17
            }, this),
            "Logging in..."
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 364,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            "Log In ",
            /* @__PURE__ */ jsxDEV(ArrowRight, {}, void 0, false, {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
              lineNumber: 370,
              columnNumber: 24
            }, this)
          ] }, void 0, true, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 369,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 362,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "auth-divider", children: /* @__PURE__ */ jsxDEV("span", { children: "Don't have an account?" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 376,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 375,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { className: "auth-secondary-submit", to: "/register", children: "Create an Account" }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 379,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
          lineNumber: 298,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
        lineNumber: 293,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Dialog,
      {
        open: resetOpen,
        onOpenChange: closeReset,
        title: resetTitle,
        description: resetDescription,
        children: [
          resetError && /* @__PURE__ */ jsxDEV("div", { className: "reset-error", role: "alert", children: resetError }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 396,
            columnNumber: 9
          }, this),
          resetMessage && /* @__PURE__ */ jsxDEV("div", { className: "reset-message", role: "status", children: resetMessage }, void 0, false, {
            fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
            lineNumber: 404,
            columnNumber: 9
          }, this),
          resetStep === "email" && /* @__PURE__ */ jsxDEV(
            "form",
            {
              className: "auth-form reset-modal-form",
              onSubmit: requestOtp,
              children: [
                /* @__PURE__ */ jsxDEV("label", { children: [
                  "Email Address",
                  /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
                    /* @__PURE__ */ jsxDEV(Mail, {}, void 0, false, {
                      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                      lineNumber: 420,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "email",
                        autoComplete: "email",
                        required: true,
                        value: resetEmail,
                        onChange: (e) => {
                          setResetEmail(e.target.value);
                          setResetError("");
                          setResetMessage("");
                        },
                        placeholder: "Enter your registered email"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                        lineNumber: 422,
                        columnNumber: 17
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 419,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                  lineNumber: 416,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    className: "auth-submit",
                    type: "submit",
                    disabled: resetBusy,
                    children: resetBusy ? "Sending code..." : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      "Send verification code ",
                      /* @__PURE__ */ jsxDEV(ArrowRight, {}, void 0, false, {
                        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                        lineNumber: 446,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                      lineNumber: 445,
                      columnNumber: 13
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 437,
                    columnNumber: 13
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
              lineNumber: 412,
              columnNumber: 9
            },
            this
          ),
          resetStep === "otp" && /* @__PURE__ */ jsxDEV(
            "form",
            {
              className: "auth-form reset-modal-form",
              onSubmit: verifyOtp,
              children: [
                /* @__PURE__ */ jsxDEV("label", { children: [
                  "6-digit verification code",
                  /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
                    /* @__PURE__ */ jsxDEV(ShieldCheck, {}, void 0, false, {
                      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                      lineNumber: 464,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        inputMode: "numeric",
                        autoComplete: "one-time-code",
                        pattern: "[0-9]{6}",
                        maxLength: 6,
                        required: true,
                        value: otp,
                        onChange: (e) => {
                          setOtp(
                            e.target.value.replace(/\D/g, "").slice(0, 6)
                          );
                          setResetError("");
                          setResetMessage("");
                        },
                        placeholder: "Enter 6-digit OTP"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                        lineNumber: 466,
                        columnNumber: 17
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 463,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                  lineNumber: 460,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    className: "auth-submit",
                    type: "submit",
                    disabled: resetBusy || otp.length !== 6,
                    children: resetBusy ? "Verifying..." : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      "Verify code ",
                      /* @__PURE__ */ jsxDEV(ArrowRight, {}, void 0, false, {
                        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                        lineNumber: 496,
                        columnNumber: 31
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                      lineNumber: 495,
                      columnNumber: 13
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 487,
                    columnNumber: 13
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "link-button",
                    disabled: resetBusy,
                    onClick: () => {
                      setResetStep("email");
                      setOtp("");
                      setResetError("");
                      setResetMessage("");
                    },
                    children: "Change email address"
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 501,
                    columnNumber: 13
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
              lineNumber: 456,
              columnNumber: 9
            },
            this
          ),
          resetStep === "password" && /* @__PURE__ */ jsxDEV(
            "form",
            {
              className: "auth-form reset-modal-form",
              onSubmit: submitNewPassword,
              children: [
                /* @__PURE__ */ jsxDEV("label", { children: [
                  "New Password",
                  /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
                    /* @__PURE__ */ jsxDEV(Lock, {}, void 0, false, {
                      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                      lineNumber: 528,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: showNewPassword ? "text" : "password",
                        autoComplete: "new-password",
                        minLength: 8,
                        maxLength: 128,
                        required: true,
                        value: newPassword,
                        onChange: (e) => {
                          setNewPassword(e.target.value);
                          setResetError("");
                        },
                        placeholder: "Enter new password"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                        lineNumber: 530,
                        columnNumber: 17
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        className: "password-toggle",
                        onClick: () => setShowNewPassword((prev) => !prev),
                        "aria-label": "Toggle new password visibility",
                        children: showNewPassword ? /* @__PURE__ */ jsxDEV(EyeOff, {}, void 0, false, {
                          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                          lineNumber: 552,
                          columnNumber: 38
                        }, this) : /* @__PURE__ */ jsxDEV(Eye, {}, void 0, false, {
                          fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                          lineNumber: 552,
                          columnNumber: 51
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                        lineNumber: 544,
                        columnNumber: 17
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 527,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                  lineNumber: 524,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV("label", { children: [
                  "Confirm New Password",
                  /* @__PURE__ */ jsxDEV("div", { className: "auth-input-wrap", children: [
                    /* @__PURE__ */ jsxDEV(KeyRound, {}, void 0, false, {
                      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                      lineNumber: 561,
                      columnNumber: 17
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: showNewPassword ? "text" : "password",
                        autoComplete: "new-password",
                        minLength: 8,
                        maxLength: 128,
                        required: true,
                        value: confirmPassword,
                        onChange: (e) => {
                          setConfirmPassword(e.target.value);
                          setResetError("");
                        },
                        placeholder: "Confirm new password"
                      },
                      void 0,
                      false,
                      {
                        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                        lineNumber: 563,
                        columnNumber: 17
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 560,
                    columnNumber: 15
                  }, this)
                ] }, void 0, true, {
                  fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                  lineNumber: 557,
                  columnNumber: 13
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    className: "auth-submit",
                    type: "submit",
                    disabled: resetBusy,
                    children: resetBusy ? "Resetting password..." : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      "Reset Password ",
                      /* @__PURE__ */ jsxDEV(ArrowRight, {}, void 0, false, {
                        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                        lineNumber: 588,
                        columnNumber: 34
                      }, this)
                    ] }, void 0, true, {
                      fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                      lineNumber: 587,
                      columnNumber: 13
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
                    lineNumber: 579,
                    columnNumber: 13
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
              lineNumber: 520,
              columnNumber: 9
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
        lineNumber: 387,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx",
    lineNumber: 290,
    columnNumber: 5
  }, this);
}
_s(LoginPage, "QGzfb73VEaGYNgijGYobTso4GGg=", false, function() {
  return [useAuth, useNavigate];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "D:/New_folder_(2)/Software development Project/banking-platfrom/frontend/banking-platform-frontend/src/features/public/pages/LoginPage.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOFNjLFNBNkRBLFVBN0RBOztBQTlTZCxTQUFTQSxnQkFBZ0M7QUFDekMsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGFBQWE7QUFFdEIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLGNBQWM7QUFJaEIsZ0JBQVNDLFlBQVk7QUFBQUMsS0FBQTtBQUMxQixRQUFNLEVBQUVDLE1BQU0sSUFBSVIsUUFBUTtBQUMxQixRQUFNUyxXQUFXbEIsWUFBWTtBQUc3QixRQUFNLENBQUNtQixPQUFPQyxRQUFRLElBQUl0QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDdUIsVUFBVUMsV0FBVyxJQUFJeEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3lCLE1BQU1DLE9BQU8sSUFBSTFCLFNBQVMsS0FBSztBQUN0QyxRQUFNLENBQUMyQixNQUFNQyxPQUFPLElBQUk1QixTQUFTLEtBQUs7QUFDdEMsUUFBTSxDQUFDNkIsVUFBVUMsV0FBVyxJQUFJOUIsU0FBUyxLQUFLO0FBRzlDLFFBQU0sQ0FBQytCLFdBQVdDLFlBQVksSUFBSWhDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNpQyxXQUFXQyxZQUFZLElBQUlsQyxTQUFvQixPQUFPO0FBRTdELFFBQU0sQ0FBQ21DLFlBQVlDLGFBQWEsSUFBSXBDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNxQyxLQUFLQyxNQUFNLElBQUl0QyxTQUFTLEVBQUU7QUFDakMsUUFBTSxDQUFDdUMsWUFBWUMsYUFBYSxJQUFJeEMsU0FBUyxFQUFFO0FBRS9DLFFBQU0sQ0FBQ3lDLGFBQWFDLGNBQWMsSUFBSTFDLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUMyQyxpQkFBaUJDLGtCQUFrQixJQUFJNUMsU0FBUyxFQUFFO0FBRXpELFFBQU0sQ0FBQzZDLGlCQUFpQkMsa0JBQWtCLElBQUk5QyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDK0MsV0FBV0MsWUFBWSxJQUFJaEQsU0FBUyxLQUFLO0FBR2hELFFBQU0sQ0FBQ2lELFlBQVlDLGFBQWEsSUFBSWxELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNtRCxjQUFjQyxlQUFlLElBQUlwRCxTQUFTLEVBQUU7QUFNbkQsaUJBQWVxRCxPQUFPQyxHQUErQjtBQUNuREEsTUFBRUMsZUFBZTtBQUVqQixRQUFJNUIsS0FBTTtBQUVWQyxZQUFRLElBQUk7QUFFWixRQUFJO0FBQ0YsWUFBTTRCLE9BQU8sTUFBTXJDLE1BQU07QUFBQSxRQUN2QkUsT0FBT0EsTUFBTW9DLEtBQUs7QUFBQSxRQUNsQmxDO0FBQUFBLE1BQ0YsQ0FBQztBQUVEYixZQUFNZ0QsUUFBUSxrQkFBa0I7QUFFaEN0QyxlQUFTTixTQUFTMEMsS0FBS0csSUFBSSxHQUFHO0FBQUEsUUFDNUJDLFNBQVM7QUFBQSxNQUNYLENBQUM7QUFBQSxJQUNILFNBQVNDLEtBQUs7QUFDWm5ELFlBQU1vRCxNQUFNakQsa0JBQWtCZ0QsR0FBRyxFQUFFRSxPQUFPO0FBQUEsSUFDNUMsVUFBQztBQUNDbkMsY0FBUSxLQUFLO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFNQSxXQUFTb0Msa0JBQWtCO0FBQ3pCOUIsaUJBQWEsT0FBTztBQUVwQkUsa0JBQWMsRUFBRTtBQUNoQkUsV0FBTyxFQUFFO0FBQ1RFLGtCQUFjLEVBQUU7QUFFaEJFLG1CQUFlLEVBQUU7QUFDakJFLHVCQUFtQixFQUFFO0FBRXJCRSx1QkFBbUIsS0FBSztBQUV4Qkksa0JBQWMsRUFBRTtBQUNoQkUsb0JBQWdCLEVBQUU7QUFFbEJKLGlCQUFhLEtBQUs7QUFBQSxFQUNwQjtBQUVBLFdBQVNpQixZQUFZO0FBQ25CRCxvQkFBZ0I7QUFHaEI1QixrQkFBY2YsTUFBTW9DLEtBQUssQ0FBQztBQUUxQnpCLGlCQUFhLElBQUk7QUFBQSxFQUNuQjtBQUVBLFdBQVNrQyxXQUFXQyxNQUFlO0FBQ2pDbkMsaUJBQWFtQyxJQUFJO0FBRWpCLFFBQUksQ0FBQ0EsTUFBTTtBQUNUSCxzQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFNQSxpQkFBZUksV0FBV2QsR0FBK0I7QUFDdkRBLE1BQUVDLGVBQWU7QUFFakIsUUFBSVIsVUFBVztBQUVmLFVBQU1zQixhQUFhbEMsV0FBV3NCLEtBQUssRUFBRWEsWUFBWTtBQUVqRCxRQUFJLENBQUNELFlBQVk7QUFDZm5CLG9CQUFjLDZDQUE2QztBQUMzRDtBQUFBLElBQ0Y7QUFFQUEsa0JBQWMsRUFBRTtBQUNoQkUsb0JBQWdCLEVBQUU7QUFDbEJKLGlCQUFhLElBQUk7QUFFakIsUUFBSTtBQUNGLFlBQU1qQyxRQUFRd0QscUJBQXFCRixVQUFVO0FBRTdDakMsb0JBQWNpQyxVQUFVO0FBQ3hCL0IsYUFBTyxFQUFFO0FBQ1RKLG1CQUFhLEtBQUs7QUFFbEJrQjtBQUFBQSxRQUNFO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBU1MsS0FBSztBQUNaWCxvQkFBY3JDLGtCQUFrQmdELEdBQUcsRUFBRUUsT0FBTztBQUFBLElBQzlDLFVBQUM7QUFDQ2YsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQU1BLGlCQUFld0IsVUFBVWxCLEdBQStCO0FBQ3REQSxNQUFFQyxlQUFlO0FBRWpCLFFBQUlSLFVBQVc7QUFFZixVQUFNMEIsV0FBV3BDLElBQUlvQixLQUFLO0FBRzFCLFFBQUksQ0FBQyxVQUFVaUIsS0FBS0QsUUFBUSxHQUFHO0FBQzdCdkIsb0JBQWMsaURBQWlEO0FBQy9EO0FBQUEsSUFDRjtBQUVBQSxrQkFBYyxFQUFFO0FBQ2hCRSxvQkFBZ0IsRUFBRTtBQUNsQkosaUJBQWEsSUFBSTtBQUVqQixRQUFJO0FBQ0YsWUFBTTJCLFNBQVMsTUFBTTVELFFBQVE2RDtBQUFBQSxRQUMzQnpDLFdBQVdzQixLQUFLO0FBQUEsUUFDaEJnQjtBQUFBQSxNQUNGO0FBRUEsVUFBSSxDQUFDRSxRQUFRcEMsWUFBWTtBQUN2QixjQUFNLElBQUlzQztBQUFBQSxVQUNSO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFHQXJDLG9CQUFjbUMsT0FBT3BDLFVBQVU7QUFHL0JMLG1CQUFhLFVBQVU7QUFFdkJJLGFBQU8sRUFBRTtBQUNUWSxvQkFBYyxFQUFFO0FBRWhCRTtBQUFBQSxRQUNFO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBU1MsS0FBSztBQUNaWCxvQkFBY3JDLGtCQUFrQmdELEdBQUcsRUFBRUUsT0FBTztBQUFBLElBQzlDLFVBQUM7QUFDQ2YsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQU1BLGlCQUFlOEIsa0JBQWtCeEIsR0FBK0I7QUFDOURBLE1BQUVDLGVBQWU7QUFFakIsUUFBSVIsVUFBVztBQUVmLFFBQUlOLFlBQVlzQyxTQUFTLEtBQUt0QyxZQUFZc0MsU0FBUyxLQUFLO0FBQ3REN0I7QUFBQUEsUUFDRTtBQUFBLE1BQ0Y7QUFDQTtBQUFBLElBQ0Y7QUFFQSxRQUFJVCxnQkFBZ0JFLGlCQUFpQjtBQUNuQ08sb0JBQWMsOEJBQThCO0FBQzVDO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQ1gsWUFBWTtBQUNmVztBQUFBQSxRQUNFO0FBQUEsTUFDRjtBQUVBaEIsbUJBQWEsT0FBTztBQUNwQkksYUFBTyxFQUFFO0FBQ1Q7QUFBQSxJQUNGO0FBRUFZLGtCQUFjLEVBQUU7QUFDaEJFLG9CQUFnQixFQUFFO0FBQ2xCSixpQkFBYSxJQUFJO0FBRWpCLFFBQUk7QUFDRixZQUFNakMsUUFBUWlFLGNBQWM7QUFBQSxRQUMxQkMsT0FBTzFDO0FBQUFBLFFBQ1BoQixVQUFVa0I7QUFBQUEsTUFDWixDQUFDO0FBR0RULG1CQUFhLEtBQUs7QUFDbEJnQyxzQkFBZ0I7QUFHaEJ4QyxrQkFBWSxFQUFFO0FBRWRkLFlBQU1nRDtBQUFBQSxRQUNKO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBU0csS0FBSztBQUNaWCxvQkFBY3JDLGtCQUFrQmdELEdBQUcsRUFBRUUsT0FBTztBQUFBLElBQzlDLFVBQUM7QUFDQ2YsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQU1BLFFBQU1rQyxhQUNKakQsY0FBYyxVQUNWLDBCQUNBQSxjQUFjLFFBQ1osc0JBQ0E7QUFFUixRQUFNa0QsbUJBQ0psRCxjQUFjLFVBQ1Ysa0VBQ0FBLGNBQWMsUUFDWiwrQ0FBK0NFLFVBQVUsTUFDekQ7QUFNUixTQUNFLG1DQUdFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLFVBQVM7QUFBQSxRQUNULFNBQVE7QUFBQSxRQUVSLGlDQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVrQixRQUNwQztBQUFBLGlDQUFDLFdBQUs7QUFBQTtBQUFBLFlBR0osdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEscUNBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFLO0FBQUEsY0FFTDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsY0FBYTtBQUFBLGtCQUNiO0FBQUEsa0JBQ0EsT0FBT2hDO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ2lDLE1BQU1oQyxTQUFTZ0MsRUFBRThCLE9BQU9DLEtBQUs7QUFBQSxrQkFDeEMsYUFBWTtBQUFBO0FBQUEsZ0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTWdDO0FBQUEsaUJBVGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUVBLHVCQUFDLFdBQUs7QUFBQTtBQUFBLFlBR0osdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEscUNBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFLO0FBQUEsY0FFTDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFNNUQsT0FBTyxTQUFTO0FBQUEsa0JBQ3RCLGNBQWE7QUFBQSxrQkFDYjtBQUFBLGtCQUNBLE9BQU9GO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQytCLE1BQU05QixZQUFZOEIsRUFBRThCLE9BQU9DLEtBQUs7QUFBQSxrQkFDM0MsYUFBWTtBQUFBO0FBQUEsZ0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTW1DO0FBQUEsY0FHbkM7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU0zRCxRQUFRLENBQUM0RCxTQUFTLENBQUNBLElBQUk7QUFBQSxrQkFDdEMsY0FBVztBQUFBLGtCQUVWN0QsaUJBQU8sdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFPLElBQU0sdUJBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFJO0FBQUE7QUFBQSxnQkFOM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxlQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGVBQ2Y7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsU0FBU0k7QUFBQUEsa0JBQ1QsVUFBVSxDQUFDeUIsTUFBTXhCLFlBQVl3QixFQUFFOEIsT0FBT0csT0FBTztBQUFBO0FBQUEsZ0JBSC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUdpRDtBQUFBO0FBQUEsaUJBSm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixTQUFTdEI7QUFBQUEsZ0JBQVU7QUFBQTtBQUFBLGNBSHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUVBLHVCQUFDLFlBQU8sV0FBVSxlQUFjLFVBQVV0QyxNQUN2Q0EsaUJBQ0MsbUNBQ0U7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQTtBQUFBLGVBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0EsSUFFQTtBQUFBO0FBQUEsWUFDUyx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFXO0FBQUEsZUFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxnQkFDYixpQ0FBQyxVQUFLLHNDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFFBQUssV0FBVSx5QkFBd0IsSUFBRyxhQUFXLGlDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFuRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9GQTtBQUFBO0FBQUEsTUF6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBMEZBO0FBQUEsSUFJQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTUk7QUFBQUEsUUFDTixjQUFjbUM7QUFBQUEsUUFDZCxPQUFPZ0I7QUFBQUEsUUFDUCxhQUFhQztBQUFBQSxRQUlabEM7QUFBQUEsd0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGVBQWMsTUFBSyxTQUMvQkEsd0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBS0RFLGdCQUNDLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsTUFBSyxVQUNqQ0EsMEJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBS0RsQixjQUFjLFdBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFVBQVVtQztBQUFBQSxjQUVWO0FBQUEsdUNBQUMsV0FBSztBQUFBO0FBQUEsa0JBR0osdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsMkNBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFLO0FBQUEsb0JBRUw7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLGNBQWE7QUFBQSx3QkFDYjtBQUFBLHdCQUNBLE9BQU9qQztBQUFBQSx3QkFDUCxVQUFVLENBQUNtQixNQUFNO0FBQ2ZsQix3Q0FBY2tCLEVBQUU4QixPQUFPQyxLQUFLO0FBQzVCbkMsd0NBQWMsRUFBRTtBQUNoQkUsMENBQWdCLEVBQUU7QUFBQSx3QkFDcEI7QUFBQSx3QkFDQSxhQUFZO0FBQUE7QUFBQSxzQkFWZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBVTJDO0FBQUEsdUJBYjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxxQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLFVBQVVMO0FBQUFBLG9CQUVUQSxzQkFDQyxvQkFFQTtBQUFBO0FBQUEsc0JBQ3lCLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQVc7QUFBQSx5QkFEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUEsa0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUE7QUFBQTtBQUFBLFlBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXNDQTtBQUFBLFVBS0RkLGNBQWMsU0FDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsVUFBVXVDO0FBQUFBLGNBRVY7QUFBQSx1Q0FBQyxXQUFLO0FBQUE7QUFBQSxrQkFHSix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwyQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFZO0FBQUEsb0JBRVo7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixjQUFhO0FBQUEsd0JBQ2IsU0FBUTtBQUFBLHdCQUNSLFdBQVc7QUFBQSx3QkFDWDtBQUFBLHdCQUNBLE9BQU9uQztBQUFBQSx3QkFDUCxVQUFVLENBQUNpQixNQUFNO0FBQ2ZoQjtBQUFBQSw0QkFDRWdCLEVBQUU4QixPQUFPQyxNQUFNekIsUUFBUSxPQUFPLEVBQUUsRUFBRTRCLE1BQU0sR0FBRyxDQUFDO0FBQUEsMEJBQzlDO0FBRUF0Qyx3Q0FBYyxFQUFFO0FBQ2hCRSwwQ0FBZ0IsRUFBRTtBQUFBLHdCQUNwQjtBQUFBLHdCQUNBLGFBQVk7QUFBQTtBQUFBLHNCQWhCZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBZ0JpQztBQUFBLHVCQW5CbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFxQkE7QUFBQSxxQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5QkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLFVBQVVMLGFBQWFWLElBQUkwQyxXQUFXO0FBQUEsb0JBRXJDaEMsc0JBQ0MsaUJBRUE7QUFBQTtBQUFBLHNCQUNjLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQVc7QUFBQSx5QkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUEsa0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixVQUFVQTtBQUFBQSxvQkFDVixTQUFTLE1BQU07QUFDYmIsbUNBQWEsT0FBTztBQUNwQkksNkJBQU8sRUFBRTtBQUNUWSxvQ0FBYyxFQUFFO0FBQ2hCRSxzQ0FBZ0IsRUFBRTtBQUFBLG9CQUNwQjtBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWUE7QUFBQTtBQUFBO0FBQUEsWUF6REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBMERBO0FBQUEsVUFLRG5CLGNBQWMsY0FDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsVUFBVTZDO0FBQUFBLGNBRVY7QUFBQSx1Q0FBQyxXQUFLO0FBQUE7QUFBQSxrQkFHSix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwyQ0FBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQUs7QUFBQSxvQkFFTDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFNakMsa0JBQWtCLFNBQVM7QUFBQSx3QkFDakMsY0FBYTtBQUFBLHdCQUNiLFdBQVc7QUFBQSx3QkFDWCxXQUFXO0FBQUEsd0JBQ1g7QUFBQSx3QkFDQSxPQUFPSjtBQUFBQSx3QkFDUCxVQUFVLENBQUNhLE1BQU07QUFDZloseUNBQWVZLEVBQUU4QixPQUFPQyxLQUFLO0FBQzdCbkMsd0NBQWMsRUFBRTtBQUFBLHdCQUNsQjtBQUFBLHdCQUNBLGFBQVk7QUFBQTtBQUFBLHNCQVhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXa0M7QUFBQSxvQkFHbEM7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQ1BKLG1CQUFtQixDQUFDd0MsU0FBUyxDQUFDQSxJQUFJO0FBQUEsd0JBRXBDLGNBQVc7QUFBQSx3QkFFVnpDLDRCQUFrQix1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQU8sSUFBTSx1QkFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQUk7QUFBQTtBQUFBLHNCQVJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBU0E7QUFBQSx1QkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEyQkE7QUFBQSxxQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkErQkE7QUFBQSxnQkFFQSx1QkFBQyxXQUFLO0FBQUE7QUFBQSxrQkFHSix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwyQ0FBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVM7QUFBQSxvQkFFVDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFNQSxrQkFBa0IsU0FBUztBQUFBLHdCQUNqQyxjQUFhO0FBQUEsd0JBQ2IsV0FBVztBQUFBLHdCQUNYLFdBQVc7QUFBQSx3QkFDWDtBQUFBLHdCQUNBLE9BQU9GO0FBQUFBLHdCQUNQLFVBQVUsQ0FBQ1csTUFBTTtBQUNmViw2Q0FBbUJVLEVBQUU4QixPQUFPQyxLQUFLO0FBQ2pDbkMsd0NBQWMsRUFBRTtBQUFBLHdCQUNsQjtBQUFBLHdCQUNBLGFBQVk7QUFBQTtBQUFBLHNCQVhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXb0M7QUFBQSx1QkFkdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFnQkE7QUFBQSxxQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFvQkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLFVBQVVIO0FBQUFBLG9CQUVUQSxzQkFDQywwQkFFQTtBQUFBO0FBQUEsc0JBQ2lCLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQVc7QUFBQSx5QkFENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUEsa0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVlBO0FBQUE7QUFBQTtBQUFBLFlBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXdFQTtBQUFBO0FBQUE7QUFBQSxNQTdNSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUErTUE7QUFBQSxPQWhURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaVRBO0FBRUo7QUFBQzdCLEdBOWpCZUQsV0FBUztBQUFBLFVBQ0xOLFNBQ0RULFdBQVc7QUFBQTtBQUFBLEtBRmRlO0FBQVMsSUFBQXdFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwiRXllIiwiRXllT2ZmIiwiTWFpbCIsIkxvY2siLCJBcnJvd1JpZ2h0IiwiS2V5Um91bmQiLCJTaGllbGRDaGVjayIsInRvYXN0IiwidXNlQXV0aCIsIkF1dGhTaGVsbCIsIm5vcm1hbGl6ZUFwaUVycm9yIiwicm9sZUhvbWUiLCJhdXRoQXBpIiwiRGlhbG9nIiwiTG9naW5QYWdlIiwiX3MiLCJsb2dpbiIsIm5hdmlnYXRlIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJzaG93Iiwic2V0U2hvdyIsImJ1c3kiLCJzZXRCdXN5IiwicmVtZW1iZXIiLCJzZXRSZW1lbWJlciIsInJlc2V0T3BlbiIsInNldFJlc2V0T3BlbiIsInJlc2V0U3RlcCIsInNldFJlc2V0U3RlcCIsInJlc2V0RW1haWwiLCJzZXRSZXNldEVtYWlsIiwib3RwIiwic2V0T3RwIiwicmVzZXRUb2tlbiIsInNldFJlc2V0VG9rZW4iLCJuZXdQYXNzd29yZCIsInNldE5ld1Bhc3N3b3JkIiwiY29uZmlybVBhc3N3b3JkIiwic2V0Q29uZmlybVBhc3N3b3JkIiwic2hvd05ld1Bhc3N3b3JkIiwic2V0U2hvd05ld1Bhc3N3b3JkIiwicmVzZXRCdXN5Iiwic2V0UmVzZXRCdXN5IiwicmVzZXRFcnJvciIsInNldFJlc2V0RXJyb3IiLCJyZXNldE1lc3NhZ2UiLCJzZXRSZXNldE1lc3NhZ2UiLCJzdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ1c2VyIiwidHJpbSIsInN1Y2Nlc3MiLCJyb2xlIiwicmVwbGFjZSIsImVyciIsImVycm9yIiwibWVzc2FnZSIsImNsZWFyUmVzZXRTdGF0ZSIsIm9wZW5SZXNldCIsImNsb3NlUmVzZXQiLCJvcGVuIiwicmVxdWVzdE90cCIsImNsZWFuRW1haWwiLCJ0b0xvd2VyQ2FzZSIsInJlcXVlc3RQYXNzd29yZFJlc2V0IiwidmVyaWZ5T3RwIiwiY2xlYW5PdHAiLCJ0ZXN0IiwicmVzdWx0IiwidmVyaWZ5UGFzc3dvcmRSZXNldE90cCIsIkVycm9yIiwic3VibWl0TmV3UGFzc3dvcmQiLCJsZW5ndGgiLCJyZXNldFBhc3N3b3JkIiwidG9rZW4iLCJyZXNldFRpdGxlIiwicmVzZXREZXNjcmlwdGlvbiIsInRhcmdldCIsInZhbHVlIiwicHJldiIsImNoZWNrZWQiLCJzbGljZSIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxvZ2luUGFnZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQge1xuICBFeWUsXG4gIEV5ZU9mZixcbiAgTWFpbCxcbiAgTG9jayxcbiAgQXJyb3dSaWdodCxcbiAgS2V5Um91bmQsXG4gIFNoaWVsZENoZWNrLFxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCJzb25uZXJcIjtcblxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi8uLi8uLi9hcHAvcHJvdmlkZXJzL0F1dGhQcm92aWRlclwiO1xuaW1wb3J0IHsgQXV0aFNoZWxsIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQXV0aFNoZWxsXCI7XG5pbXBvcnQgeyBub3JtYWxpemVBcGlFcnJvciB9IGZyb20gXCIuLi8uLi8uLi9saWIvYXBpL2FwaUVycm9yXCI7XG5pbXBvcnQgeyByb2xlSG9tZSB9IGZyb20gXCIuLi8uLi8uLi9hcHAvcm91dGVyL1JvbGVSb3V0ZXNcIjtcbmltcG9ydCB7IGF1dGhBcGkgfSBmcm9tIFwiLi4vLi4vYXV0aC9hdXRoQXBpXCI7XG5pbXBvcnQgeyBEaWFsb2cgfSBmcm9tIFwiLi4vLi4vLi4vY29tcG9uZW50cy91aS9EaWFsb2dcIjtcblxudHlwZSBSZXNldFN0ZXAgPSBcImVtYWlsXCIgfCBcIm90cFwiIHwgXCJwYXNzd29yZFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gTG9naW5QYWdlKCkge1xuICBjb25zdCB7IGxvZ2luIH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICAvLyBMb2dpbiBzdGF0ZVxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbc2hvdywgc2V0U2hvd10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtidXN5LCBzZXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3JlbWVtYmVyLCBzZXRSZW1lbWJlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gUGFzc3dvcmQgcmVzZXQgc3RhdGVcbiAgY29uc3QgW3Jlc2V0T3Blbiwgc2V0UmVzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Jlc2V0U3RlcCwgc2V0UmVzZXRTdGVwXSA9IHVzZVN0YXRlPFJlc2V0U3RlcD4oXCJlbWFpbFwiKTtcblxuICBjb25zdCBbcmVzZXRFbWFpbCwgc2V0UmVzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW290cCwgc2V0T3RwXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcmVzZXRUb2tlbiwgc2V0UmVzZXRUb2tlbl0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBbbmV3UGFzc3dvcmQsIHNldE5ld1Bhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbY29uZmlybVBhc3N3b3JkLCBzZXRDb25maXJtUGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XG5cbiAgY29uc3QgW3Nob3dOZXdQYXNzd29yZCwgc2V0U2hvd05ld1Bhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Jlc2V0QnVzeSwgc2V0UmVzZXRCdXN5XSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBNb2RhbCBtZXNzYWdlczogZXJyb3JzIGFuZCBzdWNjZXNzIG1lc3NhZ2VzIHN0YXkgaW5zaWRlIHRoZSBtb2RhbC5cbiAgY29uc3QgW3Jlc2V0RXJyb3IsIHNldFJlc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XG4gIGNvbnN0IFtyZXNldE1lc3NhZ2UsIHNldFJlc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBMT0dJTlxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdChlOiBGb3JtRXZlbnQ8SFRNTEZvcm1FbGVtZW50Pikge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcblxuICAgIGlmIChidXN5KSByZXR1cm47XG5cbiAgICBzZXRCdXN5KHRydWUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpbih7XG4gICAgICAgIGVtYWlsOiBlbWFpbC50cmltKCksXG4gICAgICAgIHBhc3N3b3JkLFxuICAgICAgfSk7XG5cbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJMb2dpbiBzdWNjZXNzZnVsXCIpO1xuXG4gICAgICBuYXZpZ2F0ZShyb2xlSG9tZSh1c2VyLnJvbGUpLCB7XG4gICAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRvYXN0LmVycm9yKG5vcm1hbGl6ZUFwaUVycm9yKGVycikubWVzc2FnZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEJ1c3koZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFBBU1NXT1JEIFJFU0VUOiBPUEVOIC8gQ0xPU0UgTU9EQUxcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICBmdW5jdGlvbiBjbGVhclJlc2V0U3RhdGUoKSB7XG4gICAgc2V0UmVzZXRTdGVwKFwiZW1haWxcIik7XG5cbiAgICBzZXRSZXNldEVtYWlsKFwiXCIpO1xuICAgIHNldE90cChcIlwiKTtcbiAgICBzZXRSZXNldFRva2VuKFwiXCIpO1xuXG4gICAgc2V0TmV3UGFzc3dvcmQoXCJcIik7XG4gICAgc2V0Q29uZmlybVBhc3N3b3JkKFwiXCIpO1xuXG4gICAgc2V0U2hvd05ld1Bhc3N3b3JkKGZhbHNlKTtcblxuICAgIHNldFJlc2V0RXJyb3IoXCJcIik7XG4gICAgc2V0UmVzZXRNZXNzYWdlKFwiXCIpO1xuXG4gICAgc2V0UmVzZXRCdXN5KGZhbHNlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9wZW5SZXNldCgpIHtcbiAgICBjbGVhclJlc2V0U3RhdGUoKTtcblxuICAgIC8vIFVzZSB0aGUgZW1haWwgYWxyZWFkeSBlbnRlcmVkIGluIHRoZSBsb2dpbiBmb3JtLlxuICAgIHNldFJlc2V0RW1haWwoZW1haWwudHJpbSgpKTtcblxuICAgIHNldFJlc2V0T3Blbih0cnVlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNsb3NlUmVzZXQob3BlbjogYm9vbGVhbikge1xuICAgIHNldFJlc2V0T3BlbihvcGVuKTtcblxuICAgIGlmICghb3Blbikge1xuICAgICAgY2xlYXJSZXNldFN0YXRlKCk7XG4gICAgfVxuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gU1RFUCAxOiBSRVFVRVNUIFBBU1NXT1JEIFJFU0VUIE9UUFxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHJlcXVlc3RPdHAoZTogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICBpZiAocmVzZXRCdXN5KSByZXR1cm47XG5cbiAgICBjb25zdCBjbGVhbkVtYWlsID0gcmVzZXRFbWFpbC50cmltKCkudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICghY2xlYW5FbWFpbCkge1xuICAgICAgc2V0UmVzZXRFcnJvcihcIlBsZWFzZSBlbnRlciB5b3VyIHJlZ2lzdGVyZWQgZW1haWwgYWRkcmVzcy5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0UmVzZXRFcnJvcihcIlwiKTtcbiAgICBzZXRSZXNldE1lc3NhZ2UoXCJcIik7XG4gICAgc2V0UmVzZXRCdXN5KHRydWUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGF1dGhBcGkucmVxdWVzdFBhc3N3b3JkUmVzZXQoY2xlYW5FbWFpbCk7XG5cbiAgICAgIHNldFJlc2V0RW1haWwoY2xlYW5FbWFpbCk7XG4gICAgICBzZXRPdHAoXCJcIik7XG4gICAgICBzZXRSZXNldFN0ZXAoXCJvdHBcIik7XG5cbiAgICAgIHNldFJlc2V0TWVzc2FnZShcbiAgICAgICAgXCJJZiBhbiBlbGlnaWJsZSBhY2NvdW50IGV4aXN0cyBmb3IgdGhpcyBlbWFpbCwgYSB2ZXJpZmljYXRpb24gY29kZSBoYXMgYmVlbiBzZW50LlwiXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0UmVzZXRFcnJvcihub3JtYWxpemVBcGlFcnJvcihlcnIpLm1lc3NhZ2UpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRSZXNldEJ1c3koZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFNURVAgMjogVkVSSUZZIE9UUFxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHZlcmlmeU90cChlOiBGb3JtRXZlbnQ8SFRNTEZvcm1FbGVtZW50Pikge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcblxuICAgIGlmIChyZXNldEJ1c3kpIHJldHVybjtcblxuICAgIGNvbnN0IGNsZWFuT3RwID0gb3RwLnRyaW0oKTtcblxuICAgIC8vIE9UUCBtdXN0IGNvbnRhaW4gZXhhY3RseSBzaXggbnVtZXJpYyBkaWdpdHMuXG4gICAgaWYgKCEvXlxcZHs2fSQvLnRlc3QoY2xlYW5PdHApKSB7XG4gICAgICBzZXRSZXNldEVycm9yKFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgNi1kaWdpdCB2ZXJpZmljYXRpb24gY29kZS5cIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0UmVzZXRFcnJvcihcIlwiKTtcbiAgICBzZXRSZXNldE1lc3NhZ2UoXCJcIik7XG4gICAgc2V0UmVzZXRCdXN5KHRydWUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGF1dGhBcGkudmVyaWZ5UGFzc3dvcmRSZXNldE90cChcbiAgICAgICAgcmVzZXRFbWFpbC50cmltKCksXG4gICAgICAgIGNsZWFuT3RwXG4gICAgICApO1xuXG4gICAgICBpZiAoIXJlc3VsdD8ucmVzZXRUb2tlbikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgXCJUaGUgdmVyaWZpY2F0aW9uIHJlc3BvbnNlIGRpZCBub3QgY29udGFpbiBhIHJlc2V0IHRva2VuLiBQbGVhc2UgdHJ5IGFnYWluLlwiXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIC8vIEtlZXAgdGhlIHNlbnNpdGl2ZSByZXNldCB0b2tlbiBpbiBjb21wb25lbnQgbWVtb3J5IG9ubHkuXG4gICAgICBzZXRSZXNldFRva2VuKHJlc3VsdC5yZXNldFRva2VuKTtcblxuICAgICAgLy8gTW92ZSB0byB0aGUgbmV3IHBhc3N3b3JkIHNjcmVlbiBvbmx5IGFmdGVyIHN1Y2Nlc3NmdWwgdmVyaWZpY2F0aW9uLlxuICAgICAgc2V0UmVzZXRTdGVwKFwicGFzc3dvcmRcIik7XG5cbiAgICAgIHNldE90cChcIlwiKTtcbiAgICAgIHNldFJlc2V0RXJyb3IoXCJcIik7XG5cbiAgICAgIHNldFJlc2V0TWVzc2FnZShcbiAgICAgICAgXCJZb3VyIGVtYWlsIGhhcyBiZWVuIHZlcmlmaWVkLiBZb3UgY2FuIG5vdyBjcmVhdGUgYSBuZXcgcGFzc3dvcmQuXCJcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRSZXNldEVycm9yKG5vcm1hbGl6ZUFwaUVycm9yKGVycikubWVzc2FnZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldFJlc2V0QnVzeShmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gU1RFUCAzOiBSRVNFVCBQQVNTV09SRFxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdE5ld1Bhc3N3b3JkKGU6IEZvcm1FdmVudDxIVE1MRm9ybUVsZW1lbnQ+KSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgaWYgKHJlc2V0QnVzeSkgcmV0dXJuO1xuXG4gICAgaWYgKG5ld1Bhc3N3b3JkLmxlbmd0aCA8IDggfHwgbmV3UGFzc3dvcmQubGVuZ3RoID4gMTI4KSB7XG4gICAgICBzZXRSZXNldEVycm9yKFxuICAgICAgICBcIlBhc3N3b3JkIG11c3QgY29udGFpbiBiZXR3ZWVuIDggYW5kIDEyOCBjaGFyYWN0ZXJzLlwiXG4gICAgICApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChuZXdQYXNzd29yZCAhPT0gY29uZmlybVBhc3N3b3JkKSB7XG4gICAgICBzZXRSZXNldEVycm9yKFwiWW91ciBwYXNzd29yZHMgZG8gbm90IG1hdGNoLlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIXJlc2V0VG9rZW4pIHtcbiAgICAgIHNldFJlc2V0RXJyb3IoXG4gICAgICAgIFwiWW91ciBwYXNzd29yZCByZXNldCBzZXNzaW9uIGhhcyBleHBpcmVkLiBQbGVhc2UgcmVxdWVzdCBhIG5ldyB2ZXJpZmljYXRpb24gY29kZS5cIlxuICAgICAgKTtcblxuICAgICAgc2V0UmVzZXRTdGVwKFwiZW1haWxcIik7XG4gICAgICBzZXRPdHAoXCJcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0UmVzZXRFcnJvcihcIlwiKTtcbiAgICBzZXRSZXNldE1lc3NhZ2UoXCJcIik7XG4gICAgc2V0UmVzZXRCdXN5KHRydWUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGF1dGhBcGkucmVzZXRQYXNzd29yZCh7XG4gICAgICAgIHRva2VuOiByZXNldFRva2VuLFxuICAgICAgICBwYXNzd29yZDogbmV3UGFzc3dvcmQsXG4gICAgICB9KTtcblxuICAgICAgLy8gQ2xvc2UgbW9kYWwgYW5kIHJlbW92ZSB0ZW1wb3JhcnkgcmVzZXQgaW5mb3JtYXRpb24uXG4gICAgICBzZXRSZXNldE9wZW4oZmFsc2UpO1xuICAgICAgY2xlYXJSZXNldFN0YXRlKCk7XG5cbiAgICAgIC8vIENsZWFyIGxvZ2luIHBhc3N3b3JkIHNvIHRoZSB1c2VyIGNhbiBlbnRlciB0aGUgbmV3IHBhc3N3b3JkLlxuICAgICAgc2V0UGFzc3dvcmQoXCJcIik7XG5cbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXG4gICAgICAgIFwiUGFzc3dvcmQgcmVzZXQgc3VjY2Vzc2Z1bC4gUGxlYXNlIHNpZ24gaW4gd2l0aCB5b3VyIG5ldyBwYXNzd29yZC5cIlxuICAgICAgKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldFJlc2V0RXJyb3Iobm9ybWFsaXplQXBpRXJyb3IoZXJyKS5tZXNzYWdlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0UmVzZXRCdXN5KGZhbHNlKTtcbiAgICB9XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBNT0RBTCBUSVRMRSBBTkQgREVTQ1JJUFRJT05cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICBjb25zdCByZXNldFRpdGxlID1cbiAgICByZXNldFN0ZXAgPT09IFwiZW1haWxcIlxuICAgICAgPyBcIkZvcmdvdCB5b3VyIHBhc3N3b3JkP1wiXG4gICAgICA6IHJlc2V0U3RlcCA9PT0gXCJvdHBcIlxuICAgICAgICA/IFwiVmVyaWZ5IHlvdXIgZW1haWxcIlxuICAgICAgICA6IFwiQ3JlYXRlIGEgbmV3IHBhc3N3b3JkXCI7XG5cbiAgY29uc3QgcmVzZXREZXNjcmlwdGlvbiA9XG4gICAgcmVzZXRTdGVwID09PSBcImVtYWlsXCJcbiAgICAgID8gXCJFbnRlciB0aGUgZW1haWwgYWRkcmVzcyBhc3NvY2lhdGVkIHdpdGggeW91ciBiYW5raW5nIGFjY291bnQuXCJcbiAgICAgIDogcmVzZXRTdGVwID09PSBcIm90cFwiXG4gICAgICAgID8gYEVudGVyIHRoZSA2LWRpZ2l0IHZlcmlmaWNhdGlvbiBjb2RlIHNlbnQgdG8gJHtyZXNldEVtYWlsfS5gXG4gICAgICAgIDogXCJDaG9vc2UgYSBzdHJvbmcgbmV3IHBhc3N3b3JkIGZvciB5b3VyIGJhbmtpbmcgYWNjb3VudC5cIjtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBSRU5ERVJcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICB7LyogTE9HSU4gUEFHRSAqL31cblxuICAgICAgPEF1dGhTaGVsbFxuICAgICAgICB0aXRsZT1cIkxvZyBJbiB0byBZb3VyIEFjY291bnRcIlxuICAgICAgICBzdWJ0aXRsZT1cIkFjY2VzcyB5b3VyIGJhbmtpbmcgYWNjb3VudCBzZWN1cmVseVwiXG4gICAgICAgIHZhcmlhbnQ9XCJsb2dpblwiXG4gICAgICA+XG4gICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImF1dGgtZm9ybVwiIG9uU3VibWl0PXtzdWJtaXR9PlxuICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgIEVtYWlsIEFkZHJlc3NcblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWlucHV0LXdyYXBcIj5cbiAgICAgICAgICAgICAgPE1haWwgLz5cblxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgZW1haWxcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgIFBhc3N3b3JkXG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1pbnB1dC13cmFwXCI+XG4gICAgICAgICAgICAgIDxMb2NrIC8+XG5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT17c2hvdyA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifVxuICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImN1cnJlbnQtcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgeW91ciBwYXNzd29yZFwiXG4gICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBhc3N3b3JkLXRvZ2dsZVwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvdygocHJldikgPT4gIXByZXYpfVxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJUb2dnbGUgcGFzc3dvcmQgdmlzaWJpbGl0eVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7c2hvdyA/IDxFeWVPZmYgLz4gOiA8RXllIC8+fVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tb3B0aW9uc1wiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImNoZWNrLWxhYmVsXCI+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17cmVtZW1iZXJ9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZW1lbWJlcihlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICBSZW1lbWJlciBtZVxuICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibGluay1idXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtvcGVuUmVzZXR9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEZvcmdvdCBQYXNzd29yZD9cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdXRoLXN1Ym1pdFwiIGRpc2FibGVkPXtidXN5fT5cbiAgICAgICAgICAgIHtidXN5ID8gKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInNwaW5uZXJcIiAvPlxuICAgICAgICAgICAgICAgIExvZ2dpbmcgaW4uLi5cbiAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIExvZyBJbiA8QXJyb3dSaWdodCAvPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtZGl2aWRlclwiPlxuICAgICAgICAgICAgPHNwYW4+RG9uJ3QgaGF2ZSBhbiBhY2NvdW50Pzwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImF1dGgtc2Vjb25kYXJ5LXN1Ym1pdFwiIHRvPVwiL3JlZ2lzdGVyXCI+XG4gICAgICAgICAgICBDcmVhdGUgYW4gQWNjb3VudFxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9BdXRoU2hlbGw+XG5cbiAgICAgIHsvKiBGT1JHT1QgUEFTU1dPUkQgRElBTE9HICovfVxuXG4gICAgICA8RGlhbG9nXG4gICAgICAgIG9wZW49e3Jlc2V0T3Blbn1cbiAgICAgICAgb25PcGVuQ2hhbmdlPXtjbG9zZVJlc2V0fVxuICAgICAgICB0aXRsZT17cmVzZXRUaXRsZX1cbiAgICAgICAgZGVzY3JpcHRpb249e3Jlc2V0RGVzY3JpcHRpb259XG4gICAgICA+XG4gICAgICAgIHsvKiBJTkxJTkUgRVJST1IgTUVTU0FHRSAqL31cblxuICAgICAgICB7cmVzZXRFcnJvciAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZXNldC1lcnJvclwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAge3Jlc2V0RXJyb3J9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIElOTElORSBTVUNDRVNTIC8gSU5GT1JNQVRJT04gTUVTU0FHRSAqL31cblxuICAgICAgICB7cmVzZXRNZXNzYWdlICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlc2V0LW1lc3NhZ2VcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICB7cmVzZXRNZXNzYWdlfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBTVEVQIDE6IEVNQUlMICovfVxuXG4gICAgICAgIHtyZXNldFN0ZXAgPT09IFwiZW1haWxcIiAmJiAoXG4gICAgICAgICAgPGZvcm1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtZm9ybSByZXNldC1tb2RhbC1mb3JtXCJcbiAgICAgICAgICAgIG9uU3VibWl0PXtyZXF1ZXN0T3RwfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgICAgRW1haWwgQWRkcmVzc1xuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1pbnB1dC13cmFwXCI+XG4gICAgICAgICAgICAgICAgPE1haWwgLz5cblxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cmVzZXRFbWFpbH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRSZXNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0UmVzZXRFcnJvcihcIlwiKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0UmVzZXRNZXNzYWdlKFwiXCIpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgeW91ciByZWdpc3RlcmVkIGVtYWlsXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zdWJtaXRcIlxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Jlc2V0QnVzeX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3Jlc2V0QnVzeSA/IChcbiAgICAgICAgICAgICAgICBcIlNlbmRpbmcgY29kZS4uLlwiXG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIFNlbmQgdmVyaWZpY2F0aW9uIGNvZGUgPEFycm93UmlnaHQgLz5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogU1RFUCAyOiBPVFAgVkVSSUZJQ0FUSU9OICovfVxuXG4gICAgICAgIHtyZXNldFN0ZXAgPT09IFwib3RwXCIgJiYgKFxuICAgICAgICAgIDxmb3JtXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhdXRoLWZvcm0gcmVzZXQtbW9kYWwtZm9ybVwiXG4gICAgICAgICAgICBvblN1Ym1pdD17dmVyaWZ5T3RwfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxsYWJlbD5cbiAgICAgICAgICAgICAgNi1kaWdpdCB2ZXJpZmljYXRpb24gY29kZVxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1pbnB1dC13cmFwXCI+XG4gICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIC8+XG5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cIm51bWVyaWNcIlxuICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib25lLXRpbWUtY29kZVwiXG4gICAgICAgICAgICAgICAgICBwYXR0ZXJuPVwiWzAtOV17Nn1cIlxuICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs2fVxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtvdHB9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0T3RwKFxuICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlLnJlcGxhY2UoL1xcRC9nLCBcIlwiKS5zbGljZSgwLCA2KVxuICAgICAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgICAgIHNldFJlc2V0RXJyb3IoXCJcIik7XG4gICAgICAgICAgICAgICAgICAgIHNldFJlc2V0TWVzc2FnZShcIlwiKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIDYtZGlnaXQgT1RQXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zdWJtaXRcIlxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Jlc2V0QnVzeSB8fCBvdHAubGVuZ3RoICE9PSA2fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cmVzZXRCdXN5ID8gKFxuICAgICAgICAgICAgICAgIFwiVmVyaWZ5aW5nLi4uXCJcbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgVmVyaWZ5IGNvZGUgPEFycm93UmlnaHQgLz5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJsaW5rLWJ1dHRvblwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtyZXNldEJ1c3l9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRSZXNldFN0ZXAoXCJlbWFpbFwiKTtcbiAgICAgICAgICAgICAgICBzZXRPdHAoXCJcIik7XG4gICAgICAgICAgICAgICAgc2V0UmVzZXRFcnJvcihcIlwiKTtcbiAgICAgICAgICAgICAgICBzZXRSZXNldE1lc3NhZ2UoXCJcIik7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIENoYW5nZSBlbWFpbCBhZGRyZXNzXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFNURVAgMzogTkVXIFBBU1NXT1JEICovfVxuXG4gICAgICAgIHtyZXNldFN0ZXAgPT09IFwicGFzc3dvcmRcIiAmJiAoXG4gICAgICAgICAgPGZvcm1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImF1dGgtZm9ybSByZXNldC1tb2RhbC1mb3JtXCJcbiAgICAgICAgICAgIG9uU3VibWl0PXtzdWJtaXROZXdQYXNzd29yZH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8bGFiZWw+XG4gICAgICAgICAgICAgIE5ldyBQYXNzd29yZFxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1pbnB1dC13cmFwXCI+XG4gICAgICAgICAgICAgICAgPExvY2sgLz5cblxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT17c2hvd05ld1Bhc3N3b3JkID8gXCJ0ZXh0XCIgOiBcInBhc3N3b3JkXCJ9XG4gICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgbWluTGVuZ3RoPXs4fVxuICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsxMjh9XG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldE5ld1Bhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0UmVzZXRFcnJvcihcIlwiKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIG5ldyBwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicGFzc3dvcmQtdG9nZ2xlXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dOZXdQYXNzd29yZCgocHJldikgPT4gIXByZXYpXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiVG9nZ2xlIG5ldyBwYXNzd29yZCB2aXNpYmlsaXR5XCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7c2hvd05ld1Bhc3N3b3JkID8gPEV5ZU9mZiAvPiA6IDxFeWUgLz59XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgPGxhYmVsPlxuICAgICAgICAgICAgICBDb25maXJtIE5ldyBQYXNzd29yZFxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1pbnB1dC13cmFwXCI+XG4gICAgICAgICAgICAgICAgPEtleVJvdW5kIC8+XG5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dOZXdQYXNzd29yZCA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifVxuICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIG1pbkxlbmd0aD17OH1cbiAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17MTI4fVxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtUGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q29uZmlybVBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0UmVzZXRFcnJvcihcIlwiKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNvbmZpcm0gbmV3IHBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYXV0aC1zdWJtaXRcIlxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Jlc2V0QnVzeX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3Jlc2V0QnVzeSA/IChcbiAgICAgICAgICAgICAgICBcIlJlc2V0dGluZyBwYXNzd29yZC4uLlwiXG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgIFJlc2V0IFBhc3N3b3JkIDxBcnJvd1JpZ2h0IC8+XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICl9XG4gICAgICA8L0RpYWxvZz5cbiAgICA8Lz5cbiAgKTtcbn0iXSwiZmlsZSI6IkQ6L05ld19mb2xkZXJfKDIpL1NvZnR3YXJlIGRldmVsb3BtZW50IFByb2plY3QvYmFua2luZy1wbGF0ZnJvbS9mcm9udGVuZC9iYW5raW5nLXBsYXRmb3JtLWZyb250ZW5kL3NyYy9mZWF0dXJlcy9wdWJsaWMvcGFnZXMvTG9naW5QYWdlLnRzeCJ9